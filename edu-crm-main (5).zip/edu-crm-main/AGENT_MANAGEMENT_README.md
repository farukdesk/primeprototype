# Agent Management CRUD Implementation

## Overview
This document describes the implementation of full CRUD (Create, Read, Update, Delete) functionality for Agent Management in the EDU-CRM system.

## Features Implemented

### 1. Agent Information Fields
- **Agent Name** (required)
- **Email** (required)
- **Phone Number**
- **Address**
- **Notes**
- **Our Student** (Yes/No checkbox)
  - When "Yes" is selected, the following fields are enabled:
    - **Student ID**
    - **Batch**
    - **Department**

### 2. CRUD Operations
- **Create**: Add new agents with all required information
- **Read**: View list of all agents and individual agent details
- **Update**: Edit existing agent information
- **Delete**: Remove agents (with validation to prevent deletion if agent has associated leads)

### 3. Security & Permissions
- Access restricted to **Admin** and **Super Admin** users only
- All database operations use prepared statements to prevent SQL injection
- XSS protection through htmlspecialchars on all outputs
- Transaction support for data integrity
- Validation to prevent duplicate emails

## Files Created/Modified

### New Files Created:

1. **database_agent_management.sql**
   - Database migration script to create the `agents` table
   - Location: `/home/runner/work/edu-crm/edu-crm/database_agent_management.sql`

2. **app/models/agent_model.php**
   - Model class handling all database operations for agents
   - Methods: getAllAgents(), getAgentById(), createAgent(), updateAgent(), deleteAgent()
   - Location: `/home/runner/work/edu-crm/edu-crm/app/models/agent_model.php`

3. **app/controllers/agent_management_controller.php**
   - Controller handling business logic and permission checks
   - Integrates model with view
   - Location: `/home/runner/work/edu-crm/edu-crm/app/controllers/agent_management_controller.php`

### Modified Files:

1. **app/views/agent_management.php**
   - Updated to include full CRUD functionality
   - Added modals for create, edit, view, and delete operations
   - Implemented conditional field display for "Our Student" option
   - Location: `/home/runner/work/edu-crm/edu-crm/app/views/agent_management.php`

## Database Schema

### Agents Table Structure
```sql
CREATE TABLE `agents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `agent_name` varchar(100) NOT NULL,
  `address` text DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `is_our_student` tinyint(1) DEFAULT 0,
  `student_id` varchar(50) DEFAULT NULL,
  `batch` varchar(50) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  CONSTRAINT `fk_agents_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

## Installation Instructions

### Step 1: Apply Database Migration
Run the migration script to create the `agents` table:

```bash
# Using MySQL command line
mysql -u [username] -p [database_name] < database_agent_management.sql

# Or using phpMyAdmin
# 1. Open phpMyAdmin
# 2. Select your database
# 3. Go to SQL tab
# 4. Copy and paste the contents of database_agent_management.sql
# 5. Click "Go" to execute
```

### Step 2: Verify Installation
After applying the migration, verify the table was created:

```sql
SHOW CREATE TABLE agents;
SELECT COUNT(*) as agent_count FROM agents;
```

### Step 3: Access Agent Management
1. Login as an Admin or Super Admin user
2. Navigate to: Dashboard → Agent Management
3. You should see the Agent Management interface

## Usage Guide

### Creating a New Agent

1. Click the **"Add New Agent"** button
2. Fill in the required fields:
   - Agent Name (required)
   - Email (required)
   - Phone Number (optional)
   - Address (optional)
   - Notes (optional)
3. If the agent is a current student:
   - Check the **"Our Student"** checkbox
   - Fill in Student ID, Batch, and Department fields
4. Click **"Create Agent"**
5. A new user account will be created with:
   - User Type: Agent
   - Default Password: `Agent@123`
   - Account Status: Active

### Editing an Agent

1. Find the agent in the list
2. Click the **Edit** button (pencil icon)
3. Update the information in the modal
4. Click **"Update Agent"**

### Viewing Agent Details

1. Find the agent in the list
2. Click the **View** button (eye icon)
3. Review all agent information in the modal
4. Click **"Close"** when done

### Deleting an Agent

1. Find the agent in the list
2. Click the **Delete** button (trash icon)
3. Confirm the deletion in the modal
4. **Note**: You cannot delete an agent who has associated leads

## Features & Behavior

### Conditional Field Display
- The "Student ID", "Batch", and "Department" fields are hidden by default
- They automatically appear when the "Our Student" checkbox is checked
- They are hidden again when the checkbox is unchecked
- Values are cleared when unchecked to prevent saving stale data

### User Account Integration
- When creating an agent, a corresponding user account is automatically created
- The user account is linked to the agent record via `user_id`
- User profile is also created with the agent's name and contact information
- When updating an agent, the linked user account and profile are also updated
- When deleting an agent, the user account and profile are also deleted (CASCADE)

### Lead Protection
- Agents with associated leads cannot be deleted
- The system checks for leads before allowing deletion
- An error message displays the number of leads if deletion is attempted

### Email Validation
- Email addresses must be unique across all agents
- Duplicate email validation occurs on both create and update operations

## Security Considerations

### Access Control
- Only Admin and Super Admin users can access agent management
- Permission checks at both controller and view levels
- Unauthorized users are redirected to dashboard

### Data Validation
- Required field validation on both client and server side
- Email format validation
- SQL injection prevention through prepared statements
- XSS prevention through output escaping

### Database Transactions
- Create, update, and delete operations use database transactions
- Ensures data integrity across multiple table operations
- Automatic rollback on errors

## Technical Details

### Model Layer (agent_model.php)
- Handles all database operations
- Returns standardized response format: `['status' => true/false, 'message' => '...']`
- Uses PDO prepared statements for security
- Implements transaction support for complex operations

### Controller Layer (agent_management_controller.php)
- Handles business logic
- Implements permission checking
- Coordinates between model and view
- Manages user session and company context

### View Layer (agent_management.php)
- Bootstrap 5 modals for user interactions
- JavaScript for dynamic field visibility
- Responsive table design
- Success/error message display

## Troubleshooting

### Issue: "Agent not found" when editing
**Solution**: Ensure the agents table has been properly migrated and populated.

### Issue: Cannot delete agent
**Solution**: Check if the agent has associated leads. Reassign or delete leads first.

### Issue: "Email already exists" error
**Solution**: Each agent must have a unique email address. Use a different email.

### Issue: Modal not appearing
**Solution**: Ensure Bootstrap JavaScript is properly loaded on the page.

### Issue: Student fields not showing
**Solution**: Check browser console for JavaScript errors. Ensure checkbox onchange event is firing.

## Testing Checklist

- [ ] Login as Admin user
- [ ] Navigate to Agent Management page
- [ ] Create a new agent without "Our Student" option
- [ ] Create a new agent with "Our Student" option
- [ ] Verify agent appears in the list
- [ ] Click view button to see agent details
- [ ] Click edit button to update agent information
- [ ] Test email uniqueness validation
- [ ] Try to delete an agent without leads
- [ ] Try to delete an agent with leads (should fail)
- [ ] Verify conditional field display works correctly
- [ ] Test form validation (required fields)
- [ ] Login as non-admin user and verify access denied
- [ ] Check database for proper data storage

## Future Enhancements

1. **Bulk Operations**: Add ability to import/export agents via CSV
2. **Agent Performance**: Dashboard showing agent statistics and performance metrics
3. **Email Notifications**: Send welcome emails to new agents with login credentials
4. **Password Reset**: Allow agents to reset their passwords
5. **Profile Photos**: Add ability to upload agent profile photos
6. **Activity Log**: Track all changes made to agent records
7. **Advanced Search**: Add search and filter functionality for agents
8. **Agent Assignment**: Automatically assign leads to agents based on criteria

## Support

For issues or questions, please contact the development team or refer to the main system documentation.

---

**Implementation Date**: January 14, 2026
**Version**: 1.0
**Status**: Complete and Ready for Testing
