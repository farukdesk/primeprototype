-- Migration: Rename Staff to Counselor in users table
-- Date: 2026-01-14
-- Description: Updates user_type enum to replace 'Staff' with 'Counselor'

-- Step 1: Update existing 'Staff' users to 'Counselor'
UPDATE users SET user_type = 'Counselor' WHERE user_type = 'Staff';

-- Step 2: Modify the enum to replace 'Staff' with 'Counselor'
ALTER TABLE users 
MODIFY COLUMN user_type ENUM('Super Admin','Admin','Manager','Counselor','Agent') 
COLLATE utf8mb4_unicode_ci NOT NULL;

-- Verification query (optional)
-- SELECT user_type, COUNT(*) as count FROM users GROUP BY user_type;
