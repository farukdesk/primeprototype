<?php
require_once 'config/config.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize($_POST['email']);
    $password = $_POST['password'];

    try {
        // Fetch user by email
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = :email LIMIT 1");
        $stmt->execute(['email' => $email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            // Set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['user_type'] = $user['user_type'];

            // Redirect to dashboard
            header("Location: dashboard.php");
            exit;
        } else {
            // Redirect with error message
            header("Location: index.php?error=Invalid email or password");
            exit;
        }
    } catch (PDOException $e) {
        // Handle database errors
        header("Location: index.php?error=Database error: " . $e->getMessage());
        exit;
    }
}
?>