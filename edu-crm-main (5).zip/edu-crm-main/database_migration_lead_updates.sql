-- Migration Script: Update Lead Management Fields
-- Date: 2026-01-14
-- Description: Remove assigned_office, country_applying_from, nationality, budget fields
--              Remove old education fields
--              Add current_city field
--              Add new education fields for Bachelor/Master degree tracking

-- ==============================================
-- STEP 1: Add new fields
-- ==============================================

-- Add current_city field to personal information
ALTER TABLE `leads` 
ADD COLUMN `current_city` VARCHAR(100) DEFAULT NULL AFTER `address`;

-- Add new education fields
ALTER TABLE `leads`
ADD COLUMN `applying_for` ENUM('Bachelor Degree', 'Master Degree') DEFAULT NULL AFTER `current_city`,
ADD COLUMN `semester` VARCHAR(100) DEFAULT NULL AFTER `applying_for`,
ADD COLUMN `ssc_gpa` DECIMAL(3,2) DEFAULT NULL AFTER `semester`,
ADD COLUMN `hsc_gpa` DECIMAL(3,2) DEFAULT NULL AFTER `ssc_gpa`,
ADD COLUMN `bachelor_subject` VARCHAR(255) DEFAULT NULL AFTER `hsc_gpa`,
ADD COLUMN `bachelor_cgpa` DECIMAL(3,2) DEFAULT NULL AFTER `bachelor_subject`;

-- ==============================================
-- STEP 2: Remove old fields (after backing up data if needed)
-- ==============================================

-- Remove assigned_office field
ALTER TABLE `leads` 
DROP COLUMN `assigned_office`;

-- Remove personal information fields that are no longer needed
ALTER TABLE `leads`
DROP COLUMN `country_applying_from`,
DROP COLUMN `nationality`,
DROP COLUMN `budget`;

-- Remove old education fields
ALTER TABLE `leads`
DROP COLUMN `most_recent_degree`,
DROP COLUMN `gpa`,
DROP COLUMN `ielts_overall`,
DROP COLUMN `ielts_reading`,
DROP COLUMN `ielts_writing`,
DROP COLUMN `ielts_speaking`,
DROP COLUMN `ielts_listening`;

-- ==============================================
-- STEP 3: Update lead_source enum if needed
-- ==============================================

-- Change 'Direct Office Visit' to 'Direct Campus Visit' in the enum if not already done
-- (Based on the code, it seems this might already be the case)

-- ==============================================
-- NOTES:
-- ==============================================
-- 1. Backup your database before running this migration
-- 2. The lead_courses and lead_semesters tables are kept for now
--    (they can be removed later if interests functionality is fully deprecated)
-- 3. This migration is destructive - data in removed columns will be lost
-- 4. Test on a development environment first
