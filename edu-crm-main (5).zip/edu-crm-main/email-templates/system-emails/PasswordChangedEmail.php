<?php
class SendPasswordChangedEmail {
    private $user;
    private $securityInfo;

    public function __construct($user, $securityInfo) {
        $this->user = $user;
        $this->securityInfo = $securityInfo;
    }

    public function getSubject() {
        return "Your Password Has Been Changed";
    }

    public function getBody() {
        return "
        <html>
        <head>
            <title>Password Changed Successfully</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    background-color: #f4f4f4;
                    margin: 0;
                    padding: 0;
                }
                .email-container {
                    max-width: 600px;
                    margin: auto;
                    background: #ffffff;
                    border-radius: 8px;
                    overflow: hidden;
                    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
                }
                .email-header {
                    background-color: #0acf97;
                    color: #ffffff;
                    padding: 20px;
                    text-align: center;
                }
                .email-header img {
                    max-width: 100px;
                    margin-bottom: 10px;
                }
                .email-header h1 {
                    margin: 0;
                    font-size: 24px;
                }
                .email-body {
                    padding: 20px;
                    color: #333333;
                }
                .email-body h2 {
                    font-size: 20px;
                    margin-bottom: 15px;
                    color: #0acf97;
                }
                .email-body p {
                    margin: 10px 0;
                    font-size: 16px;
                    line-height: 1.5;
                }
                .email-body .success-icon {
                    text-align: center;
                    font-size: 48px;
                    color: #0acf97;
                    margin: 20px 0;
                }
                .email-body .security-note {
                    background-color: #f8f9fa;
                    border-left: 4px solid #0acf97;
                    padding: 15px;
                    margin: 20px 0;
                }
                .email-footer {
                    background-color: #f4f4f4;
                    text-align: center;
                    padding: 15px;
                    font-size: 14px;
                    color: #666666;
                }
                @media only screen and (max-width: 600px) {
                    .email-container {
                        width: 100%;
                        margin: auto;
                    }
                    .email-body p, .email-body h2 {
                        text-align: center;
                    }
                }
            </style>
        </head>
        <body>
            <div class='email-container'>
                <div class='email-header'>
                    <img src='https://khanassociates.co.uk/wp-content/uploads/2024/04/logo.png' alt='PUMIS Logo'>
                    <h1>PUMIS</h1>
                </div>
                <div class='email-body'>
                    <div class='success-icon'>✓</div>
                    <h2>Password Changed Successfully</h2>
                    <p>Hi {$this->user['email']},</p>
                    <p>We wanted to let you know that your password has been successfully changed. If you did not make this change, please contact our support team immediately.</p>

                    <div class='security-note'>
                        <p><strong>Security Notice:</strong></p>
                        <p>This change was made on {$this->securityInfo['timestamp']} from IP address: {$this->securityInfo['ip_address']} using {$this->securityInfo['user_agent']}.</p>
                    </div>

                    <p>If you have any questions or need further assistance, please do not hesitate to reach out to our support team.</p>
                    <p>Thank you for using our service.</p>
                    <p>Best regards,<br>PUMIS Team</p>
                </div>
                <div class='email-footer'>
                    <p>&copy; " . date('Y') . " PUMIS - Prime University Management Information System. All rights reserved.</p>
                </div>
            </div>
        </body>
        </html>
        ";
    }
}
?>