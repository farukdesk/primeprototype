<?php
function getForgotPasswordEmail($resetLink) {
    return "
    <html>
    <head>
        <title>Reset Your Password</title>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <style>
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background-color: #f8f9fa;
                margin: 0;
                padding: 0;
                line-height: 1.6;
            }
            .email-container {
                max-width: 600px;
                margin: 20px auto;
                background: #ffffff;
                border-radius: 12px;
                overflow: hidden;
                box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
                border: 1px solid #e9ecef;
            }
            .email-header {
                background: linear-gradient(135deg, #0acf97 0%, #089f78 100%);
                color: #ffffff;
                padding: 30px 20px;
                text-align: center;
            }
            .email-header img {
                max-width: 120px;
                height: auto;
                margin-bottom: 15px;
                border-radius: 8px;
                background: rgba(255, 255, 255, 0.1);
                padding: 10px;
            }
            .email-header h1 {
                margin: 0;
                font-size: 28px;
                font-weight: 700;
                letter-spacing: 1px;
            }
            .email-body {
                padding: 30px 25px;
                color: #495057;
            }
            .email-body h2 {
                font-size: 22px;
                margin-bottom: 20px;
                color: #0acf97;
                font-weight: 600;
                text-align: center;
            }
            .email-body p {
                margin: 15px 0;
                font-size: 16px;
                line-height: 1.7;
            }
            .reset-button {
                display: inline-block;
                background: linear-gradient(135deg, #0acf97 0%, #089f78 100%);
                color: #ffffff !important;
                padding: 14px 30px;
                border-radius: 8px;
                text-decoration: none;
                font-weight: 600;
                font-size: 16px;
                margin: 20px 0;
                transition: all 0.3s ease;
                box-shadow: 0 4px 15px rgba(10, 207, 151, 0.3);
            }
            .reset-button:hover {
                background: linear-gradient(135deg, #089f78 0%, #0acf97 100%);
                transform: translateY(-2px);
                box-shadow: 0 6px 20px rgba(10, 207, 151, 0.4);
            }
            .button-container {
                text-align: center;
                margin: 25px 0;
            }
            .security-notice {
                background-color: #f8f9fa;
                border-left: 4px solid #0acf97;
                padding: 15px;
                margin: 20px 0;
                border-radius: 0 8px 8px 0;
            }
            .email-footer {
                background-color: #f8f9fa;
                text-align: center;
                padding: 20px;
                font-size: 14px;
                color: #6c757d;
                border-top: 1px solid #e9ecef;
            }
            .footer-content {
                margin-bottom: 10px;
            }
            .powered-by {
                font-size: 12px;
                color: #adb5bd;
                font-style: italic;
            }
            
            /* Responsive Design */
            @media only screen and (max-width: 600px) {
                .email-container {
                    width: 95% !important;
                    margin: 10px auto;
                    border-radius: 8px;
                }
                .email-header {
                    padding: 20px 15px;
                }
                .email-header h1 {
                    font-size: 24px;
                }
                .email-header img {
                    max-width: 100px;
                }
                .email-body {
                    padding: 20px 15px;
                }
                .email-body h2 {
                    font-size: 20px;
                }
                .email-body p {
                    font-size: 15px;
                }
                .reset-button {
                    display: block;
                    width: 80%;
                    margin: 20px auto;
                    text-align: center;
                    padding: 16px 20px;
                }
                .security-notice {
                    margin: 15px 0;
                    padding: 12px;
                }
            }
        </style>
    </head>
    <body>
        <div class='email-container'>
            <div class='email-header'>
                <img src='https://khanassociates.co.uk/wp-content/uploads/2024/04/logo.png' alt='Khan Associates Logo'>
                <h1>PUMIS</h1>
            </div>
            <div class='email-body'>
                <h2>🔐 Password Reset Request</h2>
                <p>Hello,</p>
                <p>We received a request to reset your password for your PUMIS account. If you made this request, please click the button below to set a new password:</p>
                
                <div class='button-container'>
                    <a href='$resetLink' class='reset-button'>Reset My Password</a>
                </div>
                
                <div class='security-notice'>
                    <p><strong>Security Notice:</strong> This link will expire in 1 hour for your security. If you did not request a password reset, please ignore this email and your password will remain unchanged.</p>
                </div>
                
                <p>If you're having trouble clicking the button, copy and paste the following URL into your web browser:</p>
                <p style='word-break: break-all; font-size: 14px; color: #6c757d;'>$resetLink</p>
                
                <p>Best regards,<br>Khan Associates</p>
            </div>
            <div class='email-footer'>
                <div class='footer-content'>
                    &copy; " . date('Y') . "Khan Associates. All rights reserved.
                </div>
                <div class='powered-by'>
                    Powered by PUMIS (Prime University Management Information System), developed by Technofic Lab LTD
                </div>
            </div>
        </div>
    </body>
    </html>
    ";
}
?>