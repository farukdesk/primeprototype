<?php
/**
 * AJAX endpoint for getting lead data
 * Created on: 2025-05-05
 * Created by: farukdesk
 */

// Include required files
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../app/controllers/lead_management_controller.php';

// Only process AJAX requests
if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
    // Initialize the lead controller
    $leadController = new LeadManagementController($conn);
    
    // Get lead ID from POST data
    $leadId = isset($_POST['lead_id']) ? (int)$_POST['lead_id'] : 0;
    
    if ($leadId > 0) {
        $leadResult = $leadController->getLeadDetails($leadId);
        
        if ($leadResult['status']) {
            $leadDetails = $leadResult['data'];
            
            // Get additional data for dropdowns
            $universities = $leadController->getUniversities();
            $courses = $leadController->getCourses();
            $semesters = $leadController->getSemesters();
            $staffMembers = $leadController->handleRequest()['staff'] ?? [];
            $leadStatuses = $leadController->getLeadStatuses();
            $leadSources = $leadController->getLeadSources();
            $agents = $leadController->handleRequest()['agents'] ?? [];
            $canAssignStaff = $leadController->canAssignStaff();
            
            // Return HTML for the edit form
            include __DIR__ . '/../app/views/partials/edit_lead_form.php';
        } else {
            echo '<div class="alert alert-danger">Error: ' . htmlspecialchars($leadResult['message']) . '</div>';
        }
    } else {
        echo '<div class="alert alert-danger">Invalid lead ID</div>';
    }
} else {
    echo '<div class="alert alert-danger">Invalid request</div>';
}