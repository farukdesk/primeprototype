# Agent Management - Deployment & Testing Checklist

## Pre-Deployment Steps

### 1. Database Migration
- [ ] Backup your current database
- [ ] Review the migration file: `database_agent_management.sql`
- [ ] Apply the migration to your database:
  ```sql
  -- Option 1: Using MySQL command line
  mysql -u [username] -p [database_name] < database_agent_management.sql
  
  -- Option 2: Using phpMyAdmin
  -- Copy contents of database_agent_management.sql and execute in SQL tab
  ```
- [ ] Verify table creation:
  ```sql
  SHOW CREATE TABLE agents;
  DESCRIBE agents;
  ```

### 2. File Verification
- [ ] Verify all files are present:
  - `app/models/agent_model.php`
  - `app/controllers/agent_management_controller.php`
  - `app/views/agent_management.php` (modified)
  - `database_agent_management.sql`
- [ ] Check file permissions (ensure web server can read PHP files)

### 3. Code Review
- [ ] Review changed files for any custom modifications you may need
- [ ] Verify database credentials in `config/config.php` are correct

## Post-Deployment Testing

### 4. Access Control Testing
- [ ] Login as **Super Admin** user
  - [ ] Navigate to Dashboard → Agent Management
  - [ ] Verify page loads successfully
- [ ] Login as **Admin** user
  - [ ] Navigate to Dashboard → Agent Management
  - [ ] Verify page loads successfully
- [ ] Login as **Manager** or **Staff** user (if available)
  - [ ] Try to access Agent Management
  - [ ] Verify you are redirected to dashboard (access denied)

### 5. Create Agent Testing
- [ ] Click "Add New Agent" button
- [ ] Verify modal opens
- [ ] Fill in required fields:
  - [ ] Agent Name: "Test Agent"
  - [ ] Email: "testagent@example.com"
- [ ] Leave optional fields empty initially
- [ ] Click "Create Agent"
- [ ] Verify success message appears
- [ ] Verify agent appears in the table
- [ ] Verify a new user account was created (check users table)

### 6. "Our Student" Feature Testing
- [ ] Click "Add New Agent" again
- [ ] Fill in required fields with different email
- [ ] Check the "Our Student" checkbox
- [ ] Verify Student ID, Batch, and Department fields appear
- [ ] Fill in student fields:
  - [ ] Student ID: "ST12345"
  - [ ] Batch: "2024"
  - [ ] Department: "Computer Science"
- [ ] Click "Create Agent"
- [ ] Verify success message
- [ ] Verify agent shows "Our Student" indicator in table

### 7. View Agent Testing
- [ ] Click the View button (eye icon) on an agent
- [ ] Verify modal opens with all agent details
- [ ] Verify all fields display correctly
- [ ] For "Our Student" agents, verify student details are shown
- [ ] Close the modal

### 8. Edit Agent Testing
- [ ] Click the Edit button (pencil icon) on an agent
- [ ] Verify modal opens with pre-filled data
- [ ] Modify some fields:
  - [ ] Change agent name
  - [ ] Update phone number
  - [ ] Modify address
- [ ] Click "Update Agent"
- [ ] Verify success message
- [ ] Verify changes appear in the table

### 9. Edit "Our Student" Toggle Testing
- [ ] Edit an agent that is NOT "Our Student"
- [ ] Check the "Our Student" checkbox
- [ ] Verify student fields appear
- [ ] Fill in student details
- [ ] Update agent
- [ ] Verify agent now shows "Our Student" indicator
- [ ] Edit the same agent again
- [ ] Uncheck "Our Student"
- [ ] Update agent
- [ ] Verify "Our Student" indicator is gone

### 10. Delete Agent Testing (Without Leads)
- [ ] Create a new test agent
- [ ] Immediately click Delete button on that agent
- [ ] Verify confirmation modal appears
- [ ] Verify agent name is shown in confirmation
- [ ] Click "Delete Agent"
- [ ] Verify success message
- [ ] Verify agent is removed from table

### 11. Delete Agent Testing (With Leads)
- [ ] Find or create an agent that has leads assigned
- [ ] Click Delete button on that agent
- [ ] Click "Delete Agent" in confirmation
- [ ] Verify error message appears stating agent has leads
- [ ] Verify agent is NOT deleted

### 12. Email Validation Testing
- [ ] Try to create an agent with existing email
- [ ] Verify error message about duplicate email
- [ ] Try to create agent with invalid email format
- [ ] Verify validation error

### 13. Required Field Testing
- [ ] Click "Add New Agent"
- [ ] Leave Agent Name empty
- [ ] Try to submit
- [ ] Verify browser validation prevents submission
- [ ] Leave Email empty
- [ ] Try to submit
- [ ] Verify browser validation prevents submission

### 14. Data Integrity Testing
- [ ] Create a new agent
- [ ] Check the `agents` table in database
  - [ ] Verify agent record was created
- [ ] Check the `users` table
  - [ ] Verify user account was created with user_type = 'Agent'
- [ ] Check the `user_profile` table
  - [ ] Verify profile was created with name from agent
- [ ] Update the agent
  - [ ] Verify all three tables are updated correctly
- [ ] Delete the agent
  - [ ] Verify all three tables have related records deleted

### 15. UI/UX Testing
- [ ] Verify table is responsive on mobile
- [ ] Verify modals display correctly on mobile
- [ ] Verify all buttons have proper icons
- [ ] Verify status badges display correctly (Active/Inactive)
- [ ] Verify lead count displays correctly
- [ ] Verify "Our Student" indicator displays when applicable
- [ ] Verify address truncation in table works (long addresses)

### 16. Error Handling Testing
- [ ] Disconnect database temporarily
- [ ] Try to access Agent Management
- [ ] Verify appropriate error message
- [ ] Reconnect database
- [ ] Verify system recovers properly

### 17. Browser Compatibility Testing
- [ ] Test in Chrome/Edge
- [ ] Test in Firefox
- [ ] Test in Safari (if available)
- [ ] Verify all features work in each browser

## Production Verification

### 18. Production Checklist
- [ ] All tests passed successfully
- [ ] No console errors in browser
- [ ] No PHP errors in error logs
- [ ] Database migration applied successfully
- [ ] Backup of pre-deployment state available
- [ ] Rollback procedure documented (if needed)

## Common Issues & Solutions

### Issue: Modal doesn't open
**Solution**: Verify Bootstrap JavaScript is loaded. Check browser console for errors.

### Issue: "Our Student" fields don't show/hide
**Solution**: Check browser console for JavaScript errors. Verify the toggleStudentFields function is working.

### Issue: Email validation not working
**Solution**: Check that the agents table was created correctly with unique email constraint.

### Issue: Cannot delete agent but agent has no leads
**Solution**: Check the leads table query in the model. Verify the agent_id field relationship.

### Issue: Success/error messages not showing
**Solution**: Verify Bootstrap alerts CSS is loaded. Check if message variables are set.

## Performance Checks

### 19. Performance Testing (Optional)
- [ ] Create 100+ test agents
- [ ] Verify page loads in reasonable time
- [ ] Verify table scrolls smoothly
- [ ] Consider adding pagination if performance degrades

## Documentation Review

### 20. Documentation
- [ ] Review `AGENT_MANAGEMENT_README.md`
- [ ] Review `IMPLEMENTATION_SUMMARY_AGENT_MGMT.md`
- [ ] Share documentation with team
- [ ] Update internal wiki/docs if applicable

## Sign-off

### Testing Completed By:
- Name: ___________________________
- Date: ___________________________
- Role: ___________________________

### Issues Found:
```
List any issues discovered during testing:
1. 
2. 
3. 
```

### Sign-off for Production:
- [ ] All critical tests passed
- [ ] All blocking issues resolved
- [ ] Documentation reviewed and approved
- [ ] Ready for production use

**Signature**: ___________________________ **Date**: _______________

---

## Support Contact
For issues or questions during deployment, refer to:
- `AGENT_MANAGEMENT_README.md` - User guide and troubleshooting
- `IMPLEMENTATION_SUMMARY_AGENT_MGMT.md` - Technical details

## Rollback Procedure (If Needed)
If you need to rollback this feature:

1. **Database Rollback**:
   ```sql
   DROP TABLE IF EXISTS agents;
   ```

2. **File Rollback**:
   - Restore `app/views/agent_management.php` from previous version
   - Delete `app/models/agent_model.php`
   - Delete `app/controllers/agent_management_controller.php`

3. **Clear Cache** (if applicable):
   - Clear any application caches
   - Restart web server if needed

---

**Version**: 1.0
**Last Updated**: January 14, 2026
**Status**: Ready for Testing
