<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'crmkhan2244611');
define('DB_USER', 'khansmams334');
define('DB_PASS', 'XBU9}YT0Eo{Y');

try {
    $conn = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Start a secure session
session_start([
    'cookie_lifetime' => 86400, // 1 day
    'cookie_httponly' => true, // Prevent JavaScript access to session cookies
    'cookie_secure' => isset($_SERVER['HTTPS']), // Use secure cookies over HTTPS
]);

// Set security headers
header('X-Frame-Options: SAMEORIGIN'); // Prevent clickjacking
header('X-XSS-Protection: 1; mode=block'); // Enable XSS protection
header('X-Content-Type-Options: nosniff'); // Prevent MIME sniffing
header('Referrer-Policy: no-referrer-when-downgrade'); // Limit referrer information

// Sanitize input function
function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

// CSRF token generation
function generateCsrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// Verify CSRF token
function verifyCsrfToken($token) {
    return hash_equals($_SESSION['csrf_token'], $token);
}

// Usage in forms (example)
// <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ">

// Verify CSRF token in form processing
// if (!verifyCsrfToken($_POST['csrf_token'])) {
//     die('Invalid CSRF token');
// }
?>
