<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php?error=Please log in to access this page");
    exit;
}

// Disable caching
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: Sat, 01 Jan 3000 00:00:00 GMT");
?>
