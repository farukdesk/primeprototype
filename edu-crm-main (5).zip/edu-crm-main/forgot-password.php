<?php
require_once 'config/config.php';
require_once 'email-templates/system-emails/forgot-password-email.php'; // Include email template

session_start();

// Initialize messages
$success = $error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);

    try {
        // Check if the email exists in the database
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = :email LIMIT 1");
        $stmt->execute(['email' => $email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            // Generate reset token and expiry
            $reset_token = bin2hex(random_bytes(32));
            $reset_token_expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));

            // Update reset token in the database
            $stmt = $conn->prepare("UPDATE users SET reset_token = :reset_token, reset_token_expiry = :reset_token_expiry WHERE email = :email");
            $stmt->execute([
                'reset_token' => $reset_token,
                'reset_token_expiry' => $reset_token_expiry,
                'email' => $email
            ]);

            // Generate reset link
            $reset_link = "http://crm.khanassociates.co.uk/reset-password.php?token=$reset_token";

            // Prepare email content
            $emailContent = getForgotPasswordEmail($reset_link);
            $subject = "Reset Your Password - PUMIS";
            $headers = "From: no_reply@khanassociates.co.uk\r\n";
            $headers .= "Reply-To: no_reply@khanassociates.co.uk\r\n";
            $headers .= "Content-Type: text/html; charset=UTF-8\r\n";

            // Send email
            if (mail($email, $subject, $emailContent, $headers)) {
                $success = "An email has been sent to reset your password.";
            } else {
                $error = "Failed to send email. Please try again later.";
            }
        } else {
            $error = "Email address not found.";
        }
    } catch (PDOException $e) {
        $error = "An error occurred. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Recover Password | PUMIS</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="PUMIS - Prime University Management Information System is a comprehensive ERP solution for university management." name="description" />
    <meta content="Md Omar Faruk" name="author" />
    <link rel="shortcut icon" href="assets/images/favicon.ico">
    <script src="assets/js/config.js"></script>
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" id="app-style" />
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
</head>

<body class="authentication-bg">
    <div class="account-pages pt-2 pt-sm-5 pb-4 pb-sm-5 position-relative">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xxl-8 col-lg-10">
                    <div class="card overflow-hidden">
                        <div class="row g-0">
                            <div class="col-lg-6 d-none d-lg-block p-2">
                                <img src="https://pickardproperties.co.uk/wp-content/uploads/2023/05/graduation-caps-air-blue-sky.jpg" alt="" class="img-fluid rounded h-100">
                            </div>
                            <div class="col-lg-6">
                                <div class="d-flex flex-column h-100">
                                    <div class="auth-brand p-4">
                                        <a href="index.php" class="logo-light">
                                            <img src="https://www.primeuniversity.ac.bd/prime/assets/images/logo-dark.png" alt="logo" style="max-height: 80px; width: auto;">
                                        </a>
                                        <a href="index.php" class="logo-dark">
                                            <img src="https://www.primeuniversity.ac.bd/prime/assets/images/logo-dark.png" alt="logo" style="max-height: 80px; width: auto;">
                                        </a>
                                    </div>
                                    <div class="p-4 my-auto">
                                        <h4 class="fs-20">Forgot Password?</h4>
                                        <p class="text-muted mb-3">Enter your email address and we'll send you an email with instructions to reset your password.</p>

                                        <!-- Display success or error message -->
                                        <?php if ($success): ?>
                                            <div class="alert alert-success">
                                                <?php echo htmlspecialchars($success); ?>
                                            </div>
                                        <?php elseif ($error): ?>
                                            <div class="alert alert-danger">
                                                <?php echo htmlspecialchars($error); ?>
                                            </div>
                                        <?php endif; ?>

                                        <!-- Form -->
                                        <form method="POST" action="">
                                            <div class="mb-3">
                                                <label for="emailaddress" class="form-label">Email address</label>
                                                <input class="form-control" type="email" id="emailaddress" name="email" required placeholder="Enter your email">
                                            </div>
                                            <div class="mb-0 text-start">
                                                <button class="btn btn-soft-primary w-100" type="submit">
                                                    <i class="ri-loop-left-line me-1 fw-bold"></i>
                                                    <span class="fw-bold">Reset Password</span>
                                                </button>
                                            </div>
                                        </form>
                                        <!-- end form -->
                                    </div>
                                </div>
                            </div> <!-- end col -->
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12 text-center">
                    <p class="text-dark-emphasis">Back To <a href="index.php" class="text-dark fw-bold ms-1 link-offset-3 text-decoration-underline"><b>Log In</b></a></p>
                </div>
            </div>
        </div>
    </div>
    
    <footer class="footer footer-alt fw-medium">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <span class="text-dark d-block">
                        <script>document.write(new Date().getFullYear())</script> © Powered by <strong>PUMIS</strong>
                    </span>
                    <span class="text-muted small">
                        Prime University Management Information System - Developed by <strong>Technofic Lab LTD</strong>
                    </span>
                </div>
            </div>
        </div>
    </footer>
    
    <script src="assets/js/vendor.min.js"></script>
    <script src="assets/js/app.min.js"></script>
</body>

</html>