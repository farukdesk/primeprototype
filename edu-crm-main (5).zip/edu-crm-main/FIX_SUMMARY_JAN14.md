# Bug Fixes Summary - January 14, 2026

## Issues Fixed

### 1. SQL Error: Unknown column 'status' in courses table
**Error Message:**
```
SQLSTATE[42S22]: Column not found: 1054 Unknown column 'status' in 'where clause' 
in /home/primeuniadmin/public_html/crm.primeuniversity.ac.bd/app/controllers/lead_management_controller.php:121
```

**Root Cause:**
The `courses` table in the database does not have a `status` column, but the `getCourses()` method in `lead_management_controller.php` was trying to filter by `status = 'Active'`.

**Fix Applied:**
Modified `/app/controllers/lead_management_controller.php` line 119:
- **Before:** `SELECT id, course_title FROM courses WHERE status = 'Active' ORDER BY course_title`
- **After:** `SELECT id, course_title FROM courses ORDER BY course_title`

**Files Changed:**
- `app/controllers/lead_management_controller.php`

---

### 2. Data Truncation Error: user_type column
**Error Message:**
```
Error updating user: SQLSTATE[01000]: Warning: 1265 Data truncated for column 'user_type' at row 1
```

**Root Cause:**
The database was migrated from using 'Staff' to 'Counselor' user type (via `database_migration_staff_to_counselor.sql`), but the base SQL file `primeuniadmin_crm25.sql` still contained references to 'Staff' in:
1. The enum definition for `user_type` column
2. Sample data inserts for staff users

This caused issues when trying to import or reference the base SQL file.

**Fix Applied:**
Modified `/primeuniadmin_crm25.sql`:
1. Updated enum definition (line 452):
   - **Before:** `user_type` enum('Super Admin','Admin','Manager','Staff','Agent')
   - **After:** `user_type` enum('Super Admin','Admin','Manager','Counselor','Agent')

2. Updated sample data (lines 471-474):
   - Changed all `'Staff'` values to `'Counselor'` in user inserts

**Files Changed:**
- `primeuniadmin_crm25.sql`

**Note:** The application views (`user_management.php`) already correctly use 'Counselor', so no view changes were needed.

---

### 3. UI Bug: "Our Student" checkbox not working in Add Agent modal
**Issue Description:**
When adding a new agent, checking the "Our Student" checkbox did not show the student fields (Student ID, Batch, Department). The functionality only worked in the Edit Agent modal.

**Root Cause:**
The checkbox in the Add Agent modal had ID `is_our_student`, but the JavaScript function `toggleStudentFields('add')` was looking for an element with ID `add_is_our_student` (constructed as `prefix + '_is_our_student'`).

**Fix Applied:**
Modified `/app/views/agent_management.php` line 285:
- **Before:** `<input class="form-check-input" type="checkbox" id="is_our_student" name="is_our_student" value="1" onchange="toggleStudentFields('add')">`
- **After:** `<input class="form-check-input" type="checkbox" id="add_is_our_student" name="is_our_student" value="1" onchange="toggleStudentFields('add')">`

Also updated the corresponding label's `for` attribute to match.

**Files Changed:**
- `app/views/agent_management.php`

**Expected Behavior After Fix:**
- Checking "Our Student" in Add Agent modal now properly shows the student fields
- Unchecking hides the fields and clears their values
- Consistent behavior between Add and Edit modals

---

## Testing Recommendations

Since there's no automated test infrastructure in this repository, manual testing should be performed:

### Test Case 1: Lead Management - Courses Loading
1. Navigate to Lead Management page
2. Verify that the page loads without errors
3. Verify that courses appear in the course filter dropdown
4. Check browser console for any JavaScript errors

### Test Case 2: User Management - Creating Users
1. Navigate to User Management (Admin only)
2. Create a new user with user type "Counselor"
3. Verify the user is created successfully without data truncation errors
4. Verify the user appears in the user list

### Test Case 3: Agent Management - Our Student Checkbox
1. Navigate to Agent Management (Admin only)
2. Click "Add New Agent" button
3. Fill in required fields (Agent Name, Email)
4. Check the "Our Student" checkbox
5. **Expected:** Student ID, Batch, and Department fields should appear
6. Fill in the student fields
7. Uncheck the "Our Student" checkbox
8. **Expected:** Student fields should hide and clear
9. Submit the form and verify agent is created correctly

### Test Case 4: Agent Management - Edit Mode
1. Click "Edit" on an existing agent
2. Check/uncheck the "Our Student" checkbox
3. **Expected:** Student fields should show/hide correctly
4. Verify behavior is consistent with Add mode

---

## Database Schema Notes

### Courses Table Structure
The `courses` table does not have a `status` column. If course status filtering is needed in the future, a migration would be required to add this column:

```sql
ALTER TABLE courses ADD COLUMN status ENUM('Active', 'Inactive') DEFAULT 'Active';
```

### Universities and Semesters Tables
Both tables have a `status` column and use it correctly in their respective queries. No changes needed.

### Users Table
The current enum for `user_type` is:
```sql
ENUM('Super Admin','Admin','Manager','Counselor','Agent')
```

**Note:** 'Staff' has been fully replaced with 'Counselor' across the system.

---

## Files Modified

1. **app/controllers/lead_management_controller.php**
   - Removed invalid status filter from courses query

2. **primeuniadmin_crm25.sql**
   - Updated user_type enum definition
   - Updated sample data to use 'Counselor' instead of 'Staff'

3. **app/views/agent_management.php**
   - Fixed checkbox ID in Add Agent modal for "Our Student" functionality

---

## Migration Status

The following migration has been applied to the production database:
- `database_migration_staff_to_counselor.sql` - Renamed 'Staff' to 'Counselor'

The base SQL file (`primeuniadmin_crm25.sql`) has now been updated to reflect this change for future installations.

---

## Potential Future Improvements

1. **Add status column to courses table** if course filtering by status is desired
2. **Add automated tests** for critical functionality
3. **Add data validation** to ensure user_type values are correct before insertion
4. **Add error logging** for better debugging of SQL errors
5. **Implement PHP error handlers** to catch PDO exceptions gracefully
