<!-- ========== Left Sidebar Start ========== -->
<div class="leftside-menu">

    <!-- Brand Logo Light -->
    <a href="/dashboard.php" class="logo logo-light" style="background-color: white; padding: 10px; border-radius: 4px; display: flex; align-items: center; justify-content: center; margin: 10px;">
        <span class="logo-lg">
            <img src="https://www.primeuniversity.ac.bd/prime/assets/images/logo-dark.png" alt="logo" style="max-height: 80px; width: auto; max-width: 100%;">
        </span>
        <span class="logo-sm">
            <img src="https://www.primeuniversity.ac.bd/prime/assets/images/logo-dark.png" alt="small logo" style="max-height: 60px; width: auto; max-width: 100%;">
        </span>
    </a>

    <!-- Brand Logo Dark -->
    <a href="/dashboard.php" class="logo logo-dark" style="background-color: white; padding: 10px; border-radius: 4px; display: flex; align-items: center; justify-content: center; margin: 10px;">
        <span class="logo-lg">
            <img src="https://www.primeuniversity.ac.bd/prime/assets/images/logo-dark.png" alt="dark logo" style="max-height: 80px; width: auto; max-width: 100%;">
        </span>
        <span class="logo-sm">
            <img src="https://www.primeuniversity.ac.bd/prime/assets/images/logo-dark.png" alt="small logo" style="max-height: 60px; width: auto; max-width: 100%;">
        </span>
    </a>

    <!-- Sidebar -left -->
    <div class="h-100" id="leftside-menu-container" data-simplebar>
        <!--- Sidemenu -->
        <ul class="side-nav">

            <li class="side-nav-title">Main</li>

            <li class="side-nav-item">
                <a href="/dashboard.php" class="side-nav-link">
                    <i class="ri-dashboard-3-line"></i>
                    <span> Dashboard </span>
                </a>
            </li>

            <!-- Lead Management -->
            <li class="side-nav-item">
                <a data-bs-toggle="collapse" href="#leadManagementMenu" aria-expanded="false" aria-controls="leadManagementMenu" class="side-nav-link">
                    <i class="ri-user-follow-line"></i>
                    <span>Lead Management</span>
                    <span class="menu-arrow"></span>
                </a>
                <div class="collapse" id="leadManagementMenu">
                    <ul class="side-nav-second-level">
                        <li>
                            <a href="dashboard.php?page=lead_management_view">Manage Leads</a>
                        </li>
                        <li>
                            <a href="dashboard.php?page=call_logs_view">Call Logs</a>
                        </li>
                        <li>
                            <a href="dashboard.php?page=campus_visits_view">Campus Visits</a>
                        </li>
                    </ul>
                </div>
            </li>

            <?php if ($_SESSION['user_type'] !== 'Counselor'): ?>
            <li class="side-nav-title">System Management</li>

            <!-- Semester Management -->
            <?php if (in_array($_SESSION['user_type'], ['Super Admin', 'Admin'])): ?>
            <li class="side-nav-item">
                <a href="dashboard.php?page=semester_management" class="side-nav-link">
                    <i class="ri-calendar-line"></i>
                    <span> Semester Management </span>
                </a>
            </li>
            <?php endif; ?>

            <!-- Course Management -->
            <?php if (in_array($_SESSION['user_type'], ['Super Admin', 'Admin'])): ?>
            <li class="side-nav-item">
                <a href="dashboard.php?page=course_management" class="side-nav-link">
                    <i class="ri-book-open-line"></i>
                    <span> Course Management </span>
                </a>
            </li>
            <?php endif; ?>

            <!-- Agent Management -->
            <?php if (in_array($_SESSION['user_type'], ['Super Admin', 'Admin'])): ?>
            <li class="side-nav-item">
                <a href="dashboard.php?page=agent_management" class="side-nav-link">
                    <i class="ri-user-star-line"></i>
                    <span> Agent Management </span>
                </a>
            </li>
            <?php endif; ?>

            <!-- User Management -->
            <?php if (in_array($_SESSION['user_type'], ['Super Admin', 'Admin'])): ?>
            <li class="side-nav-item">
                <a href="dashboard.php?page=user_management" class="side-nav-link">
                    <i class="ri-team-line"></i>
                    <span> User Management </span>
                </a>
            </li>
            <?php endif; ?>

            <!-- Reports -->
            <?php if (in_array($_SESSION['user_type'], ['Super Admin', 'Admin'])): ?>
            <li class="side-nav-item">
                <a data-bs-toggle="collapse" href="#reportsMenu" aria-expanded="false" aria-controls="reportsMenu" class="side-nav-link">
                    <i class="ri-file-chart-line"></i>
                    <span>Reports</span>
                    <span class="menu-arrow"></span>
                </a>
                <div class="collapse" id="reportsMenu">
                    <ul class="side-nav-second-level">
                        <li>
                            <a href="dashboard.php?page=top_sheet_report">Top Sheet</a>
                        </li>
                    </ul>
                </div>
            </li>
            <?php endif; ?>
            <?php endif; ?>

        </ul>
        <!--- End Sidemenu -->

        <div class="clearfix"></div>
    </div>
</div>
<!-- ========== Left Sidebar End ========== -->