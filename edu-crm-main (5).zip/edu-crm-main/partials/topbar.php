<?php
// Auth check is already done in dashboard.php which includes this file
// No need to include it again here
try {
    // Fetch user profile data
    $user_email = $_SESSION['email'];

    $stmt = $conn->prepare("
        SELECT up.first_name, up.profile_photo
        FROM users u
        LEFT JOIN user_profile up ON u.id = up.user_id
        WHERE u.email = ?
        ORDER BY up.id DESC
        LIMIT 1
    ");
    
    $stmt->execute([$user_email]);
    $user_data = $stmt->fetch(PDO::FETCH_ASSOC);

    $first_name = $user_data['first_name'] ?? 'User';
    $profile_photo = $user_data['profile_photo'];
    $default_avatar = '/storage/uploads/user_profile_photo/default_avatar.png'; // Updated correct path

} catch (PDOException $e) {
    // Handle any database errors
    error_log("Database Error: " . $e->getMessage());
    $first_name = 'User';
    $profile_photo = '';
    $default_avatar = '/storage/uploads/user_profile_photo/default_avatar.png';
}
?>

<!-- ========== Topbar Start ========== -->
<div class="navbar-custom">
    <div class="topbar container-fluid">
        <div class="d-flex align-items-center gap-1">

            <!-- Topbar Brand Logo -->
            <div class="logo-topbar">
                <!-- Logo light -->
                <a href="index.html" class="logo-light">
                    <span class="logo-lg">
                        <img src="https://www.primeuniversity.ac.bd/prime/assets/images/logo-dark.png" alt="logo" style="max-height: 50px; width: auto;">
                    </span>
                    <span class="logo-sm">
                        <img src="https://www.primeuniversity.ac.bd/prime/assets/images/logo-dark.png" alt="small logo" style="max-height: 40px; width: auto;">
                    </span>
                </a>

                <!-- Logo Dark -->
                <a href="index.html" class="logo-dark">
                    <span class="logo-lg">
                        <img src="https://www.primeuniversity.ac.bd/prime/assets/images/logo-dark.png" alt="dark logo" style="max-height: 50px; width: auto;">
                    </span>
                    <span class="logo-sm">
                        <img src="https://www.primeuniversity.ac.bd/prime/assets/images/logo-dark.png" alt="small logo" style="max-height: 40px; width: auto;">
                    </span>
                </a>
            </div>

            <!-- Sidebar Menu Toggle Button -->
            <button class="button-toggle-menu">
                <i class="ri-menu-line"></i>
            </button>

            <!-- Horizontal Menu Toggle Button -->
            <button class="navbar-toggle" data-bs-toggle="collapse" data-bs-target="#topnav-menu-content">
                <div class="lines">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </button>

            <!-- Topbar Search Form -->
            <div class="app-search d-none d-lg-block">
                <form>
                    <div class="input-group">
                        <input type="search" class="form-control" placeholder="Search...">
                        <span class="ri-search-line search-icon text-muted"></span>
                    </div>
                </form>
            </div>
        </div>

        <ul class="topbar-menu d-flex align-items-center gap-3">
            <li class="dropdown d-lg-none">
                <a class="nav-link dropdown-toggle arrow-none" data-bs-toggle="dropdown" href="#" role="button"
                    aria-haspopup="false" aria-expanded="false">
                    <i class="ri-search-line fs-22"></i>
                </a>
                <div class="dropdown-menu dropdown-menu-animated dropdown-lg p-0">
                    <form class="p-3">
                        <input type="search" class="form-control" placeholder="Search ..."
                            aria-label="Recipient's username">
                    </form>
                </div>
            </li>

            <!-- Topbar Profile Dropdown Menu -->
            <li class="dropdown">
                <a class="nav-link dropdown-toggle arrow-none nav-user" data-bs-toggle="dropdown" href="#" role="button"
                   aria-haspopup="false" aria-expanded="false">
        <span class="account-user-avatar">
            <?php if (!empty($profile_photo)): ?>
                <img src="/storage/uploads/user_profile_photo/<?php echo htmlspecialchars($profile_photo); ?>" alt="user-image" width="32" class="rounded-circle">
            <?php else: ?>
                <img src="<?php echo $default_avatar; ?>" alt="user-image" width="32" class="rounded-circle">
            <?php endif; ?>
        </span>
                    <span class="d-lg-block d-none">
            <h5 class="my-0 fw-normal"><?php echo htmlspecialchars($first_name); ?> <i
                        class="ri-arrow-down-s-line d-none d-sm-inline-block align-middle"></i></h5>
        </span>
                </a>
                <div class="dropdown-menu dropdown-menu-end dropdown-menu-animated profile-dropdown">
                    <!-- Profile Header -->
                    <div class="dropdown-header noti-title">
                        <h6 class="text-overflow m-0">Welcome <?php echo htmlspecialchars($first_name); ?>!</h6>
                    </div>

                    <!-- Profile Items -->
                    <a href="/dashboard.php?page=user_profile" class="dropdown-item">
                        <i class="ri-account-circle-line fs-18 align-middle me-1"></i>
                        <span>My Account</span>
                    </a>

                    <a href="/dashboard.php?page=change-password" class="dropdown-item">
                        <i class="ri-lock-password-line fs-18 align-middle me-1"></i>
                        <span>Change Password</span>
                    </a>

                    <?php if ($_SESSION['user_type'] === 'Super Admin' || $_SESSION['user_type'] === 'Admin'): ?>
                        <a href="/dashboard.php?page=company_settings" class="dropdown-item">
                            <i class="ri-building-line fs-18 align-middle me-1"></i>
                            <span>Company Settings</span>
                        </a>
                    <?php endif; ?>

                    <?php if ($_SESSION['user_type'] === 'Super Admin' || $_SESSION['user_type'] === 'Admin'): ?>
                        <a href="/dashboard.php?page=my_subscription" class="dropdown-item">
                            <i class="ri-vip-crown-line fs-18 align-middle me-1"></i>
                            <span>My Subscription</span>
                        </a>
                    <?php endif; ?>

                    <!-- Logout -->
                    <a href="logout.php" class="dropdown-item">
                        <i class="ri-logout-box-line fs-18 align-middle me-1"></i>
                        <span>Logout</span>
                    </a>
                </div>
            </li>
        </ul>
    </div>
</div>
<!-- ========== Topbar End ========== -->