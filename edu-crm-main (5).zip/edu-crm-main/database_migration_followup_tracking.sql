-- ========================================
-- Lead Follow-up Tracking Migration
-- Created: 2026-01-19
-- Purpose: Add follow-up tracking fields to leads table
-- ========================================

-- Add new columns for follow-up tracking
ALTER TABLE `leads` 
ADD COLUMN `last_status_change_date` DATETIME NULL DEFAULT NULL COMMENT 'Date when lead status was last changed' AFTER `lead_status`,
ADD COLUMN `next_followup_date` DATE NULL DEFAULT NULL COMMENT 'Calculated date for next follow-up (status change + 2 days)' AFTER `last_status_change_date`,
ADD COLUMN `last_followup_action_date` DATETIME NULL DEFAULT NULL COMMENT 'Date when last follow-up action was taken' AFTER `next_followup_date`;

-- Add index for performance when filtering by follow-up date
ALTER TABLE `leads` 
ADD INDEX `idx_next_followup_date` (`next_followup_date`),
ADD INDEX `idx_last_status_change` (`last_status_change_date`);

-- Initialize last_status_change_date for existing leads based on their updated_at or created_at
UPDATE `leads` 
SET `last_status_change_date` = COALESCE(`updated_at`, `created_at`)
WHERE `last_status_change_date` IS NULL;

-- Calculate next_followup_date for existing leads (status change + 2 days)
-- Exclude leads with status 'Dead' or 'Admitted'
UPDATE `leads` 
SET `next_followup_date` = DATE(DATE_ADD(`last_status_change_date`, INTERVAL 2 DAY))
WHERE `last_status_change_date` IS NOT NULL 
  AND `lead_status` NOT IN ('Dead', 'Admitted')
  AND `next_followup_date` IS NULL;

-- ========================================
-- Migration Complete
-- ========================================
