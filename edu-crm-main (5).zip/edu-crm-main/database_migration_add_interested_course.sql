-- Database Migration: Add interested_course_id to leads table
-- Created on: 2026-01-19
-- Purpose: Add interested_course_id field to store the course a student is interested in from the lead landing page

-- Add interested_course_id column to leads table
ALTER TABLE `leads` 
ADD COLUMN `interested_course_id` INT NULL DEFAULT NULL AFTER `bachelor_cgpa`,
ADD KEY `fk_leads_interested_course` (`interested_course_id`);

-- Add foreign key constraint
ALTER TABLE `leads`
ADD CONSTRAINT `fk_leads_interested_course` 
FOREIGN KEY (`interested_course_id`) 
REFERENCES `courses` (`id`) 
ON DELETE SET NULL 
ON UPDATE CASCADE;

-- Update lead_source enum to include 'Direct Online' if not present
ALTER TABLE `leads` 
MODIFY COLUMN `lead_source` ENUM('Direct Online','Direct Campus Visit','Agent') 
COLLATE utf8mb4_unicode_ci NOT NULL;

-- Update lead_status enum to ensure 'Fresh' is available
ALTER TABLE `leads` 
MODIFY COLUMN `lead_status` ENUM('Fresh','1st call','2nd call','3rd call','Unable to reach once','Unable to reach twice','Unable to reach trice','Dead','Will visit office','Lead converted to Applicant','Admitted') 
COLLATE utf8mb4_unicode_ci DEFAULT 'Fresh';
