# Database Import/Export Fix

## Problem
When trying to import the database file `primeuniadmin_crm25 (1).sql` to another database server, the following errors occurred:

1. **MySQL Error #1227**: Access denied; you need (at least one of) the SUPER, SET USER privilege(s) for this operation
2. **Parser Errors**: Unrecognized statement types near "IF", "END", "RETURN" keywords

## Root Cause
The SQL dump file contained MySQL function definitions with `DEFINER` clauses:
```sql
CREATE DEFINER=`primeuniadmin`@`localhost` FUNCTION `format_company_date` ...
```

The `DEFINER` clause requires:
- SUPER or SET USER privileges on the target database server
- The specified user (`primeuniadmin@localhost`) to exist on the target server

This creates portability issues when importing to different MySQL/MariaDB servers.

## Solution
Removed the `DEFINER` clause from all function definitions. The functions now use the current user's context when created:

**Before:**
```sql
CREATE DEFINER=`primeuniadmin`@`localhost` FUNCTION `format_company_date` ...
```

**After:**
```sql
CREATE FUNCTION `format_company_date` ...
```

## Functions Modified
1. `format_company_date` - Formats dates according to company-specific formats
2. `get_user_full_name` - Returns the full name of a user
3. `get_user_hierarchy` - Returns the management hierarchy for a user

## Impact
- ✅ Functions can now be imported without SUPER privileges
- ✅ Works with any MySQL user that has CREATE ROUTINE privilege
- ✅ Functions execute with the privileges of the invoking user
- ✅ No functional changes - all functions work identically
- ✅ Improved database portability across different MySQL servers

## How to Import
```bash
mysql -u your_username -p your_database < "primeuniadmin_crm25 (1).sql"
```

Or use phpMyAdmin, MySQL Workbench, or any other database management tool.

## Technical Details
When `DEFINER` is omitted:
- MySQL automatically sets the definer to the user who creates the function (`CURRENT_USER`)
- By default, functions use `SQL SECURITY DEFINER`, meaning they execute with the privileges of the definer (the user who created them), regardless of who calls the function
- This ensures consistent behavior: the function always runs with the same privileges
- To change this behavior and have functions run with the privileges of the invoking user instead, explicitly add `SQL SECURITY INVOKER` to the function definition
- Omitting `DEFINER` is the recommended approach for portable database dumps

## Prevention
For future database exports using mysqldump, you can automatically strip DEFINER clauses:

```bash
mysqldump --no-tablespaces --skip-definer -u username -p database_name > output.sql
```

Or use sed to remove DEFINER clauses from existing dumps:
```bash
sed 's/DEFINER=[^ ]*//g' input.sql > output.sql
```
