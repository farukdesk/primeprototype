-- Database Migration to Add "Admitted" Lead Status
-- Date: 2026-01-14
-- Purpose: Add "Admitted" status to track admitted students

-- Modify lead_status enum to include 'Admitted'
ALTER TABLE `leads` 
MODIFY COLUMN `lead_status` ENUM(
    'Fresh',
    '1st call',
    '2nd call',
    '3rd call',
    'Unable to reach once',
    'Unable to reach twice',
    'Unable to reach trice',
    'Dead',
    'Will visit office',
    'Lead converted to Applicant',
    'Admitted'
) DEFAULT 'Fresh';
