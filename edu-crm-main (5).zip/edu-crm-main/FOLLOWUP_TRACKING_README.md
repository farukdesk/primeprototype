# Lead Follow-up Tracking Feature

## Overview

This feature implements automated follow-up tracking for leads in the CRM system. When a lead's status changes, the system automatically schedules a follow-up 2 days later (on day 3) and tracks whether the follow-up has been completed.

## Key Features

### 1. **Automatic Follow-up Scheduling**
- When a lead status changes, the system automatically:
  - Records the date/time of the status change (`last_status_change_date`)
  - Calculates the next follow-up date (status change + 2 days = day 3)
  - Stores this in the `next_followup_date` field

### 2. **Follow-up Action Tracking**
- Every time a lead is updated (status change, note added, etc.), the system updates `last_followup_action_date`
- This allows tracking whether follow-up action has been taken

### 3. **Visual Alerts & Indicators**
The system provides visual feedback for follow-up status:

#### **Overdue Follow-ups** (Red Alert)
- Shown when `next_followup_date` is in the past AND no action has been taken
- Displays: "X days overdue" message
- Red badge with pulsing animation
- Appears in both list view and detail view

#### **Due Today** (Yellow Warning)
- Shown when `next_followup_date` is today
- Yellow badge indicating urgency
- Warning message: "Follow-up due today!"

#### **Scheduled** (Blue Info)
- Shown when `next_followup_date` is in the future
- Blue info badge
- Normal display of the scheduled date

#### **Completed** (No Alert)
- When action has been taken on or after the scheduled date
- No alert shown, considered completed

### 4. **Quick Filters**
Two prominent filter buttons at the top of the lead management page:

- **"Today's Follow-ups"** - Shows all leads that need follow-up today
- **"Overdue Follow-ups"** - Shows all leads with past-due follow-ups

Both buttons show a count badge of matching leads.

### 5. **Exclusions**
Leads with status "Dead" or "Admitted" are excluded from follow-up tracking:
- Their `next_followup_date` is set to NULL
- They don't appear in follow-up filters
- No alerts are shown for these leads

## Database Schema

### New Fields Added to `leads` Table

```sql
last_status_change_date  DATETIME NULL      -- When status last changed
next_followup_date       DATE NULL          -- Calculated follow-up date (status + 2 days)
last_followup_action_date DATETIME NULL     -- When last action was taken on lead
```

### Indexes Added
```sql
INDEX idx_next_followup_date (next_followup_date)
INDEX idx_last_status_change (last_status_change_date)
```

## How It Works

### Status Change Workflow

1. User changes lead status (e.g., from "Fresh" to "1st call")
2. System automatically:
   - Sets `last_status_change_date` = current timestamp
   - Calculates `next_followup_date` = DATE(last_status_change_date + 2 days)
   - Creates a call log entry (existing feature)

### Any Lead Update Workflow

1. User updates lead (change status, add note, edit fields, etc.)
2. System automatically:
   - Sets `last_followup_action_date` = current timestamp
   - This marks that action has been taken on this lead

### Follow-up Status Calculation

The system calculates follow-up status dynamically:

```php
calculateFollowupStatus($lastFollowupDate, $nextFollowupDate)
```

Returns:
- `'overdue'` - Past due date, no recent action
- `'due_today'` - Due today
- `'scheduled'` - Future date
- `'completed'` - Action taken after scheduled date
- `'none'` - No follow-up scheduled

## Usage Guide

### For Users

#### Viewing Today's Follow-ups
1. Click the **"Today's Follow-ups"** button at the top of the lead management page
2. System shows all leads that need follow-up today
3. Contact these leads and update their status or add notes

#### Checking Overdue Follow-ups
1. Click the **"Overdue Follow-ups"** button
2. System shows all leads with missed follow-ups
3. Red alert indicates how many days overdue
4. Take immediate action on these leads

#### In the Lead Table
- Look for the **"Next Follow-up"** column
- Red badges with alert icons = overdue (take action now!)
- Yellow badges = due today
- Blue badges = scheduled for future

#### In Lead Detail View
- Large alert box at the top shows follow-up status
- Color-coded: Red (overdue), Yellow (due today), Blue (scheduled)
- Shows exact date and days overdue if applicable

### For Developers

#### Model Methods

**`LeadModel::updateFollowupTracking($leadId, $newStatus)`**
- Called automatically when status changes
- Updates follow-up dates based on new status
- Excludes Dead/Admitted leads

**`LeadModel::calculateFollowupStatus($lastFollowupDate, $nextFollowupDate)`**
- Returns follow-up status and days overdue
- Used for display logic

**`LeadModel::getLeadsNeedingFollowupToday($userId, $userType)`**
- Returns leads with `next_followup_date = today`

**`LeadModel::getLeadsWithOverdueFollowup($userId, $userType)`**
- Returns leads with `next_followup_date < today`

#### Controller Filters

Add to query string:
- `?followup_today=1` - Filter to today's follow-ups
- `?followup_overdue=1` - Filter to overdue follow-ups

#### Stats

Available in `$result['stats']`:
- `followup_today_count` - Count of leads needing follow-up today
- `followup_overdue_count` - Count of overdue follow-ups

## Installation

### 1. Run Database Migration

Execute the SQL migration file:

```bash
mysql -u username -p database_name < database_migration_followup_tracking.sql
```

Or import through phpMyAdmin:
1. Open phpMyAdmin
2. Select your database
3. Go to "Import" tab
4. Choose `database_migration_followup_tracking.sql`
5. Click "Go"

### 2. Verify Installation

Check that the new fields exist:

```sql
DESCRIBE leads;
```

You should see:
- `last_status_change_date`
- `next_followup_date`
- `last_followup_action_date`

### 3. Test the Feature

1. Go to Lead Management page
2. Create a new lead or update an existing lead's status
3. Check that `next_followup_date` is automatically set
4. Try the "Today's Follow-ups" and "Overdue Follow-ups" filters
5. Verify visual alerts appear correctly

## Business Logic

### Follow-up Calculation Rules

1. **When status changes**: `next_followup_date` = status_change_date + 2 days
2. **Any update to lead**: `last_followup_action_date` = current timestamp
3. **Status = "Dead" or "Admitted"**: `next_followup_date` = NULL (no follow-up needed)

### Alert Rules

```
IF next_followup_date < today AND last_followup_action_date < next_followup_date
    => SHOW RED ALERT (overdue)
    
ELSE IF next_followup_date = today
    => SHOW YELLOW WARNING (due today)
    
ELSE IF next_followup_date > today
    => SHOW BLUE INFO (scheduled)
    
ELSE IF last_followup_action_date >= next_followup_date
    => NO ALERT (completed)
```

## Troubleshooting

### Follow-up dates not being set
- Check that database migration ran successfully
- Verify fields exist in `leads` table
- Check PHP error logs for exceptions in `updateFollowupTracking()`

### Counts not showing in filter buttons
- Verify `getFollowupCount()` method is working
- Check that leads have valid `next_followup_date` values
- Ensure leads are not "Dead" or "Admitted"

### Alerts not appearing
- Check that `calculateFollowupStatus()` is being called in `getLeads()`
- Verify follow-up status is included in lead data
- Check browser console for JavaScript errors

### Performance issues
- Ensure indexes are created on `next_followup_date` and `last_status_change_date`
- Check query execution plans for slow queries
- Consider adding composite indexes if needed

## Future Enhancements

Potential improvements for future versions:

1. **Configurable Follow-up Intervals**
   - Allow users to set custom follow-up intervals (1 day, 3 days, 1 week, etc.)
   - Different intervals for different lead statuses

2. **Email/SMS Reminders**
   - Send automatic reminders to assigned staff about upcoming/overdue follow-ups
   - Daily digest of follow-ups needed

3. **Follow-up History**
   - Track complete history of follow-up schedules and completions
   - Show timeline of follow-up activities

4. **Follow-up Notes**
   - Allow adding specific follow-up notes
   - Set custom follow-up dates manually

5. **Reporting & Analytics**
   - Follow-up completion rate by staff member
   - Average time to follow-up
   - Impact of follow-ups on conversion rates

6. **Calendar Integration**
   - Add follow-ups to calendar apps (Google Calendar, Outlook, etc.)
   - Show follow-ups in dashboard calendar view

## Support

For issues or questions about this feature:
1. Check this README first
2. Review the code comments in `lead_model.php`
3. Check the database migration file for schema details
4. Contact the development team

## Version History

- **v1.0** (2026-01-19): Initial implementation
  - Automatic follow-up scheduling (2 days after status change)
  - Visual alerts and indicators
  - Quick filter buttons
  - Overdue tracking
  - Exclusion of Dead/Admitted leads
