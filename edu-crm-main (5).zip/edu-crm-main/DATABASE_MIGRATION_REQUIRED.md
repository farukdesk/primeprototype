# Database Migration Required for Production

## Overview
The production system is experiencing errors because the code has been updated to use a **NEW database schema**, but the **database migrations have NOT been applied yet**.

## Current Status
❌ **Production Database**: Using OLD schema  
✅ **Application Code**: Updated for NEW schema  
⚠️ **Result**: Schema mismatch causing PHP errors

## Errors Being Fixed

### 1. Auth Check Include Error ✅ FIXED
**Error**: `include(../config/auth_check.php): Failed to open stream`
- **Location**: `partials/topbar.php:2`
- **Fix Applied**: Removed duplicate auth_check include (already included in dashboard.php)

### 2. Missing Phone Column ✅ FIXED
**Error**: `Unknown column 'up.phone' in 'field list'`
- **Location**: `app/models/user_model.php:60`
- **Issue**: Column is named `mobile_number`, not `phone` in user_profile table
- **Fix Applied**: Updated all references from `up.phone` to `up.mobile_number` with alias

### 3. Missing Department Column ⚠️ REQUIRES MIGRATION
**Error**: `Unknown column 'department' in 'field list'`
- **Location**: `app/models/course_model.php:245`
- **Issue**: OLD courses table doesn't have `department` column
- **Temporary Fix**: Added column existence check to prevent crashes
- **Permanent Fix**: Apply `database_migration_course_restructure.sql`

### 4. Missing Office Visit Date Column ⚠️ REQUIRES MIGRATION
**Error**: `Unknown column 'l.office_visit_date' in 'field list'`
- **Location**: `app/views/home.php` (dashboard stats)
- **Issue**: Column may have been renamed to `campus_visit_date` during partial migration
- **Temporary Fix**: Added dynamic column detection to use correct column name
- **Permanent Fix**: Apply `database_migration_single_university.sql`

## Required Database Migrations

### Priority 1: Apply Lead Management Updates
**File**: `database_migration_lead_updates.sql`
**Purpose**: Update lead fields to match current requirements

```bash
# Backup first!
mysqldump -u username -p database_name > backup_before_lead_migration_$(date +%Y%m%d).sql

# Apply migration
mysql -u username -p database_name < database_migration_lead_updates.sql
```

**Changes Applied**:
- Adds `current_city`, `applying_for`, `semester`, `ssc_gpa`, `hsc_gpa`, `bachelor_subject`, `bachelor_cgpa`
- Removes `assigned_office`, `country_applying_from`, `nationality`, `budget`
- Removes old education fields

### Priority 2: Apply Single University Restructure
**File**: `database_migration_single_university.sql`
**Purpose**: Rename terminology from "office" to "campus"

```bash
# Backup first!
mysqldump -u username -p database_name > backup_before_university_migration_$(date +%Y%m%d).sql

# Apply migration
mysql -u username -p database_name < database_migration_single_university.sql
```

**Changes Applied**:
- Renames `intakes` → `semesters`
- Renames `lead_intakes` → `lead_semesters`
- Renames `office_visit_date` → `campus_visit_date`
- Renames `assigned_office` → `assigned_campus`
- Updates enum values

### Priority 3: Apply Course Restructure
**File**: `database_migration_course_restructure.sql`
**Purpose**: Simplify courses table

```bash
# CRITICAL: This migration DELETES all course data!
# Backup first!
mysqldump -u username -p database_name courses > backup_courses_$(date +%Y%m%d).sql

# Apply migration
mysql -u username -p database_name < database_migration_course_restructure.sql
```

**Changes Applied**:
- **DROPS and RECREATES** courses table
- New schema: `id`, `course_title`, `department`, `credit`, timestamps
- Old schema had: `university_id`, `course_duration`, `academic_level`, `intake`, etc.

⚠️ **WARNING**: This migration is DESTRUCTIVE and will delete all existing course data!

### Priority 4: Add Admitted Status
**File**: `database_migration_add_admitted_status.sql`
**Purpose**: Add "Admitted" status to lead_status enum

```bash
# Apply migration
mysql -u username -p database_name < database_migration_add_admitted_status.sql
```

## Migration Order (Recommended)

1. **Backup entire database** ✅ CRITICAL
   ```bash
   mysqldump -u username -p database_name > backup_full_$(date +%Y%m%d_%H%M%S).sql
   ```

2. **Apply migrations in order**:
   ```bash
   # Step 1: Lead updates
   mysql -u username -p database_name < database_migration_lead_updates.sql
   
   # Step 2: Single university restructure
   mysql -u username -p database_name < database_migration_single_university.sql
   
   # Step 3: Add admitted status
   mysql -u username -p database_name < database_migration_add_admitted_status.sql
   
   # Step 4: Course restructure (DESTRUCTIVE - backup courses first!)
   mysqldump -u username -p database_name courses > backup_courses_only.sql
   mysql -u username -p database_name < database_migration_course_restructure.sql
   ```

3. **Verify migrations**:
   ```sql
   -- Check table names
   SHOW TABLES LIKE 'semesters';
   SHOW TABLES LIKE 'lead_semesters';
   
   -- Check lead columns
   DESCRIBE leads;
   
   -- Check courses structure
   DESCRIBE courses;
   
   -- Verify data
   SELECT COUNT(*) FROM leads;
   SELECT COUNT(*) FROM courses;
   SELECT COUNT(*) FROM semesters;
   ```

## Temporary Fixes Applied (Backward Compatibility)

To prevent production crashes while migrations are being planned, the following temporary fixes were applied:

### 1. Course Model - Column Detection
- **File**: `app/models/course_model.php`
- **Changes**: 
  - Added `SHOW COLUMNS` check before using `department` column
  - Returns empty array if column doesn't exist
  - Shows helpful error message when trying to create/update courses without migration

### 2. Home Dashboard - Dynamic Column Detection
- **File**: `app/views/home.php`
- **Changes**:
  - Automatically detects whether `office_visit_date` or `campus_visit_date` exists
  - Uses correct column name in queries
  - Prevents dashboard crash due to missing column

### 3. User Model - Correct Column Name
- **File**: `app/models/user_model.php`
- **Changes**:
  - Changed from `up.phone` to `up.mobile_number` (matches actual schema)
  - Added alias to maintain `phone` in result set

## Testing After Migration

After applying migrations, test the following:

1. **Dashboard**: Should load without errors
2. **Lead Management**: Create, edit, view leads
3. **Course Management**: Create, edit, delete courses
4. **User Management**: View and manage users
5. **Campus Visits**: View and manage campus visits
6. **Semester Management**: Manage semesters

## Rollback Plan

If migrations cause issues:

```bash
# Restore from backup
mysql -u username -p database_name < backup_full_YYYYMMDD_HHMMSS.sql

# Or restore specific table
mysql -u username -p database_name < backup_courses_only.sql
```

## Next Steps

1. ✅ **Apply temporary fixes** (DONE - code changes deployed)
2. ⏳ **Schedule maintenance window** for database migration
3. ⏳ **Apply migrations** in order shown above
4. ⏳ **Test thoroughly** in production
5. ⏳ **Monitor error logs** for any remaining issues

## Support

For issues or questions:
- Review migration SQL files for detailed comments
- Check `RESTRUCTURING_GUIDE.md` for more information
- Check your application error logs for any issues

## Important Notes

- ⚠️ All migrations should be tested in a development environment first
- ⚠️ Always backup before running migrations
- ⚠️ Course restructure migration is DESTRUCTIVE
- ⚠️ Some features may be limited until migrations are applied
- ✅ Application will not crash - graceful degradation is in place

---

**Last Updated**: 2026-01-14  
**Status**: Temporary fixes applied, migrations pending
