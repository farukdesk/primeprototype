# Testing Plan for Lead Landing Page Feature

## Pre-Deployment Testing

### 1. Database Migration Testing

**Test Case 1.1: Run Database Migration**
- [ ] Execute the SQL migration file on a test database
- [ ] Verify `interested_course_id` column is added to `leads` table
- [ ] Verify foreign key constraint is created
- [ ] Check that existing leads still work (NULL values allowed)
- [ ] Verify enum values for lead_source and lead_status are correct

**SQL to verify:**
```sql
-- Check column exists
SHOW COLUMNS FROM leads LIKE 'interested_course_id';

-- Check foreign key
SHOW CREATE TABLE leads;

-- Test NULL values work
SELECT id, first_name, interested_course_id FROM leads LIMIT 5;
```

### 2. Public Lead Form Testing

**Test Case 2.1: Access Public Form**
- [ ] Open `public-lead-form.php` in a browser (without login)
- [ ] Verify page loads without errors
- [ ] Check that university branding displays correctly
- [ ] Verify form styling is responsive on mobile, tablet, and desktop

**Test Case 2.2: Form Validation - Client Side**
- [ ] Try to submit empty form
- [ ] Verify required fields show validation messages
- [ ] Enter invalid email format
- [ ] Verify email validation works
- [ ] Verify phone validation works

**Test Case 2.3: Form Submission - Valid Data**
- [ ] Fill in all required fields:
  - First Name: "John"
  - Last Name: "Doe"
  - Email: "john.doe@example.com"
  - Phone: "01712345678"
- [ ] Select "Bachelor Degree" from Applying For
- [ ] Select a course from Interested Course dropdown
- [ ] Select a semester
- [ ] Submit the form
- [ ] Verify success message displays
- [ ] Check that data is saved in database with:
  - lead_source = "Direct Online"
  - lead_status = "Fresh"
  - interested_course_id matches selected course

**SQL to verify:**
```sql
SELECT id, first_name, last_name, email, lead_source, lead_status, 
       interested_course_id, created_at 
FROM leads 
WHERE email = 'john.doe@example.com' 
ORDER BY created_at DESC LIMIT 1;

-- Verify course relationship
SELECT l.first_name, l.last_name, c.course_title, c.department
FROM leads l
LEFT JOIN courses c ON l.interested_course_id = c.id
WHERE l.email = 'john.doe@example.com'
ORDER BY l.created_at DESC LIMIT 1;
```

**Test Case 2.4: Degree-Specific Fields**
- [ ] Select "Bachelor Degree"
- [ ] Verify SSC GPA and HSC GPA fields appear
- [ ] Verify Bachelor Subject and CGPA fields do NOT appear
- [ ] Select "Master Degree"
- [ ] Verify all education fields appear (SSC, HSC, Bachelor Subject, CGPA)
- [ ] Clear selection
- [ ] Verify all education fields hide

**Test Case 2.5: Error Handling**
- [ ] Test with existing email (should still create duplicate lead)
- [ ] Test with very long names (should truncate or validate)
- [ ] Test with SQL injection attempts in fields
- [ ] Test with XSS attempts in text fields
- [ ] Verify all inputs are sanitized

### 3. Internal Lead Management Testing

**Test Case 3.1: View Lead with Interested Course**
- [ ] Login to the CRM system
- [ ] Navigate to Lead Management
- [ ] Find the lead created through public form
- [ ] Click to view lead details
- [ ] Verify "Interested Course" displays in Education Information card
- [ ] Verify course title and department are shown
- [ ] Verify lead_source shows "Direct Online"
- [ ] Verify lead_status shows "Fresh"

**Test Case 3.2: Add Lead with Interested Course**
- [ ] Click "Add New Lead" button
- [ ] Fill in required personal information
- [ ] Navigate to Education tab
- [ ] Verify "Interested Course" dropdown is visible
- [ ] Verify it's populated with courses from course management
- [ ] Select a course
- [ ] Submit the form
- [ ] Verify lead is created successfully
- [ ] View the lead details and verify course is saved

**Test Case 3.3: Edit Lead - Add Interested Course**
- [ ] Find a lead without an interested course
- [ ] Click edit button
- [ ] Navigate to Education tab
- [ ] Select a course from "Interested Course" dropdown
- [ ] Save changes
- [ ] Verify success message
- [ ] Refresh lead details
- [ ] Verify interested course now displays

**Test Case 3.4: Edit Lead - Change Interested Course**
- [ ] Find a lead with an interested course
- [ ] Click edit button
- [ ] Navigate to Education tab
- [ ] Verify current course is pre-selected
- [ ] Change to a different course
- [ ] Save changes
- [ ] View lead details
- [ ] Verify new course displays
- [ ] Check edit history to verify change was tracked

**Test Case 3.5: Edit Lead - Remove Interested Course**
- [ ] Find a lead with an interested course
- [ ] Click edit button
- [ ] Navigate to Education tab
- [ ] Select empty option in "Interested Course" dropdown
- [ ] Save changes
- [ ] View lead details
- [ ] Verify "Interested Course" no longer displays

### 4. Data Integrity Testing

**Test Case 4.1: Foreign Key Constraint**
- [ ] Attempt to delete a course that is referenced by a lead
- [ ] Verify the course cannot be deleted OR
- [ ] Verify interested_course_id is set to NULL (based on ON DELETE SET NULL)

**Test Case 4.2: Course Updates**
- [ ] Update a course name in course management
- [ ] View leads with that interested course
- [ ] Verify updated course name displays

**Test Case 4.3: Change Tracking**
- [ ] Edit a lead and change the interested course
- [ ] View lead edit history
- [ ] Verify the change is tracked with:
  - Field name: "interested_course_id"
  - Old value: previous course ID
  - New value: new course ID
  - Edited by: current user
  - Timestamp

### 5. Permission & Security Testing

**Test Case 5.1: Public Form Access**
- [ ] Access public form while logged out
- [ ] Verify it works
- [ ] Access public form while logged in
- [ ] Verify it still works (doesn't require logout)

**Test Case 5.2: SQL Injection**
- [ ] Try SQL injection in interested_course_id field
- [ ] Example: `1' OR '1'='1`
- [ ] Verify input is properly sanitized/validated

**Test Case 5.3: XSS Prevention**
- [ ] Try XSS in course title display
- [ ] Verify HTML is properly escaped
- [ ] Example: Select a course with `<script>alert('XSS')</script>` in title
- [ ] Verify script doesn't execute when viewing lead

### 6. Performance Testing

**Test Case 6.1: Course Dropdown Performance**
- [ ] Add 100+ courses to the system
- [ ] Open Add Lead form
- [ ] Measure time to load course dropdown
- [ ] Should load within 1-2 seconds
- [ ] Repeat for Edit Lead form

**Test Case 6.2: Public Form Load Time**
- [ ] Measure page load time
- [ ] Should load within 2 seconds on standard connection
- [ ] Check on mobile device
- [ ] Should be responsive

### 7. Integration Testing

**Test Case 7.1: Course Management Integration**
- [ ] Add a new course in Course Management
- [ ] Immediately check Add Lead form
- [ ] Verify new course appears in dropdown
- [ ] Test on public form
- [ ] Verify new course appears

**Test Case 7.2: Multi-tab Workflow**
- [ ] Open lead in one tab
- [ ] Open same lead in another tab for editing
- [ ] Change interested course in one tab
- [ ] Save in first tab
- [ ] Try to save in second tab
- [ ] Verify data consistency

### 8. Reporting & Analytics Testing

**Test Case 8.1: Lead Source Statistics**
- [ ] Submit 5 leads through public form
- [ ] View lead statistics/reports
- [ ] Verify "Direct Online" count increases by 5

**Test Case 8.2: Course Interest Reporting**
- [ ] Submit leads interested in different courses
- [ ] Generate report of popular courses
- [ ] Verify counts are accurate

## Post-Deployment Testing

### 1. Production Smoke Tests
- [ ] Verify public form is accessible at production URL
- [ ] Submit one test lead
- [ ] Verify it appears in production system
- [ ] Delete test lead after verification

### 2. Monitoring
- [ ] Check server logs for errors
- [ ] Monitor database for any deadlocks or slow queries
- [ ] Check form submission success rate
- [ ] Monitor for spam submissions

## Bug Report Template

If you find any issues during testing, report them using this format:

```
**Bug Title:** [Short description]
**Severity:** [Critical / High / Medium / Low]
**Steps to Reproduce:**
1. 
2. 
3. 

**Expected Result:**

**Actual Result:**

**Screenshot:** [Attach if applicable]

**Environment:**
- Browser: 
- Device: 
- User Role: 
```

## Test Sign-Off

| Test Category | Status | Tester | Date | Notes |
|--------------|--------|--------|------|-------|
| Database Migration | ⬜ Not Started | | | |
| Public Form - Basic | ⬜ Not Started | | | |
| Public Form - Validation | ⬜ Not Started | | | |
| Internal Add Lead | ⬜ Not Started | | | |
| Internal Edit Lead | ⬜ Not Started | | | |
| Data Integrity | ⬜ Not Started | | | |
| Security | ⬜ Not Started | | | |
| Performance | ⬜ Not Started | | | |

**Legend:**
- ⬜ Not Started
- 🔄 In Progress
- ✅ Passed
- ❌ Failed
- ⚠️ Passed with Issues

---
**Test Plan Version:** 1.0
**Created:** 2026-01-19
**Last Updated:** 2026-01-19
