<?php
require_once 'config/config.php';

session_start();

// Initialize messages
$success = $error = '';

// Check if token is provided in the URL
if (isset($_GET['token'])) {
    $token = htmlspecialchars($_GET['token']);

    // Handle form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];

        if ($new_password === $confirm_password) {
            // Hash the new password
            $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);

            try {
                // Check if the token is valid
                $stmt = $conn->prepare("SELECT * FROM users WHERE reset_token = :token AND reset_token_expiry > NOW() LIMIT 1");
                $stmt->execute(['token' => $token]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($user) {
                    // Update the password and clear the reset token
                    $stmt = $conn->prepare("UPDATE users SET password = :password, reset_token = NULL, reset_token_expiry = NULL WHERE id = :id");
                    $stmt->execute([
                        'password' => $hashed_password,
                        'id' => $user['id']
                    ]);

                    $success = "Your password has been reset successfully. <a href='index.php'>Login now</a>.";
                    header("refresh:3;url=index.php"); // Redirect after 3 seconds
                } else {
                    $error = "Invalid or expired token.";
                }
            } catch (PDOException $e) {
                $error = "An error occurred. Please try again.";
            }
        } else {
            $error = "Passwords do not match.";
        }
    }
} else {
    $error = "Invalid password reset request.";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Reset Password | PUMIS</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="assets/images/favicon.ico">
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" id="app-style" />
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
</head>

<body class="authentication-bg">
    <div class="account-pages pt-2 pt-sm-5 pb-4 pb-sm-5 position-relative">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="fs-20">Reset Your Password</h4>
                            <p class="text-muted">Enter your new password below.</p>

                            <!-- Display success or error message -->
                            <?php if ($success): ?>
                                <div class="alert alert-success">
                                    <?php echo htmlspecialchars_decode($success); ?>
                                </div>
                            <?php elseif ($error): ?>
                                <div class="alert alert-danger">
                                    <?php echo htmlspecialchars($error); ?>
                                </div>
                            <?php endif; ?>

                            <!-- Reset Password Form -->
                            <form method="POST" action="">
                                <div class="mb-3">
                                    <label for="new_password" class="form-label">New Password</label>
                                    <input class="form-control" type="password" id="new_password" name="new_password" required placeholder="Enter new password">
                                </div>
                                <div class="mb-3">
                                    <label for="confirm_password" class="form-label">Confirm Password</label>
                                    <input class="form-control" type="password" id="confirm_password" name="confirm_password" required placeholder="Confirm new password">
                                </div>
                                <button class="btn btn-primary w-100" type="submit">Reset Password</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer class="footer footer-alt fw-medium">
        <span class="text-dark-emphasis">
        <script>document.write(new Date().getFullYear())</script> © Developed by Technofic Lab LTD
        </span>
    </footer>
    <script src="assets/js/vendor.min.js"></script>
    <script src="assets/js/app.min.js"></script>
</body>

</html>
