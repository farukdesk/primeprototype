# User Management Reconstruction - Database Migration Required

## Overview
This migration updates the user management system to:
1. Fix SQL errors in user creation/update
2. Rename "Staff" user type to "Counselor" throughout the system
3. Fix column name mismatches (phone -> mobile_number)

## Migration Steps

### IMPORTANT: Run this migration BEFORE using the updated code

1. **Backup your database** before running any migrations:
   ```bash
   mysqldump -u username -p database_name > backup_$(date +%Y%m%d).sql
   ```

2. **Run the migration SQL file**:
   ```bash
   mysql -u username -p database_name < database_migration_staff_to_counselor.sql
   ```

   Or through phpMyAdmin:
   - Open phpMyAdmin
   - Select your database
   - Go to the "SQL" tab
   - Copy and paste the contents of `database_migration_staff_to_counselor.sql`
   - Click "Go"

3. **Verify the migration**:
   ```sql
   -- Check that all Staff users have been converted to Counselor
   SELECT user_type, COUNT(*) as count FROM users GROUP BY user_type;
   
   -- Expected result: No 'Staff', should see 'Counselor' instead
   ```

## What Changed

### Database Schema Changes
- `users.user_type` enum: 'Staff' → 'Counselor'
- All existing users with type 'Staff' are updated to 'Counselor'

### Code Changes
- Fixed SQL subquery error in user creation (can't reference same table in INSERT)
- Updated all references from `phone` to `mobile_number` to match actual database column
- Updated all user type checks from 'Staff' to 'Counselor' across:
  - User management views and controllers
  - Lead management
  - Call logs
  - Campus/Office visits
  - Company management

## Files Modified
- `app/models/user_model.php` - Fixed SQL errors and column names
- `app/views/user_management.php` - Updated UI labels and form fields
- `app/controllers/lead_management_controller.php` - Updated user type checks
- `app/controllers/call_logs_controller.php` - Updated permissions
- `app/controllers/campus_visits_controller.php` - Updated permissions
- `app/controllers/office_visits_controller.php` - Updated permissions
- `app/models/lead_model.php` - Updated queries for counselor users
- `app/models/call_log_model.php` - Updated queries for counselor users
- `app/views/Company_Management_View.php` - Updated user distribution display

## Testing After Migration

1. **Test User Creation**:
   - Go to User Management
   - Click "Add New User"
   - Fill in all fields
   - Select "Counselor" as user type
   - Verify user is created successfully

2. **Test User Update**:
   - Edit an existing user
   - Update the phone number
   - Verify changes are saved

3. **Test Counselor Functionality**:
   - Login as a Counselor user
   - Verify all permissions work correctly
   - Check lead assignment and management

## Rollback (If Needed)

If you need to rollback the changes:

```sql
-- Rollback: Change Counselor back to Staff
UPDATE users SET user_type = 'Staff' WHERE user_type = 'Counselor';

ALTER TABLE users 
MODIFY COLUMN user_type ENUM('Super Admin','Admin','Manager','Staff','Agent') 
COLLATE utf8mb4_unicode_ci NOT NULL;
```

Then revert the code changes using git:
```bash
git checkout HEAD~1
```

## Support

If you encounter any issues:
1. Check the database migration completed successfully
2. Verify no 'Staff' entries remain in the users table
3. Clear any application caches
4. Review error logs for specific error messages
