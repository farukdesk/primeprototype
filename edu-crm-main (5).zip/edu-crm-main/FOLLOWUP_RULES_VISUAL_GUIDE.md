# Follow-up Rules Visual Guide

## Status-Based Follow-up Timeline

```
Fresh Status
═══════════════════════════════════════════════════════════════
Day 0: Lead created/status changed to Fresh
       └─→ Follow-up DUE: Same Day (Day 0)
       └─→ If missed: OVERDUE from Day 1


Unable to Reach (once/twice/trice)
═══════════════════════════════════════════════════════════════
Day 0: Status changed to "Unable to reach"
Day 1: Follow-up DUE
       └─→ If missed: OVERDUE from Day 2


Regular Call Statuses (1st call, 2nd call, 3rd call, Will visit office)
═══════════════════════════════════════════════════════════════
Day 0: Status changed
Day 1: (waiting)
Day 2: Follow-up DUE
       └─→ If missed: OVERDUE from Day 3


Dead / Admitted Statuses
═══════════════════════════════════════════════════════════════
No follow-up tracking
next_followup_date = NULL
No alerts shown
```

## Alert Badge System

### Fresh Status Alert Progression:
```
Day 0 (Status Change) ──→ [YELLOW] Due Today
Day 1+ (If missed)    ──→ [RED] X days overdue
```

### Unable to Reach Alert Progression:
```
Day 0 (Status Change) ──→ [BLUE] Scheduled (1 day)
Day 1                 ──→ [YELLOW] Due Today
Day 2+ (If missed)    ──→ [RED] X days overdue
```

### Regular Call Statuses Alert Progression:
```
Day 0 (Status Change) ──→ [BLUE] Scheduled (2 days)
Day 1                 ──→ [BLUE] Scheduled (1 day)
Day 2                 ──→ [YELLOW] Due Today
Day 3+ (If missed)    ──→ [RED] X days overdue
```

## Examples

### Example 1: Fresh Lead
```
Monday 9 AM:    Lead created with "Fresh" status
                next_followup_date = Monday (same day)
                Alert: [YELLOW] "Follow-up due today!"

Monday 5 PM:    If no action taken yet
                Alert: Still [YELLOW] "Follow-up due today!"

Tuesday:        If still no action
                Alert: [RED] "1 day overdue"
```

### Example 2: Unable to Reach Once
```
Monday 2 PM:    Status changed to "Unable to reach once"
                next_followup_date = Tuesday
                Alert: [BLUE] "Scheduled for tomorrow"

Tuesday:        Follow-up due
                Alert: [YELLOW] "Follow-up due today!"

Wednesday:      If missed
                Alert: [RED] "1 day overdue"
```

### Example 3: 1st Call
```
Monday:         Status changed to "1st call"
                next_followup_date = Wednesday (2 days later)
                Alert: [BLUE] "Scheduled for Jan 21"

Tuesday:        Waiting period
                Alert: [BLUE] "Scheduled for tomorrow"

Wednesday:      Follow-up due
                Alert: [YELLOW] "Follow-up due today!"

Thursday:       If missed
                Alert: [RED] "1 day overdue"
```

## Quick Reference Table

| Lead Status                | Follow-up Gap | Due Date Calculation |
|---------------------------|---------------|---------------------|
| Fresh                     | 0 days        | Same day            |
| Unable to reach once      | 1 day         | Tomorrow            |
| Unable to reach twice     | 1 day         | Tomorrow            |
| Unable to reach trice     | 1 day         | Tomorrow            |
| 1st call                  | 2 days        | Day after tomorrow  |
| 2nd call                  | 2 days        | Day after tomorrow  |
| 3rd call                  | 2 days        | Day after tomorrow  |
| Will visit office         | 2 days        | Day after tomorrow  |
| Dead                      | N/A           | No tracking         |
| Admitted                  | N/A           | No tracking         |

## Business Logic

The system automatically:
1. ✅ Updates `next_followup_date` when status changes
2. ✅ Sets `last_status_change_date` to current timestamp
3. ✅ Updates `last_followup_action_date` on ANY lead update
4. ✅ Calculates days overdue dynamically
5. ✅ Shows appropriate alert badges based on status
6. ✅ Filters leads by follow-up status (Today/Overdue buttons)
7. ✅ Excludes Dead/Admitted from all follow-up tracking

## What This Means for Staff

### Fresh Leads (High Priority):
- **Action Required:** Contact the same day
- **Why:** Fresh leads are hot - immediate response shows professionalism
- **Alert:** Yellow badge appears immediately, red if missed

### Unable to Reach (Persistent Attempts):
- **Action Required:** Try again tomorrow (1 day gap)
- **Why:** Short interval maintains momentum while not overwhelming lead
- **Alert:** Yellow badge next day, red if missed

### Regular Calls (Standard Follow-up):
- **Action Required:** Follow up in 2 days
- **Why:** Gives lead time to think/prepare while maintaining engagement
- **Alert:** Blue until due, yellow on due date, red if missed

### Final Statuses (No Action):
- **Dead:** Lead is not interested - no further follow-up
- **Admitted:** Student admitted - moved to student management
