# EDU-CRM Restructuring Guide

## Overview
This guide documents the major restructuring of the EDU-CRM system to support a **single university** managing their leads, instead of multiple universities/colleges.

## Key Changes

### 1. Terminology Updates
- **Office Visit** → **Campus Visit**
- **Intakes** → **Semesters**
- **Office Location** → **Campus Location**

### 2. Database Changes
The database schema has been updated to reflect these changes:
- `intakes` table renamed to `semesters`
- `lead_intakes` table renamed to `lead_semesters`
- `office_visit_date` field renamed to `campus_visit_date`
- `assigned_office` field renamed to `assigned_campus`
- Added `degree_type` column to `courses` table
- Updated lead source and status values

### 3. New Management Modules
Four new management sections have been added:
1. **Semester Management** - Manage academic semesters
2. **Course Management** - Manage university courses
3. **Agent Management** - View and manage agents
4. **User Management** - View and manage all users

### 4. Removed Features
- University/College selection from lead forms
- University filter from lead management
- Office Location Summary dashboard card
- Multi-university support

## Installation Instructions

### Prerequisites
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Access to the database
- Backup of current database (IMPORTANT!)

### Step 1: Backup Your Database
```bash
# Create a backup before running migration
mysqldump -u your_username -p your_database > backup_$(date +%Y%m%d_%H%M%S).sql
```

### Step 2: Apply Database Migration
```bash
# Connect to your database
mysql -u your_username -p your_database < database_migration_single_university.sql
```

Or use phpMyAdmin:
1. Open phpMyAdmin
2. Select your database
3. Go to "SQL" tab
4. Copy and paste the contents of `database_migration_single_university.sql`
5. Click "Go"

### Step 3: Verify Migration
Run these verification queries:
```sql
-- Check if tables were renamed
SHOW TABLES LIKE 'semesters';
SHOW TABLES LIKE 'lead_semesters';

-- Check if columns were updated
DESCRIBE leads;  -- Look for campus_visit_date and assigned_campus
DESCRIBE courses;  -- Look for degree_type

-- Verify data migration
SELECT DISTINCT lead_source FROM leads;
SELECT DISTINCT lead_status FROM leads;
SELECT DISTINCT degree_type FROM courses;
```

### Step 4: Clear Cache (if applicable)
```bash
# Clear any PHP caches
php artisan cache:clear  # If using Laravel
# Or restart PHP-FPM
sudo service php-fpm restart
```

### Step 5: Update File Permissions
Ensure proper permissions:
```bash
chmod -R 755 app/views/
chmod -R 755 app/controllers/
```

## Testing Checklist

### Terminology Verification
- [ ] Check dashboard for "Campus Visits" instead of "Office Visits"
- [ ] Verify "Semesters" appears instead of "Intakes"
- [ ] Confirm stats cards show 2 columns (not 3)
- [ ] Check all forms use "Campus" terminology

### Lead Management
- [ ] Create a new lead
- [ ] Edit an existing lead
- [ ] Delete a lead
- [ ] Filter leads by various criteria
- [ ] Verify no university filter appears
- [ ] Check interests show only courses and semesters

### Campus Visits
- [ ] View campus visits schedule
- [ ] Mark a visit as attended
- [ ] Filter visits by date
- [ ] Verify terminology is "Campus" not "Office"

### Semester Management (Admin/Super Admin only)
- [ ] Create a new semester
- [ ] Edit a semester
- [ ] View semester details
- [ ] Try to delete a semester with leads (should show warning)
- [ ] Delete a semester without leads

### Agent Management
- [ ] View list of all agents
- [ ] Check lead counts for each agent
- [ ] Verify agent status displays correctly

### User Management
- [ ] View list of all users
- [ ] Filter by user type
- [ ] Filter by status
- [ ] Verify all user types display correctly

### Permissions
- [ ] Login as Super Admin - verify access to all sections
- [ ] Login as Admin - verify access to management sections
- [ ] Login as Staff - verify limited access
- [ ] Login as Agent - verify agent-specific access

## Navigation Structure

```
Dashboard
├── Lead Management
│   ├── Manage Leads
│   ├── Call Logs
│   └── Campus Visits
├── System Management
│   ├── Semester Management (Admin/Super Admin only)
│   ├── Course Management (Admin/Super Admin only)
│   ├── Agent Management (Admin/Super Admin only)
│   └── User Management (Admin/Super Admin only)
├── Company Settings
└── User Profile
```

## File Changes Summary

### New Files
- `app/views/semester_management.php` - Semester CRUD interface
- `app/views/agent_management.php` - Agent listing
- `app/views/user_management.php` - User listing
- `app/controllers/campus_visits_controller.php` - Renamed from office_visits
- `app/views/campus_visits_view.php` - Renamed from office_visits
- `database_migration_single_university.sql` - Database migration script
- `RESTRUCTURING_GUIDE.md` - This file

### Modified Files
- `partials/sidebar.php` - Updated navigation menu
- `dashboard.php` - Added new allowed pages
- `app/views/lead_management_view.php` - Major updates
- `app/views/partials/*.php` - Terminology updates
- `app/controllers/lead_management_controller.php` - Terminology updates
- `app/models/lead_model.php` - Database field updates
- `ajax/get_lead_data.php` - Terminology updates

### Files to Remove (Optional)
These files are now obsolete but kept for backward compatibility:
- `app/controllers/office_visits_controller.php` - Replaced by campus_visits_controller.php
- `app/views/office_visits_view.php` - Replaced by campus_visits_view.php

## Rollback Instructions

If you need to rollback the changes:

### 1. Restore Database Backup
```bash
mysql -u your_username -p your_database < backup_YYYYMMDD_HHMMSS.sql
```

### 2. Restore Code
```bash
git checkout main  # or your previous branch
```

## Known Issues & Limitations

1. **University Data**: Existing university data is preserved but not actively used in forms
2. **Old URLs**: Bookmarks to `/dashboard.php?page=office_visits_view` will need to be updated
3. **Reports**: Any custom reports referencing old field names will need updates

## Support & Troubleshooting

### Common Issues

**Issue**: "Page not found" error when accessing new pages
**Solution**: Ensure `dashboard.php` includes the new pages in `$allowed_pages` array

**Issue**: Database migration fails
**Solution**: Check that you have ALTER TABLE permissions and the tables exist

**Issue**: Can't access management sections
**Solution**: Verify user account has Admin or Super Admin role

**Issue**: Old terminology still appears
**Solution**: Clear browser cache and PHP cache

## Future Enhancements

Potential improvements for future versions:
- Add bulk actions for semester management
- Add course degree type reporting
- Add agent performance dashboard
- Add user activity logs
- Add export functionality for all management sections

## Developer Notes

### Adding New Semesters
```php
// Example: Adding a semester programmatically
$stmt = $conn->prepare("INSERT INTO semesters (name, start_date, end_date, status, created_by) VALUES (?, ?, ?, ?, ?)");
$stmt->execute(['Fall 2026', '2026-09-01', '2026-12-31', 'Active', $user_id]);
```

### Querying Lead Semesters
```php
// Get all semesters for a lead
$stmt = $conn->prepare("
    SELECT s.* FROM semesters s
    INNER JOIN lead_semesters ls ON s.id = ls.semester_id
    WHERE ls.lead_id = ?
");
$stmt->execute([$lead_id]);
```

### Campus Visit Queries
```php
// Get all campus visits for today
$stmt = $conn->prepare("
    SELECT * FROM leads
    WHERE DATE(campus_visit_date) = CURDATE()
    AND lead_status = 'Will visit campus'
");
```

## Contact & Support

For questions or issues related to this restructuring:
- Create an issue in the GitHub repository
- Contact the development team
- Refer to the main project documentation

---

**Last Updated**: 2026-01-14
**Version**: 2.0.0
**Author**: System Restructuring Team
