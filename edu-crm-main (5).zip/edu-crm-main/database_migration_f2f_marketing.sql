-- Migration to add F2F Marketing lead source
-- Date: 2026-01-26

-- WARNING: This migration modifies an ENUM column which may lock the table briefly.
-- Test in development environment first before running in production.

-- Add F2F Marketing to the lead_source ENUM
ALTER TABLE leads 
MODIFY COLUMN lead_source ENUM(
    'Direct Online',
    'Direct Campus Visit',
    'Agent',
    'F2F Marketing'
) COLLATE utf8mb4_unicode_ci NOT NULL;

-- Rollback (if needed):
-- ALTER TABLE leads 
-- MODIFY COLUMN lead_source ENUM(
--     'Direct Online',
--     'Direct Campus Visit',
--     'Agent'
-- ) COLLATE utf8mb4_unicode_ci NOT NULL;
-- Note: Rollback will fail if any leads already have 'F2F Marketing' as their source.
