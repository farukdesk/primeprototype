-- Database Migration for Course Management Restructuring
-- Date: 2026-01-14
-- Purpose: Simplify courses table to only have course_title, department, and credit
-- WARNING: This migration will DELETE all existing course data!
-- 
-- IMPORTANT: Before running this migration:
-- 1. Backup your database: mysqldump -u user -p database > backup.sql
-- 2. OR manually backup the courses table: CREATE TABLE courses_backup AS SELECT * FROM courses;
-- 3. Verify the backup was successful before proceeding

-- Optional: Uncomment the line below to create a backup
-- CREATE TABLE courses_backup AS SELECT * FROM courses;

-- Drop existing courses table and recreate with new structure
DROP TABLE IF EXISTS `courses`;

-- Create new simplified courses table
CREATE TABLE `courses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `course_title` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `credit` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_department` (`department`),
  KEY `idx_created_by` (`created_by`),
  CONSTRAINT `fk_courses_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_courses_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert sample data
INSERT INTO `courses` (`course_title`, `department`, `credit`, `created_by`) VALUES
('Introduction to Computer Science', 'Computer Science', 3, NULL),
('Data Structures and Algorithms', 'Computer Science', 4, NULL),
('Database Management Systems', 'Computer Science', 3, NULL),
('Introduction to Business', 'Business Administration', 3, NULL),
('Financial Accounting', 'Business Administration', 3, NULL),
('Marketing Principles', 'Business Administration', 3, NULL),
('Organic Chemistry', 'Chemistry', 4, NULL),
('General Physics', 'Physics', 4, NULL),
('Calculus I', 'Mathematics', 4, NULL),
('English Literature', 'English', 3, NULL);
