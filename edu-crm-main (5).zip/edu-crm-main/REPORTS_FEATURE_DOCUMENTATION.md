# Reports Feature Documentation

## Overview
The Reports feature provides comprehensive reporting capabilities for the EDU-CRM system. Currently includes the **Top Sheet Report** for tracking student admissions.

## Features

### Top Sheet Report
**Location:** Dashboard → Reports → Top Sheet

**Purpose:** Generate admission statement of enrollment showing admitted students grouped by program.

**Access Level:** Admin and Super Admin only

#### Features:
1. **Date Range Filtering**
   - Filter admissions by custom date ranges
   - From Date and To Date selectors
   - Quick reset to view all admissions

2. **Data Display**
   - **Previous Day**: Admissions before the selected "To Date"
   - **Today**: Admissions on the selected "To Date"
   - **Total**: Total admissions in the selected range
   - **Grand Total**: Sum of all programs

3. **PDF Export**
   - Print/Save as PDF using browser's native print function
   - Print-optimized layout (hides filters and action buttons)
   - Includes university header, semester, batch, and date information

#### Report Structure:
```
PRIME UNIVERSITY
Address: 114/116, Mazar Road, Mirpur-1, Dhaka-1216
Phone: 0241002435

Admission statement of enrollment of students

Spring Semester – 2026
Batch: 68th and 14th
Date: 23rd January 2026
Date Range: [if filtered]

Admission in Spring-2026
+-------------------------------------------+---------------+-------+-------+
| Program                                   | Previous Day  | Today | Total |
+-------------------------------------------+---------------+-------+-------+
| BBA                                       | 99            | 01    | 100   |
| MBA 69 cr.                               | 09            | –     | 19    |
| ... (all programs)                       |               |       |       |
+-------------------------------------------+---------------+-------+-------+
| Grand Total                              | 510           | 10    | 520   |
+-------------------------------------------+---------------+-------+-------+
```

## Technical Implementation

### Database Schema
- **Primary Table**: `leads` (where `lead_status = 'Admitted'`)
- **Joined Tables**: 
  - `lead_courses` - Links leads to courses
  - `courses` - Program/course information
  - `companies` - University/company details
  - `semesters` - Semester information

### Key Files
1. **View**: `app/views/top_sheet_report.php`
   - User interface and report rendering
   - Date filter form
   - Print/PDF export buttons

2. **Controller**: `app/controllers/reports_controller.php`
   - Business logic
   - Data retrieval coordination
   - Error handling

3. **Model**: `app/models/reports_model.php`
   - Database queries
   - Data aggregation
   - Report metadata generation

4. **Routing**:
   - Route: `dashboard.php?page=top_sheet_report`
   - Added to `$allowed_pages` in `dashboard.php`

5. **Navigation**: `partials/sidebar.php`
   - Reports menu added to sidebar
   - Collapsible submenu with Top Sheet option

### Data Flow
1. User accesses `dashboard.php?page=top_sheet_report`
2. Permission check (Admin/Super Admin)
3. Get filter parameters (date_from, date_to)
4. Controller fetches data from model with filters
5. Model executes SQL query:
   - Groups by program name
   - Counts admissions by date
   - Calculates Previous Day, Today, Total
6. View renders report with company header
7. JavaScript handles print/PDF export

### SQL Query Logic
```sql
SELECT 
    COALESCE(c.course_title, l.applying_for, 'Uncategorized') as program_name,
    l.applying_for as degree_type,
    COUNT(CASE WHEN DATE(l.updated_at) < :today THEN 1 END) as previous_day,
    COUNT(CASE WHEN DATE(l.updated_at) = :today THEN 1 END) as today,
    COUNT(*) as total
FROM leads l
LEFT JOIN lead_courses lc ON l.id = lc.lead_id
LEFT JOIN courses c ON lc.course_id = c.id
WHERE l.company_id = :company_id 
AND l.lead_status = 'Admitted'
[AND DATE(l.updated_at) >= :date_from]
[AND DATE(l.updated_at) <= :date_to]
GROUP BY program_name, degree_type 
ORDER BY total DESC
```

## Usage Instructions

### Viewing the Report
1. Log in as Admin or Super Admin
2. Click "Reports" in the left sidebar
3. Click "Top Sheet" from the submenu
4. Report displays with current semester data

### Filtering by Date Range
1. Enter "From Date" (start of range)
2. Enter "To Date" (end of range)
3. Click "Apply Filter"
4. Report updates to show filtered data
5. Click "Reset" to clear filters

### Exporting to PDF
**Method 1: Print to PDF**
1. Click "Print / Save as PDF" button
2. In print dialog, select "Save as PDF"
3. Choose location and save

**Method 2: Download PDF**
1. Click "Download PDF" button
2. Opens print dialog
3. Select "Save as PDF" and download

### Print Optimization
When printing/exporting:
- Date filters are hidden
- Action buttons are hidden
- Page layout optimizes for paper format
- Margins adjusted for clean output

## Security Features

1. **Permission Control**: Only Admin and Super Admin can access
2. **Input Sanitization**: All user inputs are sanitized with `htmlspecialchars()`
3. **SQL Injection Prevention**: PDO prepared statements used throughout
4. **Session Validation**: Checks for valid user session
5. **XSS Protection**: Output escaping on all dynamic content

## Future Enhancements

Potential additions to the Reports module:
1. Additional report types (enrollment trends, conversion rates, etc.)
2. Advanced filters (by semester, program, campus)
3. Server-side PDF generation (TCPDF/MPDF)
4. Export to Excel/CSV formats
5. Scheduled report generation
6. Email delivery of reports
7. Dashboard widgets with report summaries

## Troubleshooting

### Report shows no data
- Check that students have `lead_status = 'Admitted'`
- Verify date range includes admission dates
- Check that students are assigned to courses via `lead_courses` table

### Permission denied
- User must be Admin or Super Admin
- Check `user_type` in users table
- Verify active session

### PDF not displaying company info
- Check `companies` table has data for the user's `company_id`
- Verify `company_name`, `address`, `phone` fields are populated

### Programs not showing
- Verify `lead_courses` entries exist
- Check `courses` table has program data
- Ensure joins are working correctly

## Maintenance Notes

### When adding new programs
Programs are automatically pulled from the `courses` table. No code changes needed.

### When changing batch information
Currently hardcoded in `reports_model.php` line 93. Update this value or implement dynamic batch retrieval from database.

### When changing report header
Company information is pulled from `companies` table. Update company record in database.

### When adjusting date calculations
"Previous Day" and "Today" logic is in `reports_model.php`. The "Today" date uses the `date_to` parameter or current date if not specified.

## Version History

- **v1.0.0** (2026-01-26): Initial implementation
  - Top Sheet report
  - Date range filtering
  - Print to PDF functionality
  - Permission-based access control
