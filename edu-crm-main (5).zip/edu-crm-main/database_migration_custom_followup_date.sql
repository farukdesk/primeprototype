-- Migration to add custom follow-up date field
-- Date: 2026-01-26
-- Updated: Allow manual modification of next_followup_date

-- No database changes needed - we're using the existing next_followup_date column
-- Users can now manually set this field via the UI, and the system will still
-- auto-calculate it on status changes when not manually set.

-- This file is kept for documentation purposes but does not need to be executed.
