<?php
header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

require 'config/config.php';
require 'config/auth_check.php';

// Get user ID from session
$user_id = $_SESSION['user_id'];

// Determine the page to load
$page = isset($_GET['page']) ? $_GET['page'] : 'home';

// Allowed pages
$allowed_pages = ['home', 'user_profile', 'change-password', 'company_settings', 'my_subscription', 'subscription_plan', 'lead_management_view', 'call_logs_view', 'campus_visits_view', 'semester_management', 'course_management', 'agent_management', 'user_management', 'top_sheet_report'];

// Validate the page
if (!in_array($page, $allowed_pages)) {
    $page = 'home'; // Default to home
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Dashboard | PUMIS</title>
    <?php include 'partials/header.php'; ?>
</head>
<body>
    <div class="wrapper">
        <?php include 'partials/topbar.php'; ?>
        <?php include 'partials/sidebar.php'; ?>

        <div class="content-page">
            <div class="content">
                <div class="container-fluid">
                    <?php
                    // Load the view dynamically
                    $file_path = "app/views/{$page}.php";
                    if (file_exists($file_path)) {
                        include $file_path;
                    } else {
                        echo "<h4 class='text-danger'>Error: View file not found for page '{$page}'.</h4>";
                    }
                    ?>
                </div>
            </div>

            <?php include 'partials/footer.php'; ?>
        </div>
    </div>
</body>
</html>
