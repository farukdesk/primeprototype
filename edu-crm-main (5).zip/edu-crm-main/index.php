<?php
// Optional security headers for enhanced protection
header("X-Frame-Options: SAMEORIGIN"); // Prevent clickjacking
header("X-XSS-Protection: 1; mode=block"); // Enable XSS protection
header("X-Content-Type-Options: nosniff"); // Prevent MIME type sniffing
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0"); // Disable caching
header("Pragma: no-cache"); // Disable caching
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>PUMIS - Prime University Management Information System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="PUMIS - Prime University Management Information System is a comprehensive ERP solution for university management." name="description" />
    <meta content="Md Omar Faruk" name="author" />

    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!-- Theme Config Js -->
    <script src="assets/js/config.js"></script>

    <!-- App css -->
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" id="app-style" />

    <!-- Icons css -->
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
</head>

<body class="authentication-bg position-relative">
    <div class="account-pages pt-2 pt-sm-5 pb-4 pb-sm-5 position-relative">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xxl-8 col-lg-10">
                    <div class="card overflow-hidden">
                        <div class="row g-0">
                            <div class="col-lg-6 d-none d-lg-block p-2">
                                <img src="https://pickardproperties.co.uk/wp-content/uploads/2023/05/graduation-caps-air-blue-sky.jpg" alt="" class="img-fluid rounded h-100">
                            </div>
                            <div class="col-lg-6">
                                <div class="d-flex flex-column h-100">
                                    <div class="auth-brand p-4">
                                        <a href="index.php" class="logo-light">
                                            <img src="https://www.primeuniversity.ac.bd/prime/assets/images/logo-dark.png" alt="logo" style="max-height: 80px; width: auto;">
                                        </a>
                                        <a href="index.php" class="logo-dark">
                                            <img src="https://www.primeuniversity.ac.bd/prime/assets/images/logo-dark.png" alt="logo" style="max-height: 80px; width: auto;">
                                        </a>
                                    </div>
                                    <div class="p-4 my-auto">
                                        <h4 class="fs-20">Sign In</h4>
                                        <p class="text-muted mb-3">Enter your email address and password to access your account.</p>

                                        <!-- Display error message if present -->
                                        <?php if (!empty($_GET['error'])): ?>
                                            <div class="alert alert-danger">
                                                <?php echo htmlspecialchars($_GET['error']); ?>
                                            </div>
                                        <?php endif; ?>

                                        <!-- Login form -->
                                        <form method="POST" action="login.php">
                                            <div class="mb-3">
                                                <label for="emailaddress" class="form-label">Email address</label>
                                                <input class="form-control" type="email" id="emailaddress" name="email" required placeholder="Enter your email" oninvalid="this.setCustomValidity('Please enter a valid email address')" oninput="setCustomValidity('')">
                                            </div>
                                            <div class="mb-3">
                                                <a href="forgot-password.php" class="text-muted float-end"><small>Forgot your password?</small></a>
                                                <label for="password" class="form-label">Password</label>
                                                <input class="form-control" type="password" id="password" name="password" required placeholder="Enter your password" oninvalid="this.setCustomValidity('Please enter your password')" oninput="setCustomValidity('')">
                                            </div>
                                            <div class="mb-3">
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input" id="checkbox-signin" name="remember_me">
                                                    <label class="form-check-label" for="checkbox-signin">Remember me</label>
                                                </div>
                                            </div>
                                            <div class="mb-0 text-start">
                                                <button class="btn btn-soft-primary w-100" type="submit"><i class="ri-login-circle-fill me-1"></i> <span class="fw-bold">Log In</span></button>
                                            </div>

                                            <div class="text-center mt-4">
                                                <p class="text-muted fs-16">Sign in with</p>
                                                <div class="d-flex gap-2 justify-content-center mt-3">
                                                    <a href="javascript: void(0);" class="btn btn-soft-primary"><i class="ri-facebook-circle-fill"></i></a>
                                                    <a href="javascript: void(0);" class="btn btn-soft-danger"><i class="ri-google-fill"></i></a>
                                                    <a href="javascript: void(0);" class="btn btn-soft-info"><i class="ri-twitter-fill"></i></a>
                                                    <a href="javascript: void(0);" class="btn btn-soft-dark"><i class="ri-github-fill"></i></a>
                                                </div>
                                            </div>
                                        </form>
                                        <!-- end form -->
                                    </div>
                                </div>
                            </div> <!-- end col -->
                        </div>
                    </div>
                </div>
            </div>
            <!--<div class="row">
                <div class="col-12 text-center">
                    <p class="text-dark-emphasis">Don't have an account? <a href="auth-register.html" class="text-dark fw-bold ms-1 link-offset-3 text-decoration-underline"><b>Sign up</b></a></p>
                </div>
            </div>-->
        </div>
    </div>
    <!-- end page -->

    <footer class="footer footer-alt fw-medium">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <span class="text-dark d-block">
                        <script>document.write(new Date().getFullYear())</script> © Powered by <strong>PUMIS</strong>
                    </span>
                    <span class="text-muted small">
                        Prime University Management Information System - Developed by <strong>Technofic Lab LTD</strong>
                    </span>
                </div>
            </div>
        </div>
    </footer>
    
    <!-- Vendor js -->
    <script src="assets/js/vendor.min.js"></script>
    <script src="assets/js/app.min.js"></script>
</body>

</html>