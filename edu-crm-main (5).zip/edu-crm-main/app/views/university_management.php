<?php
/**
 * University Management View
 * Created on: 2025-04-28
 * Created by: farukdesk
 */

require_once __DIR__ . '/../../app/controllers/university_management_controller.php';

// Initialize controller
$universityController = new UniversityManagementController($conn);

// Check permissions
if (!$universityController->hasPermission()) {
    header("Location: /dashboard.php");
    exit();
}

$result = $universityController->handleRequest();
$success = $error = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create_university'])) {
        $result = $universityController->createUniversity($_POST);
        if ($result['status']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    } elseif (isset($_POST['update_university'])) {
        $result = $universityController->updateUniversity($_POST);
        if ($result['status']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    } elseif (isset($_POST['delete_university'])) {
        $result = $universityController->deleteUniversity($_POST['university_id']);
        if ($result['status']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    }
}

// Get filter parameters
$filters = [
    'search' => isset($_GET['search']) ? trim($_GET['search']) : '',
    'status' => isset($_GET['status']) ? trim($_GET['status']) : ''
];

// Get current page
$page = isset($_GET['p']) ? max(1, (int)$_GET['p']) : 1;

// Get universities with filters and pagination
$result = $universityController->handleRequest();

// Is user superadmin?
$isSuperAdmin = $universityController->isSuperAdmin();
?>

<div class="university-container">
    <!-- Page Header -->
    <div class="page-header">
        <h1 class="page-title">
            <i class="ri-building-4-line me-2"></i>
            University & College Management
        </h1>
        <?php if ($isSuperAdmin): ?>
        <button type="button" 
                class="btn btn-custom btn-primary" 
                data-bs-toggle="modal" 
                data-bs-target="#addUniversityModal">
            <i class="ri-add-circle-line me-1"></i>
            Add University/College
        </button>
        <?php endif; ?>
    </div>

    <!-- Alert Messages -->
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show d-flex align-items-center" role="alert">
            <i class="ri-checkbox-circle-line me-2"></i>
            <div class="flex-grow-1">
                <?php echo htmlspecialchars($success); ?>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show d-flex align-items-center" role="alert">
            <i class="ri-error-warning-line me-2"></i>
            <div class="flex-grow-1">
                <?php echo htmlspecialchars($error); ?>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Stats Cards -->
    <div class="row g-3 mb-4">
        <div class="col-md-6">
            <div class="card bg-light">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-subtitle mb-1 text-muted">Total Universities</h6>
                            <h3 class="card-title mb-0">
                                <?php echo number_format($result['stats']['total_universities'] ?? 0); ?>
                            </h3>
                        </div>
                        <div class="fs-1 text-primary">
                            <i class="ri-building-4-line"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card bg-light">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-subtitle mb-1 text-muted">Active Universities</h6>
                            <h3 class="card-title mb-0">
                                <?php echo number_format($result['stats']['active_universities'] ?? 0); ?>
                            </h3>
                        </div>
                        <div class="fs-1 text-success">
                            <i class="ri-check-double-line"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Filters Section -->
    <div class="filters-section">
        <form method="GET" class="row g-3">
            <input type="hidden" name="page" value="university_management">
            
            <!-- Search Input -->
            <div class="col-md-6">
                <div class="form-floating">
                    <input type="text" 
                           class="form-control" 
                           name="search" 
                           id="search"
                           placeholder="Search universities..."
                           value="<?php echo htmlspecialchars($filters['search']); ?>">
                    <label for="search">
                        <i class="ri-search-line me-1"></i>
                        Search Universities/Colleges
                    </label>
                </div>
            </div>

            <!-- Status Filter 
            <div class="col-md-4">
                <div class="form-floating">
                    <select class="form-select" name="status" id="status">
                        <option value="">All Status</option>
                        <option value="Active" <?php echo $filters['status'] === 'Active' ? 'selected' : ''; ?>>Active</option>
                        <option value="Inactive" <?php echo $filters['status'] === 'Inactive' ? 'selected' : ''; ?>>Inactive</option>
                    </select>
                    <label for="status">Status</label>
                </div>
            </div>-->

            <!-- Filter Actions  -->
            <div class="col-md-2 d-flex justify-content-end gap-2">
                <button type="submit" class="btn btn-custom btn-primary">
                    <i class="ri-filter-3-line me-1"></i>
                    Search
                </button>
                <a href="?page=university_management" 
                   class="btn btn-custom btn-outline-secondary" 
                   title="Reset Filters">
                    <i class="ri-refresh-line"></i>
                </a>
            </div>
        </form>
    </div>

    <!-- Universities Table Section -->
    <div class="table-section">
        <?php if (!empty($result['data'])): ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th scope="col" class="text-center">#</th>
                            <th scope="col">University/College</th>
                            <th scope="col">Website</th>
                            <th scope="col">Address</th>
                            <th scope="col" class="text-center">Status</th>
                            <?php if ($isSuperAdmin): ?>
                            <th scope="col" class="text-end">Actions</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($result['data'] as $university): ?>
                            <tr>
                                <td class="text-center">
                                    <span class="badge bg-light text-dark">
                                        <?php echo htmlspecialchars($university['id']); ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <?php if (!empty($university['logo'])): ?>
                                            <img src="<?php echo htmlspecialchars($university['logo']); ?>" 
                                                 alt="University Logo" 
                                                 class="rounded-circle"
                                                 width="40" 
                                                 height="40">
                                        <?php else: ?>
                                            <div class="rounded-circle bg-light d-flex align-items-center justify-content-center" 
                                                 style="width: 40px; height: 40px;">
                                                <i class="ri-building-4-line text-muted"></i>
                                            </div>
                                        <?php endif; ?>
                                        <div>
                                            <strong class="university-name">
                                                <?php echo htmlspecialchars($university['name']); ?>
                                            </strong>
                                            <div class="text-muted small">
                                                Added: <?php echo date('M d, Y', strtotime($university['created_at'])); ?>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <?php if (!empty($university['website'])): ?>
                                        <a href="<?php echo htmlspecialchars($university['website']); ?>" target="_blank" class="text-primary">
                                            <?php echo htmlspecialchars($university['website']); ?>
                                        </a>
                                    <?php else: ?>
                                        <span class="text-muted">Not available</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo htmlspecialchars($university['address'] ?? 'Not available'); ?>
                                </td>
                                <td class="text-center">
                                    <span class="status-badge status-<?php echo strtolower($university['status']); ?>">
                                        <i class="ri-<?php echo $university['status'] === 'Active' ? 'checkbox-circle' : 'close-circle'; ?>-line"></i>
                                        <?php echo htmlspecialchars($university['status']); ?>
                                    </span>
                                </td>
                                <?php if ($isSuperAdmin): ?>
                                <td class="text-end">
                                    <div class="action-buttons">
                                        <button type="button" 
                                                class="btn btn-sm btn-outline-info me-1" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#editUniversityModal"
                                                data-university='<?php echo htmlspecialchars(json_encode($university)); ?>'
                                                title="Edit University/College">
                                            <i class="ri-edit-line"></i>
                                        </button>
                                        <button type="button" 
                                                class="btn btn-sm btn-outline-danger" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#deleteUniversityModal"
                                                data-university-id="<?php echo $university['id']; ?>"
                                                data-university-name="<?php echo htmlspecialchars($university['name']); ?>"
                                                title="Delete University/College">
                                            <i class="ri-delete-bin-line"></i>
                                        </button>
                                    </div>
                                </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <?php if ($result['pagination']['total'] > 1): ?>
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mt-4">
                    <!-- Pagination Info -->
                    <div class="pagination-info text-muted small">
                        Showing 
                        <strong><?php 
                            $start = ($page - 1) * 10 + 1;
                            echo $start;
                        ?></strong> to 
                        <strong><?php 
                            $end = min($start + 9, $result['pagination']['total_records']);
                            echo $end;
                        ?></strong> of 
                        <strong><?php echo $result['pagination']['total_records']; ?></strong> universities/colleges
                    </div>

                    <!-- Pagination Navigation -->
                    <nav aria-label="University navigation">
                        <ul class="pagination pagination-md mb-0">
                            <!-- Previous Page -->
                            <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" 
                                       href="?page=university_management&p=<?php echo ($page - 1); ?>&<?php 
                                            echo http_build_query(array_merge($filters, ['p' => ($page - 1)])); ?>" 
                                       aria-label="Previous">
                                        <i class="ri-arrow-left-s-line"></i>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <!-- Page Numbers -->
                            <?php
                            $totalPages = $result['pagination']['total'];
                            $range = 2;
                            
                            for ($i = 1; $i <= $totalPages; $i++):
                                if ($i == 1 || $i == $totalPages || 
                                    ($i >= $page - $range && $i <= $page + $range)):
                            ?>
                                <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                    <a class="page-link" 
                                       href="?page=university_management&p=<?php echo $i; ?>&<?php 
                                            echo http_build_query(array_merge($filters, ['p' => $i])); ?>">
                                        <?php echo $i; ?>
                                    </a>
                                </li>
                            <?php endif; endfor; ?>

                            <!-- Next Page -->
                            <?php if ($page < $totalPages): ?>
                                <li class="page-item">
                                    <a class="page-link" 
                                       href="?page=university_management&p=<?php echo ($page + 1); ?>&<?php 
                                            echo http_build_query(array_merge($filters, ['p' => ($page + 1)])); ?>" 
                                       aria-label="Next">
                                        <i class="ri-arrow-right-s-line"></i>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
            <?php endif; ?>

        <?php else: ?>
            <!-- No Results Found -->
            <div class="text-center py-5">
                <div class="no-data-icon mb-3">
                    <i class="ri-building-4-line fs-1 text-muted"></i>
                </div>
                <h5 class="text-muted">No universities/colleges found</h5>
                <p class="text-muted small mb-3">
                    <?php if (!empty($filters['search']) || !empty($filters['status'])): ?>
                        Try adjusting your filters
                        <?php if ($isSuperAdmin): ?>
                            or add a new university/college to get started
                        <?php endif; ?>
                    <?php else: ?>
                        <?php if ($isSuperAdmin): ?>
                            Add your first university/college to get started
                        <?php else: ?>
                            No universities/colleges have been added yet
                        <?php endif; ?>
                    <?php endif; ?>
                </p>
                <?php if ($isSuperAdmin): ?>
                    <button type="button" 
                            class="btn btn-primary" 
                            data-bs-toggle="modal" 
                            data-bs-target="#addUniversityModal">
                        <i class="ri-add-line me-1"></i>
                        Add University/College
                    </button>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php if ($isSuperAdmin): ?>
<!-- Add University Modal -->
<div class="modal fade" id="addUniversityModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-light">
                <h5 class="modal-title">
                    <i class="ri-building-4-line me-2"></i>
                    Add University/College
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="row g-3">
                        <!-- University Name -->
                        <div class="col-12">
                            <div class="form-floating">
                                <input type="text" 
                                       class="form-control" 
                                       name="name" 
                                       id="add_university_name"
                                       placeholder="Enter university/college name"
                                       required>
                                <label for="add_university_name">University/College Name</label>
                                <div class="invalid-feedback">
                                    Please provide a name.
                                </div>
                            </div>
                        </div>

                        <!-- Website URL -->
                        <div class="col-12">
                            <div class="form-floating">
                                <input type="url" 
                                       class="form-control" 
                                       name="website" 
                                       id="add_website_url"
                                       placeholder="Enter website URL">
                                <label for="add_website_url">Website URL</label>
                                <div class="invalid-feedback">
                                    Please provide a valid URL.
                                </div>
                            </div>
                        </div>

                        <!-- Address -->
                        <div class="col-12">
                            <div class="form-floating">
                                <textarea class="form-control" 
                                          name="address" 
                                          id="add_address"
                                          placeholder="Enter address"
                                          style="height: 100px"></textarea>
                                <label for="add_address">Address</label>
                            </div>
                        </div>

                        <!-- University Logo -->
                        <div class="col-12">
                            <div class="mb-3">
                                <label for="university_logo" class="form-label">University Logo</label>
                                <input type="file" 
                                       class="form-control" 
                                       name="logo" 
                                       id="university_logo"
                                       accept="image/*">
                                <div class="form-text">
                                    Recommended size: 200x200px. Max file size: 2MB. Supported formats: JPG, PNG, GIF
                                </div>
                            </div>
                            <div id="logo_preview" class="text-center d-none mb-3">
                                <img src="" alt="Logo Preview" class="img-thumbnail" style="max-width: 200px;">
                            </div>
                        </div>

                        <!-- Status -->
                        <div class="col-12">
                            <div class="form-floating">
                                <select class="form-select" 
                                        name="status" 
                                        id="add_status"
                                        required>
                                    <option value="Active" selected>Active</option>
                                    <option value="Inactive">Inactive</option>
                                </select>
                                <label for="add_status">Status</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" 
                            class="btn btn-outline-secondary" 
                            data-bs-dismiss="modal">
                        <i class="ri-close-line me-1"></i>
                        Cancel
                    </button>
                    <button type="submit" 
                            name="create_university" 
                            class="btn btn-primary">
                        <i class="ri-save-line me-1"></i>
                        Save University
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit University Modal -->
<div class="modal fade" id="editUniversityModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-light">
                <h5 class="modal-title">
                    <i class="ri-edit-line me-2"></i>
                    Edit University/College
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate enctype="multipart/form-data">
                <input type="hidden" name="university_id" id="edit_university_id">
                <div class="modal-body">
                    <!-- Current Logo Preview -->
                    <div class="text-center mb-4">
                        <div id="current_logo_preview">
                            <img src="" alt="Current Logo" class="img-thumbnail" style="max-width: 200px;">
                        </div>
                    </div>

                    <div class="row g-3">
                        <!-- University Name -->
                        <div class="col-12">
                            <div class="form-floating">
                                <input type="text" 
                                       class="form-control" 
                                       name="name" 
                                       id="edit_university_name"
                                       placeholder="Enter university/college name"
                                       required>
                                <label for="edit_university_name">University/College Name</label>
                                <div class="invalid-feedback">
                                    Please provide a name.
                                </div>
                            </div>
                        </div>

                        <!-- Website URL -->
                        <div class="col-12">
                            <div class="form-floating">
                                <input type="url" 
                                       class="form-control" 
                                       name="website" 
                                       id="edit_website_url"
                                       placeholder="Enter website URL">
                                <label for="edit_website_url">Website URL</label>
                                <div class="invalid-feedback">
                                    Please provide a valid URL.
                                </div>
                            </div>
                        </div>

                        <!-- Address -->
                        <div class="col-12">
                            <div class="form-floating">
                                <textarea class="form-control" 
                                          name="address" 
                                          id="edit_address"
                                          placeholder="Enter address"
                                          style="height: 100px"></textarea>
                                <label for="edit_address">Address</label>
                            </div>
                        </div>

                        <!-- University Logo -->
                        <div class="col-12">
                            <div class="mb-3">
                                <label for="edit_university_logo" class="form-label">Update Logo</label>
                                <input type="file" 
                                       class="form-control" 
                                       name="logo" 
                                       id="edit_university_logo"
                                       accept="image/*">
                                <div class="form-text">Leave empty to keep current logo</div>
                            </div>
                        </div>

                        <!-- Status -->
                        <div class="col-12">
                            <div class="form-floating">
                                <select class="form-select" 
                                        name="status" 
                                        id="edit_status"
                                        required>
                                    <option value="Active">Active</option>
                                    <option value="Inactive">Inactive</option>
                                </select>
                                <label for="edit_status">Status</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" 
                            class="btn btn-outline-secondary" 
                            data-bs-dismiss="modal">
                        <i class="ri-close-line me-1"></i>
                        Cancel
                    </button>
                    <button type="submit" 
                            name="update_university" 
                            class="btn btn-primary">
                        <i class="ri-save-line me-1"></i>
                        Update University
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete University Modal -->
<div class="modal fade" id="deleteUniversityModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">
                    <i class="ri-delete-bin-line me-2"></i>
                    Delete University/College
                </h5>
                <button type="button" 
                        class="btn-close btn-close-white" 
                        data-bs-dismiss="modal" 
                        aria-label="Close"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="university_id" id="delete_university_id">
                <div class="modal-body">
                    <div class="text-center mb-4">
                        <i class="ri-error-warning-line text-danger fs-1"></i>
                        <h5 class="mt-3">Are you sure you want to delete this university/college?</h5>
                        <p class="text-muted mb-0">Name: <strong id="delete_university_name"></strong></p>
                    </div>
                    <div class="alert alert-warning">
                        <i class="ri-alert-line me-2"></i>
                        This action cannot be undone. All associated data will be permanently removed.
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" 
                            class="btn btn-outline-secondary" 
                            data-bs-dismiss="modal">
                        <i class="ri-close-line me-1"></i>
                        Cancel
                    </button>
                    <button type="submit" 
                            name="delete_university" 
                            class="btn btn-danger">
                        <i class="ri-delete-bin-line me-1"></i>
                        Delete University
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- JavaScript for University Management -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Logo Preview Handler
    function handleLogoPreview(input, previewId) {
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            const preview = document.getElementById(previewId);
            
            reader.onload = function(e) {
                preview.classList.remove('d-none');
                preview.querySelector('img').src = e.target.result;
            };
            
            reader.readAsDataURL(input.files[0]);
        }
    }

    // Add logo preview handlers
    document.getElementById('university_logo')?.addEventListener('change', function() {
        handleLogoPreview(this, 'logo_preview');
    });

    document.getElementById('edit_university_logo')?.addEventListener('change', function() {
        handleLogoPreview(this, 'current_logo_preview');
    });

    // Handle Edit University Modal
    const editButtons = document.querySelectorAll('[data-bs-target="#editUniversityModal"]');
    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            try {
                const university = JSON.parse(this.dataset.university);
                populateEditForm(university);
            } catch (e) {
                console.error("Error parsing university data:", e);
            }
        });
    });

    function populateEditForm(university) {
        // Populate form fields
        document.getElementById('edit_university_id').value = university.id;
        document.getElementById('edit_university_name').value = university.name;
        document.getElementById('edit_website_url').value = university.website || '';
        document.getElementById('edit_address').value = university.address || '';
        document.getElementById('edit_status').value = university.status;
        
        // Show current logo if exists
        const logoPreview = document.getElementById('current_logo_preview');
        if (university.logo) {
            logoPreview.querySelector('img').src = university.logo;
            logoPreview.classList.remove('d-none');
        } else {
            logoPreview.classList.add('d-none');
        }
    }

    // Handle Delete University Modal
    const deleteButtons = document.querySelectorAll('[data-bs-target="#deleteUniversityModal"]');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function() {
            document.getElementById('delete_university_id').value = this.dataset.universityId;
            document.getElementById('delete_university_name').textContent = this.dataset.universityName;
        });
    });

    // Form Validation Handler
    const forms = document.querySelectorAll('.needs-validation');
    forms.forEach(form => {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    });

    // Handle File Size Validation
    const MAX_FILE_SIZE = 2 * 1024 * 1024; // 2MB
    const logoInputs = document.querySelectorAll('input[type="file"]');
    logoInputs.forEach(input => {
        input.addEventListener('change', function() {
            if (this.files[0] && this.files[0].size > MAX_FILE_SIZE) {
                alert('File size must be less than 2MB');
                this.value = '';
                return false;
            }
        });
    });
});
</script>

<style>
    .university-container {
        max-width: 1200px;
        margin: 1rem auto;
        padding: 1rem;
        background: #ffffff;
        border-radius: 1rem;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    }

    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 2rem;
        flex-wrap: wrap;
        gap: 1rem;
    }

    .filters-section {
        background: #f3f4f6;
        padding: 1.5rem;
        border-radius: 0.75rem;
        margin-bottom: 1.5rem;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
    }

    .status-badge {
        padding: 0.5rem 1rem;
        border-radius: 9999px;
        font-size: 0.875rem;
        font-weight: 500;
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
    }

    .status-active {
        background-color: #ecfdf5;
        color: #059669;
    }

    .status-inactive {
        background-color: #fef2f2;
        color: #dc2626;
    }

    @media (max-width: 768px) {
        .university-container {
            margin: 0;
            padding: 1rem;
            border-radius: 0;
        }

        .page-header {
            flex-direction: column;
            align-items: stretch;
        }
    }
</style>