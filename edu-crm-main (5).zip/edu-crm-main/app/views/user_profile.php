<?php
require_once __DIR__ . '/../../app/controllers/UserProfileController.php';

// Initialize controller and get user profile
$userProfileController = new UserProfileController($conn);
$user_id = $_SESSION['user_id'];
$profile = $userProfileController->showProfile($user_id);

$success = $error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    // Prepare update data
    $data = [
        'id' => $user_id,
        'email' => $_POST['email'],
        'first_name' => $_POST['first_name'],
        'last_name' => $_POST['last_name'],
        'date_of_birth' => $_POST['date_of_birth'],
        'mobile_number' => $_POST['mobile_number'],
        'designation' => $_POST['designation']
    ];

    // Validate data
    $errors = $userProfileController->validateProfileData($data);

    if (empty($errors)) {
        // Handle profile photo upload
        if (!empty($_FILES['profile_photo']['tmp_name'])) {
            $newPhotoName = $userProfileController->handleProfilePhotoUpload(
                $_FILES['profile_photo'],
                $profile['profile_photo'] ?? null
            );

            if ($newPhotoName) {
                $data['profile_photo'] = $newPhotoName;
            } else {
                $error = "Failed to upload profile photo.";
            }
        } else {
            $data['profile_photo'] = $profile['profile_photo'] ?? null;
        }

        // Update profile if no errors
        if (empty($error)) {
            if ($userProfileController->updateProfile($data)) {
                $success = "Profile updated successfully.";
                // Refresh profile data
                $profile = $userProfileController->showProfile($user_id);
            } else {
                $error = "Failed to update profile.";
            }
        }
    } else {
        $error = implode(", ", $errors);
    }
}

// Debug information
error_log("Current Date and Time (UTC): " . date('Y-m-d H:i:s'));
error_log("Current User's Login: " . ($profile['email'] ?? 'unknown'));
?>
<style>
    .profile-container {
        max-width: 800px;
        margin: 2rem auto;
        padding: 2rem;
        background: white;
        border-radius: 15px;
        box-shadow: 0 0 20px rgba(0,0,0,0.1);
    }

    .profile-header {
        text-align: center;
        margin-bottom: 2rem;
        padding: 1rem;
        border-bottom: 1px solid #eee;
    }

    .profile-photo-container {
        position: relative;
        width: 150px;
        height: 150px;
        margin: 0 auto 1rem;
    }

    .profile-photo {
        width: 150px;
        height: 150px;
        border-radius: 50%;
        object-fit: cover;
        border: 4px solid #fff;
        box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    .photo-upload-btn {
        position: absolute;
        bottom: 5px;
        right: 5px;
        background: #4f46e5;
        color: white;
        border-radius: 50%;
        width: 36px;
        height: 36px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .photo-upload-btn:hover {
        background: #4338ca;
        transform: scale(1.1);
    }

    .user-info {
        text-align: center;
        margin-bottom: 1rem;
    }

    .company-badge {
        display: inline-block;
        padding: 0.4rem 1rem;
        background: #f3f4f6;
        border-radius: 20px;
        font-size: 0.9rem;
        color: #4b5563;
        margin-top: 0.5rem;
    }

    .form-floating > .form-control {
        padding-top: 1.625rem;
        padding-bottom: 0.625rem;
    }

    .form-floating > label {
        padding: 1rem 0.75rem;
    }
</style>

<div class="profile-container">
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($success); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="profile-header">
        <div class="profile-photo-container">
            <?php
            $profile_photo = !empty($profile['profile_photo']) 
                ? "/storage/uploads/user_profile_photo/" . htmlspecialchars($profile['profile_photo'])
                : "/storage/uploads/user_profile_photo/default_avatar.png";
            ?>
            <img src="<?php echo $profile_photo; ?>" 
                 alt="Profile Photo" 
                 class="profile-photo"
                 onerror="this.src='/storage/uploads/user_profile_photo/default_avatar.png'">
            
            <label for="profile_photo" class="photo-upload-btn">
                <i class="ri-camera-line"></i>
            </label>
        </div>

        <div class="user-info">
            <h4 class="mb-0">
                <?php echo htmlspecialchars($profile['first_name'] . ' ' . $profile['last_name']); ?>
            </h4>
            <p class="text-muted mb-2">
                <?php echo htmlspecialchars($profile['designation'] ?? 'No designation set'); ?>
            </p>
            <?php if (!empty($profile['company_name'])): ?>
                <div class="company-badge">
                    <i class="ri-building-line me-1"></i>
                    <?php echo htmlspecialchars($profile['company_name']); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <form method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
        <input type="file" 
               id="profile_photo" 
               name="profile_photo" 
               accept="image/*" 
               class="d-none">

        <div class="row g-3">
            <!-- First Name -->
            <div class="col-md-6">
                <div class="form-floating">
                    <input type="text" 
                           class="form-control" 
                           name="first_name" 
                           id="first_name" 
                           value="<?php echo htmlspecialchars($profile['first_name'] ?? ''); ?>" 
                           required>
                    <label for="first_name">First Name</label>
                </div>
            </div>

            <!-- Last Name -->
            <div class="col-md-6">
                <div class="form-floating">
                    <input type="text" 
                           class="form-control" 
                           name="last_name" 
                           id="last_name" 
                           value="<?php echo htmlspecialchars($profile['last_name'] ?? ''); ?>" 
                           required>
                    <label for="last_name">Last Name</label>
                </div>
            </div>

            <!-- Email -->
            <div class="col-md-6">
                <div class="form-floating">
                    <input type="email" 
                           class="form-control" 
                           name="email" 
                           id="email" 
                           value="<?php echo htmlspecialchars($profile['email']); ?>" 
                           required>
                    <label for="email">Email</label>
                </div>
            </div>

            <!-- Mobile Number -->
            <div class="col-md-6">
                <div class="form-floating">
                    <input type="text" 
                           class="form-control" 
                           name="mobile_number" 
                           id="mobile_number" 
                           value="<?php echo htmlspecialchars($profile['mobile_number'] ?? ''); ?>">
                    <label for="mobile_number">Mobile Number</label>
                </div>
            </div>

            <!-- Date of Birth -->
            <div class="col-md-6">
                <div class="form-floating">
                    <input type="date" 
                           class="form-control" 
                           name="date_of_birth" 
                           id="date_of_birth" 
                           value="<?php echo htmlspecialchars($profile['date_of_birth'] ?? ''); ?>">
                    <label for="date_of_birth">Date of Birth</label>
                </div>
            </div>

            <!-- Designation -->
            <div class="col-md-6">
                <div class="form-floating">
                    <input type="text" 
                           class="form-control" 
                           name="designation" 
                           id="designation" 
                           value="<?php echo htmlspecialchars($profile['designation'] ?? ''); ?>">
                    <label for="designation">Designation</label>
                </div>
            </div>

            <!-- Company (Read-only) -->
            <?php if (!empty($profile['company_name'])): ?>
            <div class="col-md-6">
                <div class="form-floating">
                    <input type="text" 
                           class="form-control" 
                           value="<?php echo htmlspecialchars($profile['company_name']); ?>" 
                           readonly>
                    <label>Company</label>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <div class="mt-4">
            <button type="submit" name="update_profile" class="btn btn-primary w-100">
                <i class="ri-save-line me-1"></i> Update Profile
            </button>
        </div>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Handle profile photo upload and preview
    const photoInput = document.getElementById('profile_photo');
    const profilePhoto = document.querySelector('.profile-photo');

    photoInput.addEventListener('change', function(e) {
        if (this.files && this.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                profilePhoto.src = e.target.result;
            }
            reader.readAsDataURL(this.files[0]);
        }
    });

    // Form validation
    const form = document.querySelector('form');
    form.addEventListener('submit', function(event) {
        if (!form.checkValidity()) {
            event.preventDefault();
            event.stopPropagation();
        }
        form.classList.add('was-validated');
    });
});
</script>