<?php
/**
 * Semester Management View
 * Created on: 2026-01-14
 * Created by: System
 * Description: Manage university semesters - Admin/Super Admin only
 */

require_once __DIR__ . '/../../config/config.php';

// Check if user has permission (Admin or Super Admin only)
$user_id = $_SESSION['user_id'] ?? 0;
$stmt = $conn->prepare("SELECT user_type FROM users WHERE id = ?");
$stmt->bindParam(1, $user_id, PDO::PARAM_INT);
$stmt->execute();
$user_type = $stmt->fetchColumn();

if (!in_array($user_type, ['Super Admin', 'Admin'])) {
    header("Location: /dashboard.php");
    exit();
}

$success = $error = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create_semester'])) {
        $name = trim($_POST['name']);
        $start_date = $_POST['start_date'] ?: null;
        $end_date = $_POST['end_date'] ?: null;
        $status = $_POST['status'];
        
        try {
            $stmt = $conn->prepare("INSERT INTO semesters (name, start_date, end_date, status, created_by) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$name, $start_date, $end_date, $status, $user_id]);
            $success = "Semester created successfully!";
        } catch (PDOException $e) {
            $error = "Error creating semester: " . $e->getMessage();
        }
    } elseif (isset($_POST['update_semester'])) {
        $id = (int)$_POST['semester_id'];
        $name = trim($_POST['name']);
        $start_date = $_POST['start_date'] ?: null;
        $end_date = $_POST['end_date'] ?: null;
        $status = $_POST['status'];
        
        try {
            $stmt = $conn->prepare("UPDATE semesters SET name = ?, start_date = ?, end_date = ?, status = ?, updated_by = ? WHERE id = ?");
            $stmt->execute([$name, $start_date, $end_date, $status, $user_id, $id]);
            $success = "Semester updated successfully!";
        } catch (PDOException $e) {
            $error = "Error updating semester: " . $e->getMessage();
        }
    } elseif (isset($_POST['delete_semester'])) {
        $id = (int)$_POST['semester_id'];
        
        try {
            // Check if semester is being used
            $stmt = $conn->prepare("SELECT COUNT(*) FROM lead_semesters WHERE semester_id = ?");
            $stmt->execute([$id]);
            $count = $stmt->fetchColumn();
            
            if ($count > 0) {
                $error = "Cannot delete semester. It is associated with " . $count . " lead(s).";
            } else {
                $stmt = $conn->prepare("DELETE FROM semesters WHERE id = ?");
                $stmt->execute([$id]);
                $success = "Semester deleted successfully!";
            }
        } catch (PDOException $e) {
            $error = "Error deleting semester: " . $e->getMessage();
        }
    }
}

// Get all semesters
$stmt = $conn->prepare("SELECT s.*, 
    (SELECT COUNT(*) FROM lead_semesters WHERE semester_id = s.id) as lead_count
    FROM semesters s ORDER BY s.start_date DESC, s.name ASC");
$stmt->execute();
$semesters = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="semester-management-container">
    <!-- Page Header -->
    <div class="page-header">
        <div>
            <h1 class="page-title">
                <i class="ri-calendar-line me-2"></i>
                Semester Management
            </h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/dashboard.php">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Semester Management</li>
                </ol>
            </nav>
        </div>
        
        <button type="button" 
                class="btn btn-primary" 
                data-bs-toggle="modal" 
                data-bs-target="#addSemesterModal">
            <i class="ri-add-circle-line me-1"></i>
            Add New Semester
        </button>
    </div>

    <!-- Alert Messages -->
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show d-flex align-items-center" role="alert">
            <i class="ri-checkbox-circle-line me-2"></i>
            <div class="flex-grow-1">
                <?php echo htmlspecialchars($success); ?>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show d-flex align-items-center" role="alert">
            <i class="ri-error-warning-line me-2"></i>
            <div class="flex-grow-1">
                <?php echo htmlspecialchars($error); ?>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Semesters Table -->
    <div class="card">
        <div class="card-header">
            <h5 class="card-title mb-0">
                <i class="ri-list-check me-2"></i>
                All Semesters
            </h5>
        </div>
        <div class="card-body p-0">
            <?php if (!empty($semesters)): ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th scope="col">Semester Name</th>
                                <th scope="col">Start Date</th>
                                <th scope="col">End Date</th>
                                <th scope="col">Status</th>
                                <th scope="col">Associated Leads</th>
                                <th scope="col" class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($semesters as $semester): ?>
                                <tr>
                                    <td>
                                        <div class="fw-medium"><?php echo htmlspecialchars($semester['name']); ?></div>
                                    </td>
                                    <td>
                                        <?php echo $semester['start_date'] ? date('M j, Y', strtotime($semester['start_date'])) : 'Not set'; ?>
                                    </td>
                                    <td>
                                        <?php echo $semester['end_date'] ? date('M j, Y', strtotime($semester['end_date'])) : 'Not set'; ?>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo $semester['status'] === 'Active' ? 'success' : 'secondary'; ?>">
                                            <?php echo htmlspecialchars($semester['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge bg-info rounded-pill"><?php echo number_format($semester['lead_count']); ?> lead(s)</span>
                                    </td>
                                    <td class="text-end">
                                        <div class="action-buttons">
                                            <button type="button" 
                                                    class="btn btn-sm btn-outline-info me-1" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#editSemesterModal"
                                                    data-semester-id="<?php echo $semester['id']; ?>"
                                                    data-semester-name="<?php echo htmlspecialchars($semester['name']); ?>"
                                                    data-semester-start="<?php echo $semester['start_date']; ?>"
                                                    data-semester-end="<?php echo $semester['end_date']; ?>"
                                                    data-semester-status="<?php echo $semester['status']; ?>"
                                                    title="Edit Semester">
                                                <i class="ri-edit-line"></i>
                                            </button>
                                            
                                            <button type="button" 
                                                    class="btn btn-sm btn-outline-danger" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#deleteSemesterModal"
                                                    data-semester-id="<?php echo $semester['id']; ?>"
                                                    data-semester-name="<?php echo htmlspecialchars($semester['name']); ?>"
                                                    data-lead-count="<?php echo $semester['lead_count']; ?>"
                                                    title="Delete Semester">
                                                <i class="ri-delete-bin-line"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center py-5">
                    <div class="no-data-icon mb-3">
                        <i class="ri-calendar-line fs-1 text-muted"></i>
                    </div>
                    <h5 class="text-muted">No semesters found</h5>
                    <p class="text-muted small mb-3">Add your first semester to get started</p>
                    <button type="button" 
                            class="btn btn-primary" 
                            data-bs-toggle="modal" 
                            data-bs-target="#addSemesterModal">
                        <i class="ri-add-line me-1"></i>
                        Add Semester
                    </button>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Add Semester Modal -->
<div class="modal fade" id="addSemesterModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-light">
                <h5 class="modal-title">
                    <i class="ri-add-circle-line me-2"></i>
                    Add New Semester
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="create_semester" value="1">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="add_name" class="form-label">Semester Name <span class="text-danger">*</span></label>
                        <input type="text" 
                               class="form-control" 
                               name="name" 
                               id="add_name"
                               placeholder="e.g., Fall 2026, Spring 2027"
                               required>
                        <div class="invalid-feedback">
                            Please provide a semester name.
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="add_start_date" class="form-label">Start Date</label>
                        <input type="date" 
                               class="form-control" 
                               name="start_date" 
                               id="add_start_date">
                    </div>
                    
                    <div class="mb-3">
                        <label for="add_end_date" class="form-label">End Date</label>
                        <input type="date" 
                               class="form-control" 
                               name="end_date" 
                               id="add_end_date">
                    </div>
                    
                    <div class="mb-3">
                        <label for="add_status" class="form-label">Status <span class="text-danger">*</span></label>
                        <select class="form-select" name="status" id="add_status" required>
                            <option value="Active" selected>Active</option>
                            <option value="Inactive">Inactive</option>
                        </select>
                        <div class="invalid-feedback">
                            Please select a status.
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" 
                            class="btn btn-outline-secondary" 
                            data-bs-dismiss="modal">
                        <i class="ri-close-line me-1"></i>
                        Cancel
                    </button>
                    <button type="submit" 
                            class="btn btn-primary">
                        <i class="ri-save-line me-1"></i>
                        Save Semester
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Semester Modal -->
<div class="modal fade" id="editSemesterModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-light">
                <h5 class="modal-title">
                    <i class="ri-edit-line me-2"></i>
                    Edit Semester
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="update_semester" value="1">
                <input type="hidden" name="semester_id" id="edit_semester_id">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="edit_name" class="form-label">Semester Name <span class="text-danger">*</span></label>
                        <input type="text" 
                               class="form-control" 
                               name="name" 
                               id="edit_name"
                               required>
                        <div class="invalid-feedback">
                            Please provide a semester name.
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_start_date" class="form-label">Start Date</label>
                        <input type="date" 
                               class="form-control" 
                               name="start_date" 
                               id="edit_start_date">
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_end_date" class="form-label">End Date</label>
                        <input type="date" 
                               class="form-control" 
                               name="end_date" 
                               id="edit_end_date">
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_status" class="form-label">Status <span class="text-danger">*</span></label>
                        <select class="form-select" name="status" id="edit_status" required>
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                        </select>
                        <div class="invalid-feedback">
                            Please select a status.
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" 
                            class="btn btn-outline-secondary" 
                            data-bs-dismiss="modal">
                        <i class="ri-close-line me-1"></i>
                        Cancel
                    </button>
                    <button type="submit" 
                            class="btn btn-primary">
                        <i class="ri-save-line me-1"></i>
                        Update Semester
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Semester Modal -->
<div class="modal fade" id="deleteSemesterModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">
                    <i class="ri-delete-bin-line me-2"></i>
                    Delete Semester
                </h5>
                <button type="button" 
                        class="btn-close btn-close-white" 
                        data-bs-dismiss="modal" 
                        aria-label="Close"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="delete_semester" value="1">
                <input type="hidden" name="semester_id" id="delete_semester_id">
                <div class="modal-body">
                    <div class="text-center mb-4">
                        <i class="ri-error-warning-line text-danger fs-1"></i>
                        <h5 class="mt-3">Are you sure you want to delete this semester?</h5>
                        <p class="text-muted mb-0">Name: <strong id="delete_semester_name"></strong></p>
                        <p class="text-muted mb-0" id="delete_lead_count_text"></p>
                    </div>
                    <div class="alert alert-warning">
                        <i class="ri-alert-line me-2"></i>
                        This action cannot be undone.
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" 
                            class="btn btn-outline-secondary" 
                            data-bs-dismiss="modal">
                        <i class="ri-close-line me-1"></i>
                        Cancel
                    </button>
                    <button type="submit" 
                            class="btn btn-danger">
                        <i class="ri-delete-bin-line me-1"></i>
                        Delete Semester
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- JavaScript -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Form validation
    const forms = document.querySelectorAll('.needs-validation');
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    });
    
    // Handle Edit Semester Modal
    const editButtons = document.querySelectorAll('[data-bs-target="#editSemesterModal"]');
    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            document.getElementById('edit_semester_id').value = this.getAttribute('data-semester-id');
            document.getElementById('edit_name').value = this.getAttribute('data-semester-name');
            document.getElementById('edit_start_date').value = this.getAttribute('data-semester-start') || '';
            document.getElementById('edit_end_date').value = this.getAttribute('data-semester-end') || '';
            document.getElementById('edit_status').value = this.getAttribute('data-semester-status');
        });
    });
    
    // Handle Delete Semester Modal
    const deleteButtons = document.querySelectorAll('[data-bs-target="#deleteSemesterModal"]');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function() {
            const semesterId = this.getAttribute('data-semester-id');
            const semesterName = this.getAttribute('data-semester-name');
            const leadCount = parseInt(this.getAttribute('data-lead-count'));
            
            document.getElementById('delete_semester_id').value = semesterId;
            document.getElementById('delete_semester_name').textContent = semesterName;
            
            const leadCountText = document.getElementById('delete_lead_count_text');
            if (leadCount > 0) {
                leadCountText.textContent = 'This semester is associated with ' + leadCount + ' lead(s).';
                leadCountText.className = 'text-danger mb-0';
            } else {
                leadCountText.textContent = '';
            }
        });
    });
});
</script>

<style>
.semester-management-container {
    max-width: 1400px;
    margin: 1rem auto;
    padding: 1rem;
    background: #ffffff;
    border-radius: 1rem;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
}

.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
    flex-wrap: wrap;
    gap: 1rem;
}

@media (max-width: 768px) {
    .semester-management-container {
        margin: 0;
        padding: 1rem;
        border-radius: 0;
    }
    
    .page-header {
        flex-direction: column;
        align-items: flex-start;
    }
}
</style>
