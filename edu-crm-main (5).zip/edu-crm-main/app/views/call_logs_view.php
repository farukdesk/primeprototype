<?php
/**
 * Call Logs View
 * Created on: 2025-05-05
 * Created by: farukdesk
 */

require_once __DIR__ . '/../../app/controllers/call_logs_controller.php';

// Initialize controller
$callLogsController = new CallLogsController($conn);

// Check permissions
if (!$callLogsController->canViewCallLogs()) {
    header("Location: /dashboard.php");
    exit();
}

$success = $error = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_call_log'])) {
        $result = $callLogsController->updateCallLog($_POST);
        if ($result['status']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    } elseif (isset($_POST['delete_call_log'])) {
        $result = $callLogsController->deleteCallLog($_POST['call_log_id']);
        if ($result['status']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    }
}

// Get data from controller
$result = $callLogsController->handleRequest();

// Extract variables
$viewMode = $result['view_mode'];
$staffStats = $result['staff_stats'];
$canManageCallLogs = $result['can_manage_call_logs'];

// For staff detail view
$staffDetail = $result['staff_stats'] ?? null;
$leads = $result['leads'] ?? null;

// For call logs view with filters
$callLogsData = $result['logs'] ?? null;

// Get current page
$page = isset($_GET['p']) ? max(1, (int)$_GET['p']) : 1;

// Check if we're viewing a specific staff member
$viewingStaffId = isset($_GET['view_staff']) ? (int)$_GET['view_staff'] : null;
?>

<div class="call-logs-container">
    <!-- Page Header -->
    <div class="page-header">
        <div>
            <h1 class="page-title">
                <i class="ri-phone-line me-2"></i>
                <?php echo $viewingStaffId ? 'Staff Call Performance' : 'Call Logs'; ?>
            </h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/dashboard.php">Dashboard</a></li>
                    <?php if ($viewingStaffId): ?>
                        <li class="breadcrumb-item"><a href="?page=call_logs_view">Call Logs</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Staff Performance</li>
                    <?php else: ?>
                        <li class="breadcrumb-item active" aria-current="page">Call Logs</li>
                    <?php endif; ?>
                </ol>
            </nav>
        </div>
        
        <?php if ($viewingStaffId): ?>
        <a href="?page=call_logs_view" class="btn btn-outline-secondary">
            <i class="ri-arrow-left-line me-1"></i>
            Back to Staff List
        </a>
        <?php else: ?>
        <div class="d-flex gap-2">
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#filtersModal">
                <i class="ri-filter-3-line me-1"></i>
                Filter Logs
            </button>
            
            <a href="?page=call_logs_view" class="btn btn-outline-secondary">
                <i class="ri-refresh-line me-1"></i>
                Reset
            </a>
        </div>
        <?php endif; ?>
    </div>

    <!-- Alert Messages -->
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show d-flex align-items-center" role="alert">
            <i class="ri-checkbox-circle-line me-2"></i>
            <div class="flex-grow-1">
                <?php echo htmlspecialchars($success); ?>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show d-flex align-items-center" role="alert">
            <i class="ri-error-warning-line me-2"></i>
            <div class="flex-grow-1">
                <?php echo htmlspecialchars($error); ?>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($viewMode === 'staff_list'): ?>
        <!-- Staff Performance Summary -->
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">
                    <i class="ri-team-line me-2"></i>
                    Staff Call Performance
                </h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th scope="col">Staff</th>
                                <th scope="col" class="text-center">Today's Calls</th>
                                <th scope="col" class="text-center">This Week</th>
                                <th scope="col" class="text-center">This Month</th>
                                <th scope="col" class="text-center">Conversions</th>
                                <th scope="col" class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($staffStats)): ?>
                                <?php foreach ($staffStats as $staff): ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="avatar-circle avatar-sm bg-primary me-2">
                                                    <?php if (!empty($staff['profile_photo'])): ?>
                                                        <img src="/storage/uploads/user_profile_photo/<?php echo htmlspecialchars($staff['profile_photo']); ?>" 
                                                            alt="<?php echo htmlspecialchars($staff['staff_name']); ?>" 
                                                            class="rounded-circle">
                                                    <?php else: ?>
                                                        <span><?php echo strtoupper(substr($staff['staff_name'], 0, 2)); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                                <div>
                                                    <div class="fw-medium"><?php echo htmlspecialchars($staff['staff_name']); ?></div>
                                                    <?php if (!empty($staff['designation'])): ?>
                                                        <div class="text-muted small"><?php echo htmlspecialchars($staff['designation']); ?></div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge bg-<?php echo $staff['today_calls'] > 0 ? 'success' : 'light text-dark'; ?> px-3 py-2">
                                                <?php echo $staff['today_calls']; ?>
                                            </span>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge bg-<?php echo $staff['week_calls'] > 0 ? 'info' : 'light text-dark'; ?> px-3 py-2">
                                                <?php echo $staff['week_calls']; ?>
                                            </span>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge bg-<?php echo $staff['month_calls'] > 0 ? 'primary' : 'light text-dark'; ?> px-3 py-2">
                                                <?php echo $staff['month_calls']; ?>
                                            </span>
                                        </td>
                                        <td class="text-center">
                                            <div class="d-flex flex-column align-items-center">
                                                <span class="badge bg-<?php echo $staff['month_conversions'] > 0 ? 'success' : 'light text-dark'; ?> px-3 py-2">
                                                    <?php echo $staff['month_conversions']; ?>
                                                </span>
                                                
                                                <?php if ($staff['month_calls'] > 0): ?>
                                                    <div class="text-muted small mt-1">
                                                        <?php 
                                                            $conversionRate = ($staff['month_conversions'] / $staff['month_calls']) * 100;
                                                            echo number_format($conversionRate, 1) . '%';
                                                        ?>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td class="text-end">
                                            <a href="?page=call_logs_view&view_staff=<?php echo $staff['staff_id']; ?>" 
                                               class="btn btn-sm btn-outline-primary">
                                                <i class="ri-eye-line me-1"></i>
                                                View Details
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center py-4">
                                        <div class="text-muted">No staff call data available yet.</div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- Call Logs Table (only shown when filters are applied) -->
        <?php if (!empty($callLogsData)): ?>
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">
                        <i class="ri-phone-line me-2"></i>
                        Call Logs
                    </h5>
                    
                    <div class="d-flex gap-2">
                        <small class="text-muted">
                            Showing <?php echo count($callLogsData['data']); ?> of <?php echo $callLogsData['pagination']['total_records']; ?> records
                        </small>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th scope="col">Staff</th>
                                    <th scope="col">Lead</th>
                                    <th scope="col">Call Type</th>
                                    <th scope="col">Date & Time</th>
                                    <th scope="col">Status Change</th>
                                    <th scope="col" class="text-center">Converted</th>
                                    <th scope="col" class="text-end">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($callLogsData['data'] as $log): ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="avatar-circle avatar-xs bg-primary me-2">
                                                    <span><?php echo strtoupper(substr($log['staff_name'], 0, 2)); ?></span>
                                                </div>
                                                <div class="small"><?php echo htmlspecialchars($log['staff_name']); ?></div>
                                            </div>
                                        </td>
                                        <td>
                                            <div>
                                                <div class="fw-medium"><?php echo htmlspecialchars($log['lead_name']); ?></div>
                                                <div class="text-muted small"><?php echo htmlspecialchars($log['lead_email']); ?></div>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge 
                                                <?php 
                                                    switch($log['call_type']) {
                                                        case '1st call': echo 'bg-success'; break;
                                                        case '2nd call': echo 'bg-info'; break;
                                                        case '3rd call': echo 'bg-primary'; break;
                                                        case 'Office visit confirmation': echo 'bg-warning text-dark'; break;
                                                        case 'Final call': echo 'bg-danger'; break;
                                                        default: echo 'bg-secondary';
                                                    }
                                                ?>">
                                                <?php echo htmlspecialchars($log['call_type']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php echo date('M j, Y g:i A', strtotime($log['call_date'])); ?>
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <span class="badge bg-light text-dark me-2">
                                                    <?php echo htmlspecialchars($log['previous_status']); ?>
                                                </span>
                                                <i class="ri-arrow-right-line"></i>
                                                <span class="badge bg-primary ms-2">
                                                    <?php echo htmlspecialchars($log['new_status']); ?>
                                                </span>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <?php if ($log['call_converted']): ?>
                                                <i class="ri-check-double-line text-success fs-5"></i>
                                            <?php else: ?>
                                                <i class="ri-close-line text-muted fs-5"></i>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-end">
                                            <?php if ($canManageCallLogs): ?>
                                            <button type="button" 
                                                   class="btn btn-sm btn-outline-secondary me-1" 
                                                   data-bs-toggle="modal" 
                                                   data-bs-target="#viewCallLogModal"
                                                   data-call-log-id="<?php echo $log['id']; ?>"
                                                   data-call-log-notes="<?php echo htmlspecialchars($log['call_notes'] ?? ''); ?>"
                                                   data-call-lead-name="<?php echo htmlspecialchars($log['lead_name']); ?>"
                                                   data-call-staff-name="<?php echo htmlspecialchars($log['staff_name']); ?>"
                                                   data-call-date="<?php echo date('M j, Y g:i A', strtotime($log['call_date'])); ?>"
                                                   data-call-type="<?php echo htmlspecialchars($log['call_type']); ?>"
                                                   data-call-previous-status="<?php echo htmlspecialchars($log['previous_status']); ?>"
                                                   data-call-new-status="<?php echo htmlspecialchars($log['new_status']); ?>"
                                                   data-call-duration="<?php echo htmlspecialchars($log['call_duration'] ?? ''); ?>"
                                                   data-call-outcome="<?php echo htmlspecialchars($log['call_outcome'] ?? ''); ?>">
                                                <i class="ri-eye-line"></i>
                                            </button>
                                            
                                            <button type="button" 
                                                   class="btn btn-sm btn-outline-danger" 
                                                   data-bs-toggle="modal" 
                                                   data-bs-target="#deleteCallLogModal"
                                                   data-call-log-id="<?php echo $log['id']; ?>"
                                                   data-call-lead-name="<?php echo htmlspecialchars($log['lead_name']); ?>"
                                                   data-call-date="<?php echo date('M j, Y g:i A', strtotime($log['call_date'])); ?>">
                                                <i class="ri-delete-bin-line"></i>
                                            </button>
                                            <?php else: ?>
                                            <button type="button" 
                                                   class="btn btn-sm btn-outline-secondary" 
                                                   data-bs-toggle="modal" 
                                                   data-bs-target="#viewCallLogModal"
                                                   data-call-log-id="<?php echo $log['id']; ?>"
                                                   data-call-log-notes="<?php echo htmlspecialchars($log['call_notes'] ?? ''); ?>"
                                                   data-call-lead-name="<?php echo htmlspecialchars($log['lead_name']); ?>"
                                                   data-call-staff-name="<?php echo htmlspecialchars($log['staff_name']); ?>"
                                                   data-call-date="<?php echo date('M j, Y g:i A', strtotime($log['call_date'])); ?>"
                                                   data-call-type="<?php echo htmlspecialchars($log['call_type']); ?>"
                                                   data-call-previous-status="<?php echo htmlspecialchars($log['previous_status']); ?>"
                                                   data-call-new-status="<?php echo htmlspecialchars($log['new_status']); ?>"
                                                   data-call-duration="<?php echo htmlspecialchars($log['call_duration'] ?? ''); ?>"
                                                   data-call-outcome="<?php echo htmlspecialchars($log['call_outcome'] ?? ''); ?>">
                                                <i class="ri-eye-line"></i>
                                            </button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <!-- Pagination for call logs -->
                <?php if ($callLogsData['pagination']['total'] > 1): ?>
                    <div class="card-footer bg-white d-flex justify-content-center">
                        <nav aria-label="Call logs pagination">
                            <ul class="pagination pagination-sm mb-0">
                                <!-- Previous Page -->
                                <?php if ($page > 1): ?>
                                    <li class="page-item">
                                        <a class="page-link" 
                                           href="?page=call_logs_view&p=<?php echo ($page - 1); ?>&<?php 
                                                echo http_build_query(array_filter($_GET, function($key) {
                                                    return $key !== 'page' && $key !== 'p';
                                                }, ARRAY_FILTER_USE_KEY)); ?>" 
                                           aria-label="Previous">
                                            <i class="ri-arrow-left-s-line"></i>
                                        </a>
                                    </li>
                                <?php endif; ?>
                                
                                <!-- Page Numbers -->
                                <?php
                                $totalPages = $callLogsData['pagination']['total'];
                                $range = 2;
                                
                                for ($i = 1; $i <= $totalPages; $i++):
                                    if ($i == 1 || $i == $totalPages || ($i >= $page - $range && $i <= $page + $range)):
                                ?>
                                    <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                        <a class="page-link" 
                                           href="?page=call_logs_view&p=<?php echo $i; ?>&<?php 
                                                echo http_build_query(array_filter($_GET, function($key) {
                                                    return $key !== 'page' && $key !== 'p';
                                                }, ARRAY_FILTER_USE_KEY)); ?>">
                                            <?php echo $i; ?>
                                        </a>
                                    </li>
                                <?php endif; endfor; ?>
                                
                                <!-- Next Page -->
                                <?php if ($page < $totalPages): ?>
                                    <li class="page-item">
                                        <a class="page-link" 
                                           href="?page=call_logs_view&p=<?php echo ($page + 1); ?>&<?php 
                                                echo http_build_query(array_filter($_GET, function($key) {
                                                    return $key !== 'page' && $key !== 'p';
                                                }, ARRAY_FILTER_USE_KEY)); ?>" 
                                           aria-label="Next">
                                            <i class="ri-arrow-right-s-line"></i>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        
    <?php else: ?>
        <!-- Staff Detail View -->
        <?php if ($staffDetail): ?>
            <!-- Staff Performance Card -->
            <div class="card mb-4">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3 d-flex align-items-center">
                            <div class="text-center w-100">
                                <div class="avatar-circle avatar-xl bg-primary mx-auto mb-3">
                                    <?php if (!empty($staffDetail['profile_photo'])): ?>
                                        <img src="uploads/profile_photos/<?php echo htmlspecialchars($staffDetail['profile_photo']); ?>" 
                                            alt="<?php echo htmlspecialchars($staffDetail['staff_name']); ?>" 
                                            class="rounded-circle">
                                    <?php else: ?>
                                        <span class="fs-1"><?php echo strtoupper(substr($staffDetail['staff_name'], 0, 2)); ?></span>
                                    <?php endif; ?>
                                </div>
                                <h5 class="fw-bold"><?php echo htmlspecialchars($staffDetail['staff_name']); ?></h5>
                                <?php if (!empty($staffDetail['designation'])): ?>
                                    <p class="text-muted"><?php echo htmlspecialchars($staffDetail['designation']); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-9">
                            <h5 class="card-title">Performance Summary</h5>
                            
                            <div class="row g-4 mt-3">
                                <div class="col-md-3 col-6">
                                    <div class="card bg-light h-100">
                                        <div class="card-body text-center p-3">
                                            <h3 class="mb-0"><?php echo $staffDetail['today_calls']; ?></h3>
                                            <p class="text-muted mb-0">Today's Calls</p>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-3 col-6">
                                    <div class="card bg-light h-100">
                                        <div class="card-body text-center p-3">
                                            <h3 class="mb-0"><?php echo $staffDetail['week_calls']; ?></h3>
                                            <p class="text-muted mb-0">This Week</p>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-3 col-6">
                                    <div class="card bg-light h-100">
                                        <div class="card-body text-center p-3">
                                            <h3 class="mb-0"><?php echo $staffDetail['month_calls']; ?></h3>
                                            <p class="text-muted mb-0">This Month</p>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-3 col-6">
                                    <div class="card bg-light h-100">
                                        <div class="card-body text-center p-3">
                                            <h3 class="mb-0"><?php echo $staffDetail['month_conversions']; ?></h3>
                                            <p class="text-muted mb-0">Conversions</p>
                                                                                        <?php if ($staffDetail['month_calls'] > 0): ?>
                                                <small class="text-<?php echo ($staffDetail['month_conversions'] / $staffDetail['month_calls'] > 0.2) ? 'success' : 'muted'; ?>">
                                                    <?php echo number_format(($staffDetail['month_conversions'] / $staffDetail['month_calls']) * 100, 1); ?>% rate
                                                </small>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mt-4">
                                <h6>Performance Overview</h6>
                                <div class="progress mb-2" style="height: 10px;">
                                    <div class="progress-bar bg-success" role="progressbar" 
                                         style="width: <?php echo min(100, ($staffDetail['today_calls'] / 10) * 100); ?>%" 
                                         aria-valuenow="<?php echo $staffDetail['today_calls']; ?>" 
                                         aria-valuemin="0" 
                                         aria-valuemax="10">
                                    </div>
                                </div>
                                <div class="d-flex justify-content-between mb-3">
                                    <small class="text-muted">Today's target: <?php echo $staffDetail['today_calls']; ?>/10 calls</small>
                                    <small class="text-<?php echo $staffDetail['today_calls'] >= 10 ? 'success' : 'muted'; ?>">
                                        <?php echo $staffDetail['today_calls'] >= 10 ? 'Target reached' : (10 - $staffDetail['today_calls'] . ' more to reach target'); ?>
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Leads Handled Section -->
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">
                        <i class="ri-user-follow-line me-2"></i>
                        Leads Handled
                    </h5>
                </div>
                
                <div class="card-body p-0">
                    <?php if (!empty($leads['data'])): ?>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th scope="col">Lead</th>
                                        <th scope="col">Contact Info</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Last Call</th>
                                        <th scope="col" class="text-center">Total Calls</th>
                                        <th scope="col" class="text-end">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($leads['data'] as $lead): ?>
                                        <tr>
                                            <td>
                                                <div class="fw-medium"><?php echo htmlspecialchars($lead['lead_name']); ?></div>
                                            </td>
                                            <td>
                                                <div>
                                                    <div><i class="ri-mail-line me-1 text-muted"></i> <?php echo htmlspecialchars($lead['email']); ?></div>
                                                    <div><i class="ri-phone-line me-1 text-muted"></i> <?php echo htmlspecialchars($lead['phone']); ?></div>
                                                </div>
                                            </td>
                                            <td>
                                                <?php 
                                                $statusClass = 'bg-secondary';
                                                $statusIcon = 'ri-question-line';

                                                if (strpos($lead['lead_status'], 'Fresh') !== false) {
                                                    $statusClass = 'bg-success';
                                                    $statusIcon = 'ri-seedling-line';
                                                } else if (strpos($lead['lead_status'], 'call') !== false) {
                                                    $statusClass = 'bg-info';
                                                    $statusIcon = 'ri-phone-line';
                                                } else if (strpos($lead['lead_status'], 'Unable to reach') !== false) {
                                                    $statusClass = 'bg-warning';
                                                    $statusIcon = 'ri-phone-off-line';
                                                } else if ($lead['lead_status'] === 'Dead') {
                                                    $statusClass = 'bg-danger';
                                                    $statusIcon = 'ri-close-circle-line';
                                                } else if ($lead['lead_status'] === 'Will visit office') {
                                                    $statusClass = 'bg-primary';
                                                    $statusIcon = 'ri-calendar-check-line';
                                                } else if ($lead['lead_status'] === 'Admitted') {
                                                    $statusClass = 'bg-success';
                                                    $statusIcon = 'ri-user-star-line';
                                                }
                                                ?>
                                                <span class="badge <?php echo $statusClass; ?>">
                                                    <i class="<?php echo $statusIcon; ?> me-1"></i>
                                                    <?php echo htmlspecialchars($lead['lead_status']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php echo date('M j, Y g:i A', strtotime($lead['last_call_date'])); ?>
                                            </td>
                                            <td class="text-center">
                                                <span class="badge bg-primary px-3 py-2">
                                                    <?php echo $lead['call_count']; ?>
                                                </span>
                                            </td>
                                            <td class="text-end">
                                                <a href="?page=lead_management_view&view_lead=<?php echo $lead['lead_id']; ?>" 
                                                    class="btn btn-sm btn-outline-primary">
                                                    <i class="ri-eye-line me-1"></i>
                                                    View Lead
                                                </a>
                                                
                                                <a href="?page=call_logs_view&staff_id=<?php echo $viewingStaffId; ?>&lead_id=<?php echo $lead['lead_id']; ?>" 
                                                    class="btn btn-sm btn-outline-secondary ms-1">
                                                    <i class="ri-phone-line me-1"></i>
                                                    Call History
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <!-- Pagination for leads -->
                        <?php if ($leads['pagination']['total'] > 1): ?>
                            <div class="card-footer bg-white d-flex justify-content-center">
                                <nav aria-label="Leads pagination">
                                    <ul class="pagination pagination-sm mb-0">
                                        <!-- Previous Page -->
                                        <?php 
                                        $leadsPage = isset($_GET['leads_page']) ? max(1, (int)$_GET['leads_page']) : 1;
                                        if ($leadsPage > 1): 
                                        ?>
                                            <li class="page-item">
                                                <a class="page-link" 
                                                   href="?page=call_logs_view&view_staff=<?php echo $viewingStaffId; ?>&leads_page=<?php echo ($leadsPage - 1); ?>" 
                                                   aria-label="Previous">
                                                    <i class="ri-arrow-left-s-line"></i>
                                                </a>
                                            </li>
                                        <?php endif; ?>
                                        
                                        <!-- Page Numbers -->
                                        <?php
                                        $totalPages = $leads['pagination']['total'];
                                        $range = 2;
                                        
                                        for ($i = 1; $i <= $totalPages; $i++):
                                            if ($i == 1 || $i == $totalPages || ($i >= $leadsPage - $range && $i <= $leadsPage + $range)):
                                        ?>
                                            <li class="page-item <?php echo $i === $leadsPage ? 'active' : ''; ?>">
                                                <a class="page-link" 
                                                   href="?page=call_logs_view&view_staff=<?php echo $viewingStaffId; ?>&leads_page=<?php echo $i; ?>">
                                                    <?php echo $i; ?>
                                                </a>
                                            </li>
                                        <?php endif; endfor; ?>
                                        
                                        <!-- Next Page -->
                                        <?php if ($leadsPage < $totalPages): ?>
                                            <li class="page-item">
                                                <a class="page-link" 
                                                   href="?page=call_logs_view&view_staff=<?php echo $viewingStaffId; ?>&leads_page=<?php echo ($leadsPage + 1); ?>" 
                                                   aria-label="Next">
                                                    <i class="ri-arrow-right-s-line"></i>
                                                </a>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </nav>
                            </div>
                        <?php endif; ?>
                        
                    <?php else: ?>
                        <div class="text-center py-4">
                            <div class="mb-3">
                                <i class="ri-user-search-line fs-1 text-muted"></i>
                            </div>
                            <p class="text-muted">No leads have been handled by this staff member yet.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Filters for specific staff's calls -->
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">
                        <i class="ri-filter-3-line me-2"></i>
                        Filter Staff Calls
                    </h5>
                </div>
                <div class="card-body">
                    <form method="GET" class="row g-3">
                        <input type="hidden" name="page" value="call_logs_view">
                        <input type="hidden" name="view_staff" value="<?php echo $viewingStaffId; ?>">
                        
                        <!-- Date Range -->
                        <div class="col-md-4">
                            <label class="form-label">From Date</label>
                            <input type="date" class="form-control" name="date_from" 
                                   value="<?php echo isset($_GET['date_from']) ? htmlspecialchars($_GET['date_from']) : ''; ?>">
                        </div>
                        
                        <div class="col-md-4">
                            <label class="form-label">To Date</label>
                            <input type="date" class="form-control" name="date_to" 
                                   value="<?php echo isset($_GET['date_to']) ? htmlspecialchars($_GET['date_to']) : ''; ?>">
                        </div>
                        
                        <!-- Call Type -->
                        <div class="col-md-4">
                            <label class="form-label">Call Type</label>
                            <select class="form-select" name="call_type">
                                <option value="">All Types</option>
                                <option value="1st call" <?php echo isset($_GET['call_type']) && $_GET['call_type'] === '1st call' ? 'selected' : ''; ?>>1st Call</option>
                                <option value="2nd call" <?php echo isset($_GET['call_type']) && $_GET['call_type'] === '2nd call' ? 'selected' : ''; ?>>2nd Call</option>
                                <option value="3rd call" <?php echo isset($_GET['call_type']) && $_GET['call_type'] === '3rd call' ? 'selected' : ''; ?>>3rd Call</option>
                                <option value="Office visit confirmation" <?php echo isset($_GET['call_type']) && $_GET['call_type'] === 'Office visit confirmation' ? 'selected' : ''; ?>>Office Visit Confirmation</option>
                                <option value="Final call" <?php echo isset($_GET['call_type']) && $_GET['call_type'] === 'Final call' ? 'selected' : ''; ?>>Final Call</option>
                            </select>
                        </div>
                        
                        <!-- Filter Actions -->
                        <div class="col-12 d-flex justify-content-between">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="converted" value="1" id="convertedOnly" <?php echo isset($_GET['converted']) && $_GET['converted'] == 1 ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="convertedOnly">
                                    Show only calls that led to conversion
                                </label>
                            </div>
                            
                            <div>
                                <a href="?page=call_logs_view&view_staff=<?php echo $viewingStaffId; ?>" class="btn btn-outline-secondary me-2">
                                    <i class="ri-refresh-line me-1"></i>
                                    Reset
                                </a>
                                <button type="submit" class="btn btn-primary">
                                    <i class="ri-filter-3-line me-1"></i>
                                    Apply Filters
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            
        <?php else: ?>
            <div class="card">
                <div class="card-body text-center py-5">
                    <i class="ri-user-search-line fs-1 text-muted mb-3"></i>
                    <h5>Staff member not found</h5>
                    <p class="text-muted">The requested staff member could not be found or you don't have permission to view their details.</p>
                    <a href="?page=call_logs_view" class="btn btn-primary">
                        <i class="ri-arrow-left-line me-1"></i>
                        Return to Staff List
                    </a>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<!-- View Call Log Modal -->
<div class="modal fade" id="viewCallLogModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="ri-phone-line me-2"></i>
                    Call Log Details
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <?php if ($canManageCallLogs): ?>
            <form method="POST">
                <input type="hidden" name="update_call_log" value="1">
                <input type="hidden" name="call_log_id" id="call_log_id">
                <div class="modal-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Lead</label>
                                <div class="form-control-plaintext" id="view_lead_name"></div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Staff</label>
                                <div class="form-control-plaintext" id="view_staff_name"></div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Call Date</label>
                                <div class="form-control-plaintext" id="view_call_date"></div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Call Type</label>
                                <div class="badge bg-primary" id="view_call_type"></div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-12">
                            <div class="mb-3">
                                <label class="form-label">Status Change</label>
                                <div class="d-flex align-items-center">
                                    <span class="badge bg-light text-dark" id="view_previous_status"></span>
                                    <i class="ri-arrow-right-line mx-2"></i>
                                    <span class="badge bg-primary" id="view_new_status"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Call Duration (seconds)</label>
                                <input type="number" class="form-control" name="call_duration" id="view_call_duration" min="0">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Call Outcome</label>
                                <input type="text" class="form-control" name="call_outcome" id="view_call_outcome">
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Call Notes</label>
                        <textarea class="form-control" name="call_notes" id="view_call_notes" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Update Call Log</button>
                </div>
            </form>
            <?php else: ?>
            <div class="modal-body">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">Lead</label>
                            <div class="form-control-plaintext" id="view_lead_name"></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">Staff</label>
                            <div class="form-control-plaintext" id="view_staff_name"></div>
                        </div>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">Call Date</label>
                            <div class="form-control-plaintext" id="view_call_date"></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">Call Type</label>
                            <div class="badge bg-primary" id="view_call_type"></div>
                        </div>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-12">
                        <div class="mb-3">
                            <label class="form-label">Status Change</label>
                            <div class="d-flex align-items-center">
                                <span class="badge bg-light text-dark" id="view_previous_status"></span>
                                <i class="ri-arrow-right-line mx-2"></i>
                                <span class="badge bg-primary" id="view_new_status"></span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">Call Duration</label>
                            <div class="form-control-plaintext" id="view_call_duration_text"></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">Call Outcome</label>
                            <div class="form-control-plaintext" id="view_call_outcome_text"></div>
                        </div>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Call Notes</label>
                    <div class="form-control-plaintext bg-light p-2 rounded" id="view_call_notes_text"></div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Delete Call Log Modal -->
<?php if ($canManageCallLogs): ?>
<div class="modal fade" id="deleteCallLogModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">
                    <i class="ri-delete-bin-line me-2"></i>
                    Delete Call Log
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="delete_call_log" value="1">
                <input type="hidden" name="call_log_id" id="delete_call_log_id">
                <div class="modal-body">
                    <div class="text-center mb-4">
                        <i class="ri-error-warning-line text-danger fs-1"></i>
                        <h5 class="mt-3">Are you sure you want to delete this call log?</h5>
                        <p class="text-muted mb-0">Lead: <strong id="delete_lead_name"></strong></p>
                        <p class="text-muted mb-0">Date: <strong id="delete_call_date"></strong></p>
                    </div>
                    <div class="alert alert-warning">
                        <i class="ri-alert-line me-2"></i>
                        This action cannot be undone. The call log will be permanently removed from the system.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        <i class="ri-close-line me-1"></i>
                        Cancel
                    </button>
                    <button type="submit" class="btn btn-danger">
                        <i class="ri-delete-bin-line me-1"></i>
                        Delete Call Log
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Filter Modal -->
<div class="modal fade" id="filtersModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="ri-filter-3-line me-2"></i>
                    Filter Call Logs
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="GET" action="?page=call_logs_view">
                <input type="hidden" name="page" value="call_logs_view">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Staff Member</label>
                        <select class="form-select" name="staff_id">
                            <option value="">All Staff</option>
                            <?php foreach ($staffStats as $staff): ?>
                                <option value="<?php echo $staff['staff_id']; ?>" <?php echo isset($_GET['staff_id']) && $_GET['staff_id'] == $staff['staff_id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($staff['staff_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">From Date</label>
                            <input type="date" class="form-control" name="date_from" 
                                   value="<?php echo isset($_GET['date_from']) ? htmlspecialchars($_GET['date_from']) : ''; ?>">
                        </div>
                        
                        <div class="col-md-6">
                            <label class="form-label">To Date</label>
                            <input type="date" class="form-control" name="date_to" 
                                   value="<?php echo isset($_GET['date_to']) ? htmlspecialchars($_GET['date_to']) : ''; ?>">
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Call Type</label>
                        <select class="form-select" name="call_type">
                            <option value="">All Types</option>
                            <option value="1st call" <?php echo isset($_GET['call_type']) && $_GET['call_type'] === '1st call' ? 'selected' : ''; ?>>1st Call</option>
                            <option value="2nd call" <?php echo isset($_GET['call_type']) && $_GET['call_type'] === '2nd call' ? 'selected' : ''; ?>>2nd Call</option>
                            <option value="3rd call" <?php echo isset($_GET['call_type']) && $_GET['call_type'] === '3rd call' ? 'selected' : ''; ?>>3rd Call</option>
                            <option value="Office visit confirmation" <?php echo isset($_GET['call_type']) && $_GET['call_type'] === 'Office visit confirmation' ? 'selected' : ''; ?>>Office Visit Confirmation</option>
                            <option value="Final call" <?php echo isset($_GET['call_type']) && $_GET['call_type'] === 'Final call' ? 'selected' : ''; ?>>Final Call</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Search</label>
                        <input type="text" class="form-control" name="search" placeholder="Search by name, email or phone" 
                               value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                    </div>
                    
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" name="converted" value="1" id="filterConvertedOnly" <?php echo isset($_GET['converted']) && $_GET['converted'] == 1 ? 'checked' : ''; ?>>
                        <label class="form-check-label" for="filterConvertedOnly">
                            Show only calls that led to conversion
                        </label>
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="?page=call_logs_view" class="btn btn-outline-secondary">
                        <i class="ri-refresh-line me-1"></i>
                        Reset
                    </a>
                    <button type="submit" class="btn btn-primary">
                        <i class="ri-filter-3-line me-1"></i>
                        Apply Filters
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
.call-logs-container {
    max-width: 1400px;
    margin: 1rem auto;
    padding: 1rem;
    background: #ffffff;
    border-radius: 1rem;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
}

.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
    flex-wrap: wrap;
    gap: 1rem;
}

.avatar-circle {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    color: white;
    font-weight: 600;
    overflow: hidden;
}

.avatar-circle.avatar-xl {
    width: 100px;
    height: 100px;
}

.avatar-circle.avatar-sm {
    width: 32px;
    height: 32px;
    font-size: 0.75rem;
}

.avatar-circle.avatar-xs {
    width: 24px;
    height: 24px;
    font-size: 0.625rem;
}

.avatar-circle img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

@media (max-width: 768px) {
    .call-logs-container {
        margin: 0;
        padding: 1rem;
        border-radius: 0;
    }
    
    .page-header {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .avatar-circle.avatar-xl {
        width: 80px;
        height: 80px;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // View Call Log modal
    const viewCallLogModal = document.getElementById('viewCallLogModal');
    if (viewCallLogModal) {
        viewCallLogModal.addEventListener('show.bs.modal', function (event) {
            const button = event.relatedTarget;
            
            // Extract info from data-* attributes
            const callLogId = button.getAttribute('data-call-log-id');
            const leadName = button.getAttribute('data-call-lead-name');
            const staffName = button.getAttribute('data-call-staff-name');
            const callDate = button.getAttribute('data-call-date');
            const callType = button.getAttribute('data-call-type');
            const previousStatus = button.getAttribute('data-call-previous-status');
            const newStatus = button.getAttribute('data-call-new-status');
            const callDuration = button.getAttribute('data-call-duration');
            const callOutcome = button.getAttribute('data-call-outcome');
            const callNotes = button.getAttribute('data-call-log-notes');
            
            // Update modal content
            const modal = event.target;
            
            // Update form fields
            if (modal.querySelector('#call_log_id')) {
                modal.querySelector('#call_log_id').value = callLogId;
            }
            
            // Update text fields
            modal.querySelector('#view_lead_name').textContent = leadName;
            modal.querySelector('#view_staff_name').textContent = staffName;
            modal.querySelector('#view_call_date').textContent = callDate;
            modal.querySelector('#view_call_type').textContent = callType;
            modal.querySelector('#view_previous_status').textContent = previousStatus;
            modal.querySelector('#view_new_status').textContent = newStatus;
            
            // Update editable fields (for admin users)
            if (modal.querySelector('#view_call_duration')) {
                modal.querySelector('#view_call_duration').value = callDuration;
            }
            
            if (modal.querySelector('#view_call_outcome')) {
                modal.querySelector('#view_call_outcome').value = callOutcome;
            }
            
            if (modal.querySelector('#view_call_notes')) {
                modal.querySelector('#view_call_notes').value = callNotes;
            }
            
            // Update read-only text fields (for non-admin users)
            if (modal.querySelector('#view_call_duration_text')) {
                modal.querySelector('#view_call_duration_text').textContent = 
                    callDuration ? callDuration + ' seconds' : 'Not recorded';
            }
            
            if (modal.querySelector('#view_call_outcome_text')) {
                modal.querySelector('#view_call_outcome_text').textContent = 
                    callOutcome ? callOutcome : 'Not recorded';
            }
            
            if (modal.querySelector('#view_call_notes_text')) {
                modal.querySelector('#view_call_notes_text').textContent = 
                    callNotes ? callNotes : 'No notes were recorded for this call.';
            }
        });
    }
    
    // Delete Call Log modal
    const deleteCallLogModal = document.getElementById('deleteCallLogModal');
    if (deleteCallLogModal) {
        deleteCallLogModal.addEventListener('show.bs.modal', function (event) {
            const button = event.relatedTarget;
            
            // Extract info from data-* attributes
            const callLogId = button.getAttribute('data-call-log-id');
            const leadName = button.getAttribute('data-call-lead-name');
            const callDate = button.getAttribute('data-call-date');
            
            // Update modal content
            const modal = event.target;
            modal.querySelector('#delete_call_log_id').value = callLogId;
            modal.querySelector('#delete_lead_name').textContent = leadName;
            modal.querySelector('#delete_call_date').textContent = callDate;
        });
    }
});
</script>