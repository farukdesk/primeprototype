<?php
require_once 'config/config.php';
require_once 'app/controllers/PasswordController.php';

$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    try {
        $passwordController = new PasswordController($conn);

        $data = [
            'user_id' => $_SESSION['user_id'],
            'current_password' => $_POST['current_password'],
            'new_password' => $_POST['new_password'],
            'confirm_password' => $_POST['confirm_password']
        ];

        if ($passwordController->changePassword($data)) {
            $success = "Password changed successfully!";
        }
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>

<style>
    .password-container {
        max-width: 500px;
        margin: 2rem auto;
        padding: 2rem;
        background: white;
        border-radius: 15px;
        box-shadow: 0 0 20px rgba(0,0,0,0.1);
    }

    .password-requirements {
        font-size: 0.85rem;
        color: #666;
        margin-top: 1rem;
        padding: 1rem;
        background: #f8f9fa;
        border-radius: 8px;
    }

    .password-requirements ul {
        margin-bottom: 0;
        padding-left: 1.2rem;
    }

    .form-floating {
        margin-bottom: 1rem;
    }
</style>

<div class="password-container">
    <h4 class="mb-4">Change Password</h4>

    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($success); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <form method="POST" class="needs-validation" novalidate>
        <div class="form-floating">
            <input type="password"
                   class="form-control"
                   id="current_password"
                   name="current_password"
                   required>
            <label for="current_password">Current Password</label>
        </div>

        <div class="form-floating">
            <input type="password"
                   class="form-control"
                   id="new_password"
                   name="new_password"
                   required>
            <label for="new_password">New Password</label>
        </div>

        <div class="form-floating">
            <input type="password"
                   class="form-control"
                   id="confirm_password"
                   name="confirm_password"
                   required>
            <label for="confirm_password">Confirm New Password</label>
        </div>

        <div class="password-requirements">
            <p class="mb-2">Password must meet the following requirements:</p>
            <ul>
                <li>At least 8 characters long</li>
                <li>Contains at least one uppercase letter</li>
                <li>Contains at least one lowercase letter</li>
                <li>Contains at least one number</li>
                <li>Contains at least one special character</li>
            </ul>
        </div>

        <div class="mt-4">
            <button type="submit" name="change_password" class="btn btn-primary w-100">
                <i class="ri-lock-password-line me-1"></i> Change Password
            </button>
        </div>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Form validation
    const form = document.querySelector('form');
    form.addEventListener('submit', function(event) {
        if (!form.checkValidity()) {
            event.preventDefault();
            event.stopPropagation();
        }
        form.classList.add('was-validated');
    });

    // Password match validation
    const newPassword = document.getElementById('new_password');
    const confirmPassword = document.getElementById('confirm_password');

    function validatePasswordMatch() {
        if (confirmPassword.value !== newPassword.value) {
            confirmPassword.setCustomValidity("Passwords do not match");
        } else {
            confirmPassword.setCustomValidity("");
        }
    }

    newPassword.addEventListener('change', validatePasswordMatch);
    confirmPassword.addEventListener('keyup', validatePasswordMatch);
});
</script>