<?php
/**
 * Course Management View
 * Restructured on: 2026-01-14
 * Purpose: Simplified course management with only title, department, and credit
 */

require_once __DIR__ . '/../controllers/course_management_controller.php';

// Initialize controller
$courseController = new CourseManagementController($conn);

// Check permissions
if (!$courseController->hasPermission()) {
    header("Location: /dashboard.php");
    exit();
}

$success = $error = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create_course'])) {
        $result = $courseController->createCourse($_POST);
        if ($result['status']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    } elseif (isset($_POST['update_course'])) {
        $result = $courseController->updateCourse($_POST);
        if ($result['status']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    } elseif (isset($_POST['delete_course'])) {
        $result = $courseController->deleteCourse($_POST['course_id']);
        if ($result['status']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    }
}

// Get current page
$page = isset($_GET['p']) ? max(1, (int)$_GET['p']) : 1;

// Get courses with filters and pagination
$result = $courseController->handleRequest();

// Is user admin?
$isAdmin = $courseController->isAdmin();

// Get filter options
$departments = $result['departments'] ?? [];

// Get current filters
$filters = $result['filters'] ?? [];
?>

<div class="course-container">
    <!-- Page Header -->
    <div class="page-header">
        <div>
            <h1 class="page-title">
                <i class="ri-book-open-line me-2"></i>
                Course Management
            </h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/dashboard.php">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Courses</li>
                </ol>
            </nav>
        </div>
        
        <?php if ($isAdmin): ?>
        <button type="button" 
                class="btn btn-custom btn-primary" 
                data-bs-toggle="modal" 
                data-bs-target="#addCourseModal">
            <i class="ri-add-circle-line me-1"></i>
            Add New Course
        </button>
        <?php endif; ?>
    </div>

    <!-- Alert Messages -->
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show d-flex align-items-center" role="alert">
            <i class="ri-checkbox-circle-line me-2"></i>
            <div class="flex-grow-1">
                <?php echo htmlspecialchars($success); ?>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show d-flex align-items-center" role="alert">
            <i class="ri-error-warning-line me-2"></i>
            <div class="flex-grow-1">
                <?php echo htmlspecialchars($error); ?>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Stats Card -->
    <div class="row g-3 mb-4">
        <div class="col-md-12">
            <div class="card bg-light">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-subtitle mb-1 text-muted">Total Courses</h6>
                            <h3 class="card-title mb-0">
                                <?php echo number_format($result['stats']['total_courses'] ?? 0); ?>
                            </h3>
                        </div>
                        <div class="fs-1 text-primary">
                            <i class="ri-book-open-line"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Filters Section -->
    <div class="filters-section mb-4">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <i class="ri-filter-3-line me-1"></i> 
                    Filter Courses
                </h5>
                <button class="btn btn-sm btn-link text-muted" type="button" data-bs-toggle="collapse" data-bs-target="#filterCollapse" aria-expanded="false">
                    <i class="ri-arrow-down-s-line"></i>
                </button>
            </div>
            <div class="collapse show" id="filterCollapse">
                <div class="card-body">
                    <form method="GET" class="row g-3">
                        <input type="hidden" name="page" value="course_management">
                        
                        <!-- Search Input -->
                        <div class="col-lg-4 col-md-6">
                            <div class="form-floating">
                                <input type="text" 
                                       class="form-control" 
                                       name="search" 
                                       id="search"
                                       placeholder="Search courses..."
                                       value="<?php echo htmlspecialchars($filters['search'] ?? ''); ?>">
                                <label for="search">
                                    <i class="ri-search-line me-1"></i>
                                    Search Courses or Department
                                </label>
                            </div>
                        </div>

                        <!-- Department Filter -->
                        <div class="col-lg-4 col-md-6">
                            <div class="form-floating">
                                <select class="form-select" name="department" id="filter_department">
                                    <option value="">All Departments</option>
                                    <?php foreach ($departments as $dept): ?>
                                        <option value="<?php echo htmlspecialchars($dept); ?>" 
                                            <?php echo (isset($filters['department']) && $filters['department'] == $dept) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($dept); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <label for="filter_department">Department</label>
                            </div>
                        </div>

                        <!-- Sort By Filter -->
                        <div class="col-lg-4 col-md-6">
                            <div class="form-floating">
                                <select class="form-select" name="sort" id="sort_by">
                                    <option value="">Default Sorting</option>
                                    <option value="title_asc" <?php echo (isset($filters['sort']) && $filters['sort'] == 'title_asc') ? 'selected' : ''; ?>>Course Title (A-Z)</option>
                                    <option value="title_desc" <?php echo (isset($filters['sort']) && $filters['sort'] == 'title_desc') ? 'selected' : ''; ?>>Course Title (Z-A)</option>
                                    <option value="department_asc" <?php echo (isset($filters['sort']) && $filters['sort'] == 'department_asc') ? 'selected' : ''; ?>>Department (A-Z)</option>
                                    <option value="department_desc" <?php echo (isset($filters['sort']) && $filters['sort'] == 'department_desc') ? 'selected' : ''; ?>>Department (Z-A)</option>
                                    <option value="credit_asc" <?php echo (isset($filters['sort']) && $filters['sort'] == 'credit_asc') ? 'selected' : ''; ?>>Credit (Low to High)</option>
                                    <option value="credit_desc" <?php echo (isset($filters['sort']) && $filters['sort'] == 'credit_desc') ? 'selected' : ''; ?>>Credit (High to Low)</option>
                                </select>
                                <label for="sort_by">Sort By</label>
                            </div>
                        </div>

                        <!-- Filter Actions -->
                        <div class="col-12 d-flex justify-content-end gap-2">
                            <a href="?page=course_management" 
                               class="btn btn-outline-secondary" 
                               title="Reset Filters">
                                <i class="ri-refresh-line me-1"></i>
                                Reset
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class="ri-filter-3-line me-1"></i>
                                Apply Filters
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Courses Table Section -->
    <div class="table-section">
        <?php if (!empty($result['data'])): ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th scope="col">Course Title</th>
                            <th scope="col">Department</th>
                            <th scope="col">Credit</th>
                            <?php if ($isAdmin): ?>
                            <th scope="col" class="text-end">Actions</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($result['data'] as $course): ?>
                            <tr>
                                <td>
                                    <div class="course-title">
                                        <strong><?php echo htmlspecialchars($course['course_title']); ?></strong>
                                    </div>
                                </td>
                                <td><?php echo htmlspecialchars($course['department']); ?></td>
                                <td>
                                    <span class="badge bg-info">
                                        <?php echo htmlspecialchars($course['credit']); ?> credits
                                    </span>
                                </td>
                                <?php if ($isAdmin): ?>
                                <td class="text-end">
                                    <div class="action-buttons">
                                        <button type="button" 
                                                class="btn btn-sm btn-outline-info me-1" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#editCourseModal"
                                                data-course='<?php echo htmlspecialchars(json_encode($course)); ?>'
                                                title="Edit Course">
                                            <i class="ri-edit-line"></i>
                                        </button>
                                        <button type="button" 
                                                class="btn btn-sm btn-outline-danger" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#deleteCourseModal"
                                                data-course-id="<?php echo $course['id']; ?>"
                                                data-course-title="<?php echo htmlspecialchars($course['course_title']); ?>"
                                                title="Delete Course">
                                            <i class="ri-delete-bin-line"></i>
                                        </button>
                                    </div>
                                </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <?php if ($result['pagination']['total'] > 1): ?>
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mt-4">
                    <!-- Pagination Info -->
                    <div class="pagination-info text-muted small">
                        Showing 
                        <strong><?php 
                            $start = ($page - 1) * 10 + 1;
                            echo $start;
                        ?></strong> to 
                        <strong><?php 
                            $end = min($start + 9, $result['pagination']['total_records']);
                            echo $end;
                        ?></strong> of 
                        <strong><?php echo $result['pagination']['total_records']; ?></strong> courses
                    </div>

                    <!-- Pagination Navigation -->
                    <nav aria-label="Course navigation">
                        <ul class="pagination pagination-md mb-0">
                            <!-- Previous Page -->
                            <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" 
                                       href="?page=course_management&p=<?php echo ($page - 1); ?>&<?php 
                                            echo http_build_query(array_filter($filters)); ?>" 
                                       aria-label="Previous">
                                        <i class="ri-arrow-left-s-line"></i>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <!-- Page Numbers -->
                            <?php
                            $totalPages = $result['pagination']['total'];
                            $range = 2;
                            
                            for ($i = 1; $i <= $totalPages; $i++):
                                if ($i == 1 || $i == $totalPages || 
                                    ($i >= $page - $range && $i <= $page + $range)):
                            ?>
                                <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                    <a class="page-link" 
                                       href="?page=course_management&p=<?php echo $i; ?>&<?php 
                                            echo http_build_query(array_filter($filters)); ?>">
                                        <?php echo $i; ?>
                                    </a>
                                </li>
                            <?php endif; endfor; ?>

                            <!-- Next Page -->
                            <?php if ($page < $totalPages): ?>
                                <li class="page-item">
                                    <a class="page-link" 
                                       href="?page=course_management&p=<?php echo ($page + 1); ?>&<?php 
                                            echo http_build_query(array_filter($filters)); ?>" 
                                       aria-label="Next">
                                        <i class="ri-arrow-right-s-line"></i>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
            <?php endif; ?>

        <?php else: ?>
            <!-- No Results Found -->
            <div class="text-center py-5">
                <div class="no-data-icon mb-3">
                    <i class="ri-book-open-line fs-1 text-muted"></i>
                </div>
                <h5 class="text-muted">No courses found</h5>
                <p class="text-muted small mb-3">
                    <?php if (!empty(array_filter($filters))): ?>
                        Try adjusting your filters
                        <?php if ($isAdmin): ?>
                            or add a new course to get started
                        <?php endif; ?>
                    <?php else: ?>
                        <?php if ($isAdmin): ?>
                            Add your first course to get started
                        <?php else: ?>
                            No courses have been added yet
                        <?php endif; ?>
                    <?php endif; ?>
                </p>
                <?php if ($isAdmin): ?>
                    <button type="button" 
                            class="btn btn-primary" 
                            data-bs-toggle="modal" 
                            data-bs-target="#addCourseModal">
                        <i class="ri-add-line me-1"></i>
                        Add Course
                    </button>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php if ($isAdmin): ?>
<!-- Add Course Modal -->
<div class="modal fade" id="addCourseModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-light">
                <h5 class="modal-title">
                    <i class="ri-book-open-line me-2"></i>
                    Add New Course
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate>
                <div class="modal-body">
                    <div class="row g-3">
                        <!-- Course Title -->
                        <div class="col-md-12">
                            <div class="form-floating">
                                <input type="text" 
                                       class="form-control" 
                                       name="course_title" 
                                       id="add_course_title"
                                       placeholder="Enter course title"
                                       required>
                                <label for="add_course_title">Course Title</label>
                                <div class="invalid-feedback">
                                    Please provide a course title.
                                </div>
                            </div>
                        </div>

                        <!-- Department -->
                        <div class="col-md-12">
                            <div class="form-floating">
                                <input type="text" 
                                       class="form-control" 
                                       name="department" 
                                       id="add_department"
                                       placeholder="Enter department"
                                       required>
                                <label for="add_department">Department</label>
                                <div class="invalid-feedback">
                                    Please provide a department.
                                </div>
                            </div>
                        </div>

                        <!-- Credit -->
                        <div class="col-md-12">
                            <div class="form-floating">
                                <input type="number" 
                                       class="form-control" 
                                       name="credit" 
                                       id="add_credit"
                                       placeholder="Enter credit hours"
                                       min="0"
                                       step="1"
                                       required>
                                <label for="add_credit">Credit Hours</label>
                                <div class="invalid-feedback">
                                    Please provide credit hours.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" 
                            class="btn btn-outline-secondary" 
                            data-bs-dismiss="modal">
                        <i class="ri-close-line me-1"></i>
                        Cancel
                    </button>
                    <button type="submit" 
                            name="create_course" 
                            class="btn btn-primary">
                        <i class="ri-save-line me-1"></i>
                        Save Course
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Course Modal -->
<div class="modal fade" id="editCourseModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-light">
                <h5 class="modal-title">
                    <i class="ri-edit-line me-2"></i>
                    Edit Course
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="course_id" id="edit_course_id">
                <div class="modal-body">
                    <div class="row g-3">
                        <!-- Course Title -->
                        <div class="col-md-12">
                            <div class="form-floating">
                                <input type="text" 
                                       class="form-control" 
                                       name="course_title" 
                                       id="edit_course_title"
                                       placeholder="Enter course title"
                                       required>
                                <label for="edit_course_title">Course Title</label>
                                <div class="invalid-feedback">
                                    Please provide a course title.
                                </div>
                            </div>
                        </div>

                        <!-- Department -->
                        <div class="col-md-12">
                            <div class="form-floating">
                                <input type="text" 
                                       class="form-control" 
                                       name="department" 
                                       id="edit_department"
                                       placeholder="Enter department"
                                       required>
                                <label for="edit_department">Department</label>
                                <div class="invalid-feedback">
                                    Please provide a department.
                                </div>
                            </div>
                        </div>

                        <!-- Credit -->
                        <div class="col-md-12">
                            <div class="form-floating">
                                <input type="number" 
                                       class="form-control" 
                                       name="credit" 
                                       id="edit_credit"
                                       placeholder="Enter credit hours"
                                       min="0"
                                       step="1"
                                       required>
                                <label for="edit_credit">Credit Hours</label>
                                <div class="invalid-feedback">
                                    Please provide credit hours.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" 
                            class="btn btn-outline-secondary" 
                            data-bs-dismiss="modal">
                        <i class="ri-close-line me-1"></i>
                        Cancel
                    </button>
                    <button type="submit" 
                            name="update_course" 
                            class="btn btn-primary">
                        <i class="ri-save-line me-1"></i>
                        Update Course
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Course Modal -->
<div class="modal fade" id="deleteCourseModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">
                    <i class="ri-delete-bin-line me-2"></i>
                    Delete Course
                </h5>
                <button type="button" 
                        class="btn-close btn-close-white" 
                        data-bs-dismiss="modal" 
                        aria-label="Close"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="course_id" id="delete_course_id">
                <div class="modal-body">
                    <div class="text-center mb-4">
                        <i class="ri-error-warning-line text-danger fs-1"></i>
                        <h5 class="mt-3">Are you sure you want to delete this course?</h5>
                        <p class="text-muted mb-0">Title: <strong id="delete_course_title"></strong></p>
                    </div>
                    <div class="alert alert-warning">
                        <i class="ri-alert-line me-2"></i>
                        This action cannot be undone. All data associated with this course will be permanently removed.
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" 
                            class="btn btn-outline-secondary" 
                            data-bs-dismiss="modal">
                        <i class="ri-close-line me-1"></i>
                        Cancel
                    </button>
                    <button type="submit" 
                            name="delete_course" 
                            class="btn btn-danger">
                        <i class="ri-delete-bin-line me-1"></i>
                        Delete Course
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- JavaScript for Course Management -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });

    // Handle Edit Course Modal
    const editButtons = document.querySelectorAll('[data-bs-target="#editCourseModal"]');
    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            try {
                const course = JSON.parse(this.dataset.course);
                populateEditForm(course);
            } catch (e) {
                console.error("Error parsing course data:", e);
            }
        });
    });

    function populateEditForm(course) {
        // Populate form fields
        document.getElementById('edit_course_id').value = course.id;
        document.getElementById('edit_course_title').value = course.course_title;
        document.getElementById('edit_department').value = course.department;
        document.getElementById('edit_credit').value = course.credit;
    }

    // Handle Delete Course Modal
    const deleteButtons = document.querySelectorAll('[data-bs-target="#deleteCourseModal"]');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function() {
            document.getElementById('delete_course_id').value = this.dataset.courseId;
            document.getElementById('delete_course_title').textContent = this.dataset.courseTitle;
        });
    });

    // Form Validation Handler
    const forms = document.querySelectorAll('.needs-validation');
    forms.forEach(form => {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    });
});
</script>

<style>
    .course-container {
        max-width: 1200px;
        margin: 1rem auto;
        padding: 1rem;
        background: #ffffff;
        border-radius: 1rem;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    }

    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 1.5rem;
        flex-wrap: wrap;
        gap: 1rem;
    }

    .filters-section .card-header {
        background-color: #f8f9fa;
        padding: 0.75rem 1rem;
    }

    .filters-section .card-body {
        padding: 1.5rem;
    }

    .course-title {
        max-width: 400px;
    }

    @media (max-width: 768px) {
        .course-container {
            margin: 0;
            padding: 1rem;
            border-radius: 0;
        }

        .page-header {
            flex-direction: column;
            align-items: stretch;
        }
    }
</style>
