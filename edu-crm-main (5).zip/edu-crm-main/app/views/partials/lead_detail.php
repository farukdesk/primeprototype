<?php
/**
 * Lead Detail Partial Template
 * Created on: 2025-05-05
 * Created by: farukdesk
 */

// Helper function for pluralization
if (!function_exists('pluralize')) {
    function pluralize($count, $singular, $plural = null) {
        if ($plural === null) {
            $plural = $singular . 's';
        }
        return $count == 1 ? $singular : $plural;
    }
}
?>

<div class="lead-detail-view">
    <!-- Lead Profile Header -->
    <div class="lead-profile-header">
        <div class="lead-avatar bg-primary text-white">
            <?php echo strtoupper(substr($leadDetails['first_name'], 0, 1) . substr($leadDetails['last_name'], 0, 1)); ?>
        </div>
        
        <div class="lead-basic-info">
            <div class="d-flex justify-content-between align-items-start flex-wrap">
                <div>
                    <h2 class="mb-1"><?php echo htmlspecialchars($leadDetails['first_name'] . ' ' . $leadDetails['last_name']); ?></h2>
                    <div class="mb-2 text-muted">
                        <i class="ri-mail-line me-1"></i> <?php echo htmlspecialchars($leadDetails['email']); ?> 
                        <span class="mx-2">|</span>
                        <i class="ri-phone-line me-1"></i> <?php echo htmlspecialchars($leadDetails['phone']); ?>
                    </div>
                    
                    <div class="mb-3">
                        <?php 
                        $statusClass = 'bg-secondary';
                        $statusIcon = 'ri-question-line';

                        if (strpos($leadDetails['lead_status'], 'Fresh') !== false) {
                            $statusClass = 'bg-success';
                            $statusIcon = 'ri-seedling-line';
                        } else if (strpos($leadDetails['lead_status'], 'call') !== false) {
                            $statusClass = 'bg-info';
                            $statusIcon = 'ri-phone-line';
                        } else if (strpos($leadDetails['lead_status'], 'Unable to reach') !== false) {
                            $statusClass = 'bg-warning';
                            $statusIcon = 'ri-phone-off-line';
                        } else if ($leadDetails['lead_status'] === 'Dead') {
                            $statusClass = 'bg-danger';
                            $statusIcon = 'ri-close-circle-line';
                        } else if ($leadDetails['lead_status'] === 'Will visit office') {
                            $statusClass = 'bg-primary';
                            $statusIcon = 'ri-calendar-check-line';
                        } else if ($leadDetails['lead_status'] === 'Admitted') {
                            $statusClass = 'bg-success';
                            $statusIcon = 'ri-user-star-line';
                        }
                        ?>
                        <span class="badge <?php echo $statusClass; ?>">
                            <i class="<?php echo $statusIcon; ?> me-1"></i>
                            <?php echo htmlspecialchars($leadDetails['lead_status']); ?>
                        </span>
                        
                        <?php if ($leadDetails['lead_source'] === 'Direct Online'): ?>
                            <span class="badge bg-primary-subtle text-primary ms-2">
                                <i class="ri-global-line me-1"></i> Online Lead
                            </span>
                        <?php elseif ($leadDetails['lead_source'] === 'Direct Campus Visit'): ?>
                            <span class="badge bg-success-subtle text-success ms-2">
                                <i class="ri-building-line me-1"></i> Campus Visit Lead
                            </span>
                        <?php elseif ($leadDetails['lead_source'] === 'Agent'): ?>
                            <span class="badge bg-info-subtle text-info ms-2">
                                <i class="ri-user-star-line me-1"></i> Agent Lead
                            </span>
                        <?php elseif ($leadDetails['lead_source'] === 'F2F Marketing'): ?>
                            <span class="badge bg-warning-subtle text-warning ms-2">
                                <i class="ri-team-line me-1"></i> F2F Marketing Lead
                            </span>
                        <?php endif; ?>
                        
                    </div>
                    
                    <!-- Follow-up Information -->
                    <?php if (!empty($leadDetails['next_followup_date']) && !in_array($leadDetails['lead_status'], ['Dead', 'Admitted'])): ?>
                        <?php
                        // Calculate follow-up status using the model method
                        require_once __DIR__ . '/../../models/lead_model.php';
                        $tempLeadModel = new LeadModel($conn);
                        $followupInfo = $tempLeadModel->calculateFollowupStatus(
                            $leadDetails['last_followup_action_date'] ?? null,
                            $leadDetails['next_followup_date'] ?? null
                        );
                        $followupStatus = $followupInfo['alert_status'];
                        $daysOverdue = $followupInfo['days_overdue'];
                        ?>
                        <div class="alert <?php 
                            if ($followupStatus === 'overdue') echo 'alert-danger';
                            elseif ($followupStatus === 'due_today') echo 'alert-warning';
                            else echo 'alert-info';
                        ?> mb-3">
                            <div class="d-flex align-items-center">
                                <i class="<?php 
                                    if ($followupStatus === 'overdue') echo 'ri-alarm-warning-fill';
                                    elseif ($followupStatus === 'due_today') echo 'ri-calendar-event-fill';
                                    else echo 'ri-calendar-check-line';
                                ?> me-2 fs-5"></i>
                                <div>
                                    <strong>Next Follow-up: <?php echo date('l, F j, Y', strtotime($leadDetails['next_followup_date'])); ?></strong>
                                    <?php if ($followupStatus === 'overdue'): ?>
                                        <br><small>⚠️ <strong><?php echo $daysOverdue . ' ' . pluralize($daysOverdue, 'day'); ?> overdue!</strong> No action taken since scheduled date.</small>
                                    <?php elseif ($followupStatus === 'due_today'): ?>
                                        <br><small>⏰ <strong>Follow-up due today!</strong> Make sure to contact this lead.</small>
                                    <?php else: ?>
                                        <br><small>📅 Scheduled follow-up date</small>
                                    <?php endif; ?>
                                    <?php if (!empty($leadDetails['last_status_change_date'])): ?>
                                        <br><small class="text-muted">Last status change: <?php echo date('M j, Y g:i A', strtotime($leadDetails['last_status_change_date'])); ?></small>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    
                    <div class="text-muted small">
                        <div><i class="ri-time-line me-1"></i> Created: <?php echo date('F j, Y g:i A', strtotime($leadDetails['created_at'])); ?></div>
                        <div><i class="ri-user-line me-1"></i> Created by: <?php echo htmlspecialchars($leadDetails['created_by_name']); ?></div>
                        <?php if ($leadDetails['lead_source'] === 'Agent' && !empty($leadDetails['agent_name'])): ?>
                            <div><i class="ri-user-star-line me-1"></i> Agent: <?php echo htmlspecialchars($leadDetails['agent_name']); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="d-flex gap-2 mt-2 mt-md-0">
                    <?php if ($canEditLead): ?>
                    <button type="button" 
                            class="btn btn-outline-primary" 
                            data-bs-toggle="modal" 
                            data-bs-target="#editLeadModal"
                            data-lead-id="<?php echo $leadDetails['id']; ?>">
                        <i class="ri-edit-line me-1"></i>
                        Edit Lead
                    </button>
                    <?php endif; ?>
                    
                    <button type="button" 
                            class="btn btn-outline-success" 
                            data-bs-toggle="modal" 
                            data-bs-target="#addNoteModal">
                        <i class="ri-sticky-note-add-line me-1"></i>
                        Add Note
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Lead Detail Tabs -->
    <div class="lead-tabs">
        <ul class="nav nav-tabs" id="leadDetailTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="details-tab" data-bs-toggle="tab" data-bs-target="#details-pane" type="button" role="tab" aria-controls="details-pane" aria-selected="true">
                    <i class="ri-user-line me-1"></i>
                    Details
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="notes-tab" data-bs-toggle="tab" data-bs-target="#notes-pane" type="button" role="tab" aria-controls="notes-pane" aria-selected="false">
                    <i class="ri-sticky-note-line me-1"></i>
                    Notes
                    <?php if(!empty($leadDetails['notes'])): ?>
                    <span class="badge rounded-pill bg-light text-dark ms-1">
                        <?php echo count($leadDetails['notes']); ?>
                    </span>
                    <?php endif; ?>
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="history-tab" data-bs-toggle="tab" data-bs-target="#history-pane" type="button" role="tab" aria-controls="history-pane" aria-selected="false">
                    <i class="ri-history-line me-1"></i>
                    History
                    <?php if(!empty($leadDetails['edit_history'])): ?>
                    <span class="badge rounded-pill bg-light text-dark ms-1">
                        <?php echo count($leadDetails['edit_history']); ?>
                    </span>
                    <?php endif; ?>
                </button>
            </li>
            <?php if ($canAssignStaff): ?>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="staff-tab" data-bs-toggle="tab" data-bs-target="#staff-pane" type="button" role="tab" aria-controls="staff-pane" aria-selected="false">
                    <i class="ri-team-line me-1"></i>
                    Staff Assignment
                    <?php if(!empty($leadDetails['assigned_staff'])): ?>
                    <span class="badge rounded-pill bg-light text-dark ms-1">
                        <?php echo count($leadDetails['assigned_staff']); ?>
                    </span>
                    <?php endif; ?>
                </button>
            </li>
            <?php endif; ?>
        </ul>
        <div class="tab-content pt-4" id="leadDetailTabContent">
            <!-- Details Tab -->
            <div class="tab-pane fade show active" id="details-pane" role="tabpanel" aria-labelledby="details-tab">
                <div class="row g-4">
                    <!-- Personal Information Card -->
                    <div class="col-md-6">
                        <div class="card info-card">
                            <div class="card-header">
                                <h5 class="card-title mb-0"><i class="ri-user-line me-2"></i>Personal Information</h5>
                            </div>
                            <div class="card-body">
                                <ul class="info-list">
                                    <li class="d-flex justify-content-between">
                                        <span class="info-label">Full Name</span>
                                        <span><?php echo htmlspecialchars($leadDetails['first_name'] . ' ' . $leadDetails['last_name']); ?></span>
                                    </li>
                                    <li class="d-flex justify-content-between">
                                        <span class="info-label">Email</span>
                                        <span><?php echo htmlspecialchars($leadDetails['email']); ?></span>
                                    </li>
                                    <li class="d-flex justify-content-between">
                                        <span class="info-label">Phone</span>
                                        <span><?php echo htmlspecialchars($leadDetails['phone']); ?></span>
                                    </li>
                                    <?php if (!empty($leadDetails['address'])): ?>
                                    <li class="d-flex justify-content-between">
                                        <span class="info-label">Address</span>
                                        <span><?php echo htmlspecialchars($leadDetails['address']); ?></span>
                                    </li>
                                    <?php endif; ?>
                                    <?php if (!empty($leadDetails['current_city'])): ?>
                                    <li class="d-flex justify-content-between">
                                        <span class="info-label">Current City</span>
                                        <span><?php echo htmlspecialchars($leadDetails['current_city']); ?></span>
                                    </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Education Information Card -->
                    <div class="col-md-6">
                        <div class="card info-card">
                            <div class="card-header">
                                <h5 class="card-title mb-0"><i class="ri-book-open-line me-2"></i>Education Information</h5>
                            </div>
                            <div class="card-body">
                                <ul class="info-list">
                                    <?php if (!empty($leadDetails['applying_for'])): ?>
                                    <li class="d-flex justify-content-between">
                                        <span class="info-label">Applying For</span>
                                        <span><?php echo htmlspecialchars($leadDetails['applying_for']); ?></span>
                                    </li>
                                    <?php endif; ?>
                                    <?php if (!empty($leadDetails['interested_course_name'])): ?>
                                    <li class="d-flex justify-content-between">
                                        <span class="info-label">Interested Course</span>
                                        <span>
                                            <?php echo htmlspecialchars($leadDetails['interested_course_name']); ?>
                                            <?php if (!empty($leadDetails['interested_course_department'])): ?>
                                                <small class="text-muted">(<?php echo htmlspecialchars($leadDetails['interested_course_department']); ?>)</small>
                                            <?php endif; ?>
                                        </span>
                                    </li>
                                    <?php endif; ?>
                                    <?php if (!empty($leadDetails['semester'])): ?>
                                    <li class="d-flex justify-content-between">
                                        <span class="info-label">Semester</span>
                                        <span><?php echo htmlspecialchars($leadDetails['semester']); ?></span>
                                    </li>
                                    <?php endif; ?>
                                    <?php if (!empty($leadDetails['ssc_gpa'])): ?>
                                    <li class="d-flex justify-content-between">
                                        <span class="info-label">SSC GPA</span>
                                        <span><?php echo number_format($leadDetails['ssc_gpa'], 2); ?></span>
                                    </li>
                                    <?php endif; ?>
                                    <?php if (!empty($leadDetails['hsc_gpa'])): ?>
                                    <li class="d-flex justify-content-between">
                                        <span class="info-label">HSC GPA</span>
                                        <span><?php echo number_format($leadDetails['hsc_gpa'], 2); ?></span>
                                    </li>
                                    <?php endif; ?>
                                    <?php if (!empty($leadDetails['bachelor_subject'])): ?>
                                    <li class="d-flex justify-content-between">
                                        <span class="info-label">Bachelor Subject</span>
                                        <span><?php echo htmlspecialchars($leadDetails['bachelor_subject']); ?></span>
                                    </li>
                                    <?php endif; ?>
                                    <?php if (!empty($leadDetails['bachelor_cgpa'])): ?>
                                    <li class="d-flex justify-content-between">
                                        <span class="info-label">Bachelor CGPA</span>
                                        <span><?php echo number_format($leadDetails['bachelor_cgpa'], 2); ?></span>
                                    </li>
                                    <?php endif; ?>
                                    <?php if (empty($leadDetails['applying_for']) && empty($leadDetails['semester']) && 
                                             empty($leadDetails['ssc_gpa']) && empty($leadDetails['hsc_gpa']) && 
                                             empty($leadDetails['bachelor_subject']) && empty($leadDetails['bachelor_cgpa']) &&
                                             empty($leadDetails['interested_course_name'])): ?>
                                    <li class="text-muted fst-italic">No education information available</li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
            
            <!-- Notes Tab -->
            <div class="tab-pane fade" id="notes-pane" role="tabpanel" aria-labelledby="notes-tab">
                <div class="d-flex justify-content-between mb-4">
                    <h5><i class="ri-sticky-note-line me-2"></i>Notes & Updates</h5>
                    <button type="button" 
                            class="btn btn-sm btn-primary" 
                            data-bs-toggle="modal" 
                            data-bs-target="#addNoteModal">
                        <i class="ri-add-line me-1"></i>
                        Add Note
                    </button>
                </div>
                
                <?php if (!empty($leadDetails['notes'])): ?>
                    <div class="timeline">
                        <?php foreach ($leadDetails['notes'] as $note): ?>
                            <div class="timeline-item">
                                <div class="timeline-marker"></div>
                                <div class="timeline-content">
                                    <div class="d-flex justify-content-between mb-2">
                                        <div class="d-flex align-items-center">
                                            <div class="avatar-circle avatar-xs me-2">
                                                <?php if (!empty($note['profile_photo'])): ?>
                                                    <img src="uploads/profile_photos/<?php echo htmlspecialchars($note['profile_photo']); ?>" alt="User">
                                                <?php else: ?>
                                                    <span><?php echo strtoupper(substr($note['created_by_name'], 0, 2)); ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="fw-medium"><?php echo htmlspecialchars($note['created_by_name']); ?></div>
                                        </div>
                                        <div class="text-muted small"><?php echo date('M j, Y g:i A', strtotime($note['created_at'])); ?></div>
                                    </div>
                                    <div class="note-text"><?php echo nl2br(htmlspecialchars($note['note_text'])); ?></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-4">
                        <div class="mb-3">
                            <i class="ri-sticky-note-line fs-1 text-muted"></i>
                        </div>
                        <p class="text-muted">No notes have been added yet.</p>
                        <button type="button" 
                                class="btn btn-sm btn-primary" 
                                data-bs-toggle="modal" 
                                data-bs-target="#addNoteModal">
                            <i class="ri-add-line me-1"></i>
                            Add First Note
                        </button>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- History Tab -->
            <div class="tab-pane fade" id="history-pane" role="tabpanel" aria-labelledby="history-tab">
                <div class="d-flex justify-content-between mb-4">
                    <h5><i class="ri-history-line me-2"></i>Edit History</h5>
                </div>
                
                <?php if (!empty($leadDetails['edit_history'])): ?>
                    <div class="timeline">
                        <?php foreach ($leadDetails['edit_history'] as $history): ?>
                            <div class="timeline-item">
                                <div class="timeline-marker"></div>
                                <div class="timeline-content">
                                    <div class="d-flex justify-content-between mb-2">
                                        <div class="d-flex align-items-center">
                                            <div class="avatar-circle avatar-xs me-2">
                                                <?php if (!empty($history['profile_photo'])): ?>
                                                    <img src="uploads/profile_photos/<?php echo htmlspecialchars($history['profile_photo']); ?>" alt="User">
                                                <?php else: ?>
                                                    <span><?php echo strtoupper(substr($history['edited_by_name'], 0, 2)); ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="fw-medium"><?php echo htmlspecialchars($history['edited_by_name']); ?></div>
                                        </div>
                                        <div class="text-muted small"><?php echo date('M j, Y g:i A', strtotime($history['edited_at'])); ?></div>
                                    </div>
                                    
                                    <div class="history-change">
                                        <div class="fw-medium">
                                            <?php 
                                            $fieldName = str_replace('_', ' ', $history['field_name']);
                                            echo "Changed ".ucwords($fieldName);
                                            ?>
                                        </div>
                                        <div class="d-flex mt-1">
                                            <div class="history-old me-3">
                                                <div class="text-muted small">Old Value:</div>
                                                <div class="px-2 py-1 bg-light rounded">
                                                    <?php echo !empty($history['old_value']) ? htmlspecialchars($history['old_value']) : '<em class="text-muted">Empty</em>'; ?>
                                                </div>
                                            </div>
                                            <div class="history-arrow align-self-center">
                                                <i class="ri-arrow-right-line"></i>
                                            </div>
                                            <div class="history-new ms-3">
                                                <div class="text-muted small">New Value:</div>
                                                <div class="px-2 py-1 bg-light rounded">
                                                    <?php echo !empty($history['new_value']) ? htmlspecialchars($history['new_value']) : '<em class="text-muted">Empty</em>'; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-4">
                        <div class="mb-3">
                            <i class="ri-history-line fs-1 text-muted"></i>
                        </div>
                        <p class="text-muted">No edit history available for this lead.</p>
                    </div>
                <?php endif; ?>
            </div>
            
            <?php if ($canAssignStaff): ?>
            <!-- Staff Assignment Tab -->
            <div class="tab-pane fade" id="staff-pane" role="tabpanel" aria-labelledby="staff-tab">
                <div class="d-flex justify-content-between mb-4">
                    <h5><i class="ri-team-line me-2"></i>Assigned Staff</h5>
                    <button type="button" 
                            class="btn btn-sm btn-primary" 
                            data-bs-toggle="modal" 
                            data-bs-target="#editLeadModal"
                            data-lead-id="<?php echo $leadDetails['id']; ?>"
                            data-tab="staff">
                        <i class="ri-user-add-line me-1"></i>
                        Manage Staff
                    </button>
                </div>
                
                <?php if (!empty($leadDetails['assigned_staff'])): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>Staff Member</th>
                                    <th>Assigned By</th>
                                    <th>Assigned Date</th>
                                    <th class="text-end">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($leadDetails['assigned_staff'] as $staff): ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="avatar-circle avatar-sm me-2">
                                                    <?php if (!empty($staff['profile_photo'])): ?>
                                                        <img src="uploads/profile_photos/<?php echo htmlspecialchars($staff['profile_photo']); ?>" alt="Staff">
                                                    <?php else: ?>
                                                        <span><?php echo strtoupper(substr($staff['staff_name'], 0, 2)); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                                <div><?php echo htmlspecialchars($staff['staff_name']); ?></div>
                                            </div>
                                        </td>
                                        <td><?php echo htmlspecialchars($staff['assigned_by_name']); ?></td>
                                        <td><?php echo date('M j, Y', strtotime($staff['assigned_at'])); ?></td>
                                        <td class="text-end">
                                            <form method="POST" onsubmit="return confirm('Are you sure you want to remove this staff member from the lead?')">
                                                <input type="hidden" name="remove_staff" value="1">
                                                <input type="hidden" name="assignment_id" value="<?php echo $staff['assignment_id']; ?>">
                                                <button type="submit" class="btn btn-sm btn-outline-danger">
                                                    <i class="ri-delete-bin-line"></i>
                                                    Remove
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-4">
                        <div class="mb-3">
                            <i class="ri-team-line fs-1 text-muted"></i>
                        </div>
                        <p class="text-muted">No staff members have been assigned to this lead.</p>
                        <button type="button" 
                                class="btn btn-sm btn-primary" 
                                data-bs-toggle="modal" 
                                data-bs-target="#editLeadModal"
                                data-lead-id="<?php echo $leadDetails['id']; ?>"
                                data-tab="staff">
                            <i class="ri-user-add-line me-1"></i>
                            Assign Staff
                        </button>
                    </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Handle Edit Lead with specific tab selection
    const editButtons = document.querySelectorAll('[data-bs-target="#editLeadModal"][data-tab]');
    if (editButtons.length > 0) {
        editButtons.forEach(button => {
            button.addEventListener('click', function() {
                // Store the tab to activate when modal is loaded
                const tab = this.getAttribute('data-tab');
                sessionStorage.setItem('activeEditTab', tab);
            });
        });
    }
});
</script>