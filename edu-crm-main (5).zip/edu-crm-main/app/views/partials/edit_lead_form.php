<?php
/**
 * Edit Lead Form Partial
 * Created on: 2025-05-05
 * Created by: farukdesk
 */
?>

<div class="row g-3">
    <div class="col-12">
        <div class="lead-source-selector border rounded p-3 mb-3">
            <div class="source-title mb-2">
                <label class="fw-medium">Lead Source</label>
                <span class="text-danger">*</span>
            </div>
            <div class="source-options d-flex flex-wrap gap-3">
                <div class="form-check form-check-inline source-option">
                    <input class="form-check-input" type="radio" name="lead_source" id="edit_source_online" value="Direct Online" required <?php echo $leadDetails['lead_source'] === 'Direct Online' ? 'checked' : ''; ?>>
                    <label class="form-check-label" for="edit_source_online">
                        <i class="ri-global-line me-1 text-primary"></i> Direct Online Lead
                    </label>
                </div>
                <div class="form-check form-check-inline source-option">
                    <input class="form-check-input" type="radio" name="lead_source" id="edit_source_office" value="Direct Campus Visit" required <?php echo $leadDetails['lead_source'] === 'Direct Campus Visit' ? 'checked' : ''; ?>>
                    <label class="form-check-label" for="edit_source_office">
                        <i class="ri-building-line me-1 text-success"></i> Campus Visit Lead
                    </label>
                </div>
                <div class="form-check form-check-inline source-option">
                    <input class="form-check-input" type="radio" name="lead_source" id="edit_source_agent" value="Agent" required <?php echo $leadDetails['lead_source'] === 'Agent' ? 'checked' : ''; ?>>
                    <label class="form-check-label" for="edit_source_agent">
                        <i class="ri-user-star-line me-1 text-info"></i> Agent Lead
                    </label>
                </div>
                <div class="form-check form-check-inline source-option">
                    <input class="form-check-input" type="radio" name="lead_source" id="edit_source_f2f" value="F2F Marketing" required <?php echo $leadDetails['lead_source'] === 'F2F Marketing' ? 'checked' : ''; ?>>
                    <label class="form-check-label" for="edit_source_f2f">
                        <i class="ri-team-line me-1 text-warning"></i> F2F Marketing
                    </label>
                </div>
            </div>
            
            <!-- Agent Selection -->
            <div id="edit_agent_selection_container" class="mt-3" style="display: <?php echo $leadDetails['lead_source'] === 'Agent' ? 'block' : 'none'; ?>;">
                <div class="form-floating agent-autocomplete-container">
                    <input type="text" 
                           class="form-control agent-autocomplete" 
                           id="edit_agent_name" 
                           placeholder="Search agent..."
                           autocomplete="off"
                           value="<?php 
                                if(!empty($leadDetails['agent_id'])) {
                                    foreach($agents as $agent) {
                                        if($agent['id'] == $leadDetails['agent_id']) {
                                            echo htmlspecialchars($agent['name']);
                                            break;
                                        }
                                    }
                                }
                           ?>">
                    <input type="hidden" 
                           name="agent_id" 
                           id="edit_agent_id"
                           value="<?php echo $leadDetails['agent_id'] ?? ''; ?>">
                    <label for="edit_agent_name">Assign Agent</label>
                    <div class="agent-autocomplete-results"></div>
                </div>
            </div>
        </div>
    </div>


    <!-- Tabs Navigation -->
    <div class="col-12">
        <ul class="nav nav-tabs" id="editLeadFormTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="edit-personal-info-tab" data-bs-toggle="tab" data-bs-target="#edit-personal-info-pane" type="button" role="tab" aria-controls="edit-personal-info-pane" aria-selected="true">
                    <i class="ri-user-line me-1"></i>
                    Personal Info
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="edit-education-tab" data-bs-toggle="tab" data-bs-target="#edit-education-pane" type="button" role="tab" aria-controls="edit-education-pane" aria-selected="false">
                    <i class="ri-book-open-line me-1"></i>
                    Education
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="edit-notes-tab" data-bs-toggle="tab" data-bs-target="#edit-notes-pane" type="button" role="tab" aria-controls="edit-notes-pane" aria-selected="false">
                    <i class="ri-sticky-note-line me-1"></i>
                    Notes
                </button>
            </li>
            <?php if ($canAssignStaff): ?>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="edit-staff-tab" data-bs-toggle="tab" data-bs-target="#edit-staff-pane" type="button" role="tab" aria-controls="edit-staff-pane" aria-selected="false">
                    <i class="ri-team-line me-1"></i>
                    Assign Staff
                </button>
            </li>
            <?php endif; ?>
        </ul>
        <div class="tab-content p-3 border border-top-0 rounded-bottom" id="editLeadFormTabContent">
            <!-- Personal Info Tab -->
            <div class="tab-pane fade show active" id="edit-personal-info-pane" role="tabpanel" aria-labelledby="edit-personal-info-tab">
                <div class="row g-3">
                    <!-- First Name -->
                    <div class="col-md-6">
                        <div class="form-floating">
                            <input type="text" 
                                class="form-control" 
                                name="first_name" 
                                id="edit_first_name"
                                placeholder="Enter first name"
                                value="<?php echo htmlspecialchars($leadDetails['first_name']); ?>"
                                required>
                            <label for="edit_first_name">First Name <span class="text-danger">*</span></label>
                            <div class="invalid-feedback">
                                Please provide a first name.
                            </div>
                        </div>
                    </div>
                    
                    <!-- Last Name -->
                    <div class="col-md-6">
                        <div class="form-floating">
                            <input type="text" 
                                class="form-control" 
                                name="last_name" 
                                id="edit_last_name"
                                placeholder="Enter last name"
                                value="<?php echo htmlspecialchars($leadDetails['last_name']); ?>"
                                required>
                            <label for="edit_last_name">Last Name <span class="text-danger">*</span></label>
                            <div class="invalid-feedback">
                                Please provide a last name.
                            </div>
                        </div>
                    </div>
                    
                    <!-- Email -->
                    <div class="col-md-6">
                        <div class="form-floating">
                            <input type="email" 
                                class="form-control" 
                                name="email" 
                                id="edit_email"
                                placeholder="Enter email"
                                value="<?php echo htmlspecialchars($leadDetails['email']); ?>"
                                required>
                            <label for="edit_email">Email <span class="text-danger">*</span></label>
                            <div class="invalid-feedback">
                                Please provide a valid email.
                            </div>
                        </div>
                    </div>
                    
                    <!-- Phone -->
                    <div class="col-md-6">
                        <div class="form-floating">
                            <input type="tel" 
                                class="form-control" 
                                name="phone" 
                                id="edit_phone"
                                placeholder="Enter phone"
                                value="<?php echo htmlspecialchars($leadDetails['phone']); ?>"
                                required>
                            <label for="edit_phone">Phone <span class="text-danger">*</span></label>
                            <div class="invalid-feedback">
                                Please provide a phone number.
                            </div>
                        </div>
                    </div>
                    
                    <!-- Address -->
                    <div class="col-md-12">
                        <div class="form-floating">
                            <textarea 
                                class="form-control" 
                                name="address" 
                                id="edit_address"
                                placeholder="Enter address"
                                style="height: 100px"><?php echo htmlspecialchars($leadDetails['address'] ?? ''); ?></textarea>
                            <label for="edit_address">Address</label>
                        </div>
                    </div>
                    
                    <!-- Current City -->
                    <div class="col-md-6">
                        <div class="form-floating">
                            <input type="text" 
                                class="form-control" 
                                name="current_city" 
                                id="edit_current_city"
                                placeholder="Enter current city"
                                value="<?php echo htmlspecialchars($leadDetails['current_city'] ?? ''); ?>">
                            <label for="edit_current_city">Current City</label>
                        </div>
                    </div>
                    
                    <!-- Lead Status -->
                    <div class="col-md-6">
                        <div class="form-floating">
                            <select class="form-select" 
                                    name="lead_status" 
                                    id="edit_lead_status"
                                    required>
                                <?php foreach ($leadStatuses as $status): ?>
                                    <option value="<?php echo $status; ?>" <?php echo $leadDetails['lead_status'] === $status ? 'selected' : ''; ?>>
                                        <?php echo $status; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <label for="edit_lead_status">Lead Status <span class="text-danger">*</span></label>
                        </div>
                    </div>
                    
                    <!-- Campus Visit Date (appears only when "Will visit office" status is selected) -->
<div class="col-md-6" id="edit_campus_visit_date_container" style="display: <?php echo $leadDetails['lead_status'] === 'Will visit office' ? 'block' : 'none'; ?>;">
    <div class="form-floating">
        <input type="datetime-local" 
            class="form-control" 
            name="campus_visit_date" 
            id="edit_campus_visit_date"
            placeholder="Select visit date"
            value="<?php echo !empty($leadDetails['campus_visit_date']) ? date('Y-m-d\TH:i', strtotime($leadDetails['campus_visit_date'])) : ''; ?>">
        <label for="edit_campus_visit_date">Campus Visit Date & Time</label>
    </div>
</div>

                    <!-- Custom Follow-up Date -->
                    <div class="col-md-6">
                        <div class="form-floating">
                            <input type="date" 
                                class="form-control" 
                                name="next_followup_date" 
                                id="edit_next_followup_date"
                                value="<?php echo !empty($leadDetails['next_followup_date']) ? date('Y-m-d', strtotime($leadDetails['next_followup_date'])) : ''; ?>">
                            <label for="edit_next_followup_date">
                                <i class="ri-calendar-check-line me-1"></i> Next Follow-up Date (Optional)
                            </label>
                            <div class="form-text small mt-1">
                                Set a custom follow-up date. Leave empty for automatic calculation.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Education Tab -->
            <div class="tab-pane fade" id="edit-education-pane" role="tabpanel" aria-labelledby="edit-education-tab">
                <div class="row g-3">
                    <!-- Applying For -->
                    <div class="col-md-6">
                        <div class="form-floating">
                            <select class="form-select" 
                                    name="applying_for" 
                                    id="edit_applying_for">
                                <option value="">Select Degree</option>
                                <option value="Bachelor Degree" <?php echo ($leadDetails['applying_for'] ?? '') === 'Bachelor Degree' ? 'selected' : ''; ?>>Bachelor Degree</option>
                                <option value="Master Degree" <?php echo ($leadDetails['applying_for'] ?? '') === 'Master Degree' ? 'selected' : ''; ?>>Master Degree</option>
                            </select>
                            <label for="edit_applying_for">Applying For</label>
                        </div>
                    </div>
                    
                    <!-- Interested Course -->
                    <div class="col-md-6">
                        <div class="form-floating">
                            <select class="form-select" 
                                    name="interested_course_id" 
                                    id="edit_interested_course_id">
                                <option value="">Select Course</option>
                                <?php foreach ($courses as $course): ?>
                                    <option value="<?php echo $course['id']; ?>" 
                                        <?php echo (isset($leadDetails['interested_course_id']) && $leadDetails['interested_course_id'] == $course['id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($course['course_title']); ?>
                                        <?php if (!empty($course['department'])): ?>
                                            - <?php echo htmlspecialchars($course['department']); ?>
                                        <?php endif; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <label for="edit_interested_course_id">Interested Course</label>
                        </div>
                    </div>
                    
                    <!-- Semester -->
                    <div class="col-md-6">
                        <div class="form-floating">
                            <select class="form-select" 
                                    name="semester" 
                                    id="edit_semester">
                                <option value="">Select Semester</option>
                                <?php foreach ($semesters as $semester): ?>
                                    <option value="<?php echo htmlspecialchars($semester['name']); ?>" 
                                        <?php echo (isset($leadDetails['semester']) && $leadDetails['semester'] == $semester['name']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($semester['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <label for="edit_semester">Semester</label>
                        </div>
                    </div>
                    
                    <!-- SSC GPA (shown for both) -->
                    <div class="col-md-6 degree-field" id="edit_ssc_gpa_container" style="display: <?php echo !empty($leadDetails['applying_for']) ? 'block' : 'none'; ?>;">
                        <div class="form-floating">
                            <input type="number" 
                                class="form-control" 
                                name="ssc_gpa" 
                                id="edit_ssc_gpa"
                                placeholder="Enter SSC GPA"
                                min="0"
                                max="5"
                                step="0.01"
                                value="<?php echo $leadDetails['ssc_gpa'] ?? ''; ?>">
                            <label for="edit_ssc_gpa">SSC GPA</label>
                        </div>
                    </div>
                    
                    <!-- HSC GPA (shown for both) -->
                    <div class="col-md-6 degree-field" id="edit_hsc_gpa_container" style="display: <?php echo !empty($leadDetails['applying_for']) ? 'block' : 'none'; ?>;">
                        <div class="form-floating">
                            <input type="number" 
                                class="form-control" 
                                name="hsc_gpa" 
                                id="edit_hsc_gpa"
                                placeholder="Enter HSC GPA"
                                min="0"
                                max="5"
                                step="0.01"
                                value="<?php echo $leadDetails['hsc_gpa'] ?? ''; ?>">
                            <label for="edit_hsc_gpa">HSC GPA</label>
                        </div>
                    </div>
                    
                    <!-- Bachelor Subject (shown for Master's only) -->
                    <div class="col-md-6 master-field" id="edit_bachelor_subject_container" style="display: <?php echo ($leadDetails['applying_for'] ?? '') === 'Master Degree' ? 'block' : 'none'; ?>;">
                        <div class="form-floating">
                            <input type="text" 
                                class="form-control" 
                                name="bachelor_subject" 
                                id="edit_bachelor_subject"
                                placeholder="Enter bachelor subject"
                                value="<?php echo htmlspecialchars($leadDetails['bachelor_subject'] ?? ''); ?>">
                            <label for="edit_bachelor_subject">Bachelor Subject</label>
                        </div>
                    </div>
                    
                    <!-- CGPA (shown for Master's only) -->
                    <div class="col-md-6 master-field" id="edit_bachelor_cgpa_container" style="display: <?php echo ($leadDetails['applying_for'] ?? '') === 'Master Degree' ? 'block' : 'none'; ?>;">
                        <div class="form-floating">
                            <input type="number" 
                                class="form-control" 
                                name="bachelor_cgpa" 
                                id="edit_bachelor_cgpa"
                                placeholder="Enter CGPA"
                                min="0"
                                max="4"
                                step="0.01"
                                value="<?php echo $leadDetails['bachelor_cgpa'] ?? ''; ?>">
                            <label for="edit_bachelor_cgpa">CGPA</label>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Notes Tab -->
            <div class="tab-pane fade" id="edit-notes-pane" role="tabpanel" aria-labelledby="edit-notes-tab">
                <div class="row g-3">
                    <div class="col-md-12">
                        <div class="form-floating">
                            <textarea 
                                class="form-control" 
                                name="note" 
                                id="edit_note"
                                placeholder="Enter note"
                                style="height: 150px"></textarea>
                            <label for="edit_note">Add Note</label>
                        </div>
                        <div class="form-text">
                            Add a new note or comment about this lead. This will be added to the lead's notes history.
                        </div>
                    </div>
                    
                    <?php if (!empty($leadDetails['notes'])): ?>
                    <div class="col-12">
                        <h6>Previous Notes</h6>
                        <div class="previous-notes mt-2">
                            <?php foreach (array_slice($leadDetails['notes'], 0, 2) as $note): ?>
                            <div class="previous-note p-2 mb-2 bg-light rounded">
                                <div class="d-flex justify-content-between mb-1">
                                    <div class="note-author small"><?php echo htmlspecialchars($note['created_by_name']); ?></div>
                                    <div class="note-date small text-muted"><?php echo date('M j, Y g:i A', strtotime($note['created_at'])); ?></div>
                                </div>
                                <div class="note-text small"><?php echo nl2br(htmlspecialchars($note['note_text'])); ?></div>
                            </div>
                            <?php endforeach; ?>
                            
                            <?php if (count($leadDetails['notes']) > 2): ?>
                            <div class="text-center">
                                <a href="?page=lead_management_view&view_lead=<?php echo $leadDetails['id']; ?>#notes-pane" class="btn btn-sm btn-link">View all notes</a>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <?php if ($canAssignStaff): ?>
            <!-- Staff Assignment Tab -->
            <div class="tab-pane fade" id="edit-staff-pane" role="tabpanel" aria-labelledby="edit-staff-tab">
                <div class="row g-3">
                    <div class="col-md-12">
                        <label class="form-label">Assign Staff Members</label>
                        <div class="multiple-select-container">
                            <select class="form-select staff-select" 
                                    id="edit_staff_select"
                                    multiple>
                                <?php foreach ($staffMembers as $staff): ?>
                                    <option value="<?php echo $staff['id']; ?>">
                                        <?php echo htmlspecialchars($staff['name']); ?>
                                        <?php if (!empty($staff['designation'])): ?>
                                            (<?php echo htmlspecialchars($staff['designation']); ?>)
                                        <?php endif; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <div id="edit_selected_staff_container" class="selected-items mt-2">
                                <?php foreach ($leadDetails['assigned_staff'] as $staff): ?>
                                <div class="selected-item" data-id="<?php echo $staff['staff_id']; ?>" data-container="edit_selected_staff_container">
                                    <?php echo htmlspecialchars($staff['staff_name']); ?>
                                    <button type="button" class="remove-item btn btn-sm" aria-label="Remove">×</button>
                                </div>
                                <?php endforeach; ?>
                            </div>
                            <input type="hidden" name="assigned_staff" id="edit_staff_assigned" value="<?php echo implode(',', array_column($leadDetails['assigned_staff'], 'staff_id')); ?>">
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
// Updated initialization script for edit lead form
document.addEventListener('DOMContentLoaded', function() {
    console.log("Edit lead form script loaded");
    
    // Handle source radio buttons
    const editSourceRadios = document.querySelectorAll('input[name="lead_source"]');
    const editAgentSelectionContainer = document.getElementById('edit_agent_selection_container');
    
    if (editSourceRadios && editAgentSelectionContainer) {
        editSourceRadios.forEach(radio => {
            radio.addEventListener('change', function() {
                console.log("Source changed to: " + this.value);
                editAgentSelectionContainer.style.display = (this.value === 'Agent') ? 'block' : 'none';
            });
        });
    }
    
    // Handle Lead Status selection for Campus Visit Date - Fixed
    const editLeadStatusSelect = document.getElementById('edit_lead_status');
    const editOfficeVisitDateContainer = document.getElementById('edit_campus_visit_date_container');
    
    if (editLeadStatusSelect && editOfficeVisitDateContainer) {
        console.log("Lead status select initialized with current value: " + editLeadStatusSelect.value);
        
        // Initial state based on current selection
        editOfficeVisitDateContainer.style.display = (editLeadStatusSelect.value === 'Will visit office') ? 'block' : 'none';
        
        // Add change event listener
        editLeadStatusSelect.addEventListener('change', function() {
            console.log("Lead status changed to: " + this.value);
            const showVisitDate = (this.value === 'Will visit office');
            editOfficeVisitDateContainer.style.display = showVisitDate ? 'block' : 'none';
            
            // If showing the date field and it's empty, set it to current date/time
            const dateField = document.getElementById('edit_campus_visit_date');
            if (showVisitDate && dateField && !dateField.value) {
                const now = new Date();
                const year = now.getFullYear();
                const month = String(now.getMonth() + 1).padStart(2, '0');
                const day = String(now.getDate()).padStart(2, '0');
                const hours = String(now.getHours()).padStart(2, '0');
                const minutes = String(now.getMinutes()).padStart(2, '0');
                
                dateField.value = `${year}-${month}-${day}T${hours}:${minutes}`;
            }
        });
    } else {
        console.warn("Lead status select or campus visit date container not found!");
    }
    
    // Define the multi-select initialization function
    function initializeMultiSelect(selectId, containerName, hiddenInputId) {
        const select = document.getElementById(selectId);
        const container = document.getElementById(containerName);
        const hiddenInput = document.getElementById(hiddenInputId);
        
        if (!select || !container || !hiddenInput) {
            console.warn(`One of the elements not found for ${selectId}`);
            return;
        }
        
        // Initialize for the dropdown selection change
        select.addEventListener('change', function() {
            const option = this.options[this.selectedIndex];
            if (!option) return;
            
            const value = option.value;
            const text = option.text;
            
            // Check if already selected
            if (document.querySelector(`[data-id="${value}"][data-container="${containerName}"]`)) {
                this.selectedIndex = 0;
                return;
            }
            
            // Create selected item tag
            const tag = document.createElement('div');
            tag.className = 'selected-item';
            tag.setAttribute('data-id', value);
            tag.setAttribute('data-container', containerName);
            tag.innerHTML = `
                ${text}
                <button type="button" class="remove-item btn btn-sm" aria-label="Remove">×</button>
            `;
            
            // Add remove event
            tag.querySelector('.remove-item').addEventListener('click', function() {
                tag.remove();
                updateHiddenInput();
            });
            
            container.appendChild(tag);
            this.selectedIndex = 0;
            
            updateHiddenInput();
        });
        
        // Set up remove buttons for existing selections
        document.querySelectorAll(`#${containerName} .remove-item`).forEach(button => {
            button.addEventListener('click', function() {
                const item = this.parentNode;
                item.remove();
                updateHiddenInput();
            });
        });
        
        function updateHiddenInput() {
            const selectedItems = container.querySelectorAll('.selected-item');
            const values = Array.from(selectedItems).map(item => item.dataset.id);
            hiddenInput.value = values.join(',');
        }
    }
    
    // Initialize multi-selects for editing (kept for staff assignments)
    if (document.getElementById('edit_staff_select')) {
        initializeMultiSelect('edit_staff_select', 'edit_selected_staff_container', 'edit_staff_assigned');
    }
    
    // Initialize autocomplete for agent in edit form
    if (typeof initializeAutocomplete === 'function' && document.getElementById('edit_agent_name')) {
        initializeAutocomplete('agent', 'edit_agent_name', 'edit_agent_id', agentData, 'name');
    }
    
    // Handle Applying For selection in edit form to show/hide education fields
    const editApplyingForSelect = document.getElementById('edit_applying_for');
    if (editApplyingForSelect) {
        editApplyingForSelect.addEventListener('change', function() {
            const sscContainer = document.getElementById('edit_ssc_gpa_container');
            const hscContainer = document.getElementById('edit_hsc_gpa_container');
            const bachelorSubjectContainer = document.getElementById('edit_bachelor_subject_container');
            const bachelorCgpaContainer = document.getElementById('edit_bachelor_cgpa_container');
            
            if (this.value === '') {
                // Hide all fields
                if (sscContainer) sscContainer.style.display = 'none';
                if (hscContainer) hscContainer.style.display = 'none';
                if (bachelorSubjectContainer) bachelorSubjectContainer.style.display = 'none';
                if (bachelorCgpaContainer) bachelorCgpaContainer.style.display = 'none';
            } else if (this.value === 'Bachelor Degree') {
                // Show SSC and HSC only
                if (sscContainer) sscContainer.style.display = 'block';
                if (hscContainer) hscContainer.style.display = 'block';
                if (bachelorSubjectContainer) bachelorSubjectContainer.style.display = 'none';
                if (bachelorCgpaContainer) bachelorCgpaContainer.style.display = 'none';
            } else if (this.value === 'Master Degree') {
                // Show all fields
                if (sscContainer) sscContainer.style.display = 'block';
                if (hscContainer) hscContainer.style.display = 'block';
                if (bachelorSubjectContainer) bachelorSubjectContainer.style.display = 'block';
                if (bachelorCgpaContainer) bachelorCgpaContainer.style.display = 'block';
            }
        });
    }
});
</script>