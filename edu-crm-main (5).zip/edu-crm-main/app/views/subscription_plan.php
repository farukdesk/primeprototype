<?php
require_once __DIR__ . '/../../app/controllers/SubscriptionPlanController.php';

// Initialize controller
$subscriptionController = new SubscriptionPlanController($conn);

// Check permissions
if (!$subscriptionController->hasPermission()) {
    header("Location: /dashboard.php");
    exit();
}

$success = $error = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create_plan'])) {
        $result = $subscriptionController->createPlan($_POST);
        if ($result['status']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    } elseif (isset($_POST['update_plan'])) {
        $result = $subscriptionController->updatePlan($_POST);
        if ($result['status']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    } elseif (isset($_POST['delete_plan'])) {
        $result = $subscriptionController->deletePlan($_POST['plan_id']);
        if ($result['status']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    }
}

// Get filter parameters

$filters = [
    'plan_name' => isset($_GET['plan_name']) ? trim($_GET['plan_name']) : '',
    'plan_type' => isset($_GET['plan_type']) ? trim($_GET['plan_type']) : '',
    'status' => isset($_GET['status']) ? trim($_GET['status']) : ''
];
// Get current page
$page = isset($_GET['p']) ? max(1, (int)$_GET['p']) : 1;

// Get subscription plans with filters and pagination
$result = $subscriptionController->listPlans($filters, $page);

// Debug information
error_log("Current Date and Time (UTC - YYYY-MM-DD HH:MM:SS formatted): " . date('Y-m-d H:i:s'));
error_log("Current User's Login: " . ($_SESSION['email'] ?? 'unknown'));
?>

<!-- Enhanced Styles -->
<style>
    :root {
        --primary-color: #4f46e5;
        --primary-hover: #4338ca;
        --success-color: #059669;
        --danger-color: #dc2626;
        --warning-color: #d97706;
        --background-color: #f3f4f6;
        --card-background: #ffffff;
        --text-color: #1f2937;
        --border-color: #e5e7eb;
    }

    .subscription-container {
        max-width: 1200px;
        margin: 1rem auto;
        padding: 1rem;
        background: var(--card-background);
        border-radius: 1rem;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    }

    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 2rem;
        flex-wrap: wrap;
        gap: 1rem;
    }

    .page-title {
        font-size: 1.5rem;
        font-weight: 600;
        color: var(--text-color);
        margin: 0;
    }

    .filters-section {
        background: var(--background-color);
        padding: 1.5rem;
        border-radius: 0.75rem;
        margin-bottom: 1.5rem;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
    }

    .form-floating > .form-control:focus,
    .form-floating > .form-control:not(:placeholder-shown) {
        padding-top: 1.625rem;
        padding-bottom: 0.625rem;
    }

    .form-floating > .form-control {
        height: calc(3.5rem + 2px);
        line-height: 1.25;
    }

    .status-badge {
        padding: 0.5rem 1rem;
        border-radius: 9999px;
        font-size: 0.875rem;
        font-weight: 500;
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
    }
 /* Add this to your existing styles */
    .form-floating > .form-select {
        padding-top: 1.625rem;
        padding-bottom: 0.625rem;
        height: calc(3.5rem + 2px);
    }

    .form-select {
        background-color: #fff;
        border: 1px solid #ced4da;
    }

    .form-floating > .form-select:focus {
        border-color: var(--primary-color);
        box-shadow: 0 0 0 0.25rem rgba(79, 70, 229, 0.25);
    }

    /* Ensure proper z-index for floating labels */
    .form-floating > label {
        z-index: 3;
    }

    /* Style for selected option */
    .form-select option:checked {
        background-color: var(--primary-color);
        color: white;
    }
    .status-active {
        background-color: #ecfdf5;
        color: var(--success-color);
    }

    .status-inactive {
        background-color: #fef2f2;
        color: var(--danger-color);
    }

    /* Responsive Table Styles */
    @media (max-width: 992px) {
        .table-responsive {
            display: block;
            width: 100%;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }
    }

    /* Mobile Optimizations */
    @media (max-width: 768px) {
        .subscription-container {
            margin: 0;
            padding: 1rem;
            border-radius: 0;
        }

        .page-header {
            flex-direction: column;
            align-items: stretch;
        }

        .filters-section form {
            gap: 1rem !important;
        }

        .col-md-3 {
            width: 100%;
        }
    }

    /* Custom Button Styles */
    .btn-custom {
        padding: 0.5rem 1rem;
        border-radius: 0.5rem;
        font-weight: 500;
        transition: all 0.2s;
    }

    .btn-custom:hover {
        transform: translateY(-1px);
    }

    /* Animation for alerts */
    .alert {
        animation: slideDown 0.3s ease-out;
    }

    @keyframes slideDown {
        from {
            transform: translateY(-20px);
            opacity: 0;
        }
        to {
            transform: translateY(0);
            opacity: 1;
        }
    }
</style>
<div class="subscription-container">
    <!-- Page Header -->
    <div class="page-header">
        <h1 class="page-title">
            <i class="ri-money-dollar-circle-line me-2"></i>
            Subscription Plans Management
        </h1>
        <button type="button" 
                class="btn btn-custom btn-primary" 
                data-bs-toggle="modal" 
                data-bs-target="#addPlanModal">
            <i class="ri-add-circle-line me-1"></i>
            Create New Plan
        </button>
    </div>

    <!-- Alert Messages -->
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show d-flex align-items-center" role="alert">
            <i class="ri-checkbox-circle-line me-2"></i>
            <div class="flex-grow-1">
                <?php echo htmlspecialchars($success); ?>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show d-flex align-items-center" role="alert">
            <i class="ri-error-warning-line me-2"></i>
            <div class="flex-grow-1">
                <?php echo htmlspecialchars($error); ?>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Filters Section -->

<div class="filters-section">
    <form method="GET" class="row g-3">
        <!-- Add this hidden input -->
        <input type="hidden" name="page" value="subscription_plan">
        
        <!-- Search Input -->
        <div class="col-md-4">
            <div class="form-floating">
                <input type="text" 
                       class="form-control" 
                       name="plan_name" 
                       id="plan_name"
                       placeholder="Search plans..."
                       value="<?php echo htmlspecialchars($filters['plan_name']); ?>">
                <label for="plan_name">
                    <i class="ri-search-line me-1"></i>
                    Search Plans
                </label>
            </div>
        </div>

            <!-- Plan Type Filter -->
            <div class="col-md-3">
                <div class="form-floating">
                    <select class="form-select" name="plan_type" id="plan_type">
                        <option value="">All Types</option>
                        <?php
                        $planTypes = ['Monthly', 'Yearly', 'Lifetime'];
                        foreach ($planTypes as $type):
                            $selected = $filters['plan_type'] === $type ? 'selected' : '';
                        ?>
                            <option value="<?php echo $type; ?>" <?php echo $selected; ?>>
                                <?php echo $type; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <label for="plan_type">
                        <i class="ri-calendar-line me-1"></i>
                        Plan Type
                    </label>
                </div>
            </div>

            <!-- Status Filter -->
            <!-- Status Filter -->


            <!-- Filter Actions -->
            <div class="col-md-2 d-flex align-items-center gap-2">
                <button type="submit" class="btn btn-custom btn-primary flex-grow-1">
                    <i class="ri-filter-3-line me-1"></i>
                    Filter
                </button>
<a href="?page=subscription_plan" 
   class="btn btn-custom btn-outline-secondary" 
   title="Reset Filters">
    <i class="ri-refresh-line"></i>
</a>
            </div>
        </form>
    </div>

    <!-- Stats Cards -->
    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card bg-light">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-subtitle mb-1 text-muted">Total Plans</h6>
                            <h3 class="card-title mb-0">
                                <?php echo $result['pagination']['total_records'] ?? 0; ?>
                            </h3>
                        </div>
                        <div class="fs-1 text-primary">
                            <i class="ri-price-tag-3-line"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-light">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-subtitle mb-1 text-muted">Active Plans</h6>
                            <h3 class="card-title mb-0">
                                <?php 
                                $activePlans = array_filter($result['data'] ?? [], function($plan) {
                                    return $plan['status'] === 'Active';
                                });
                                echo count($activePlans);
                                ?>
                            </h3>
                        </div>
                        <div class="fs-1 text-success">
                            <i class="ri-check-double-line"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-light">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-subtitle mb-1 text-muted">Inactive Plans</h6>
                            <h3 class="card-title mb-0">
                                <?php 
                                $inactivePlans = array_filter($result['data'] ?? [], function($plan) {
                                    return $plan['status'] === 'Inactive';
                                });
                                echo count($inactivePlans);
                                ?>
                            </h3>
                        </div>
                        <div class="fs-1 text-danger">
                            <i class="ri-close-circle-line"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Additional Styles for this section -->
    <style>
        .card {
            transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
            border: none;
            border-radius: 0.75rem;
        }

        .card:hover {
            transform: translateY(-3px);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }

        .form-floating .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(79, 70, 229, 0.25);
        }

        .btn-custom {
            padding: 0.75rem 1.5rem;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        @media (max-width: 768px) {
            .stats-cards .col-md-4 {
                margin-bottom: 1rem;
            }
            
            .btn-custom {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
    <!-- Plans Table Section -->
<div class="table-section">
    <?php if (!empty($result['data'])): ?>
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th scope="col" class="text-center">#</th>
                        <th scope="col">Plan Details</th>
                        <th scope="col" class="text-end">Price</th>
                        <th scope="col" class="d-none d-md-table-cell">Features</th>
                        <th scope="col" class="text-center">Status</th>
                        <th scope="col" class="d-none d-lg-table-cell">Created</th>
                        <th scope="col" class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($result['data'] as $plan): ?>
                        <tr>
                            <!-- ID -->
                            <td class="text-center">
                                <span class="badge bg-light text-dark">
                                    <?php echo htmlspecialchars($plan['id']); ?>
                                </span>
                            </td>

                            <!-- Plan Details -->
                            <td>
                                <div class="d-flex flex-column">
                                    <strong class="plan-name">
                                        <?php echo htmlspecialchars($plan['plan_name']); ?>
                                    </strong>
                                    <span class="text-muted small">
                                        <i class="ri-time-line me-1"></i>
                                        <?php echo htmlspecialchars($plan['plan_type']); ?>
                                    </span>
                                    <span class="text-muted small d-md-none">
                                        <?php echo htmlspecialchars($plan['description']); ?>
                                    </span>
                                </div>
                            </td>

                            <!-- Price -->
                            <td class="text-end">
                                <div class="price-wrapper">
                                    <strong class="text-primary">
                                        £<?php echo number_format($plan['price'], 2); ?>
                                    </strong>
                                    <small class="text-muted d-block">
                                        <?php echo strtolower($plan['plan_type']); ?>
                                    </small>
                                </div>
                            </td>

                            <!-- Features -->
                            <td class="d-none d-md-table-cell">
                                <?php 
                                $features = json_decode($plan['features'], true);
                                if (!empty($features)):
                                ?>
                                    <div class="features-wrapper">
                                        <div class="features-list">
                                            <?php foreach (array_slice($features, 0, 2) as $feature): ?>
                                                <div class="feature-item">
                                                    <i class="ri-checkbox-circle-line text-success me-1"></i>
                                                    <?php echo htmlspecialchars($feature); ?>
                                                </div>
                                            <?php endforeach; ?>
                                            <?php if (count($features) > 2): ?>
                                                <div class="feature-item text-muted">
                                                    +<?php echo count($features) - 2; ?> more features
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <button type="button" 
                                                class="btn btn-link btn-sm p-0 view-features" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#featuresModal"
                                                data-features='<?php echo htmlspecialchars(json_encode($features)); ?>'
                                                data-plan-name="<?php echo htmlspecialchars($plan['plan_name']); ?>">
                                            View all
                                        </button>
                                    </div>
                                <?php else: ?>
                                    <span class="text-muted">No features listed</span>
                                <?php endif; ?>
                            </td>

                            <!-- Status -->
                            <td class="text-center">
                                <span class="status-badge status-<?php echo strtolower($plan['status']); ?>">
                                    <i class="ri-<?php echo $plan['status'] === 'Active' ? 'checkbox-circle' : 'close-circle'; ?>-line"></i>
                                    <?php echo htmlspecialchars($plan['status']); ?>
                                </span>
                            </td>

                            <!-- Created Date -->
                            <td class="d-none d-lg-table-cell">
                                <div class="text-muted small">
                                    <i class="ri-calendar-line me-1"></i>
                                    <?php echo date('M d, Y', strtotime($plan['created_at'])); ?>
                                    <br>
                                    <i class="ri-time-line me-1"></i>
                                    <?php echo date('H:i', strtotime($plan['created_at'])); ?>
                                </div>
                            </td>

                            <!-- Actions -->
                            <td class="text-end">
                                <div class="action-buttons">
                                    <button type="button" 
                                            class="btn btn-sm btn-outline-primary edit-plan me-1" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#editPlanModal"
                                            data-plan='<?php echo htmlspecialchars(json_encode($plan)); ?>'
                                            title="Edit Plan">
                                        <i class="ri-edit-line"></i>
                                    </button>
                                    <button type="button" 
                                            class="btn btn-sm btn-outline-danger delete-plan" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#deletePlanModal"
                                            data-plan-id="<?php echo $plan['id']; ?>"
                                            data-plan-name="<?php echo htmlspecialchars($plan['plan_name']); ?>"
                                            title="Delete Plan">
                                        <i class="ri-delete-bin-line"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
<!-- Pagination -->
<?php if ($result['pagination']['total'] > 1): ?>
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mt-4">
        <!-- Pagination Info -->
        <div class="pagination-info text-muted small">
            Showing 
            <strong><?php 
                $start = ($page - 1) * 10 + 1;
                echo $start;
            ?></strong> to 
            <strong><?php 
                $end = min($start + 9, $result['pagination']['total_records']);
                echo $end;
            ?></strong> of 
            <strong><?php echo $result['pagination']['total_records']; ?></strong> plans
        </div>

        <!-- Pagination Navigation -->
        <nav aria-label="Page navigation" class="pagination-nav">
    <ul class="pagination pagination-md mb-0">
        <!-- Previous Page -->
        <?php if ($page > 1): ?>
            <li class="page-item">
                <a class="page-link" 
                   href="?page=subscription_plan&p=<?php echo ($page - 1); ?>&<?php 
                        echo http_build_query(array_merge($filters, ['p' => ($page - 1)])); ?>" 
                   aria-label="Previous">
                    <i class="ri-arrow-left-s-line"></i>
                </a>
            </li>
        <?php endif; ?>

        <!-- Page Numbers -->
        <?php
        $totalPages = $result['pagination']['total'];
        $range = 2;
        
        for ($i = 1; $i <= $totalPages; $i++):
            if ($i == 1 || $i == $totalPages || 
                ($i >= $page - $range && $i <= $page + $range)):
        ?>
            <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                <a class="page-link" 
                   href="?page=subscription_plan&p=<?php echo $i; ?>&<?php 
                        echo http_build_query(array_merge($filters, ['p' => $i])); ?>">
                    <?php echo $i; ?>
                </a>
            </li>
        <?php endif; endfor; ?>

        <!-- Next Page -->
        <?php if ($page < $totalPages): ?>
            <li class="page-item">
                <a class="page-link" 
                   href="?page=subscription_plan&p=<?php echo ($page + 1); ?>&<?php 
                        echo http_build_query(array_merge($filters, ['p' => ($page + 1)])); ?>" 
                   aria-label="Next">
                    <i class="ri-arrow-right-s-line"></i>
                </a>
            </li>
        <?php endif; ?>
    </ul>
</nav>
    </div>
<?php endif; ?>

<?php else: ?>
    <!-- No Results Found -->
    <div class="text-center py-5">
        <div class="no-data-icon mb-3">
            <i class="ri-file-search-line fs-1 text-muted"></i>
        </div>
        <h5 class="text-muted">No subscription plans found</h5>
        <p class="text-muted small mb-3">
            <?php if (!empty($filters['plan_name']) || !empty($filters['plan_type']) || !empty($filters['status'])): ?>
                Try adjusting your filters or
            <?php endif; ?>
            create a new plan to get started
        </p>
        <button type="button" 
                class="btn btn-primary" 
                data-bs-toggle="modal" 
                data-bs-target="#addPlanModal">
            <i class="ri-add-line me-1"></i>
            Create New Plan
        </button>
    </div>
<?php endif; ?>

<!-- Pagination and Table Styles -->
<style>
    /* Table Styles */
    .table {
        margin-bottom: 0;
    }

    .table > :not(caption) > * > * {
        padding: 1rem;
    }

    .table > tbody > tr {
        transition: background-color 0.2s;
    }

    .table > tbody > tr:hover {
        background-color: rgba(var(--bs-primary-rgb), 0.05);
    }

    /* Plan Name Styles */
    .plan-name {
        color: var(--bs-primary);
        font-size: 1rem;
    }

    /* Features List Styles */
    .features-wrapper {
        max-width: 300px;
    }

    .features-list {
        margin-bottom: 0.5rem;
    }

    .feature-item {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        font-size: 0.875rem;
        margin-bottom: 0.25rem;
    }

    /* Status Badge Styles */
    .status-badge {
        font-size: 0.75rem;
        padding: 0.375rem 0.75rem;
    }

    /* Pagination Styles */
    .pagination {
        margin-bottom: 0;
    }

    .page-link {
        border-radius: 0.375rem;
        margin: 0 0.125rem;
        min-width: 2.5rem;
        height: 2.5rem;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--bs-primary);
        border: 1px solid var(--bs-gray-300);
    }

    .page-link:hover {
        background-color: var(--bs-primary);
        color: white;
        border-color: var(--bs-primary);
    }

    .page-item.active .page-link {
        background-color: var(--bs-primary);
        border-color: var(--bs-primary);
    }

    /* Mobile Optimizations */
    @media (max-width: 768px) {
        .table > :not(caption) > * > * {
            padding: 0.75rem;
        }

        .status-badge {
            padding: 0.25rem 0.5rem;
        }

        .pagination-nav {
            width: 100%;
            justify-content: center;
        }

        .pagination-info {
            width: 100%;
            text-align: center;
        }
    }
</style>
<!-- Features View Modal -->
<div class="modal fade" id="featuresModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="ri-list-check-2 me-2"></i>
                    <span id="featuresModalPlanName"></span> Features
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <ul class="features-list list-unstyled mb-0" id="featuresList"></ul>
            </div>
        </div>
    </div>
</div>

<!-- Add Plan Modal -->
<div class="modal fade" id="addPlanModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-light">
                <h5 class="modal-title">
                    <i class="ri-add-circle-line me-2"></i>
                    Create New Subscription Plan
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate>
                <div class="modal-body">
                    <div class="row g-4">
                        <!-- Plan Name -->
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="text" 
                                       class="form-control" 
                                       name="plan_name" 
                                       id="add_plan_name"
                                       placeholder="Enter plan name"
                                       required>
                                <label for="add_plan_name">Plan Name</label>
                                <div class="invalid-feedback">
                                    Please provide a plan name.
                                </div>
                            </div>
                        </div>

                        <!-- Plan Type -->
                        <div class="col-md-6">
                            <div class="form-floating">
                                <select class="form-select" 
                                        name="plan_type" 
                                        id="add_plan_type"
                                        required>
                                    <option value="">Select plan type</option>
                                    <option value="Monthly">Monthly</option>
                                    <option value="Yearly">Yearly</option>
                                    <option value="Lifetime">Lifetime</option>
                                </select>
                                <label for="add_plan_type">Plan Type</label>
                                <div class="invalid-feedback">
                                    Please select a plan type.
                                </div>
                            </div>
                        </div>

                        <!-- Price -->
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="number" 
                                       class="form-control" 
                                       name="price" 
                                       id="add_price"
                                       placeholder="Enter price"
                                       step="0.01"
                                       min="0"
                                       required>
                                <label for="add_price">Price (£)</label>
                                <div class="invalid-feedback">
                                    Please provide a valid price.
                                </div>
                            </div>
                        </div>

                        <!-- Status -->
                        <div class="col-md-6">
                            <div class="form-floating">
                                <select class="form-select" 
                                        name="status" 
                                        id="add_status"
                                        required>
                                    <option value="">Select status</option>
                                    <option value="Active">Active</option>
                                    <option value="Inactive">Inactive</option>
                                </select>
                                <label for="add_status">Status</label>
                                <div class="invalid-feedback">
                                    Please select a status.
                                </div>
                            </div>
                        </div>

                        <!-- Description -->
                        <div class="col-12">
                            <div class="form-floating">
                                <textarea class="form-control" 
                                          name="description" 
                                          id="add_description"
                                          placeholder="Enter description"
                                          style="height: 100px"></textarea>
                                <label for="add_description">Description</label>
                            </div>
                        </div>

                        <!-- Features -->
                        <div class="col-12">
                            <div class="form-floating">
                                <textarea class="form-control" 
                                          name="features" 
                                          id="add_features"
                                          placeholder="Enter features"
                                          style="height: 150px"
                                          required></textarea>
                                <label for="add_features">Features (One per line)</label>
                                <div class="invalid-feedback">
                                    Please add at least one feature.
                                </div>
                            </div>
                            <small class="text-muted">
                                Enter each feature on a new line. Example:
                                <br>
                                ✓ Feature 1
                                <br>
                                ✓ Feature 2
                            </small>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" 
                            class="btn btn-outline-secondary" 
                            data-bs-dismiss="modal">
                        <i class="ri-close-line me-1"></i>
                        Cancel
                    </button>
                    <button type="submit" 
                            name="create_plan" 
                            class="btn btn-primary">
                        <i class="ri-save-line me-1"></i>
                        Create Plan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Plan Modal -->
<div class="modal fade" id="editPlanModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-light">
                <h5 class="modal-title">
                    <i class="ri-edit-line me-2"></i>
                    Edit Subscription Plan
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="id" id="edit_plan_id">
                <div class="modal-body">
                    <div class="row g-4">
                        <!-- Plan Name -->
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="text" 
                                       class="form-control" 
                                       name="plan_name" 
                                       id="edit_plan_name"
                                       placeholder="Enter plan name"
                                       required>
                                <label for="add_plan_name">Plan Name</label>
                                <div class="invalid-feedback">
                                    Please provide a plan name.
                                </div>
                            </div>
                        </div>

                        <!-- Plan Type -->
                        <div class="col-md-6">
                            <div class="form-floating">
                                <select class="form-select" 
                                        name="plan_type" 
                                        id="edit_plan_type"
                                        required>
                                    <option value="">Select plan type</option>
                                    <option value="Monthly">Monthly</option>
                                    <option value="Yearly">Yearly</option>
                                    <option value="Lifetime">Lifetime</option>
                                </select>
                                <label for="add_plan_type">Plan Type</label>
                                <div class="invalid-feedback">
                                    Please select a plan type.
                                </div>
                            </div>
                        </div>

                        <!-- Price -->
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="number" 
                                       class="form-control" 
                                       name="price" 
                                       id="edit_price"
                                       placeholder="Enter price"
                                       step="0.01"
                                       min="0"
                                       required>
                                <label for="add_price">Price (£)</label>
                                <div class="invalid-feedback">
                                    Please provide a valid price.
                                </div>
                            </div>
                        </div>

                        <!-- Status -->
                        <div class="col-md-6">
                            <div class="form-floating">
                                <select class="form-select" 
                                        name="status" 
                                        id="edit_status"
                                        required>
                                    <option value="">Select status</option>
                                    <option value="Active">Active</option>
                                    <option value="Inactive">Inactive</option>
                                </select>
                                <label for="add_status">Status</label>
                                <div class="invalid-feedback">
                                    Please select a status.
                                </div>
                            </div>
                        </div>

                        <!-- Description -->
                        <div class="col-12">
                            <div class="form-floating">
                                <textarea class="form-control" 
                                          name="description" 
                                          id="edit_description"
                                          placeholder="Enter description"
                                          style="height: 100px"></textarea>
                                <label for="add_description">Description</label>
                            </div>
                        </div>

                        <!-- Features -->
                        <div class="col-12">
                            <div class="form-floating">
                                <textarea class="form-control" 
                                          name="features" 
                                          id="edit_features"
                                          placeholder="Enter features"
                                          style="height: 150px"
                                          required></textarea>
                                <label for="add_features">Features (One per line)</label>
                                <div class="invalid-feedback">
                                    Please add at least one feature.
                                </div>
                            </div>
                            <small class="text-muted">
                                Enter each feature on a new line. Example:
                                <br>
                                ✓ Feature 1
                                <br>
                                ✓ Feature 2
                            </small>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" 
                            class="btn btn-outline-secondary" 
                            data-bs-dismiss="modal">
                        <i class="ri-close-line me-1"></i>
                        Cancel
                    </button>
                    <button type="submit" 
                            name="update_plan" 
                            class="btn btn-primary">
                        <i class="ri-save-line me-1"></i>
                        Update Plan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Plan Modal -->
<div class="modal fade" id="deletePlanModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">
                    <i class="ri-delete-bin-line me-2"></i>
                    Delete Plan
                </h5>
                <button type="button" 
                        class="btn-close btn-close-white" 
                        data-bs-dismiss="modal" 
                        aria-label="Close"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="plan_id" id="delete_plan_id">
                <div class="modal-body">
                    <div class="text-center mb-4">
                        <i class="ri-error-warning-line text-danger fs-1"></i>
                        <h5 class="mt-3">Are you sure you want to delete this plan?</h5>
                        <p class="text-muted mb-0">Plan Name: <strong id="delete_plan_name"></strong></p>
                    </div>
                    <div class="alert alert-warning">
                        <i class="ri-alert-line me-2"></i>
                        This action cannot be undone. All data associated with this plan will be permanently removed.
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" 
                            class="btn btn-outline-secondary" 
                            data-bs-dismiss="modal">
                        <i class="ri-close-line me-1"></i>
                        Cancel
                    </button>
                    <button type="submit" 
                            name="delete_plan" 
                            class="btn btn-danger">
                        <i class="ri-delete-bin-line me-1"></i>
                        Delete Plan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- Additional Styles -->
<style>
    /* Modal Styles */
    .modal-content {
        border: none;
        border-radius: 1rem;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
    }

    .modal-header {
        border-top-left-radius: 1rem;
        border-top-right-radius: 1rem;
        padding: 1.25rem 1.5rem;
    }

    .modal-footer {
        border-bottom-left-radius: 1rem;
        border-bottom-right-radius: 1rem;
        padding: 1.25rem 1.5rem;
    }

    .modal-body {
        padding: 1.5rem;
    }

    /* Form Control Styles */
    .form-floating > .form-control:focus,
    .form-floating > .form-select:focus {
        border-color: var(--primary-color);
        box-shadow: 0 0 0 0.25rem rgba(79, 70, 229, 0.25);
    }

    .form-floating > .form-control,
    .form-floating > .form-select {
        border-radius: 0.5rem;
    }

    /* Features List in Modal */
    #featuresList .feature-item {
        padding: 0.5rem 1rem;
        margin-bottom: 0.5rem;
        background: #f8fafc;
        border-radius: 0.5rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    #featuresList .feature-item i {
        color: var(--success-color);
    }

    /* Animations */
    .modal.fade .modal-dialog {
        transform: scale(0.95);
        transition: transform 0.2s ease-out;
    }

    .modal.show .modal-dialog {
        transform: scale(1);
    }


    /* Loading Spinner */
    .spinner-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(255, 255, 255, 0.8);
        display: none;
        justify-content: center;
        align-items: center;
        z-index: 1050;
    }
</style>


<!-- Loading Spinner -->
<div class="spinner-overlay">
    <div class="spinner-border text-primary" role="status">
        <span class="visually-hidden">Loading...</span>
    </div>
</div>

<!-- JavaScript -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Bootstrap tooltips
    const tooltips = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    tooltips.forEach(tooltip => new bootstrap.Tooltip(tooltip));

    // Handle Edit Plan Modal
    const editButtons = document.querySelectorAll('.edit-plan');
    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            const plan = JSON.parse(this.dataset.plan);
            
            // Populate form fields
            document.getElementById('edit_plan_id').value = plan.id;
            document.getElementById('edit_plan_name').value = plan.plan_name;
            document.getElementById('edit_plan_type').value = plan.plan_type;
            document.getElementById('edit_price').value = plan.price;
            document.getElementById('edit_description').value = plan.description;
            document.getElementById('edit_features').value = JSON.parse(plan.features).join('\n');
            document.getElementById('edit_status').value = plan.status;
        });
    });

    // Handle Delete Plan Modal
    const deleteButtons = document.querySelectorAll('.delete-plan');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function() {
            document.getElementById('delete_plan_id').value = this.dataset.planId;
            document.getElementById('delete_plan_name').textContent = this.dataset.planName;
        });
    });

    // Handle Features Modal
    const viewFeaturesButtons = document.querySelectorAll('.view-features');
    viewFeaturesButtons.forEach(button => {
        button.addEventListener('click', function() {
            const features = JSON.parse(this.dataset.features);
            const planName = this.dataset.planName;
            
            document.getElementById('featuresModalPlanName').textContent = planName;
            const featuresList = document.getElementById('featuresList');
            featuresList.innerHTML = features.map(feature => `
                <li class="feature-item">
                    <i class="ri-checkbox-circle-line"></i>
                    ${feature}
                </li>
            `).join('');
        });
    });

    // Form validation
    const forms = document.querySelectorAll('.needs-validation');
    forms.forEach(form => {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            } else {
                showLoading();
            }
            form.classList.add('was-validated');
        });
    });

    // Show loading spinner
    function showLoading() {
        document.querySelector('.spinner-overlay').style.display = 'flex';
    }

    // Hide loading spinner
    function hideLoading() {
        document.querySelector('.spinner-overlay').style.display = 'none';
    }

    

    // Auto-hide alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });

    // Format price inputs
    const priceInputs = document.querySelectorAll('input[type="number"][step="0.01"]');
    priceInputs.forEach(input => {
        input.addEventListener('blur', function() {
            if (this.value) {
                this.value = parseFloat(this.value).toFixed(2);
            }
        });
    });
});
document.addEventListener('DOMContentLoaded', function() {
    // Handle status select
    const statusSelect = document.getElementById('status');
    if (statusSelect) {
        statusSelect.addEventListener('change', function() {
            console.log('Status changed to:', this.value); // Debug log
        });

        // Set initial value if exists in URL
        const urlParams = new URLSearchParams(window.location.search);
        const statusParam = urlParams.get('status');
        if (statusParam) {
            statusSelect.value = statusParam;
        }
    }
});
</script>
