<?php
require_once __DIR__ . '/../../app/controllers/CompanySubscriptionController.php';

// Initialize controller
$subscriptionController = new CompanySubscriptionController($conn);

// Check user permissions using the public method
if (!$subscriptionController->hasPermission()) {
    header("Location: /dashboard.php");
    exit();
}

// Get company ID from session
$company_id = $_SESSION['company_id'] ?? 1; // Make sure to use the correct session variable

// Get subscription details
$subscriptionData = $subscriptionController->showSubscription($company_id);

if (!$subscriptionData['status']) {
    $error = $subscriptionData['message'];
} else {
    $subscription = $subscriptionData['data'];
}

// Debug information
error_log("Current Date and Time (UTC): " . date('Y-m-d H:i:s'));
error_log("Current User's Login: " . ($_SESSION['email'] ?? 'unknown'));
?>




<style>
    .subscription-container {
        max-width: 1000px;
        margin: 2rem auto;
        padding: 1rem;
    }

    .subscription-card {
        background: white;
        border-radius: 15px;
        box-shadow: 0 0 20px rgba(0,0,0,0.1);
        padding: 2rem;
        margin-bottom: 2rem;
    }

    .status-badge {
        display: inline-block;
        padding: 0.4rem 1rem;
        border-radius: 20px;
        font-size: 0.9rem;
    }

    .status-badge.active { background: #d1fae5; color: #065f46; }
    .status-badge.expired { background: #fee2e2; color: #991b1b; }
    .status-badge.cancelled { background: #fef3c7; color: #92400e; }
    .status-badge.suspended { background: #e5e7eb; color: #1f2937; }

    .subscription-header {
        text-align: center;
        margin-bottom: 2rem;
        padding-bottom: 1rem;
        border-bottom: 1px solid #eee;
    }

    .info-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 1.5rem;
    }

    .info-item {
        padding: 1rem;
        background: #f8fafc;
        border-radius: 10px;
    }

    .info-label {
        color: #64748b;
        font-size: 0.9rem;
        margin-bottom: 0.5rem;
    }

    .info-value {
        font-size: 1.1rem;
        font-weight: 500;
        color: #1e293b;
    }

    .history-table th {
        background: #f8fafc;
        color: #64748b;
    }

    .renewal-alert {
        background: #fffbeb;
        border-left: 4px solid #f59e0b;
        padding: 1rem;
        margin-bottom: 1rem;
        border-radius: 0 10px 10px 0;
    }
</style>

<div class="subscription-container">
    <?php if (isset($error)): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if (isset($subscription)): ?>
        <!-- Current Subscription -->
        <div class="subscription-card">
            <div class="subscription-header">
                <h4 class="mb-3">Current Subscription</h4>
                <div class="status-badge <?php echo strtolower($subscription['current_subscription']['status']); ?>">
                    <?php echo htmlspecialchars($subscription['current_subscription']['status']); ?>
                </div>
            </div>

            <?php if (isset($subscription['expiry_details']) && 
                      $subscriptionController->needsRenewal($subscription['expiry_details'])): ?>
                <div class="renewal-alert">
                    <i class="ri-alert-line me-2"></i>
                    Your subscription will expire in <?php echo $subscription['expiry_details']['days_remaining']; ?> days.
                    Please renew your subscription to avoid service interruption.
                </div>
            <?php endif; ?>

            <div class="info-grid">
                <div class="info-item">
                    <div class="info-label">Plan Name</div>
                    <div class="info-value"><?php echo htmlspecialchars($subscription['current_subscription']['plan_name']); ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Start Date</div>
                    <div class="info-value"><?php echo htmlspecialchars($subscription['current_subscription']['start_date']); ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">End Date</div>
                    <div class="info-value"><?php echo htmlspecialchars($subscription['current_subscription']['end_date']); ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Price Paid</div>
                    <div class="info-value">£<?php echo htmlspecialchars($subscription['current_subscription']['price_paid']); ?></div>
                </div>
            </div>
        </div>

        <!-- Plan Details -->
        <div class="subscription-card">
            <h5 class="mb-4">Plan Details</h5>
            <div class="info-grid">
                <div class="info-item">
                    <div class="info-label">Description</div>
                    <div class="info-value"><?php echo htmlspecialchars($subscription['plan_details']['description']); ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Duration</div>
                    <div class="info-value"><?php echo htmlspecialchars($subscription['plan_details']['duration']); ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Regular Price</div>
                    <div class="info-value">£<?php echo htmlspecialchars($subscription['plan_details']['regular_price']); ?></div>
                </div>
            </div>
        </div>

        <!-- Subscription History -->
        <div class="subscription-card">
            <h5 class="mb-4">Subscription History</h5>
            <div class="table-responsive">
                <table class="table table-hover history-table">
                    <thead>
                        <tr>
                            <th>Plan Name</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Price Paid</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($subscription['subscription_history'] as $history): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($history['plan_name']); ?></td>
                                <td><?php echo htmlspecialchars($history['start_date']); ?></td>
                                <td><?php echo htmlspecialchars($history['end_date']); ?></td>
                                <td>£<?php echo htmlspecialchars($history['price_paid']); ?></td>
                                <td>
                                    <span class="status-badge <?php echo strtolower($history['status']); ?>">
                                        <?php echo htmlspecialchars($history['status']); ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Statistics -->
        <div class="subscription-card">
            <h5 class="mb-4">Subscription Statistics</h5>
            <div class="info-grid">
                <div class="info-item">
                    <div class="info-label">Total Subscriptions</div>
                    <div class="info-value"><?php echo htmlspecialchars($subscription['statistics']['total_subscriptions']); ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Total Amount Paid</div>
                    <div class="info-value">£<?php echo htmlspecialchars($subscription['statistics']['total_amount_paid']); ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Customer Since</div>
                    <div class="info-value"><?php echo htmlspecialchars($subscription['statistics']['subscription_since']); ?></div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>