<?php
/**
 * Agent Management View
 * Created on: 2026-01-14
 * Description: Manage agents - Admin/Super Admin only
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../controllers/agent_management_controller.php';

// Initialize controller
$agentController = new AgentManagementController($conn);

// Check permissions
if (!$agentController->hasPermission()) {
    header("Location: /dashboard.php");
    exit();
}

$success = $error = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create_agent'])) {
        $result = $agentController->createAgent($_POST);
        if ($result['status']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    } elseif (isset($_POST['update_agent'])) {
        $result = $agentController->updateAgent($_POST['agent_id'], $_POST);
        if ($result['status']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    } elseif (isset($_POST['delete_agent'])) {
        $result = $agentController->deleteAgent($_POST['agent_id']);
        if ($result['status']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    }
}

// Get all agents
$agents = $agentController->getAllAgents();
?>

<div class="agent-management-container">
    <!-- Success/Error Messages -->
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="ri-checkbox-circle-line me-2"></i>
            <?php echo htmlspecialchars($success); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="ri-error-warning-line me-2"></i>
            <?php echo htmlspecialchars($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Page Header -->
    <div class="page-header">
        <div>
            <h1 class="page-title">
                <i class="ri-user-star-line me-2"></i>
                Agent Management
            </h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/dashboard.php">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Agent Management</li>
                </ol>
            </nav>
        </div>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addAgentModal">
            <i class="ri-add-circle-line me-1"></i>
            Add New Agent
        </button>
    </div>

    <!-- Agents Table -->
    <div class="card">
        <div class="card-header">
            <h5 class="card-title mb-0">
                <i class="ri-list-check me-2"></i>
                All Agents
            </h5>
        </div>
        <div class="card-body p-0">
            <?php if (!empty($agents)): ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th scope="col">Agent</th>
                                <th scope="col">Email</th>
                                <th scope="col">Phone</th>
                                <th scope="col">Address</th>
                                <th scope="col">Status</th>
                                <th scope="col">Leads</th>
                                <th scope="col">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($agents as $agent): ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <?php if (!empty($agent['profile_photo'])): ?>
                                                <img src="/storage/uploads/user_profile_photo/<?php echo htmlspecialchars($agent['profile_photo']); ?>" 
                                                     alt="<?php echo htmlspecialchars($agent['agent_name']); ?>" 
                                                     class="rounded-circle me-2"
                                                     style="width: 40px; height: 40px; object-fit: cover;">
                                            <?php else: ?>
                                                <div class="avatar-circle me-2" style="width: 40px; height: 40px; background-color: #0d6efd;">
                                                    <span><?php echo strtoupper(substr($agent['agent_name'] ?? 'A', 0, 1)); ?></span>
                                                </div>
                                            <?php endif; ?>
                                            <div>
                                                <div class="fw-medium"><?php echo htmlspecialchars($agent['agent_name'] ?? 'N/A'); ?></div>
                                                <?php if ($agent['is_our_student']): ?>
                                                    <small class="text-primary">
                                                        <i class="ri-shield-star-line"></i> Our Student
                                                    </small>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo htmlspecialchars($agent['email']); ?></td>
                                    <td><?php echo htmlspecialchars($agent['phone_number'] ?? 'N/A'); ?></td>
                                    <td>
                                        <span class="text-truncate d-inline-block" style="max-width: 150px;" 
                                              title="<?php echo htmlspecialchars($agent['address'] ?? ''); ?>">
                                            <?php echo htmlspecialchars($agent['address'] ?? 'N/A'); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo $agent['account_status'] === 'Active' ? 'success' : 'secondary'; ?>">
                                            <?php echo htmlspecialchars($agent['account_status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge bg-info rounded-pill"><?php echo number_format($agent['lead_count']); ?></span>
                                    </td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <button type="button" 
                                                    class="btn btn-sm btn-outline-primary" 
                                                    onclick="viewAgent(<?php echo $agent['id']; ?>)"
                                                    title="View Details">
                                                <i class="ri-eye-line"></i>
                                            </button>
                                            <button type="button" 
                                                    class="btn btn-sm btn-outline-warning" 
                                                    onclick="editAgent(<?php echo $agent['id']; ?>)"
                                                    title="Edit">
                                                <i class="ri-edit-line"></i>
                                            </button>
                                            <button type="button" 
                                                    class="btn btn-sm btn-outline-danger" 
                                                    onclick="deleteAgent(<?php echo $agent['id']; ?>, '<?php echo htmlspecialchars($agent['agent_name'], ENT_QUOTES); ?>')"
                                                    title="Delete">
                                                <i class="ri-delete-bin-line"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center py-5">
                    <div class="no-data-icon mb-3">
                        <i class="ri-user-star-line fs-1 text-muted"></i>
                    </div>
                    <h5 class="text-muted">No agents found</h5>
                    <p class="text-muted">Click "Add New Agent" to create your first agent</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
.agent-management-container {
    max-width: 1400px;
    margin: 1rem auto;
    padding: 1rem;
    background: #ffffff;
    border-radius: 1rem;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
}

.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
    flex-wrap: wrap;
    gap: 1rem;
}

.avatar-circle {
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    color: white;
    font-weight: 600;
}

.student-fields {
    display: none !important;
    padding: 1rem;
    background-color: #f8f9fa;
    border-radius: 0.5rem;
    margin-top: 1rem;
}

.student-fields.show {
    display: block !important;
}

@media (max-width: 768px) {
    .agent-management-container {
        margin: 0;
        padding: 1rem;
        border-radius: 0;
    }
}
</style>

<!-- Add Agent Modal -->
<div class="modal fade" id="addAgentModal" tabindex="-1" aria-labelledby="addAgentModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" action="">
                <div class="modal-header">
                    <h5 class="modal-title" id="addAgentModalLabel">
                        <i class="ri-user-add-line me-2"></i>
                        Add New Agent
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-12">
                            <label for="agent_name" class="form-label">Agent Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="agent_name" name="agent_name" required>
                        </div>
                        
                        <div class="col-md-6">
                            <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" id="email" name="email" required>
                            <small class="text-muted">Default password: Agent@123</small>
                        </div>
                        
                        <div class="col-md-6">
                            <label for="phone_number" class="form-label">Phone Number</label>
                            <input type="text" class="form-control" id="phone_number" name="phone_number">
                        </div>
                        
                        <div class="col-md-12">
                            <label for="address" class="form-label">Address</label>
                            <textarea class="form-control" id="address" name="address" rows="2"></textarea>
                        </div>
                        
                        <div class="col-md-12">
                            <label for="notes" class="form-label">Notes</label>
                            <textarea class="form-control" id="notes" name="notes" rows="3"></textarea>
                        </div>
                        
                        <div class="col-md-12">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="add_is_our_student" name="is_our_student" value="1" onchange="toggleStudentFields('add')">
                                <label class="form-check-label" for="add_is_our_student">
                                    Our Student
                                </label>
                            </div>
                        </div>
                        
                        <div id="add-student-fields" class="col-md-12 student-fields">
                            <div class="row g-3">
                                <div class="col-md-4">
                                    <label for="student_id" class="form-label">Student ID</label>
                                    <input type="text" class="form-control" id="student_id" name="student_id">
                                </div>
                                
                                <div class="col-md-4">
                                    <label for="batch" class="form-label">Batch</label>
                                    <input type="text" class="form-control" id="batch" name="batch">
                                </div>
                                
                                <div class="col-md-4">
                                    <label for="department" class="form-label">Department</label>
                                    <input type="text" class="form-control" id="department" name="department">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="create_agent" class="btn btn-primary">
                        <i class="ri-save-line me-1"></i>
                        Create Agent
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Agent Modal -->
<div class="modal fade" id="editAgentModal" tabindex="-1" aria-labelledby="editAgentModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" action="">
                <input type="hidden" id="edit_agent_id" name="agent_id">
                <div class="modal-header">
                    <h5 class="modal-title" id="editAgentModalLabel">
                        <i class="ri-edit-line me-2"></i>
                        Edit Agent
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-12">
                            <label for="edit_agent_name" class="form-label">Agent Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="edit_agent_name" name="agent_name" required>
                        </div>
                        
                        <div class="col-md-6">
                            <label for="edit_email" class="form-label">Email <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" id="edit_email" name="email" required>
                        </div>
                        
                        <div class="col-md-6">
                            <label for="edit_phone_number" class="form-label">Phone Number</label>
                            <input type="text" class="form-control" id="edit_phone_number" name="phone_number">
                        </div>
                        
                        <div class="col-md-12">
                            <label for="edit_address" class="form-label">Address</label>
                            <textarea class="form-control" id="edit_address" name="address" rows="2"></textarea>
                        </div>
                        
                        <div class="col-md-12">
                            <label for="edit_notes" class="form-label">Notes</label>
                            <textarea class="form-control" id="edit_notes" name="notes" rows="3"></textarea>
                        </div>
                        
                        <div class="col-md-12">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="edit_is_our_student" name="is_our_student" value="1" onchange="toggleStudentFields('edit')">
                                <label class="form-check-label" for="edit_is_our_student">
                                    Our Student
                                </label>
                            </div>
                        </div>
                        
                        <div id="edit-student-fields" class="col-md-12 student-fields">
                            <div class="row g-3">
                                <div class="col-md-4">
                                    <label for="edit_student_id" class="form-label">Student ID</label>
                                    <input type="text" class="form-control" id="edit_student_id" name="student_id">
                                </div>
                                
                                <div class="col-md-4">
                                    <label for="edit_batch" class="form-label">Batch</label>
                                    <input type="text" class="form-control" id="edit_batch" name="batch">
                                </div>
                                
                                <div class="col-md-4">
                                    <label for="edit_department" class="form-label">Department</label>
                                    <input type="text" class="form-control" id="edit_department" name="department">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="update_agent" class="btn btn-primary">
                        <i class="ri-save-line me-1"></i>
                        Update Agent
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- View Agent Modal -->
<div class="modal fade" id="viewAgentModal" tabindex="-1" aria-labelledby="viewAgentModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewAgentModalLabel">
                    <i class="ri-eye-line me-2"></i>
                    Agent Details
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="viewAgentContent">
                <!-- Content will be loaded dynamically -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteAgentModal" tabindex="-1" aria-labelledby="deleteAgentModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="">
                <input type="hidden" id="delete_agent_id" name="agent_id">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title" id="deleteAgentModalLabel">
                        <i class="ri-delete-bin-line me-2"></i>
                        Delete Agent
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete agent <strong id="delete_agent_name"></strong>?</p>
                    <p class="text-danger"><i class="ri-error-warning-line me-1"></i>This action cannot be undone.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="delete_agent" class="btn btn-danger">
                        <i class="ri-delete-bin-line me-1"></i>
                        Delete Agent
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Toggle student fields visibility
function toggleStudentFields(prefix) {
    try {
        const checkbox = document.getElementById(prefix + '_is_our_student');
        const fields = document.getElementById(prefix + '-student-fields');
        
        if (!checkbox || !fields) {
            console.error('Toggle elements not found:', {
                checkbox: checkbox ? 'found' : 'not found',
                fields: fields ? 'found' : 'not found',
                prefix: prefix
            });
            return;
        }
        
        if (checkbox.checked) {
            fields.classList.add('show');
            fields.style.display = 'block';
        } else {
            fields.classList.remove('show');
            fields.style.display = 'none';
            // Clear student fields when unchecked
            if (prefix === 'add') {
                const studentId = document.getElementById('student_id');
                const batch = document.getElementById('batch');
                const department = document.getElementById('department');
                if (studentId) studentId.value = '';
                if (batch) batch.value = '';
                if (department) department.value = '';
            } else {
                const studentId = document.getElementById('edit_student_id');
                const batch = document.getElementById('edit_batch');
                const department = document.getElementById('edit_department');
                if (studentId) studentId.value = '';
                if (batch) batch.value = '';
                if (department) department.value = '';
            }
        }
    } catch (error) {
        console.error('Error in toggleStudentFields:', error);
    }
}

// Make function globally accessible
window.toggleStudentFields = toggleStudentFields;

// View agent details
function viewAgent(agentId) {
    // Get agent data from the table row
    const agents = <?php echo json_encode($agents); ?>;
    const agent = agents.find(a => a.id == agentId);
    
    if (!agent) {
        alert('Agent not found');
        return;
    }
    
    let html = `
        <div class="row g-3">
            <div class="col-md-6">
                <label class="form-label fw-bold">Agent Name:</label>
                <p class="form-control-plaintext">${agent.agent_name || 'N/A'}</p>
            </div>
            <div class="col-md-6">
                <label class="form-label fw-bold">Email:</label>
                <p class="form-control-plaintext">${agent.email || 'N/A'}</p>
            </div>
            <div class="col-md-6">
                <label class="form-label fw-bold">Phone Number:</label>
                <p class="form-control-plaintext">${agent.phone_number || 'N/A'}</p>
            </div>
            <div class="col-md-6">
                <label class="form-label fw-bold">Account Status:</label>
                <p class="form-control-plaintext">
                    <span class="badge bg-${agent.account_status === 'Active' ? 'success' : 'secondary'}">
                        ${agent.account_status}
                    </span>
                </p>
            </div>
            <div class="col-md-12">
                <label class="form-label fw-bold">Address:</label>
                <p class="form-control-plaintext">${agent.address || 'N/A'}</p>
            </div>
            <div class="col-md-12">
                <label class="form-label fw-bold">Notes:</label>
                <p class="form-control-plaintext">${agent.notes || 'N/A'}</p>
            </div>
            <div class="col-md-12">
                <label class="form-label fw-bold">Our Student:</label>
                <p class="form-control-plaintext">${agent.is_our_student == 1 ? 'Yes' : 'No'}</p>
            </div>
    `;
    
    if (agent.is_our_student == 1) {
        html += `
            <div class="col-md-4">
                <label class="form-label fw-bold">Student ID:</label>
                <p class="form-control-plaintext">${agent.student_id || 'N/A'}</p>
            </div>
            <div class="col-md-4">
                <label class="form-label fw-bold">Batch:</label>
                <p class="form-control-plaintext">${agent.batch || 'N/A'}</p>
            </div>
            <div class="col-md-4">
                <label class="form-label fw-bold">Department:</label>
                <p class="form-control-plaintext">${agent.department || 'N/A'}</p>
            </div>
        `;
    }
    
    html += `
            <div class="col-md-6">
                <label class="form-label fw-bold">Lead Count:</label>
                <p class="form-control-plaintext">
                    <span class="badge bg-info rounded-pill">${agent.lead_count || 0}</span>
                </p>
            </div>
        </div>
    `;
    
    document.getElementById('viewAgentContent').innerHTML = html;
    new bootstrap.Modal(document.getElementById('viewAgentModal')).show();
}

// Edit agent
function editAgent(agentId) {
    const agents = <?php echo json_encode($agents); ?>;
    const agent = agents.find(a => a.id == agentId);
    
    if (!agent) {
        alert('Agent not found');
        return;
    }
    
    // Populate form fields
    document.getElementById('edit_agent_id').value = agent.id;
    document.getElementById('edit_agent_name').value = agent.agent_name || '';
    document.getElementById('edit_email').value = agent.email || '';
    document.getElementById('edit_phone_number').value = agent.phone_number || '';
    document.getElementById('edit_address').value = agent.address || '';
    document.getElementById('edit_notes').value = agent.notes || '';
    document.getElementById('edit_is_our_student').checked = agent.is_our_student == 1;
    
    if (agent.is_our_student == 1) {
        document.getElementById('edit_student_id').value = agent.student_id || '';
        document.getElementById('edit_batch').value = agent.batch || '';
        document.getElementById('edit_department').value = agent.department || '';
        document.getElementById('edit-student-fields').classList.add('show');
    } else {
        document.getElementById('edit-student-fields').classList.remove('show');
    }
    
    new bootstrap.Modal(document.getElementById('editAgentModal')).show();
}

// Delete agent
function deleteAgent(agentId, agentName) {
    document.getElementById('delete_agent_id').value = agentId;
    document.getElementById('delete_agent_name').textContent = agentName;
    new bootstrap.Modal(document.getElementById('deleteAgentModal')).show();
}
</script>
