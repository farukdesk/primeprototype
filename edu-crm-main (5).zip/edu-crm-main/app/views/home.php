<?php
/**
 * Home Dashboard View - PUMIS
 * Prime University Management Information System
 * Updated: 2026-01-14
 */

// Get statistics for different time periods
try {
    // Check which visit date column exists (office_visit_date or campus_visit_date)
    // This check runs once per dashboard load - acceptable performance impact
    // Whitelist validation for security
    $visitDateColumn = 'office_visit_date'; // default to old column name
    try {
        $checkQuery = "SHOW COLUMNS FROM leads LIKE 'campus_visit_date'";
        $checkStmt = $conn->prepare($checkQuery);
        $checkStmt->execute();
        if ($checkStmt->rowCount() > 0) {
            $visitDateColumn = 'campus_visit_date';
        }
    } catch (PDOException $e) {
        // Ignore error, use default column name
    }
    
    // Validate column name against whitelist (security)
    $allowedColumns = ['office_visit_date', 'campus_visit_date'];
    if (!in_array($visitDateColumn, $allowedColumns)) {
        $visitDateColumn = 'office_visit_date'; // fallback to safe default
    }
    
    // Today's statistics
    $todayQuery = "SELECT 
        COUNT(DISTINCT CASE WHEN DATE(cl.call_date) = CURDATE() THEN cl.id END) as today_calls,
        COUNT(DISTINCT CASE WHEN DATE(l.{$visitDateColumn}) = CURDATE() THEN l.id END) as today_campus_visits,
        COUNT(DISTINCT CASE WHEN l.lead_status = 'Admitted' AND DATE(l.updated_at) = CURDATE() THEN l.id END) as today_admitted
    FROM leads l
    LEFT JOIN call_logs cl ON l.id = cl.lead_id";
    
    $stmt = $conn->prepare($todayQuery);
    $stmt->execute();
    $todayStats = $stmt->fetch(PDO::FETCH_ASSOC);

    // This week's statistics (last 7 days)
    $weekQuery = "SELECT 
        COUNT(DISTINCT CASE WHEN DATE(cl.call_date) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) THEN cl.id END) as week_calls,
        COUNT(DISTINCT CASE WHEN DATE(l.{$visitDateColumn}) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) THEN l.id END) as week_campus_visits,
        COUNT(DISTINCT CASE WHEN l.lead_status = 'Admitted' AND DATE(l.updated_at) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) THEN l.id END) as week_admitted
    FROM leads l
    LEFT JOIN call_logs cl ON l.id = cl.lead_id";
    
    $stmt = $conn->prepare($weekQuery);
    $stmt->execute();
    $weekStats = $stmt->fetch(PDO::FETCH_ASSOC);

    // This month's statistics (last 30 days)
    $monthQuery = "SELECT 
        COUNT(DISTINCT CASE WHEN DATE(cl.call_date) >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) THEN cl.id END) as month_calls,
        COUNT(DISTINCT CASE WHEN DATE(l.{$visitDateColumn}) >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) THEN l.id END) as month_campus_visits,
        COUNT(DISTINCT CASE WHEN l.lead_status = 'Admitted' AND DATE(l.updated_at) >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) THEN l.id END) as month_admitted
    FROM leads l
    LEFT JOIN call_logs cl ON l.id = cl.lead_id";
    
    $stmt = $conn->prepare($monthQuery);
    $stmt->execute();
    $monthStats = $stmt->fetch(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    error_log("Error fetching dashboard stats: " . $e->getMessage());
    $todayStats = ['today_calls' => 0, 'today_campus_visits' => 0, 'today_admitted' => 0];
    $weekStats = ['week_calls' => 0, 'week_campus_visits' => 0, 'week_admitted' => 0];
    $monthStats = ['month_calls' => 0, 'month_campus_visits' => 0, 'month_admitted' => 0];
}
?>

<!-- Page Title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <h4 class="page-title">Dashboard</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item active">PUMIS - Prime University Management Information System</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<!-- Today's Statistics -->
<div class="row">
    <div class="col-12">
        <h5 class="mb-3"><i class="ri-calendar-line me-2"></i>Today's Statistics</h5>
    </div>
</div>
<div class="row mb-4">
    <div class="col-xl-4 col-md-6">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4 class="mb-1 mt-1">
                            <span data-plugin="counterup"><?php echo number_format($todayStats['today_campus_visits']); ?></span>
                        </h4>
                        <p class="mb-0">Today's Campus Visits</p>
                    </div>
                    <div class="avatar-sm">
                        <span class="avatar-title bg-soft-info text-info rounded">
                            <i class="ri-home-4-line font-20"></i>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-4 col-md-6">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4 class="mb-1 mt-1">
                            <span data-plugin="counterup"><?php echo number_format($todayStats['today_calls']); ?></span>
                        </h4>
                        <p class="mb-0">Today's Calls</p>
                    </div>
                    <div class="avatar-sm">
                        <span class="avatar-title bg-soft-primary text-primary rounded">
                            <i class="ri-phone-line font-20"></i>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-4 col-md-6">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4 class="mb-1 mt-1">
                            <span data-plugin="counterup"><?php echo number_format($todayStats['today_admitted']); ?></span>
                        </h4>
                        <p class="mb-0">Today's Total Admitted</p>
                    </div>
                    <div class="avatar-sm">
                        <span class="avatar-title bg-soft-success text-success rounded">
                            <i class="ri-graduation-cap-line font-20"></i>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- This Week's Statistics (Last 7 Days) -->
<div class="row">
    <div class="col-12">
        <h5 class="mb-3"><i class="ri-calendar-2-line me-2"></i>This Week's Statistics (Last 7 Days)</h5>
    </div>
</div>
<div class="row mb-4">
    <div class="col-xl-4 col-md-6">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4 class="mb-1 mt-1">
                            <span data-plugin="counterup"><?php echo number_format($weekStats['week_campus_visits']); ?></span>
                        </h4>
                        <p class="mb-0">Week's Campus Visits</p>
                    </div>
                    <div class="avatar-sm">
                        <span class="avatar-title bg-soft-info text-info rounded">
                            <i class="ri-home-4-line font-20"></i>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-4 col-md-6">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4 class="mb-1 mt-1">
                            <span data-plugin="counterup"><?php echo number_format($weekStats['week_calls']); ?></span>
                        </h4>
                        <p class="mb-0">Week's Calls</p>
                    </div>
                    <div class="avatar-sm">
                        <span class="avatar-title bg-soft-primary text-primary rounded">
                            <i class="ri-phone-line font-20"></i>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-4 col-md-6">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4 class="mb-1 mt-1">
                            <span data-plugin="counterup"><?php echo number_format($weekStats['week_admitted']); ?></span>
                        </h4>
                        <p class="mb-0">Week's Total Admitted</p>
                    </div>
                    <div class="avatar-sm">
                        <span class="avatar-title bg-soft-success text-success rounded">
                            <i class="ri-graduation-cap-line font-20"></i>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- This Month's Statistics (Last 30 Days) -->
<div class="row">
    <div class="col-12">
        <h5 class="mb-3"><i class="ri-calendar-event-line me-2"></i>This Month's Statistics (Last 30 Days)</h5>
    </div>
</div>
<div class="row mb-4">
    <div class="col-xl-4 col-md-6">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4 class="mb-1 mt-1">
                            <span data-plugin="counterup"><?php echo number_format($monthStats['month_campus_visits']); ?></span>
                        </h4>
                        <p class="mb-0">Month's Campus Visits</p>
                    </div>
                    <div class="avatar-sm">
                        <span class="avatar-title bg-soft-info text-info rounded">
                            <i class="ri-home-4-line font-20"></i>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-4 col-md-6">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4 class="mb-1 mt-1">
                            <span data-plugin="counterup"><?php echo number_format($monthStats['month_calls']); ?></span>
                        </h4>
                        <p class="mb-0">Month's Calls</p>
                    </div>
                    <div class="avatar-sm">
                        <span class="avatar-title bg-soft-primary text-primary rounded">
                            <i class="ri-phone-line font-20"></i>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-4 col-md-6">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4 class="mb-1 mt-1">
                            <span data-plugin="counterup"><?php echo number_format($monthStats['month_admitted']); ?></span>
                        </h4>
                        <p class="mb-0">Month's Total Admitted</p>
                    </div>
                    <div class="avatar-sm">
                        <span class="avatar-title bg-soft-success text-success rounded">
                            <i class="ri-graduation-cap-line font-20"></i>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Welcome Message -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h4 class="header-title mb-3">Welcome to PUMIS</h4>
                <p class="text-muted">
                    <strong>Prime University Management Information System (PUMIS)</strong> is a comprehensive ERP solution 
                    designed for university management. Track admissions, manage leads, and monitor campus activities all in one place.
                </p>
                <div class="mt-3">
                    <h5>Quick Actions:</h5>
                    <div class="d-flex gap-2 flex-wrap mt-2">
                        <a href="dashboard.php?page=lead_management_view" class="btn btn-primary">
                            <i class="ri-user-follow-line me-1"></i> Manage Leads
                        </a>
                        <a href="dashboard.php?page=call_logs_view" class="btn btn-success">
                            <i class="ri-phone-line me-1"></i> View Call Logs
                        </a>
                        <a href="dashboard.php?page=campus_visits_view" class="btn btn-info">
                            <i class="ri-calendar-line me-1"></i> Campus Visits
                        </a>
                        <a href="dashboard.php?page=course_management" class="btn btn-warning">
                            <i class="ri-book-open-line me-1"></i> Course Management
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
