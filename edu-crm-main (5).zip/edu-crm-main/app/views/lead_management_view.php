<?php
/**
 * Lead Management View
 * Created on: 2025-05-05
 * Created by: farukdesk
 */

require_once __DIR__ . '/../../app/controllers/lead_management_controller.php';

// Helper function for pluralization
function pluralize($count, $singular, $plural = null) {
    if ($plural === null) {
        $plural = $singular . 's';
    }
    return $count == 1 ? $singular : $plural;
}

// Initialize controller
$leadController = new LeadManagementController($conn);

// Check permissions
if (!$leadController->hasPermission()) {
    header("Location: /dashboard.php");
    exit();
}

$success = $error = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create_lead'])) {
        $result = $leadController->createLead($_POST);
        if ($result['status']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    } elseif (isset($_POST['update_lead'])) {
        $result = $leadController->updateLead($_POST);
        if ($result['status']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    } elseif (isset($_POST['delete_lead'])) {
        $result = $leadController->deleteLead($_POST['lead_id']);
        if ($result['status']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    } elseif (isset($_POST['add_note'])) {
        $result = $leadController->addLeadNote($_POST['lead_id'], $_POST['note_text']);
        if ($result['status']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    } elseif (isset($_POST['delete_note'])) {
        $result = $leadController->deleteLeadNote($_POST['note_id']);
        if ($result['status']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    } elseif (isset($_POST['remove_staff'])) {
        $result = $leadController->removeStaffFromLead($_POST['assignment_id']);
        if ($result['status']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    }
}

// Check if viewing a specific lead
$viewLeadId = isset($_GET['view_lead']) ? (int)$_GET['view_lead'] : null;
$leadDetails = null;

if ($viewLeadId) {
    $leadResult = $leadController->getLeadDetails($viewLeadId);
    if ($leadResult['status']) {
        $leadDetails = $leadResult['data'];
    } else {
        $error = $leadResult['message'];
        $viewLeadId = null;
    }
}

// Get current page
$page = isset($_GET['p']) ? max(1, (int)$_GET['p']) : 1;

// Get leads with filters and pagination
$result = $leadController->handleRequest();

// Check user permissions
$isSuperAdmin = $leadController->isSuperAdmin();
$isAdmin = $leadController->isAdmin();
$isManager = $leadController->isManager();
$isStaff = $leadController->isStaff();
$isAgent = $leadController->isAgent();
$canCreateLead = $leadController->canCreateLead();
$canEditLead = $leadController->canEditLead();
$canDeleteLead = $leadController->canDeleteLead();
$canAssignStaff = $leadController->canAssignStaff();

// Get filter options
$agents = $result['agents'] ?? [];
$staffMembers = $result['staff'] ?? [];
$universities = $result['universities'] ?? [];
$courses = $result['courses'] ?? [];
$semesters = $result['semesters'] ?? [];
$leadStatuses = $leadController->getLeadStatuses();
$leadSources = $leadController->getLeadSources();

// Get current filters
$filters = $result['filters'] ?? [];

// Get stats
$stats = $result['stats'] ?? [];
?>

<div class="lead-container">
    <!-- Page Header -->
    <div class="page-header">
        <div>
            <h1 class="page-title">
                <i class="ri-user-follow-line me-2"></i>
                <?php echo $viewLeadId ? 'Lead Details' : 'Lead Management'; ?>
            </h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/dashboard.php">Dashboard</a></li>
                    <?php if ($viewLeadId): ?>
                        <li class="breadcrumb-item"><a href="?page=lead_management_view">Lead Management</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Lead #<?php echo $viewLeadId; ?></li>
                    <?php else: ?>
                        <li class="breadcrumb-item active" aria-current="page">Lead Management</li>
                    <?php endif; ?>
                </ol>
            </nav>
        </div>
        
        <?php if (!$viewLeadId && $canCreateLead): ?>
        <button type="button" 
                class="btn btn-custom btn-primary" 
                data-bs-toggle="modal" 
                data-bs-target="#addLeadModal">
            <i class="ri-add-circle-line me-1"></i>
            Add New Lead
        </button>
        <?php elseif ($viewLeadId): ?>
        <a href="?page=lead_management_view" class="btn btn-outline-secondary">
            <i class="ri-arrow-left-line me-1"></i>
            Back to Lead List
        </a>
        <?php endif; ?>
    </div>

    <!-- Alert Messages -->
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show d-flex align-items-center" role="alert">
            <i class="ri-checkbox-circle-line me-2"></i>
            <div class="flex-grow-1">
                <?php echo htmlspecialchars($success); ?>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show d-flex align-items-center" role="alert">
            <i class="ri-error-warning-line me-2"></i>
            <div class="flex-grow-1">
                <?php echo htmlspecialchars($error); ?>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if ($viewLeadId && $leadDetails): ?>
        <!-- Lead Detail View -->
        <div class="lead-detail-view">
            <?php include __DIR__ . '/partials/lead_detail.php'; ?>
        </div>
    <?php else: ?>
        <!-- Stats Cards -->
        <!-- Stats Cards - Redesigned UI -->
<div class="row g-3 mb-4">
    <!-- Card 1 - Lead Status Summary -->
    <div class="col-md-6">
        <div class="card h-100">
            <div class="card-header bg-light">
                <h5 class="card-title mb-0">
                    <i class="ri-pie-chart-line me-2"></i>Lead Status Summary
                </h5>
            </div>
            <div class="card-body">
                <ul class="list-group list-group-flush">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <strong>Total Leads</strong>
                        <span class="badge bg-primary rounded-pill"><?php echo number_format($stats['total_leads'] ?? 0); ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <span><i class="ri-seedling-line text-success me-1"></i> Fresh Leads</span>
                        <span class="badge bg-success rounded-pill"><?php echo number_format($stats['fresh_leads'] ?? 0); ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <span><i class="ri-phone-off-line text-warning me-1"></i> Unable to Reach</span>
                        <span class="badge bg-warning rounded-pill"><?php echo number_format($stats['unable_to_reach'] ?? 0); ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <span><i class="ri-user-star-line text-success me-1"></i> Converted Leads</span>
                        <span class="badge bg-success rounded-pill"><?php echo number_format($stats['converted_leads'] ?? 0); ?></span>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <!-- Card 2 - Source Summary -->
    <div class="col-md-6">
        <div class="card h-100">
            <div class="card-header bg-light">
                <h5 class="card-title mb-0">
                    <i class="ri-route-line me-2"></i>Lead Source Summary
                </h5>
            </div>
            <div class="card-body">
                <ul class="list-group list-group-flush">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <span><i class="ri-global-line text-primary me-1"></i> Direct Online</span>
                        <?php 
                        $onlineCount = 0;
                        foreach ($stats['by_source'] ?? [] as $source) {
                            if ($source['lead_source'] === 'Direct Online') {
                                $onlineCount = $source['count'];
                                break;
                            }
                        }
                        ?>
                        <span class="badge bg-primary rounded-pill"><?php echo number_format($onlineCount); ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <span><i class="ri-building-line text-success me-1"></i> Campus Visit</span>
                        <?php 
                        $officeCount = 0;
                        foreach ($stats['by_source'] ?? [] as $source) {
                            if ($source['lead_source'] === 'Direct Campus Visit') {
                                $officeCount = $source['count'];
                                break;
                            }
                        }
                        ?>
                        <span class="badge bg-success rounded-pill"><?php echo number_format($officeCount); ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <span><i class="ri-user-star-line text-info me-1"></i> Agent</span>
                        <?php 
                        $agentCount = 0;
                        foreach ($stats['by_source'] ?? [] as $source) {
                            if ($source['lead_source'] === 'Agent') {
                                $agentCount = $source['count'];
                                break;
                            }
                        }
                        ?>
                        <span class="badge bg-info rounded-pill"><?php echo number_format($agentCount); ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <span><i class="ri-team-line text-warning me-1"></i> F2F Marketing</span>
                        <?php 
                        $f2fCount = 0;
                        foreach ($stats['by_source'] ?? [] as $source) {
                            if ($source['lead_source'] === 'F2F Marketing') {
                                $f2fCount = $source['count'];
                                break;
                            }
                        }
                        ?>
                        <span class="badge bg-warning rounded-pill"><?php echo number_format($f2fCount); ?></span>
                    </li>
                </ul>
            </div>
        </div>
    </div>

</div>
        
        <!-- Quick Follow-up Filters -->
        <div class="followup-quick-filters mb-3">
            <div class="d-flex gap-2 flex-wrap">
                <a href="?page=lead_management_view&followup_today=1" 
                   class="btn <?php echo (!empty($filters['followup_today'])) ? 'btn-primary' : 'btn-outline-primary'; ?>">
                    <i class="ri-calendar-check-line me-1"></i>
                    Today's Follow-ups
                    <?php 
                    // Count leads needing follow-up today
                    if (!empty($result['stats']['followup_today_count'])) {
                        echo '<span class="badge bg-white text-primary ms-1">' . $result['stats']['followup_today_count'] . '</span>';
                    }
                    ?>
                </a>
                <a href="?page=lead_management_view&followup_overdue=1" 
                   class="btn <?php echo (!empty($filters['followup_overdue'])) ? 'btn-danger' : 'btn-outline-danger'; ?>">
                    <i class="ri-alarm-warning-line me-1"></i>
                    Overdue Follow-ups
                    <?php 
                    // Count leads with overdue follow-ups
                    if (!empty($result['stats']['followup_overdue_count'])) {
                        echo '<span class="badge bg-white text-danger ms-1">' . $result['stats']['followup_overdue_count'] . '</span>';
                    }
                    ?>
                </a>
                <?php if (!empty($filters['followup_today']) || !empty($filters['followup_overdue'])): ?>
                <a href="?page=lead_management_view" class="btn btn-outline-secondary">
                    <i class="ri-close-line me-1"></i>
                    Clear Follow-up Filter
                </a>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Filters Section -->
        <div class="filters-section mb-4">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">
                        <i class="ri-filter-3-line me-1"></i> 
                        Filter Leads
                    </h5>
                    <button class="btn btn-sm btn-link text-muted" type="button" data-bs-toggle="collapse" data-bs-target="#filterCollapse" aria-expanded="false">
                        <i class="ri-arrow-down-s-line"></i>
                    </button>
                </div>
                <div class="collapse show" id="filterCollapse">
                    <div class="card-body">
                        <form method="GET" class="row g-3">
                            <input type="hidden" name="page" value="lead_management_view">
                            
                            <!-- Search Input -->
                            <div class="col-lg-4 col-md-6">
                                <div class="form-floating">
                                    <input type="text" 
                                           class="form-control" 
                                           name="search" 
                                           id="search"
                                           placeholder="Search leads..."
                                           value="<?php echo htmlspecialchars($filters['search'] ?? ''); ?>">
                                    <label for="search">
                                        <i class="ri-search-line me-1"></i>
                                        Search by Name, Email, Phone
                                    </label>
                                </div>
                            </div>
                            
                            <!-- Lead Status Filter -->
                            <div class="col-lg-4 col-md-6">
                                <div class="form-floating">
                                    <select class="form-select" name="lead_status" id="filter_lead_status">
                                        <option value="">All Statuses</option>
                                        <?php foreach ($leadStatuses as $status): ?>
                                            <option value="<?php echo htmlspecialchars($status); ?>" 
                                                <?php echo (isset($filters['lead_status']) && $filters['lead_status'] == $status) ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($status); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <label for="filter_lead_status">Lead Status</label>
                                </div>
                            </div>
                            
                            <!-- Lead Source Filter -->
                            <div class="col-lg-4 col-md-6">
                                <div class="form-floating">
                                    <select class="form-select" name="lead_source" id="filter_lead_source">
                                        <option value="">All Sources</option>
                                        <?php foreach ($leadSources as $source): ?>
                                            <option value="<?php echo htmlspecialchars($source); ?>" 
                                                <?php echo (isset($filters['lead_source']) && $filters['lead_source'] == $source) ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($source); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <label for="filter_lead_source">Lead Source</label>
                                </div>
                            </div>
                            
                            <?php if (!$isAgent): ?>
                            <!-- Agent Filter -->
                            <div class="col-lg-4 col-md-6">
                                <div class="form-floating">
                                    <select class="form-select" name="agent_id" id="filter_agent_id">
                                        <option value="">All Agents</option>
                                        <?php foreach ($agents as $agent): ?>
                                            <option value="<?php echo $agent['id']; ?>" 
                                                <?php echo (isset($filters['agent_id']) && $filters['agent_id'] == $agent['id']) ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($agent['name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <label for="filter_agent_id">Agent</label>
                                </div>
                            </div>
                            <?php endif; ?>
                            
                            <?php if ($canAssignStaff): ?>
                            <!-- Staff Filter -->
                            <div class="col-lg-4 col-md-6">
                                <div class="form-floating">
                                    <select class="form-select" name="staff_id" id="filter_staff_id">
                                        <option value="">All Staff</option>
                                        <?php foreach ($staffMembers as $staff): ?>
                                            <option value="<?php echo $staff['id']; ?>" 
                                                <?php echo (isset($filters['staff_id']) && $filters['staff_id'] == $staff['id']) ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($staff['name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <label for="filter_staff_id">Assigned Staff</label>
                                </div>
                            </div>
                            <?php endif; ?>
                            
                            <!-- Course Filter (Autocomplete) -->
                            <div class="col-lg-4 col-md-6">
                                <div class="form-floating course-autocomplete-container">
                                    <input type="text" 
                                           class="form-control course-autocomplete" 
                                           id="filter_course_name" 
                                           placeholder="Search course..."
                                           autocomplete="off"
                                           value="<?php 
                                                if(isset($filters['course_id'])) {
                                                    foreach($courses as $course) {
                                                        if($course['id'] == $filters['course_id']) {
                                                            echo htmlspecialchars($course['course_title']);
                                                            break;
                                                        }
                                                    }
                                                }
                                           ?>">
                                    <input type="hidden" 
                                           name="course_id" 
                                           id="filter_course_id" 
                                           value="<?php echo htmlspecialchars($filters['course_id'] ?? ''); ?>">
                                    <label for="filter_course_name">Course</label>
                                    <div class="course-autocomplete-results"></div>
                                </div>
                            </div>
                            
                            <!-- Semester Filter -->
                            <div class="col-lg-4 col-md-6">
                                <div class="form-floating">
                                    <select class="form-select" name="semester_id" id="filter_semester_id">
                                        <option value="">All Semesters</option>
                                        <?php foreach ($semesters as $semester): ?>
                                            <option value="<?php echo $semester['id']; ?>" 
                                                <?php echo (isset($filters['semester_id']) && $filters['semester_id'] == $semester['id']) ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($semester['name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <label for="filter_semester_id">Semester</label>
                                </div>
                            </div>
                            
                            <!-- Sort By Filter -->
                            <div class="col-lg-4 col-md-6">
                                <div class="form-floating">
                                    <select class="form-select" name="sort" id="sort_by">
                                        <option value="date_desc" <?php echo (!isset($filters['sort']) || $filters['sort'] == 'date_desc') ? 'selected' : ''; ?>>Newest First</option>
                                        <option value="date_asc" <?php echo (isset($filters['sort']) && $filters['sort'] == 'date_asc') ? 'selected' : ''; ?>>Oldest First</option>
                                        <option value="name_asc" <?php echo (isset($filters['sort']) && $filters['sort'] == 'name_asc') ? 'selected' : ''; ?>>Name (A-Z)</option>
                                        <option value="name_desc" <?php echo (isset($filters['sort']) && $filters['sort'] == 'name_desc') ? 'selected' : ''; ?>>Name (Z-A)</option>
                                        <option value="status_asc" <?php echo (isset($filters['sort']) && $filters['sort'] == 'status_asc') ? 'selected' : ''; ?>>Status (A-Z)</option>
                                        <option value="status_desc" <?php echo (isset($filters['sort']) && $filters['sort'] == 'status_desc') ? 'selected' : ''; ?>>Status (Z-A)</option>
                                    </select>
                                    <label for="sort_by">Sort By</label>
                                </div>
                            </div>


                            <!-- Filter Actions -->
                            <div class="col-12 d-flex justify-content-end gap-2">
                                <a href="?page=lead_management_view" 
                                   class="btn btn-outline-secondary" 
                                   title="Reset Filters">
                                    <i class="ri-refresh-line me-1"></i>
                                    Reset
                                </a>
                                <button type="submit" class="btn btn-primary">
                                    <i class="ri-filter-3-line me-1"></i>
                                    Apply Filters
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Leads Table Section -->
        <div class="table-section">
            <?php if (!empty($result['data'])): ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th scope="col">Lead</th>
                                <th scope="col">Contact Info</th>
                                <th scope="col">Source</th>
                                <th scope="col">Status</th>
                                <th scope="col">Next Follow-up</th>
                                <th scope="col">Semester</th>
                                <th scope="col">Assigned To</th>
                                <th scope="col" class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($result['data'] as $lead): ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="avatar-circle avatar-sm bg-primary me-2">
                                                <span><?php echo strtoupper(substr($lead['first_name'], 0, 1) . substr($lead['last_name'], 0, 1)); ?></span>
                                            </div>
                                            <div>
                                                <div class="fw-medium"><?php echo htmlspecialchars($lead['first_name'] . ' ' . $lead['last_name']); ?></div>
                                                <div class="text-muted small"><?php echo date('M j, Y', strtotime($lead['created_at'])); ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div>
                                            <div><i class="ri-mail-line me-1 text-muted"></i> <?php echo htmlspecialchars($lead['email']); ?></div>
                                            <div><i class="ri-phone-line me-1 text-muted"></i> <?php echo htmlspecialchars($lead['phone']); ?></div>
                                        </div>
                                    </td>
                                    <td>
    <div class="d-flex flex-column">
        <div class="d-flex align-items-center">
            <?php if ($lead['lead_source'] === 'Direct Online'): ?>
                <span class="badge rounded-pill bg-primary-subtle text-primary">
                    <i class="ri-global-line me-1"></i> Online
                </span>
            <?php elseif ($lead['lead_source'] === 'Direct Campus Visit'): ?>
                <span class="badge rounded-pill bg-success-subtle text-success">
                    <i class="ri-building-line me-1"></i> Office
                </span>
            <?php elseif ($lead['lead_source'] === 'Agent'): ?>
                <span class="badge rounded-pill bg-info-subtle text-info">
                    <i class="ri-user-star-line me-1"></i> Agent
                </span>
                <?php if ($lead['agent_name']): ?>
                    <span class="ms-1 small text-muted"><?php echo htmlspecialchars($lead['agent_name']); ?></span>
                <?php endif; ?>
            <?php elseif ($lead['lead_source'] === 'F2F Marketing'): ?>
                <span class="badge rounded-pill bg-warning-subtle text-warning">
                    <i class="ri-team-line me-1"></i> F2F
                </span>
            <?php endif; ?>
        </div>
    </div>
</td>
                                    <td>
                                        <?php 
                                        $statusClass = 'bg-secondary';
                                        $statusIcon = 'ri-question-line';

                                        if (strpos($lead['lead_status'], 'Fresh') !== false) {
                                            $statusClass = 'bg-success';
                                            $statusIcon = 'ri-seedling-line';
                                        } else if (strpos($lead['lead_status'], 'call') !== false) {
                                            $statusClass = 'bg-info';
                                            $statusIcon = 'ri-phone-line';
                                        } else if (strpos($lead['lead_status'], 'Unable to reach') !== false) {
                                            $statusClass = 'bg-warning';
                                            $statusIcon = 'ri-phone-off-line';
                                        } else if ($lead['lead_status'] === 'Dead') {
                                            $statusClass = 'bg-danger';
                                            $statusIcon = 'ri-close-circle-line';
                                        } else if ($lead['lead_status'] === 'Will visit office') {
                                            $statusClass = 'bg-primary';
                                            $statusIcon = 'ri-calendar-check-line';
                                        } else if ($lead['lead_status'] === 'Admitted') {
                                            $statusClass = 'bg-success';
                                            $statusIcon = 'ri-user-star-line';
                                        }
                                        ?>
                                        <span class="badge <?php echo $statusClass; ?>">
                                            <i class="<?php echo $statusIcon; ?> me-1"></i>
                                            <?php echo htmlspecialchars($lead['lead_status']); ?>
                                        </span>
                                        
                                        <?php if ($lead['lead_status'] === 'Will visit office' && !empty($lead['campus_visit_date'])): ?>
                                            <div class="text-muted mt-1 small">
                                                <i class="ri-calendar-event-line me-1"></i>
                                                <?php echo date('M j, Y g:i A', strtotime($lead['campus_visit_date'])); ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <!-- Follow-up Column -->
                                    <td>
                                        <?php if (!empty($lead['next_followup_date'])): ?>
                                            <?php
                                            $followupStatus = $lead['followup_status'] ?? 'none';
                                            $daysOverdue = $lead['days_overdue'] ?? 0;
                                            
                                            if ($followupStatus === 'overdue') {
                                                // Red alert for overdue
                                                $badgeClass = 'bg-danger';
                                                $icon = 'ri-alarm-warning-fill';
                                                $text = date('M j', strtotime($lead['next_followup_date']));
                                                $message = $daysOverdue . ' ' . pluralize($daysOverdue, 'day') . ' overdue';
                                            } elseif ($followupStatus === 'due_today') {
                                                // Warning for due today
                                                $badgeClass = 'bg-warning';
                                                $icon = 'ri-calendar-event-fill';
                                                $text = 'Today';
                                                $message = 'Follow-up due today';
                                            } elseif ($followupStatus === 'scheduled') {
                                                // Info for upcoming
                                                $badgeClass = 'bg-info-subtle text-info';
                                                $icon = 'ri-calendar-line';
                                                $text = date('M j', strtotime($lead['next_followup_date']));
                                                $message = '';
                                            } else {
                                                // Neutral/completed
                                                $badgeClass = 'bg-secondary-subtle text-secondary';
                                                $icon = 'ri-check-line';
                                                $text = date('M j', strtotime($lead['next_followup_date']));
                                                $message = '';
                                            }
                                            ?>
                                            <div class="d-flex flex-column">
                                                <span class="badge <?php echo $badgeClass; ?> mb-1">
                                                    <i class="<?php echo $icon; ?> me-1"></i>
                                                    <?php echo $text; ?>
                                                </span>
                                                <?php if (!empty($message)): ?>
                                                    <small class="text-<?php echo ($followupStatus === 'overdue') ? 'danger' : 'warning'; ?> fw-medium">
                                                        <i class="ri-alert-line me-1"></i><?php echo $message; ?>
                                                    </small>
                                                <?php endif; ?>
                                            </div>
                                        <?php else: ?>
                                            <span class="text-muted small">
                                                <?php if (in_array($lead['lead_status'], ['Dead', 'Admitted'])): ?>
                                                    <i class="ri-check-double-line me-1"></i>Complete
                                                <?php else: ?>
                                                    N/A
                                                <?php endif; ?>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($lead['semester'])): ?>
                                            <span class="badge bg-info-subtle text-info">
                                                <i class="ri-calendar-line me-1"></i>
                                                <?php echo htmlspecialchars($lead['semester']); ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="text-muted small">N/A</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($lead['assigned_staff'])): ?>
                                            <div class="d-flex flex-column">
                                                <?php foreach ($lead['assigned_staff'] as $staff): ?>
                                                    <span class="text-nowrap mb-1">
                                                        <i class="ri-user-line me-1"></i>
                                                        <?php echo htmlspecialchars($staff['staff_name']); ?>
                                                    </span>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php else: ?>
                                            <span class="text-muted"><i class="ri-user-unfollow-line me-1"></i> None</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end">
                                        <div class="action-buttons">
                                            <a href="?page=lead_management_view&view_lead=<?php echo $lead['id']; ?>" 
                                              class="btn btn-sm btn-outline-primary me-1" 
                                              title="View Lead Details">
                                                <i class="ri-eye-line"></i>
                                            </a>
                                            
                                            <?php if ($canEditLead): ?>
                                            <button type="button" 
                                                    class="btn btn-sm btn-outline-info me-1" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#editLeadModal"
                                                    data-lead-id="<?php echo $lead['id']; ?>"
                                                    title="Edit Lead">
                                                <i class="ri-edit-line"></i>
                                            </button>
                                            <?php endif; ?>
                                            
                                            <?php if ($canDeleteLead && ($isSuperAdmin || ($isAgent && $lead['created_by'] == $result['user_id']))): ?>
                                            <button type="button" 
                                                    class="btn btn-sm btn-outline-danger" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#deleteLeadModal"
                                                    data-lead-id="<?php echo $lead['id']; ?>"
                                                    data-lead-name="<?php echo htmlspecialchars($lead['first_name'] . ' ' . $lead['last_name']); ?>"
                                                    title="Delete Lead">
                                                <i class="ri-delete-bin-line"></i>
                                            </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php if ($result['pagination']['total'] > 1): ?>
                    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mt-4">
                        <!-- Pagination Info -->
                        <div class="pagination-info text-muted small">
                            Showing 
                            <strong><?php 
                                $start = ($page - 1) * 10 + 1;
                                echo $start;
                            ?></strong> to 
                            <strong><?php 
                                $end = min($start + 9, $result['pagination']['total_records']);
                                echo $end;
                            ?></strong> of 
                            <strong><?php echo $result['pagination']['total_records']; ?></strong> leads
                        </div>

                        <!-- Pagination Navigation -->
                        <nav aria-label="Lead navigation">
                            <ul class="pagination pagination-md mb-0">
                                <!-- Previous Page -->
                                <?php if ($page > 1): ?>
                                    <li class="page-item">
                                        <a class="page-link" 
                                           href="?page=lead_management_view&p=<?php echo ($page - 1); ?>&<?php 
                                                echo http_build_query(array_filter($filters)); ?>" 
                                           aria-label="Previous">
                                            <i class="ri-arrow-left-s-line"></i>
                                        </a>
                                    </li>
                                <?php endif; ?>

                                <!-- Page Numbers -->
                                <?php
                                $totalPages = $result['pagination']['total'];
                                $range = 2;
                                
                                for ($i = 1; $i <= $totalPages; $i++):
                                    if ($i == 1 || $i == $totalPages || 
                                        ($i >= $page - $range && $i <= $page + $range)):
                                ?>
                                    <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                        <a class="page-link" 
                                           href="?page=lead_management_view&p=<?php echo $i; ?>&<?php 
                                                echo http_build_query(array_filter($filters)); ?>">
                                            <?php echo $i; ?>
                                        </a>
                                    </li>
                                <?php endif; endfor; ?>

                                <!-- Next Page -->
                                <?php if ($page < $totalPages): ?>
                                    <li class="page-item">
                                        <a class="page-link" 
                                           href="?page=lead_management_view&p=<?php echo ($page + 1); ?>&<?php 
                                                echo http_build_query(array_filter($filters)); ?>" 
                                           aria-label="Next">
                                            <i class="ri-arrow-right-s-line"></i>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    </div>
                <?php endif; ?>

            <?php else: ?>
                <!-- No Results Found -->
                <div class="text-center py-5">
                    <div class="no-data-icon mb-3">
                        <i class="ri-user-search-line fs-1 text-muted"></i>
                    </div>
                    <h5 class="text-muted">No leads found</h5>
                    <p class="text-muted small mb-3">
                        <?php if (!empty(array_filter($filters))): ?>
                            Try adjusting your filters
                            <?php if ($canCreateLead): ?>
                                or add a new lead to get started
                            <?php endif; ?>
                        <?php else: ?>
                            <?php if ($canCreateLead): ?>
                                Add your first lead to get started
                            <?php else: ?>
                                No leads have been added yet
                            <?php endif; ?>
                        <?php endif; ?>
                    </p>
                    <?php if ($canCreateLead): ?>
                        <button type="button" 
                                class="btn btn-primary" 
                                data-bs-toggle="modal" 
                                data-bs-target="#addLeadModal">
                            <i class="ri-add-line me-1"></i>
                            Add Lead
                        </button>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<!-- Add Lead Modal -->
<?php if ($canCreateLead): ?>
<div class="modal fade" id="addLeadModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content">
            <div class="modal-header bg-light">
                <h5 class="modal-title">
                    <i class="ri-user-add-line me-2"></i>
                    Add New Lead
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate id="addLeadForm">
                <input type="hidden" name="create_lead" value="1">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-8">
                            <div class="lead-source-selector border rounded p-3 mb-3">
                                <div class="source-title mb-2">
                                    <label class="fw-medium">Lead Source</label>
                                    <span class="text-danger">*</span>
                                </div>
                                <div class="source-options d-flex flex-wrap gap-3">
                                    <div class="form-check form-check-inline source-option">
                                        <input class="form-check-input" type="radio" name="lead_source" id="source_online" value="Direct Online" required checked>
                                        <label class="form-check-label" for="source_online">
                                            <i class="ri-global-line me-1 text-primary"></i> Direct Online Lead
                                        </label>
                                    </div>
                                    <div class="form-check form-check-inline source-option">
                                        <input class="form-check-input" type="radio" name="lead_source" id="source_office" value="Direct Campus Visit" required>
                                        <label class="form-check-label" for="source_office">
                                            <i class="ri-building-line me-1 text-success"></i> Campus Visit Lead
                                        </label>
                                    </div>
                                    <div class="form-check form-check-inline source-option">
                                        <input class="form-check-input" type="radio" name="lead_source" id="source_agent" value="Agent" required>
                                        <label class="form-check-label" for="source_agent">
                                            <i class="ri-user-star-line me-1 text-info"></i> Agent Lead
                                        </label>
                                    </div>
                                    <div class="form-check form-check-inline source-option">
                                        <input class="form-check-input" type="radio" name="lead_source" id="source_f2f" value="F2F Marketing" required>
                                        <label class="form-check-label" for="source_f2f">
                                            <i class="ri-team-line me-1 text-warning"></i> F2F Marketing
                                        </label>
                                    </div>
                                </div>
                                
                                <!-- Agent Selection (shown only if Agent source is selected) -->
                                <div id="agent_selection_container" class="mt-3" style="display: none;">
                                    <div class="form-floating agent-autocomplete-container">
                                        <input type="text" 
                                               class="form-control agent-autocomplete" 
                                               id="add_agent_name" 
                                               placeholder="Search agent..."
                                               autocomplete="off">
                                        <input type="hidden" 
                                               name="agent_id" 
                                               id="add_agent_id">
                                        <label for="add_agent_name">Assign Agent</label>
                                        <div class="agent-autocomplete-results"></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Tabs Navigation -->
                        <div class="col-12">
                            <ul class="nav nav-tabs" id="leadFormTabs" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link active" id="personal-info-tab" data-bs-toggle="tab" data-bs-target="#personal-info-pane" type="button" role="tab" aria-controls="personal-info-pane" aria-selected="true">
                                        <i class="ri-user-line me-1"></i>
                                        Personal Info
                                    </button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="education-tab" data-bs-toggle="tab" data-bs-target="#education-pane" type="button" role="tab" aria-controls="education-pane" aria-selected="false">
                                        <i class="ri-book-open-line me-1"></i>
                                        Education
                                    </button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="notes-tab" data-bs-toggle="tab" data-bs-target="#notes-pane" type="button" role="tab" aria-controls="notes-pane" aria-selected="false">
                                        <i class="ri-sticky-note-line me-1"></i>
                                        Notes
                                    </button>
                                </li>
                                <?php if ($canAssignStaff): ?>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="staff-tab" data-bs-toggle="tab" data-bs-target="#staff-pane" type="button" role="tab" aria-controls="staff-pane" aria-selected="false">
                                        <i class="ri-team-line me-1"></i>
                                        Assign Staff
                                    </button>
                                </li>
                                <?php endif; ?>
                            </ul>
                            <div class="tab-content p-3 border border-top-0 rounded-bottom" id="leadFormTabContent">
                                <!-- Personal Info Tab -->
                                <div class="tab-pane fade show active" id="personal-info-pane" role="tabpanel" aria-labelledby="personal-info-tab">
                                    <div class="row g-3">
                                        <!-- First Name -->
                                        <div class="col-md-6">
                                            <div class="form-floating">
                                                <input type="text" 
                                                    class="form-control" 
                                                    name="first_name" 
                                                    id="add_first_name"
                                                    placeholder="Enter first name"
                                                    required>
                                                <label for="add_first_name">First Name <span class="text-danger">*</span></label>
                                                <div class="invalid-feedback">
                                                    Please provide a first name.
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <!-- Last Name -->
                                        <div class="col-md-6">
                                            <div class="form-floating">
                                                <input type="text" 
                                                    class="form-control" 
                                                    name="last_name" 
                                                    id="add_last_name"
                                                    placeholder="Enter last name"
                                                    required>
                                                <label for="add_last_name">Last Name <span class="text-danger">*</span></label>
                                                <div class="invalid-feedback">
                                                    Please provide a last name.
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <!-- Email -->
                                        <div class="col-md-6">
                                            <div class="form-floating">
                                                <input type="email" 
                                                    class="form-control" 
                                                    name="email" 
                                                    id="add_email"
                                                    placeholder="Enter email"
                                                    required>
                                                <label for="add_email">Email <span class="text-danger">*</span></label>
                                                <div class="invalid-feedback">
                                                    Please provide a valid email.
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <!-- Phone -->
                                        <div class="col-md-6">
                                            <div class="form-floating">
                                                <input type="tel" 
                                                    class="form-control" 
                                                    name="phone" 
                                                    id="add_phone"
                                                    placeholder="Enter phone"
                                                    required>
                                                <label for="add_phone">Phone <span class="text-danger">*</span></label>
                                                <div class="invalid-feedback">
                                                    Please provide a phone number.
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <!-- Address -->
                                        <div class="col-md-12">
                                            <div class="form-floating">
                                                <textarea 
                                                    class="form-control" 
                                                    name="address" 
                                                    id="add_address"
                                                    placeholder="Enter address"
                                                    style="height: 100px"></textarea>
                                                <label for="add_address">Address</label>
                                            </div>
                                        </div>
                                        
                                        <!-- Current City -->
                                        <div class="col-md-6">
                                            <div class="form-floating">
                                                <input type="text" 
                                                    class="form-control" 
                                                    name="current_city" 
                                                    id="add_current_city"
                                                    placeholder="Enter current city">
                                                <label for="add_current_city">Current City</label>
                                            </div>
                                        </div>
                                        
                                        <!-- Lead Status -->
                                        <div class="col-md-6">
                                            <div class="form-floating">
                                                <select class="form-select" 
                                                        name="lead_status" 
                                                        id="add_lead_status"
                                                        required>
                                                    <?php foreach ($leadStatuses as $status): ?>
                                                        <option value="<?php echo $status; ?>" <?php echo $status === 'Fresh' ? 'selected' : ''; ?>>
                                                            <?php echo $status; ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                                <label for="add_lead_status">Lead Status <span class="text-danger">*</span></label>
                                            </div>
                                        </div>
                                        
                                        <!-- Campus Visit Date (appears only when "Will visit office" status is selected) -->
                                        <div class="col-md-6" id="campus_visit_date_container" style="display: none;">
                                            <div class="form-floating">
                                                <input type="datetime-local" 
                                                    class="form-control" 
                                                    name="campus_visit_date" 
                                                    id="add_campus_visit_date"
                                                    placeholder="Select visit date">
                                                <label for="add_campus_visit_date">Campus Visit Date & Time</label>
                                            </div>
                                        </div>
                                        
                                        <!-- Custom Follow-up Date -->
                                        <div class="col-md-6">
                                            <div class="form-floating">
                                                <input type="date" 
                                                    class="form-control" 
                                                    name="next_followup_date" 
                                                    id="add_next_followup_date">
                                                <label for="add_next_followup_date">
                                                    <i class="ri-calendar-check-line me-1"></i> Next Follow-up Date (Optional)
                                                </label>
                                                <div class="form-text small mt-1">
                                                    Set a custom follow-up date. Leave empty for automatic calculation.
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Education Tab -->
                                <div class="tab-pane fade" id="education-pane" role="tabpanel" aria-labelledby="education-tab">
                                    <div class="row g-3">
                                        <!-- Applying For -->
                                        <div class="col-md-6">
                                            <div class="form-floating">
                                                <select class="form-select" 
                                                        name="applying_for" 
                                                        id="add_applying_for">
                                                    <option value="">Select Degree</option>
                                                    <option value="Bachelor Degree">Bachelor Degree</option>
                                                    <option value="Master Degree">Master Degree</option>
                                                </select>
                                                <label for="add_applying_for">Applying For</label>
                                            </div>
                                        </div>
                                        
                                        <!-- Interested Course -->
                                        <div class="col-md-6">
                                            <div class="form-floating">
                                                <select class="form-select" 
                                                        name="interested_course_id" 
                                                        id="add_interested_course_id">
                                                    <option value="">Select Course</option>
                                                    <?php foreach ($courses as $course): ?>
                                                        <option value="<?php echo $course['id']; ?>">
                                                            <?php echo htmlspecialchars($course['course_title']); ?>
                                                            <?php if (!empty($course['department'])): ?>
                                                                - <?php echo htmlspecialchars($course['department']); ?>
                                                            <?php endif; ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                                <label for="add_interested_course_id">Interested Course</label>
                                            </div>
                                        </div>
                                        
                                        <!-- Semester -->
                                        <div class="col-md-6">
                                            <div class="form-floating">
                                                <select class="form-select" 
                                                        name="semester" 
                                                        id="add_semester">
                                                    <option value="">Select Semester</option>
                                                    <?php foreach ($semesters as $semester): ?>
                                                        <option value="<?php echo htmlspecialchars($semester['name']); ?>">
                                                            <?php echo htmlspecialchars($semester['name']); ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                                <label for="add_semester">Semester</label>
                                            </div>
                                        </div>
                                        
                                        <!-- SSC GPA (shown for both) -->
                                        <div class="col-md-6 degree-field" id="add_ssc_gpa_container" style="display: none;">
                                            <div class="form-floating">
                                                <input type="number" 
                                                    class="form-control" 
                                                    name="ssc_gpa" 
                                                    id="add_ssc_gpa"
                                                    placeholder="Enter SSC GPA"
                                                    min="0"
                                                    max="5"
                                                    step="0.01">
                                                <label for="add_ssc_gpa">SSC GPA</label>
                                            </div>
                                        </div>
                                        
                                        <!-- HSC GPA (shown for both) -->
                                        <div class="col-md-6 degree-field" id="add_hsc_gpa_container" style="display: none;">
                                            <div class="form-floating">
                                                <input type="number" 
                                                    class="form-control" 
                                                    name="hsc_gpa" 
                                                    id="add_hsc_gpa"
                                                    placeholder="Enter HSC GPA"
                                                    min="0"
                                                    max="5"
                                                    step="0.01">
                                                <label for="add_hsc_gpa">HSC GPA</label>
                                            </div>
                                        </div>
                                        
                                        <!-- Bachelor Subject (shown for Master's only) -->
                                        <div class="col-md-6 master-field" id="add_bachelor_subject_container" style="display: none;">
                                            <div class="form-floating">
                                                <input type="text" 
                                                    class="form-control" 
                                                    name="bachelor_subject" 
                                                    id="add_bachelor_subject"
                                                    placeholder="Enter bachelor subject">
                                                <label for="add_bachelor_subject">Bachelor Subject</label>
                                            </div>
                                        </div>
                                        
                                        <!-- CGPA (shown for Master's only) -->
                                        <div class="col-md-6 master-field" id="add_bachelor_cgpa_container" style="display: none;">
                                            <div class="form-floating">
                                                <input type="number" 
                                                    class="form-control" 
                                                    name="bachelor_cgpa" 
                                                    id="add_bachelor_cgpa"
                                                    placeholder="Enter CGPA"
                                                    min="0"
                                                    max="4"
                                                    step="0.01">
                                                <label for="add_bachelor_cgpa">CGPA</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Interests Tab -->
                                <div class="tab-pane fade" id="interests-pane" role="tabpanel" aria-labelledby="interests-tab">
                                    <div class="row g-3">
                                        <!-- Courses -->
                                        <div class="col-md-12">
                                            <label class="form-label">Interested Courses</label>
                                            <div class="multiple-select-container">
                                                <select class="form-select course-select" 
                                                        id="add_courses_select"
                                                        multiple>
                                                    <?php foreach ($courses as $course): ?>
                                                        <option value="<?php echo $course['id']; ?>">
                                                            <?php echo htmlspecialchars($course['course_title']); ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                                <div id="selected_courses_container" class="selected-items mt-2"></div>
                                                <input type="hidden" name="courses" id="add_courses" value="">
                                            </div>
                                        </div>
                                        
                                        <!-- Semesters -->
                                        <div class="col-md-12">
                                            <label class="form-label">Interested Semesters</label>
                                            <div class="multiple-select-container">
                                                <select class="form-select semester-select" 
                                                        id="add_semesters_select"
                                                        multiple>
                                                    <?php foreach ($semesters as $semester): ?>
                                                        <option value="<?php echo $semester['id']; ?>">
                                                            <?php echo htmlspecialchars($semester['name']); ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                                <div id="selected_semesters_container" class="selected-items mt-2"></div>
                                                <input type="hidden" name="semesters" id="add_semesters" value="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Notes Tab -->
                                                                <div class="tab-pane fade" id="notes-pane" role="tabpanel" aria-labelledby="notes-tab">
                                    <div class="row g-3">
                                        <div class="col-md-12">
                                            <div class="form-floating">
                                                <textarea 
                                                    class="form-control" 
                                                    name="initial_note" 
                                                    id="add_initial_note"
                                                    placeholder="Enter initial note"
                                                    style="height: 150px"></textarea>
                                                <label for="add_initial_note">Initial Note</label>
                                            </div>
                                            <div class="form-text">
                                                Add any initial notes or comments about this lead. This will be recorded in the lead's history.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <?php if ($canAssignStaff): ?>
                                <!-- Staff Assignment Tab -->
                                <div class="tab-pane fade" id="staff-pane" role="tabpanel" aria-labelledby="staff-tab">
                                    <div class="row g-3">
                                        <div class="col-md-12">
                                            <label class="form-label">Assign Staff Members</label>
                                            <div class="multiple-select-container">
                                                <select class="form-select staff-select" 
                                                        id="add_staff_select"
                                                        multiple>
                                                    <?php foreach ($staffMembers as $staff): ?>
                                                        <option value="<?php echo $staff['id']; ?>">
                                                            <?php echo htmlspecialchars($staff['name']); ?>
                                                            <?php if (!empty($staff['designation'])): ?>
                                                                (<?php echo htmlspecialchars($staff['designation']); ?>)
                                                            <?php endif; ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                                <div id="selected_staff_container" class="selected-items mt-2"></div>
                                                <input type="hidden" name="assigned_staff" id="add_staff_assigned" value="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" 
                            class="btn btn-outline-secondary" 
                            data-bs-dismiss="modal">
                        <i class="ri-close-line me-1"></i>
                        Cancel
                    </button>
                    <button type="submit" 
                            class="btn btn-primary">
                        <i class="ri-save-line me-1"></i>
                        Save Lead
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Edit Lead Modal -->
<?php if ($canEditLead): ?>
<div class="modal fade" id="editLeadModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content">
            <div class="modal-header bg-light">
                <h5 class="modal-title">
                    <i class="ri-edit-line me-2"></i>
                    Edit Lead
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate id="editLeadForm">
                <input type="hidden" name="update_lead" value="1">
                <input type="hidden" name="lead_id" id="edit_lead_id">
                <!-- Modal content is dynamically loaded via AJAX -->
                <div id="editLeadContent" class="modal-body">
                    <div class="text-center py-5">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                        <p class="mt-2">Loading lead data...</p>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" 
                            class="btn btn-outline-secondary" 
                            data-bs-dismiss="modal">
                        <i class="ri-close-line me-1"></i>
                        Cancel
                    </button>
                    <button type="submit" 
                            class="btn btn-primary">
                        <i class="ri-save-line me-1"></i>
                        Update Lead
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Delete Lead Modal -->
<?php if ($canDeleteLead): ?>
<div class="modal fade" id="deleteLeadModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">
                    <i class="ri-delete-bin-line me-2"></i>
                    Delete Lead
                </h5>
                <button type="button" 
                        class="btn-close btn-close-white" 
                        data-bs-dismiss="modal" 
                        aria-label="Close"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="delete_lead" value="1">
                <input type="hidden" name="lead_id" id="delete_lead_id">
                <div class="modal-body">
                    <div class="text-center mb-4">
                        <i class="ri-error-warning-line text-danger fs-1"></i>
                        <h5 class="mt-3">Are you sure you want to delete this lead?</h5>
                        <p class="text-muted mb-0">Name: <strong id="delete_lead_name"></strong></p>
                    </div>
                    <div class="alert alert-warning">
                        <i class="ri-alert-line me-2"></i>
                        This action cannot be undone. All data associated with this lead will be permanently removed.
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" 
                            class="btn btn-outline-secondary" 
                            data-bs-dismiss="modal">
                        <i class="ri-close-line me-1"></i>
                        Cancel
                    </button>
                    <button type="submit" 
                            class="btn btn-danger">
                        <i class="ri-delete-bin-line me-1"></i>
                        Delete Lead
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Add Note Modal -->
<?php if ($viewLeadId): ?>
<div class="modal fade" id="addNoteModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-light">
                <h5 class="modal-title">
                    <i class="ri-sticky-note-add-line me-2"></i>
                    Add Note
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="add_note" value="1">
                <input type="hidden" name="lead_id" value="<?php echo $viewLeadId; ?>">
                <div class="modal-body">
                    <div class="form-floating">
                        <textarea 
                            class="form-control" 
                            name="note_text" 
                            id="add_note_text"
                            placeholder="Enter note"
                            style="height: 150px"
                            required></textarea>
                        <label for="add_note_text">Note</label>
                        <div class="invalid-feedback">
                            Please provide a note.
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" 
                            class="btn btn-outline-secondary" 
                            data-bs-dismiss="modal">
                        <i class="ri-close-line me-1"></i>
                        Cancel
                    </button>
                    <button type="submit" 
                            class="btn btn-primary">
                        <i class="ri-save-line me-1"></i>
                        Add Note
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- JavaScript for Lead Management -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });
    
    // Form validation
    const forms = document.querySelectorAll('.needs-validation');
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    });
    
    // Handle Lead Source selection
    const sourceRadios = document.querySelectorAll('input[name="lead_source"]');
    const agentSelectionContainer = document.getElementById('agent_selection_container');
    
    if (sourceRadios && agentSelectionContainer) {
        sourceRadios.forEach(radio => {
            radio.addEventListener('change', function() {
                agentSelectionContainer.style.display = (this.value === 'Agent') ? 'block' : 'none';
            });
        });
    }
    
    // Handle Lead Status selection for Campus Visit Date
    const leadStatusSelect = document.getElementById('add_lead_status');
    const officeVisitDateContainer = document.getElementById('campus_visit_date_container');
    
    if (leadStatusSelect && officeVisitDateContainer) {
        leadStatusSelect.addEventListener('change', function() {
            officeVisitDateContainer.style.display = (this.value === 'Will visit office') ? 'block' : 'none';
        });
    }
    
    // Handle Applying For selection to show/hide education fields
    const applyingForSelect = document.getElementById('add_applying_for');
    if (applyingForSelect) {
        applyingForSelect.addEventListener('change', function() {
            const sscContainer = document.getElementById('add_ssc_gpa_container');
            const hscContainer = document.getElementById('add_hsc_gpa_container');
            const bachelorSubjectContainer = document.getElementById('add_bachelor_subject_container');
            const bachelorCgpaContainer = document.getElementById('add_bachelor_cgpa_container');
            
            if (this.value === '') {
                // Hide all fields
                if (sscContainer) sscContainer.style.display = 'none';
                if (hscContainer) hscContainer.style.display = 'none';
                if (bachelorSubjectContainer) bachelorSubjectContainer.style.display = 'none';
                if (bachelorCgpaContainer) bachelorCgpaContainer.style.display = 'none';
            } else if (this.value === 'Bachelor Degree') {
                // Show SSC and HSC only
                if (sscContainer) sscContainer.style.display = 'block';
                if (hscContainer) hscContainer.style.display = 'block';
                if (bachelorSubjectContainer) bachelorSubjectContainer.style.display = 'none';
                if (bachelorCgpaContainer) bachelorCgpaContainer.style.display = 'none';
            } else if (this.value === 'Master Degree') {
                // Show all fields
                if (sscContainer) sscContainer.style.display = 'block';
                if (hscContainer) hscContainer.style.display = 'block';
                if (bachelorSubjectContainer) bachelorSubjectContainer.style.display = 'block';
                if (bachelorCgpaContainer) bachelorCgpaContainer.style.display = 'block';
            }
        });
    }
    
    // Multiple select handling (kept for backward compatibility with interests - will be removed later)
    function initializeMultiSelect(selectId, containerName, hiddenInputId) {
        const select = document.getElementById(selectId);
        const container = document.getElementById(containerName);
        const hiddenInput = document.getElementById(hiddenInputId);
        
        if (!select || !container || !hiddenInput) return;
        
        select.addEventListener('change', function() {
            const option = this.options[this.selectedIndex];
            if (!option) return;
            
            const value = option.value;
            const text = option.text;
            
            // Check if already selected
            if (document.querySelector(`[data-id="${value}"][data-container="${containerName}"]`)) {
                this.selectedIndex = 0;
                return;
            }
            
            // Create selected item tag
            const tag = document.createElement('div');
            tag.className = 'selected-item';
            tag.setAttribute('data-id', value);
            tag.setAttribute('data-container', containerName);
            tag.innerHTML = `
                ${text}
                <button type="button" class="remove-item btn btn-sm" aria-label="Remove">×</button>
            `;
            
            // Add remove event
            tag.querySelector('.remove-item').addEventListener('click', function() {
                tag.remove();
                updateHiddenInput();
            });
            
            container.appendChild(tag);
            this.selectedIndex = 0;
            
            updateHiddenInput();
        });
        
        function updateHiddenInput() {
            const selectedItems = container.querySelectorAll('.selected-item');
            const values = Array.from(selectedItems).map(item => item.dataset.id);
            hiddenInput.value = values.join(',');
        }
    }
    
    // Initialize multi-selects
    initializeMultiSelect('add_courses_select', 'selected_courses_container', 'add_courses');
    initializeMultiSelect('add_semesters_select', 'selected_semesters_container', 'add_semesters');
    
    if (document.getElementById('add_staff_select')) {
        initializeMultiSelect('add_staff_select', 'selected_staff_container', 'add_staff_assigned');
    }
    
    // Initialize autocompletes
    initializeAutocomplete('agent', 'add_agent_name', 'add_agent_id', <?php echo json_encode($agents); ?>, 'name');
    initializeAutocomplete('course', 'filter_course_name', 'filter_course_id', <?php echo json_encode($courses); ?>, 'course_title');
    
    // Autocomplete function
    function initializeAutocomplete(type, inputId, hiddenInputId, data, displayField) {
        const input = document.getElementById(inputId);
        const hiddenInput = document.getElementById(hiddenInputId);
        if (!input || !hiddenInput) return;
        
        const resultsContainer = input.parentElement.querySelector(`.${type}-autocomplete-results`);
        if (!resultsContainer) return;
        
        // Style the results container
        resultsContainer.style.position = 'absolute';
        resultsContainer.style.top = '100%';
        resultsContainer.style.left = '0';
        resultsContainer.style.right = '0';
        resultsContainer.style.maxHeight = '200px';
        resultsContainer.style.overflowY = 'auto';
        resultsContainer.style.backgroundColor = '#fff';
        resultsContainer.style.border = '1px solid #ced4da';
        resultsContainer.style.borderRadius = '0 0 0.25rem 0.25rem';
        resultsContainer.style.zIndex = '1050';
        resultsContainer.style.display = 'none';
        
        // Input event handler
        input.addEventListener('input', function() {
            const query = this.value.toLowerCase().trim();
            
            // Clear results container
            resultsContainer.innerHTML = '';
            resultsContainer.style.display = 'none';
            
            if (query.length < 2) return;
            
            // Filter data based on input
            const matches = data.filter(item => 
                item[displayField].toLowerCase().includes(query)
            );
            
            if (matches.length > 0) {
                resultsContainer.style.display = 'block';
                
                // Create and append result items
                matches.forEach(item => {
                    const resultItem = document.createElement('div');
                    resultItem.className = `${type}-result-item p-2`;
                    resultItem.style.cursor = 'pointer';
                    resultItem.style.borderBottom = '1px solid #f0f0f0';
                    resultItem.innerHTML = item[displayField];
                    resultItem.dataset.id = item.id;
                    resultItem.dataset.name = item[displayField];
                    
                    resultItem.addEventListener('mouseover', function() {
                        this.style.backgroundColor = '#f8f9fa';
                    });
                    
                    resultItem.addEventListener('mouseout', function() {
                        this.style.backgroundColor = 'transparent';
                    });
                    
                    resultItem.addEventListener('click', function() {
                        input.value = this.dataset.name;
                        hiddenInput.value = this.dataset.id;
                        resultsContainer.style.display = 'none';
                        input.dispatchEvent(new Event('change'));
                    });
                    
                    resultsContainer.appendChild(resultItem);
                });
            }
        });
        
        // Handle blur event - close dropdown when clicked outside
        document.addEventListener('click', function(e) {
            if (!input.contains(e.target) && !resultsContainer.contains(e.target)) {
                resultsContainer.style.display = 'none';
            }
        });
        
        // Prevent form submission on Enter key in autocomplete field
        input.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' && resultsContainer.style.display === 'block') {
                e.preventDefault();
                const firstResult = resultsContainer.querySelector(`.${type}-result-item`);
                if (firstResult) {
                    firstResult.click();
                }
            }
        });
    }
    
    // Handle Edit Lead Modal
    // Replace the Edit Lead Modal handling code with this in lead_management_view.php
const editLeadButtons = document.querySelectorAll('[data-bs-target="#editLeadModal"]');
if (editLeadButtons.length > 0) {
    editLeadButtons.forEach(button => {
        button.addEventListener('click', function() {
            const leadId = this.getAttribute('data-lead-id');
            document.getElementById('edit_lead_id').value = leadId;
            
            // Loading state
            const contentDiv = document.getElementById('editLeadContent');
            contentDiv.innerHTML = `
                <div class="text-center py-5">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-2">Loading lead #${leadId} data...</p>
                </div>
            `;
            
            // Get the selected tab to activate after loading
            const tabToActivate = this.getAttribute('data-tab');
            
            // AJAX call to get lead data
// AJAX call to get lead data
const xhr = new XMLHttpRequest();
xhr.open('POST', 'ajax/get_lead_data.php', true);
xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');

xhr.onload = function() {
    if (xhr.status === 200) {
        // Update the modal content
        contentDiv.innerHTML = xhr.responseText;
        
        // THIS IS KEY: Execute scripts after the content is loaded
        setTimeout(() => {
            // Fix campus visit date field
            const editLeadStatusSelect = document.getElementById('edit_lead_status');
            const editOfficeVisitDateContainer = document.getElementById('edit_campus_visit_date_container');
            
            if (editLeadStatusSelect && editOfficeVisitDateContainer) {
                console.log("Initializing edit lead status handler");
                
                // Make sure initial display is correct (important!)
                editOfficeVisitDateContainer.style.display = 
                    (editLeadStatusSelect.value === 'Will visit office') ? 'block' : 'none';
                
                // Add change event listener
                editLeadStatusSelect.addEventListener('change', function() {
                    console.log("Lead status changed to: " + this.value);
                    editOfficeVisitDateContainer.style.display = 
                        (this.value === 'Will visit office') ? 'block' : 'none';
                    
                    // Populate date if empty and status is "Will visit office"
                    if (this.value === 'Will visit office') {
                        const dateField = document.getElementById('edit_campus_visit_date');
                        if (dateField && !dateField.value) {
                            // Set to current date/time
                            const now = new Date();
                            const year = now.getFullYear();
                            const month = String(now.getMonth() + 1).padStart(2, '0');
                            const day = String(now.getDate()).padStart(2, '0');
                            const hours = String(now.getHours()).padStart(2, '0');
                            const minutes = String(now.getMinutes()).padStart(2, '0');
                            
                            dateField.value = `${year}-${month}-${day}T${hours}:${minutes}`;
                            console.log("Date field populated with: " + dateField.value);
                        }
                    }
                });
            }
            
            // Fix multiselect functionality for edit form
            function initializeEditMultiSelect(selectId, containerName, hiddenInputId) {
                const select = document.getElementById(selectId);
                const container = document.getElementById(containerName);
                const hiddenInput = document.getElementById(hiddenInputId);
                
                if (!select || !container || !hiddenInput) {
                    console.warn(`Missing elements for ${selectId}`);
                    return;
                }
                
                console.log(`Initializing multiselect for ${selectId}`);
                
                // Add change event listener to select dropdown
                select.addEventListener('change', function() {
                    const option = this.options[this.selectedIndex];
                    if (!option) return;
                    
                    const value = option.value;
                    const text = option.text;
                    
                    // Check if already selected
                    if (container.querySelector(`[data-id="${value}"]`)) {
                        this.selectedIndex = 0;
                        return;
                    }
                    
                    // Create selected item tag
                    const tag = document.createElement('div');
                    tag.className = 'selected-item';
                    tag.setAttribute('data-id', value);
                    tag.setAttribute('data-container', containerName);
                    tag.innerHTML = `
                        ${text}
                        <button type="button" class="remove-item btn btn-sm" aria-label="Remove">×</button>
                    `;
                    
                    // Handle remove button click
                    const removeBtn = tag.querySelector('.remove-item');
                    removeBtn.addEventListener('click', function() {
                        tag.remove();
                        updateHiddenInput();
                    });
                    
                    container.appendChild(tag);
                    this.selectedIndex = 0;
                    updateHiddenInput();
                });
                
                // Initialize existing remove buttons
                container.querySelectorAll('.remove-item').forEach(button => {
                    button.addEventListener('click', function() {
                        const item = this.parentNode;
                        item.remove();
                        updateHiddenInput();
                    });
                });
                
                // Update hidden input helper
                function updateHiddenInput() {
                    const selectedItems = container.querySelectorAll('.selected-item');
                    const values = Array.from(selectedItems).map(item => item.dataset.id);
                    hiddenInput.value = values.join(',');
                    console.log(`Updated ${hiddenInputId} with values: ${hiddenInput.value}`);
                }
            }
            
            // Initialize multiselects for edit form
            initializeEditMultiSelect('edit_courses_select', 'edit_selected_courses_container', 'edit_courses');
            initializeEditMultiSelect('edit_semesters_select', 'edit_selected_semesters_container', 'edit_semesters');
            
            if (document.getElementById('edit_staff_select')) {
                initializeEditMultiSelect('edit_staff_select', 'edit_selected_staff_container', 'edit_staff_assigned');
            }
            
            // Initialize agent autocomplete if exists
            if (typeof initializeAutocomplete === 'function' && document.getElementById('edit_agent_name')) {
                initializeAutocomplete('agent', 'edit_agent_name', 'edit_agent_id', agentData, 'name');
            }
            
            // Initialize edit form source radio buttons
            const editSourceRadios = document.querySelectorAll('#editLeadForm input[name="lead_source"]');
            const editAgentSelectionContainer = document.getElementById('edit_agent_selection_container');
            
            if (editSourceRadios && editAgentSelectionContainer) {
                editSourceRadios.forEach(radio => {
                    radio.addEventListener('change', function() {
                        editAgentSelectionContainer.style.display = (this.value === 'Agent') ? 'block' : 'none';
                    });
                });
            }
            
            // Activate the specified tab if needed
            if (tabToActivate) {
                const tabElement = document.querySelector(`#editLeadFormTabs .nav-link[href="#edit-${tabToActivate}-pane"]`);
                if (tabElement) {
                    bootstrap.Tab.getOrCreateInstance(tabElement).show();
                }
            }
        }, 100); // Small delay to ensure DOM is fully updated
    } else {
        contentDiv.innerHTML = `
            <div class="alert alert-danger">
                <i class="ri-error-warning-line me-2"></i>
                Error loading lead data. Please try again.
                <br>
                Status: ${xhr.status}
                <br>
                Response: ${xhr.responseText.substring(0, 200)}${xhr.responseText.length > 200 ? '...' : ''}
            </div>
        `;
    }
};

xhr.onerror = function() {
    contentDiv.innerHTML = `
        <div class="alert alert-danger">
            <i class="ri-error-warning-line me-2"></i>
            Network error. Please check your connection and try again.
        </div>
    `;
};

xhr.send('lead_id=' + encodeURIComponent(leadId));
        });
    });
}
    
    // Handle Delete Lead Modal
    const deleteLeadButtons = document.querySelectorAll('[data-bs-target="#deleteLeadModal"]');
    if (deleteLeadButtons.length > 0) {
        deleteLeadButtons.forEach(button => {
            button.addEventListener('click', function() {
                const leadId = this.getAttribute('data-lead-id');
                const leadName = this.getAttribute('data-lead-name');
                
                document.getElementById('delete_lead_id').value = leadId;
                document.getElementById('delete_lead_name').textContent = leadName;
            });
        });
    }

});
</script>

<style>
.lead-container {
    max-width: 1400px;
    margin: 1rem auto;
    padding: 1rem;
    background: #ffffff;
    border-radius: 1rem;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
}

.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
    flex-wrap: wrap;
    gap: 1rem;
}

.filters-section .card-header {
    background-color: #f8f9fa;
    padding: 0.75rem 1rem;
}

.filters-section .card-body {
    padding: 1.5rem;
}

.lead-source-selector .source-option {
    padding: 0.5rem 1rem;
    border: 1px solid #dee2e6;
    border-radius: 0.25rem;
    margin-right: 0;
}

.lead-source-selector .source-option input[type="radio"] {
    margin-right: 0.5rem;
}

.lead-source-selector .source-option:hover {
    background-color: #f8f9fa;
}

.avatar-circle {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    color: white;
    font-weight: 600;
}

.avatar-circle.avatar-sm {
    width: 32px;
    height: 32px;
    font-size: 0.75rem;
}

.avatar-circle.avatar-xs {
    width: 24px;
    height: 24px;
    font-size: 0.625rem;
}
.avatar-circle.avatar-xl {
    width: 100px;
    height: 100px;
}

.avatar-group {
    display: flex;
}

.avatar-group .avatar-circle {
    margin-right: -8px;
    border: 2px solid #fff;
}

.interests-column {
    max-width: 200px;
}

.interest-tags {
    display: flex;
    flex-wrap: wrap;
    gap: 0.25rem;
}

.interest-tag {
    display: inline-block;
    padding: 0.25rem 0.5rem;
    background-color: #e9ecef;
    border-radius: 0.25rem;
    font-size: 0.75rem;
    white-space: nowrap;
}

.multiple-select-container .selected-items {
    display: flex;
    flex-wrap: wrap;
    gap: 0.5rem;
}

.selected-item {
    display: inline-flex;
    align-items: center;
    background-color: #e9ecef;
    border-radius: 0.25rem;
    padding: 0.25rem 0.5rem;
    font-size: 0.875rem;
}

.selected-item .remove-item {
    line-height: 0.5;
    padding: 0.25rem;
    margin-left: 0.25rem;
    border-radius: 50%;
}

/* Autocomplete Styles */
.agent-autocomplete-container,
.university-autocomplete-container,
.course-autocomplete-container {
    position: relative;
}

.agent-autocomplete-results,
.university-autocomplete-results,
.course-autocomplete-results {
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    max-height: 200px;
    overflow-y: auto;
    background-color: #fff;
    border: 1px solid #ced4da;
    border-radius: 0 0 0.25rem 0.25rem;
    z-index: 1050;
    display: none;
}

.agent-result-item,
.university-result-item,
.course-result-item {
    padding: 0.5rem 1rem;
    cursor: pointer;
    border-bottom: 1px solid #f0f0f0;
}

.agent-result-item:hover,
.university-result-item:hover,
.course-result-item:hover {
    background-color: #f8f9fa;
}

/* Follow-up Quick Filters Styling */
.followup-quick-filters {
    background-color: #f8f9fa;
    padding: 1rem;
    border-radius: 0.5rem;
}

.followup-quick-filters .btn {
    font-weight: 500;
    transition: all 0.2s ease;
}

.followup-quick-filters .btn:hover {
    transform: translateY(-1px);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}

.followup-quick-filters .badge {
    font-size: 0.75rem;
    font-weight: 600;
    padding: 0.25rem 0.5rem;
}

/* Follow-up Badge Animations */
@keyframes pulseAlert {
    0%, 100% {
        opacity: 1;
    }
    50% {
        opacity: 0.7;
    }
}

.badge.bg-danger {
    animation: pulseAlert 2s infinite;
}

.badge.bg-warning {
    animation: pulseAlert 3s infinite;
}

/* Respect user preference for reduced motion */
@media (prefers-reduced-motion: reduce) {
    .badge.bg-danger,
    .badge.bg-warning {
        animation: none;
    }
}

/* Follow-up Column Styling */
td .badge {
    white-space: nowrap;
}

td small.text-danger,
td small.text-warning {
    display: block;
    line-height: 1.2;
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .lead-container {
        margin: 0;
        padding: 1rem;
        border-radius: 0;
    }

    .page-header {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .avatar-group .avatar-circle {
        margin-right: -4px;
    }
    
    .interests-column {
        max-width: 100%;
    }
    
    .followup-quick-filters .d-flex {
        flex-direction: column;
    }
    
    .followup-quick-filters .btn {
        width: 100%;
    }
}
</style>

<?php if ($viewLeadId && $leadDetails): ?>
<!-- Lead Detail Page Styles -->
<style>
.lead-detail-view {
    max-width: 1200px;
    margin: 0 auto;
}

.lead-profile-header {
    display: flex;
    flex-wrap: wrap;
    gap: 2rem;
    margin-bottom: 2rem;
    padding: 2rem;
    background-color: #f8f9fa;
    border-radius: 0.5rem;
}

.lead-avatar {
    width: 100px;
    height: 100px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 2.5rem;
    border-radius: 50%;
}

.lead-basic-info {
    flex: 1;
}

.lead-tabs {
    margin-bottom: 2rem;
}

.info-card {
    height: 100%;
}

.info-card .card-header {
    background-color: rgba(0,0,0,0.03);
    padding: 0.75rem 1.25rem;
}

.info-list {
    list-style: none;
    padding: 0;
    margin: 0;
}

.info-list li {
    padding: 0.5rem 0;
    border-bottom: 1px solid #f0f0f0;
}

.info-list li:last-child {
    border-bottom: none;
}

.info-label {
    font-weight: 500;
    color: #6c757d;
}

.timeline {
    position: relative;
    padding-left: 2rem;
}

.timeline:before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    width: 2px;
    background-color: #e9ecef;
}

.timeline-item {
    position: relative;
    padding-bottom: 2rem;
}

.timeline-item:last-child {
    padding-bottom: 0;
}

.timeline-marker {
    position: absolute;
    left: -1.5rem;
    top: 0;
    width: 1rem;
    height: 1rem;
    border-radius: 50%;
    background-color: #0d6efd;
    transform: translateX(-50%);
}

.timeline-content {
    padding: 1rem;
    background-color: #f8f9fa;
    border-radius: 0.5rem;
}
</style>
<?php endif; ?>