<?php
require_once __DIR__ . '/../../app/controllers/CompanyController.php';

// Check user permissions
$companyController = new CompanyController($conn);
if (!$companyController->checkUserPermissions()) {
    header("Location: /dashboard.php");
    exit();
}

// Get company details (assuming company_id is 1 or stored in session)
$company_id = 1; // or $_SESSION['company_id'];
$company = $companyController->showCompany($company_id);

$success = $error = '';
$is_super_admin = $_SESSION['user_type'] === 'Super Admin';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_company'])) {
    // Prepare update data
    $data = [
        'id' => $company_id,
        'company_name' => $_POST['company_name'],
        'contact_first_name' => $_POST['contact_first_name'],
        'contact_last_name' => $_POST['contact_last_name'],
        'phone_number' => $_POST['phone_number'],
        'website_url' => $_POST['website_url'],
        'contact_email' => $_POST['contact_email'],
        'system_email' => $_POST['system_email'],
        'address' => $_POST['address'],
        'status' => $is_super_admin ? $_POST['status'] : $company['status'] // Only super admin can change status
    ];

    // Validate data
    $errors = $companyController->validateCompanyData($data);

    if (empty($errors)) {
        // Handle logo upload
        if (!empty($_FILES['logo']['tmp_name'])) {
            $newLogoName = $companyController->handleLogoUpload(
                $_FILES['logo'],
                $company['logo'] ?? null
            );

            if ($newLogoName) {
                $data['logo'] = $newLogoName;
            } else {
                $error = "Failed to upload company logo.";
            }
        } else {
            $data['logo'] = $company['logo'] ?? null;
        }

        // Update company if no errors
        if (empty($error)) {
            if ($companyController->updateCompany($data)) {
                $success = "Company settings updated successfully.";
                // Refresh company data
                $company = $companyController->showCompany($company_id);
            } else {
                $error = "Failed to update company settings.";
            }
        }
    } else {
        $error = implode(", ", $errors);
    }
}

// Debug information
error_log("Current Date and Time (UTC): " . date('Y-m-d H:i:s'));
error_log("Current User's Login: " . $_SESSION['email']);
?>

<style>
    .company-container {
        max-width: 800px;
        margin: 2rem auto;
        padding: 1rem;
        background: white;
        border-radius: 15px;
        box-shadow: 0 0 20px rgba(0,0,0,0.1);
    }

    @media (min-width: 768px) {
        .company-container {
            padding: 2rem;
        }
    }

    .company-header {
        text-align: center;
        margin-bottom: 2rem;
        padding: 1rem;
        border-bottom: 1px solid #eee;
    }

    .company-logo-container {
        position: relative;
        width: 120px;
        height: 120px;
        margin: 0 auto 1rem;
    }

    @media (min-width: 768px) {
        .company-logo-container {
            width: 150px;
            height: 150px;
        }
    }

    .company-logo {
        width: 100%;
        height: 100%;
        border-radius: 15px;
        object-fit: contain;
        border: 4px solid #fff;
        box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    .logo-upload-btn {
        position: absolute;
        bottom: 5px;
        right: 5px;
        background: #4f46e5;
        color: white;
        border-radius: 50%;
        width: 36px;
        height: 36px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .logo-upload-btn:hover {
        background: #4338ca;
        transform: scale(1.1);
    }

    .status-badge {
        display: inline-block;
        padding: 0.4rem 1rem;
        border-radius: 20px;
        font-size: 0.9rem;
        margin-top: 0.5rem;
    }

    .status-badge.active {
        background: #d1fae5;
        color: #065f46;
    }

    .status-badge.inactive {
        background: #fee2e2;
        color: #991b1b;
    }

    .form-section {
        margin-bottom: 1.5rem;
    }

    .form-section-title {
        font-size: 1.1rem;
        font-weight: 600;
        margin-bottom: 1rem;
        color: #374151;
    }

    /* Responsive form grid */
    .row {
        margin-left: -0.5rem;
        margin-right: -0.5rem;
    }

    .col-md-6, .col-12 {
        padding: 0 0.5rem;
    }

    @media (max-width: 767px) {
        .col-md-6 {
            margin-bottom: 1rem;
        }
    }
</style>

<div class="company-container">
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($success); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="company-header">
        <div class="company-logo-container">
            <?php
            $logo = !empty($company['logo']) 
                ? "/storage/uploads/company_logos/" . htmlspecialchars($company['logo'])
                : "/storage/uploads/company_logos/default_logo.png";
            ?>
            <img src="<?php echo $logo; ?>" 
                 alt="Company Logo" 
                 class="company-logo"
                 onerror="this.src='/storage/uploads/company_logos/default_logo.png'">
            
            <label for="logo" class="logo-upload-btn">
                <i class="ri-camera-line"></i>
            </label>
        </div>

        <h4 class="mb-2"><?php echo htmlspecialchars($company['company_name']); ?></h4>
        <div class="status-badge <?php echo strtolower($company['status']); ?>">
            <?php echo htmlspecialchars($company['status']); ?>
        </div>
    </div>

    <form method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
        <input type="file" 
               id="logo" 
               name="logo" 
               accept="image/*" 
               class="d-none">

        <!-- Company Information -->
        <div class="form-section">
            <div class="form-section-title">Company Information</div>
            <div class="row">
                <div class="col-12">
                    <div class="form-floating mb-3">
                        <input type="text" 
                               class="form-control" 
                               name="company_name" 
                               id="company_name" 
                               value="<?php echo htmlspecialchars($company['company_name']); ?>" 
                               required>
                        <label for="company_name">Company Name</label>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-floating mb-3">
                        <input type="url" 
                               class="form-control" 
                               name="website_url" 
                               id="website_url" 
                               value="<?php echo htmlspecialchars($company['website_url'] ?? ''); ?>">
                        <label for="website_url">Website URL</label>
                    </div>
                </div>

                <div class="col-12">
                    <div class="form-floating mb-3">
                        <textarea class="form-control" 
                                  name="address" 
                                  id="address" 
                                  style="height: 100px"><?php echo htmlspecialchars($company['address'] ?? ''); ?></textarea>
                        <label for="address">Address</label>
                    </div>
                </div>
            </div>
        </div>

        <!-- Contact Information -->
        <div class="form-section">
            <div class="form-section-title">Contact Information</div>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-floating mb-3">
                        <input type="text" 
                               class="form-control" 
                               name="contact_first_name" 
                               id="contact_first_name" 
                               value="<?php echo htmlspecialchars($company['contact_first_name']); ?>" 
                               required>
                        <label for="contact_first_name">Contact First Name</label>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-floating mb-3">
                        <input type="text" 
                               class="form-control" 
                               name="contact_last_name" 
                               id="contact_last_name" 
                               value="<?php echo htmlspecialchars($company['contact_last_name']); ?>" 
                               required>
                        <label for="contact_last_name">Contact Last Name</label>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-floating mb-3">
                        <input type="text" 
                               class="form-control" 
                               name="phone_number" 
                               id="phone_number" 
                               value="<?php echo htmlspecialchars($company['phone_number']); ?>" 
                               required>
                        <label for="phone_number">Phone Number</label>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-floating mb-3">
                        <input type="email" 
                               class="form-control" 
                               name="contact_email" 
                               id="contact_email" 
                               value="<?php echo htmlspecialchars($company['contact_email']); ?>" 
                               required>
                        <label for="contact_email">Contact Email</label>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-floating mb-3">
                        <input type="email" 
                               class="form-control" 
                               name="system_email" 
                               id="system_email" 
                               value="<?php echo htmlspecialchars($company['system_email']); ?>" 
                               required>
                        <label for="system_email">System Email</label>
                    </div>
                </div>

                <?php if ($is_super_admin): ?>
                <div class="col-md-6">
                    <div class="form-floating mb-3">
                        <select class="form-select" 
                                name="status" 
                                id="status" 
                                required>
                            <option value="Active" <?php echo ($company['status'] === 'Active') ? 'selected' : ''; ?>>Active</option>
                            <option value="Inactive" <?php echo ($company['status'] === 'Inactive') ? 'selected' : ''; ?>>Inactive</option>
                        </select>
                        <label for="status">Status</label>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="mt-4">
            <button type="submit" name="update_company" class="btn btn-primary w-100">
                <i class="ri-save-line me-1"></i> Update Company Settings
            </button>
        </div>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Handle logo upload and preview
    const logoInput = document.getElementById('logo');
    const companyLogo = document.querySelector('.company-logo');

    logoInput.addEventListener('change', function(e) {
        if (this.files && this.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                companyLogo.src = e.target.result;
            }
            reader.readAsDataURL(this.files[0]);
        }
    });

    // Form validation
    const form = document.querySelector('form');
    form.addEventListener('submit', function(event) {
        if (!form.checkValidity()) {
            event.preventDefault();
            event.stopPropagation();
        }
        form.classList.add('was-validated');
    });
});
</script>