<?php
/**
 * Top Sheet Report View
 * Created on: 2026-01-26
 * Description: Admission statement of enrollment of students
 */

require_once __DIR__ . '/../../config/config.php';

// Check if user has permission (Admin or Super Admin only)
$user_id = $_SESSION['user_id'] ?? 0;
$company_id = $_SESSION['company_id'] ?? 0;
$stmt = $conn->prepare("SELECT user_type FROM users WHERE id = ?");
$stmt->bindParam(1, $user_id, PDO::PARAM_INT);
$stmt->execute();
$user_type = $stmt->fetchColumn();

if (!in_array($user_type, ['Super Admin', 'Admin'])) {
    header("Location: /dashboard.php");
    exit();
}

// Get filter parameters
$date_from = $_GET['date_from'] ?? null;
$date_to = $_GET['date_to'] ?? null;

// Include controller and model
require_once __DIR__ . '/../controllers/reports_controller.php';

$controller = new ReportsController($conn);
$metadata_result = $controller->getReportMetadata($company_id);
$metadata = $metadata_result['metadata'] ?? [];

$data_result = $controller->getTopSheetData($company_id, null, null, $date_from, $date_to);
$programs = $data_result['data'] ?? [];

// Get company details for header
$stmt = $conn->prepare("SELECT company_name, address, phone_number FROM companies WHERE id = ?");
$stmt->execute([$company_id]);
$company = $stmt->fetch(PDO::FETCH_ASSOC);

// Calculate grand totals
$grand_previous = 0;
$grand_today = 0;
$grand_total = 0;

foreach ($programs as $program) {
    $grand_previous += $program['previous_day'];
    $grand_today += $program['today'];
    $grand_total += $program['total'];
}

// Format dates for display
$display_date_from = $date_from ? date('jS F Y', strtotime($date_from)) : 'Beginning';
$display_date_to = $date_to ? date('jS F Y', strtotime($date_to)) : 'Now';
?>

<style>
@media print {
    .no-print {
        display: none !important;
    }
    .content-page {
        margin: 0 !important;
        padding: 0 !important;
    }
    .report-container {
        padding: 20px !important;
    }
}

.report-container {
    background: white;
    padding: 40px;
    max-width: 1000px;
    margin: 0 auto;
}

.report-header {
    text-align: center;
    margin-bottom: 30px;
}

.report-header h1 {
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 10px;
    text-transform: uppercase;
}

.report-header p {
    margin: 5px 0;
    font-size: 14px;
}

.report-title {
    text-align: center;
    margin: 30px 0;
}

.report-title h2 {
    font-size: 18px;
    font-weight: bold;
    text-decoration: underline;
}

.report-info {
    margin-bottom: 20px;
}

.report-info p {
    margin: 5px 0;
    font-size: 14px;
}

.report-table {
    width: 100%;
    border-collapse: collapse;
    margin: 20px 0;
}

.report-table th,
.report-table td {
    border: 1px solid #000;
    padding: 8px;
    text-align: left;
}

.report-table th {
    background-color: #f5f5f5;
    font-weight: bold;
    text-align: center;
}

.report-table td {
    text-align: center;
}

.report-table td:first-child {
    text-align: left;
}

.report-table .grand-total {
    font-weight: bold;
    background-color: #e9ecef;
}

.action-buttons {
    margin-bottom: 20px;
    text-align: right;
}

.btn-download {
    background-color: #0d6efd;
    color: white;
    border: none;
    padding: 10px 20px;
    cursor: pointer;
    border-radius: 4px;
    margin-left: 10px;
}

.btn-download:hover {
    background-color: #0b5ed7;
}
</style>

<div class="row no-print">
    <div class="col-12">
        <div class="page-title-box">
            <h4 class="page-title">Top Sheet Report</h4>
        </div>
    </div>
</div>

<div class="row no-print">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <form method="GET" action="" class="row g-3">
                    <input type="hidden" name="page" value="top_sheet_report">
                    <div class="col-md-4">
                        <label for="date_from" class="form-label">From Date</label>
                        <input type="date" class="form-control" id="date_from" name="date_from" value="<?php echo htmlspecialchars($date_from ?? ''); ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="date_to" class="form-label">To Date</label>
                        <input type="date" class="form-control" id="date_to" name="date_to" value="<?php echo htmlspecialchars($date_to ?? ''); ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">&nbsp;</label>
                        <div>
                            <button type="submit" class="btn btn-primary">
                                <i class="ri-filter-line"></i> Apply Filter
                            </button>
                            <a href="?page=top_sheet_report" class="btn btn-secondary">
                                <i class="ri-refresh-line"></i> Reset
                            </a>
                        </div>
                    </div>
                </form>
                
                <?php if ($date_from || $date_to): ?>
                <div class="alert alert-info mt-3">
                    <i class="ri-information-line"></i> 
                    Showing admissions from <strong><?php echo $display_date_from; ?></strong> to <strong><?php echo $display_date_to; ?></strong>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="row no-print action-buttons">
    <div class="col-12">
        <button onclick="window.print()" class="btn btn-primary">
            <i class="ri-printer-line"></i> Print / Save as PDF
        </button>
        <button onclick="downloadPDF()" class="btn btn-success">
            <i class="ri-download-line"></i> Download PDF
        </button>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="report-container" id="reportContent">
                    <!-- Report Header -->
                    <div class="report-header">
                        <h1><?php echo htmlspecialchars($company['company_name'] ?? 'PRIME UNIVERSITY'); ?></h1>
                        <p><?php echo htmlspecialchars($company['address'] ?? 'Address: 114/116, Mazar Road, Mirpur-1, Dhaka-1216'); ?></p>
                        <p>Phone: <?php echo htmlspecialchars($company['phone_number'] ?? '0241002435'); ?></p>
                    </div>

                    <!-- Report Title -->
                    <div class="report-title">
                        <h2>Admission statement of enrollment of students</h2>
                    </div>

                    <!-- Report Info -->
                    <div class="report-info">
                        <p><strong><?php echo htmlspecialchars($metadata['current_semester'] ?? 'Spring Semester – 2026'); ?></strong></p>
                        <p><strong>Batch:</strong> <?php echo htmlspecialchars($metadata['batch'] ?? '68th and 14th'); ?></p>
                        <p><strong>Date:</strong> <?php echo htmlspecialchars($metadata['report_date'] ?? date('jS F Y')); ?></p>
                        <?php if ($date_from || $date_to): ?>
                        <p><strong>Date Range:</strong> <?php echo $display_date_from . ' to ' . $display_date_to; ?></p>
                        <?php endif; ?>
                    </div>

                    <!-- Admission Table -->
                    <p><strong>Admission in <?php 
                        $semester_parts = explode(' –', $metadata['current_semester'] ?? 'Spring-2026');
                        echo htmlspecialchars($semester_parts[0] ?? 'Spring-2026'); 
                    ?></strong></p>
                    <table class="report-table">
                        <thead>
                            <tr>
                                <th>Program</th>
                                <th>Previous Day</th>
                                <th>Today</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($programs)): ?>
                            <tr>
                                <td colspan="4" style="text-align: center;">No admission data available</td>
                            </tr>
                            <?php else: ?>
                                <?php foreach ($programs as $program): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($program['program_name']); ?></td>
                                    <td><?php echo $program['previous_day'] > 0 ? str_pad($program['previous_day'], 2, '0', STR_PAD_LEFT) : '–'; ?></td>
                                    <td><?php echo $program['today'] > 0 ? str_pad($program['today'], 2, '0', STR_PAD_LEFT) : '–'; ?></td>
                                    <td><?php echo $program['total'] > 0 ? str_pad($program['total'], 2, '0', STR_PAD_LEFT) : '–'; ?></td>
                                </tr>
                                <?php endforeach; ?>
                                <tr class="grand-total">
                                    <td><strong>Grand Total</strong></td>
                                    <td><strong><?php echo $grand_previous; ?></strong></td>
                                    <td><strong><?php echo $grand_today; ?></strong></td>
                                    <td><strong><?php echo $grand_total; ?></strong></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function downloadPDF() {
    // For now, use browser's print to PDF
    // This will open the print dialog where user can save as PDF
    window.print();
}
</script>
