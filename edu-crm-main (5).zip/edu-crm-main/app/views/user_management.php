<?php
/**
 * User Management View
 * Created on: 2026-01-14
 * Description: Manage all users - Admin only with full CRUD
 */

require_once __DIR__ . '/../controllers/user_management_controller.php';

// Initialize controller
$userController = new UserManagementController($conn);

// Check if user has admin permission
if (!$userController->isAdmin()) {
    echo '<div class="alert alert-danger">Access denied. Admin privileges required.</div>';
    exit();
}

$success = $error = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create_user'])) {
        $result = $userController->createUser($_POST);
        if ($result['status']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    } elseif (isset($_POST['update_user'])) {
        $result = $userController->updateUser($_POST);
        if ($result['status']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    } elseif (isset($_POST['delete_user'])) {
        $result = $userController->deleteUser($_POST['user_id']);
        if ($result['status']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    }
}

// Get users with filters
$result = $userController->handleRequest();

if (isset($result['error'])) {
    echo '<div class="alert alert-danger">' . htmlspecialchars($result['error']) . '</div>';
    exit();
}

$users = $result;

// Get current filters
$filter_user_type = isset($_GET['user_type']) ? $_GET['user_type'] : '';
$filter_status = isset($_GET['status']) ? $_GET['status'] : '';
$filter_search = isset($_GET['search']) ? $_GET['search'] : '';
?>

<div class="user-management-container">
    <!-- Page Header -->
    <div class="page-header">
        <div>
            <h1 class="page-title">
                <i class="ri-team-line me-2"></i>
                User Management
            </h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/dashboard.php">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">User Management</li>
                </ol>
            </nav>
        </div>
        
        <button type="button" 
                class="btn btn-primary" 
                data-bs-toggle="modal" 
                data-bs-target="#addUserModal">
            <i class="ri-user-add-line me-1"></i>
            Add New User
        </button>
    </div>

    <!-- Alert Messages -->
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show d-flex align-items-center" role="alert">
            <i class="ri-checkbox-circle-line me-2"></i>
            <div class="flex-grow-1">
                <?php echo htmlspecialchars($success); ?>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show d-flex align-items-center" role="alert">
            <i class="ri-error-warning-line me-2"></i>
            <div class="flex-grow-1">
                <?php echo htmlspecialchars($error); ?>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Filters -->
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">
                <i class="ri-filter-3-line me-1"></i>
                Filter Users
            </h5>
        </div>
        <div class="card-body">
            <form method="GET" class="row g-3">
                <input type="hidden" name="page" value="user_management">
                
                <div class="col-md-3">
                    <div class="form-floating">
                        <input type="text" 
                               class="form-control" 
                               name="search" 
                               id="search"
                               placeholder="Search users..."
                               value="<?php echo htmlspecialchars($filter_search); ?>">
                        <label for="search">Search (Name, Email, Phone)</label>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="form-floating">
                        <select class="form-select" name="user_type" id="user_type">
                            <option value="">All Types</option>
                            <option value="Super Admin" <?php echo $filter_user_type === 'Super Admin' ? 'selected' : ''; ?>>Super Admin</option>
                            <option value="Admin" <?php echo $filter_user_type === 'Admin' ? 'selected' : ''; ?>>Admin</option>
                            <option value="Manager" <?php echo $filter_user_type === 'Manager' ? 'selected' : ''; ?>>Manager</option>
                            <option value="Counselor" <?php echo $filter_user_type === 'Counselor' ? 'selected' : ''; ?>>Counselor</option>
                            <option value="Agent" <?php echo $filter_user_type === 'Agent' ? 'selected' : ''; ?>>Agent</option>
                        </select>
                        <label for="user_type">User Type</label>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="form-floating">
                        <select class="form-select" name="status" id="status">
                            <option value="">All Statuses</option>
                            <option value="Active" <?php echo $filter_status === 'Active' ? 'selected' : ''; ?>>Active</option>
                            <option value="Deactive" <?php echo $filter_status === 'Deactive' ? 'selected' : ''; ?>>Deactive</option>
                        </select>
                        <label for="status">Status</label>
                    </div>
                </div>
                
                <div class="col-md-3 d-flex align-items-end gap-2">
                    <button type="submit" class="btn btn-primary">
                        <i class="ri-filter-3-line me-1"></i>
                        Apply Filters
                    </button>
                    <a href="?page=user_management" class="btn btn-outline-secondary">
                        <i class="ri-refresh-line me-1"></i>
                        Reset
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- Users Table -->
    <div class="card">
        <div class="card-header">
            <h5 class="card-title mb-0">
                <i class="ri-list-check me-2"></i>
                All Users (<?php echo count($users); ?>)
            </h5>
        </div>
        <div class="card-body p-0">
            <?php if (!empty($users)): ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th scope="col">User</th>
                                <th scope="col">Email</th>
                                <th scope="col">Phone</th>
                                <th scope="col">User Type</th>
                                <th scope="col">Status</th>
                                <th scope="col">Joined Date</th>
                                <th scope="col" class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <?php if (!empty($user['profile_photo'])): ?>
                                                <img src="/storage/uploads/user_profile_photo/<?php echo htmlspecialchars($user['profile_photo']); ?>" 
                                                     alt="<?php echo htmlspecialchars($user['first_name']); ?>" 
                                                     class="rounded-circle me-2"
                                                     style="width: 40px; height: 40px; object-fit: cover;">
                                            <?php else: ?>
                                                <div class="avatar-circle me-2" style="width: 40px; height: 40px; background-color: #0d6efd;">
                                                    <span><?php echo strtoupper(substr($user['first_name'] ?? 'U', 0, 1) . substr($user['last_name'] ?? 'U', 0, 1)); ?></span>
                                                </div>
                                            <?php endif; ?>
                                            <div>
                                                <div class="fw-medium"><?php echo htmlspecialchars(($user['first_name'] ?? '') . ' ' . ($user['last_name'] ?? '')); ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                                    <td><?php echo htmlspecialchars($user['mobile_number'] ?? 'N/A'); ?></td>
                                    <td>
                                        <span class="badge bg-<?php 
                                            echo $user['user_type'] === 'Super Admin' ? 'danger' : 
                                                 ($user['user_type'] === 'Admin' ? 'primary' : 
                                                 ($user['user_type'] === 'Manager' ? 'info' : 
                                                 ($user['user_type'] === 'Counselor' ? 'success' : 'warning'))); 
                                        ?>">
                                            <?php echo htmlspecialchars($user['user_type']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo $user['account_status'] === 'Active' ? 'success' : 'secondary'; ?>">
                                            <?php echo htmlspecialchars($user['account_status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('M j, Y', strtotime($user['created_at'])); ?></td>
                                    <td class="text-end">
                                        <div class="action-buttons">
                                            <button type="button" 
                                                    class="btn btn-sm btn-outline-info me-1" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#editUserModal"
                                                    data-user='<?php echo htmlspecialchars(json_encode($user)); ?>'
                                                    title="Edit User">
                                                <i class="ri-edit-line"></i>
                                            </button>
                                            <button type="button" 
                                                    class="btn btn-sm btn-outline-danger" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#deleteUserModal"
                                                    data-user-id="<?php echo $user['id']; ?>"
                                                    data-user-name="<?php echo htmlspecialchars(($user['first_name'] ?? '') . ' ' . ($user['last_name'] ?? '')); ?>"
                                                    title="Delete User">
                                                <i class="ri-delete-bin-line"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center py-5">
                    <div class="no-data-icon mb-3">
                        <i class="ri-team-line fs-1 text-muted"></i>
                    </div>
                    <h5 class="text-muted">No users found</h5>
                    <p class="text-muted small mb-3">Try adjusting your filters or add a new user.</p>
                    <button type="button" 
                            class="btn btn-primary" 
                            data-bs-toggle="modal" 
                            data-bs-target="#addUserModal">
                        <i class="ri-user-add-line me-1"></i>
                        Add User
                    </button>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Add User Modal -->
<div class="modal fade" id="addUserModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-light">
                <h5 class="modal-title">
                    <i class="ri-user-add-line me-2"></i>
                    Add New User
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="text" class="form-control" name="first_name" id="add_first_name" required>
                                <label for="add_first_name">First Name</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="text" class="form-control" name="last_name" id="add_last_name" required>
                                <label for="add_last_name">Last Name</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="email" class="form-control" name="email" id="add_email" required>
                                <label for="add_email">Email Address</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="text" class="form-control" name="mobile_number" id="add_mobile_number">
                                <label for="add_mobile_number">Phone</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="password" class="form-control" name="password" id="add_password" required minlength="6">
                                <label for="add_password">Password</label>
                                <div class="form-text">Minimum 6 characters</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating">
                                <select class="form-select" name="user_type" id="add_user_type" required>
                                    <option value="">Select Type</option>
                                    <option value="Admin">Admin</option>
                                    <option value="Manager">Manager</option>
                                    <option value="Counselor">Counselor</option>
                                    <option value="Agent">Agent</option>
                                </select>
                                <label for="add_user_type">User Type</label>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-floating">
                                <select class="form-select" name="account_status" id="add_account_status" required>
                                    <option value="Active" selected>Active</option>
                                    <option value="Deactive">Deactive</option>
                                </select>
                                <label for="add_account_status">Account Status</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        <i class="ri-close-line me-1"></i> Cancel
                    </button>
                    <button type="submit" name="create_user" class="btn btn-primary">
                        <i class="ri-save-line me-1"></i> Create User
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit User Modal -->
<div class="modal fade" id="editUserModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-light">
                <h5 class="modal-title">
                    <i class="ri-edit-line me-2"></i>
                    Edit User
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate>
                <input type="hidden" name="user_id" id="edit_user_id">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="text" class="form-control" name="first_name" id="edit_first_name" required>
                                <label for="edit_first_name">First Name</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="text" class="form-control" name="last_name" id="edit_last_name" required>
                                <label for="edit_last_name">Last Name</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="email" class="form-control" name="email" id="edit_email" required>
                                <label for="edit_email">Email Address</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="text" class="form-control" name="mobile_number" id="edit_mobile_number">
                                <label for="edit_mobile_number">Phone</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="password" class="form-control" name="password" id="edit_password" minlength="6">
                                <label for="edit_password">New Password (leave blank to keep current)</label>
                                <div class="form-text">Minimum 6 characters</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating">
                                <select class="form-select" name="user_type" id="edit_user_type" required>
                                    <option value="">Select Type</option>
                                    <option value="Admin">Admin</option>
                                    <option value="Manager">Manager</option>
                                    <option value="Counselor">Counselor</option>
                                    <option value="Agent">Agent</option>
                                </select>
                                <label for="edit_user_type">User Type</label>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-floating">
                                <select class="form-select" name="account_status" id="edit_account_status" required>
                                    <option value="Active">Active</option>
                                    <option value="Deactive">Deactive</option>
                                </select>
                                <label for="edit_account_status">Account Status</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        <i class="ri-close-line me-1"></i> Cancel
                    </button>
                    <button type="submit" name="update_user" class="btn btn-primary">
                        <i class="ri-save-line me-1"></i> Update User
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete User Modal -->
<div class="modal fade" id="deleteUserModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">
                    <i class="ri-delete-bin-line me-2"></i>
                    Delete User
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="user_id" id="delete_user_id">
                <div class="modal-body">
                    <div class="text-center mb-4">
                        <i class="ri-error-warning-line text-danger fs-1"></i>
                        <h5 class="mt-3">Are you sure you want to delete this user?</h5>
                        <p class="text-muted mb-0">Name: <strong id="delete_user_name"></strong></p>
                    </div>
                    <div class="alert alert-warning">
                        <i class="ri-alert-line me-2"></i>
                        This action cannot be undone. All data associated with this user will be permanently removed.
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        <i class="ri-close-line me-1"></i> Cancel
                    </button>
                    <button type="submit" name="delete_user" class="btn btn-danger">
                        <i class="ri-delete-bin-line me-1"></i> Delete User
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
.user-management-container {
    max-width: 1400px;
    margin: 1rem auto;
    padding: 1rem;
    background: #ffffff;
    border-radius: 1rem;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
}

.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
    flex-wrap: wrap;
    gap: 1rem;
}

.avatar-circle {
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    color: white;
    font-weight: 600;
}

@media (max-width: 768px) {
    .user-management-container {
        margin: 0;
        padding: 1rem;
        border-radius: 0;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Handle Edit User Modal
    const editButtons = document.querySelectorAll('[data-bs-target="#editUserModal"]');
    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            try {
                const user = JSON.parse(this.dataset.user);
                document.getElementById('edit_user_id').value = user.id;
                document.getElementById('edit_first_name').value = user.first_name || '';
                document.getElementById('edit_last_name').value = user.last_name || '';
                document.getElementById('edit_email').value = user.email;
                document.getElementById('edit_mobile_number').value = user.mobile_number || '';
                document.getElementById('edit_user_type').value = user.user_type;
                document.getElementById('edit_account_status').value = user.account_status;
            } catch (e) {
                console.error("Error parsing user data:", e);
            }
        });
    });

    // Handle Delete User Modal
    const deleteButtons = document.querySelectorAll('[data-bs-target="#deleteUserModal"]');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function() {
            document.getElementById('delete_user_id').value = this.dataset.userId;
            document.getElementById('delete_user_name').textContent = this.dataset.userName;
        });
    });

    // Form Validation
    const forms = document.querySelectorAll('.needs-validation');
    forms.forEach(form => {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    });
});
</script>
