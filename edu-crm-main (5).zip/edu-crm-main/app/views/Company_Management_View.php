<?php
/**
 * Company Management View
 * Created on: 2025-01-16 00:54:53 UTC
 * Created by: farukdesk
 */

require_once __DIR__ . '/../../app/controllers/company_management_Controller.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);
// Initialize controller
$companyController = new CompanyManagementController($conn);

// Check permissions
if (!$companyController->hasPermission()) {
    header("Location: /dashboard.php");
    exit();
}
$result = $companyController->handleRequest();



$success = $error = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create_company'])) {
        $result = $companyController->createCompany($_POST);
        if ($result['status']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    } elseif (isset($_POST['update_company'])) {
        $result = $companyController->updateCompany($_POST);
        if ($result['status']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    } elseif (isset($_POST['delete_company'])) {
        $result = $companyController->deleteCompany($_POST['company_id']);
        if ($result['status']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    }
}

// Get filter parameters
$filters = [
    'search' => isset($_GET['search']) ? trim($_GET['search']) : '',
    'status' => isset($_GET['status']) ? trim($_GET['status']) : '',
    'subscription_status' => isset($_GET['subscription_status']) ? trim($_GET['subscription_status']) : '',
    'payment_status' => isset($_GET['payment_status']) ? trim($_GET['payment_status']) : '',
    'date_from' => isset($_GET['date_from']) ? trim($_GET['date_from']) : '',
    'date_to' => isset($_GET['date_to']) ? trim($_GET['date_to']) : ''
];

// Get current page
$page = isset($_GET['p']) ? max(1, (int)$_GET['p']) : 1;

// Get companies with filters and pagination
$result = $companyController->handleRequest();

// Debug information
error_log("Current Date and Time (UTC): " . date('Y-m-d H:i:s'));
error_log("Current User's Login: " . ($_SESSION['email'] ?? 'unknown'));
?>
<!-- Enhanced Styles -->
<style>
    :root {
        --primary-color: #4f46e5;
        --primary-hover: #4338ca;
        --success-color: #059669;
        --danger-color: #dc2626;
        --warning-color: #d97706;
        --background-color: #f3f4f6;
        --card-background: #ffffff;
        --text-color: #1f2937;
        --border-color: #e5e7eb;
    }

    .company-container {
        max-width: 1200px;
        margin: 1rem auto;
        padding: 1rem;
        background: var(--card-background);
        border-radius: 1rem;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    }

    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 2rem;
        flex-wrap: wrap;
        gap: 1rem;
    }

    .page-title {
        font-size: 1.5rem;
        font-weight: 600;
        color: var(--text-color);
        margin: 0;
    }

    .filters-section {
        background: var(--background-color);
        padding: 1.5rem;
        border-radius: 0.75rem;
        margin-bottom: 1.5rem;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
    }

    .status-badge {
        padding: 0.5rem 1rem;
        border-radius: 9999px;
        font-size: 0.875rem;
        font-weight: 500;
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
    }

    .status-active {
        background-color: #ecfdf5;
        color: var(--success-color);
    }

    .status-inactive {
        background-color: #fef2f2;
        color: var(--danger-color);
    }

    /* Responsive Table Styles */
    @media (max-width: 992px) {
        .table-responsive {
            display: block;
            width: 100%;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }
    }

    /* Mobile Optimizations */
    @media (max-width: 768px) {
        .company-container {
            margin: 0;
            padding: 1rem;
            border-radius: 0;
        }

        .page-header {
            flex-direction: column;
            align-items: stretch;
        }

        .filters-section form {
            gap: 1rem !important;
        }
    }
</style>

<div class="company-container">
    <!-- Page Header -->
    <div class="page-header">
        <h1 class="page-title">
            <i class="ri-building-2-line me-2"></i>
            Company Management
        </h1>
        <button type="button" 
                class="btn btn-custom btn-primary" 
                data-bs-toggle="modal" 
                data-bs-target="#addCompanyModal">
            <i class="ri-add-circle-line me-1"></i>
            Add New Company
        </button>
    </div>

    <!-- Alert Messages -->
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show d-flex align-items-center" role="alert">
            <i class="ri-checkbox-circle-line me-2"></i>
            <div class="flex-grow-1">
                <?php echo htmlspecialchars($success); ?>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show d-flex align-items-center" role="alert">
            <i class="ri-error-warning-line me-2"></i>
            <div class="flex-grow-1">
                <?php echo htmlspecialchars($error); ?>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Filters Section -->
    <div class="filters-section">
        <form method="GET" class="row g-3">
            <input type="hidden" name="page" value="company_management">
            
            <!-- Search Input -->
            <div class="col-md-4">
                <div class="form-floating">
                    <input type="text" 
                           class="form-control" 
                           name="search" 
                           id="search"
                           placeholder="Search companies..."
                           value="<?php echo htmlspecialchars($filters['search']); ?>">
                    <label for="search">
                        <i class="ri-search-line me-1"></i>
                        Search Companies
                    </label>
                </div>
            </div>

            <!-- Status Filter -->
            <div class="col-md-2">
                <div class="form-floating">
                    <select class="form-select" name="status" id="status">
                        <option value="">All Status</option>
                        <option value="Active" <?php echo $filters['status'] === 'Active' ? 'selected' : ''; ?>>Active</option>
                        <option value="Inactive" <?php echo $filters['status'] === 'Inactive' ? 'selected' : ''; ?>>Inactive</option>
                    </select>
                    <label for="status">Company Status</label>
                </div>
            </div>

            <!-- Subscription Status Filter -->
            <div class="col-md-2">
                <div class="form-floating">
                    <select class="form-select" name="subscription_status" id="subscription_status">
                        <option value="">All Subscriptions</option>
                        <option value="Active" <?php echo $filters['subscription_status'] === 'Active' ? 'selected' : ''; ?>>Active</option>
                        <option value="Expired" <?php echo $filters['subscription_status'] === 'Expired' ? 'selected' : ''; ?>>Expired</option>
                        <option value="Pending" <?php echo $filters['subscription_status'] === 'Pending' ? 'selected' : ''; ?>>Pending</option>
                    </select>
                    <label for="subscription_status">Subscription</label>
                </div>
            </div>

            <!-- Date Range Filters -->
            <div class="col-md-2">
                <div class="form-floating">
                    <input type="date" 
                           class="form-control" 
                           name="date_from" 
                           id="date_from"
                           value="<?php echo htmlspecialchars($filters['date_from']); ?>">
                    <label for="date_from">From Date</label>
                </div>
            </div>

            <div class="col-md-2">
                <div class="form-floating">
                    <input type="date" 
                           class="form-control" 
                           name="date_to" 
                           id="date_to"
                           value="<?php echo htmlspecialchars($filters['date_to']); ?>">
                    <label for="date_to">To Date</label>
                </div>
            </div>

            <!-- Filter Actions -->
            <div class="col-md-12 d-flex justify-content-end gap-2">
                <button type="submit" class="btn btn-custom btn-primary">
                    <i class="ri-filter-3-line me-1"></i>
                    Apply Filters
                </button>
                <a href="?page=company_management" 
                   class="btn btn-custom btn-outline-secondary" 
                   title="Reset Filters">
                    <i class="ri-refresh-line"></i>
                    Reset
                </a>
            </div>
        </form>
    </div>
    <!-- Stats Cards -->
<div class="row g-3 mb-4">
    <div class="col-md-3">
        <div class="card bg-light">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-subtitle mb-1 text-muted">Total Companies</h6>
                        <h3 class="card-title mb-0">
                            <?php echo number_format($result['stats']['total_companies'] ?? 0); ?>
                        </h3>
                    </div>
                    <div class="fs-1 text-primary">
                        <i class="ri-building-2-line"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-light">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-subtitle mb-1 text-muted">Active Companies</h6>
                        <h3 class="card-title mb-0">
                            <?php echo number_format($result['stats']['active_companies'] ?? 0); ?>
                        </h3>
                    </div>
                    <div class="fs-1 text-success">
                        <i class="ri-check-double-line"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-light">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-subtitle mb-1 text-muted">Total Staff</h6>
                        <h3 class="card-title mb-0">
                            <?php echo number_format($result['stats']['total_users'] ?? 0); ?>
                        </h3>
                    </div>
                    <div class="fs-1 text-info">
                        <i class="ri-team-line"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-light">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-subtitle mb-1 text-muted">Active Subscriptions</h6>
                        <h3 class="card-title mb-0">
                            <?php echo number_format($result['stats']['active_subscriptions'] ?? 0); ?>
                        </h3>
                    </div>
                    <div class="fs-1 text-warning">
                        <i class="ri-vip-crown-line"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Companies Table Section -->
<div class="table-section">
    <?php if (!empty($result['data'])): ?>
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th scope="col" class="text-center">#</th>
                        <th scope="col">Company Details</th>
                        <th scope="col" class="d-none d-md-table-cell">Contact Info</th>
                        <th scope="col" class="d-none d-lg-table-cell">Subscription</th>
                        <th scope="col" class="text-center">Staff</th>
                        <th scope="col" class="text-center">Status</th>
                        <th scope="col" class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($result['data'] as $company): ?>
                        <tr>
                            <!-- ID -->
                            <td class="text-center">
                                <span class="badge bg-light text-dark">
                                    <?php echo htmlspecialchars($company['id']); ?>
                                </span>
                            </td>

                            <!-- Company Details -->
                            <td>
                                <div class="d-flex align-items-center gap-2">
                                    <?php if (!empty($company['logo'])): ?>
                                        <img src="<?php echo htmlspecialchars($company['logo']); ?>" 
                                             alt="Company Logo" 
                                             class="rounded-circle"
                                             width="40" 
                                             height="40">
                                    <?php else: ?>
                                        <div class="rounded-circle bg-light d-flex align-items-center justify-content-center" 
                                             style="width: 40px; height: 40px;">
                                            <i class="ri-building-line text-muted"></i>
                                        </div>
                                    <?php endif; ?>
                                    <div>
                                        <strong class="company-name">
                                            <?php echo htmlspecialchars($company['company_name']); ?>
                                        </strong>
                                        <div class="text-muted small">
                                            Created: <?php echo date('M d, Y', strtotime($company['created_at'])); ?>
                                        </div>
                                    </div>
                                </div>
                            </td>

                            <!-- Contact Info -->
                            <td class="d-none d-md-table-cell">
                                <div class="contact-info">
                                    <div>
                                        <?php echo htmlspecialchars($company['contact_first_name'] . ' ' . $company['contact_last_name']); ?>
                                    </div>
                                    <div class="text-muted small">
                                        <i class="ri-mail-line me-1"></i>
                                        <?php echo htmlspecialchars($company['contact_email']); ?>
                                    </div>
                                    <div class="text-muted small">
                                        <i class="ri-phone-line me-1"></i>
                                        <?php echo htmlspecialchars($company['phone_number']); ?>
                                    </div>
                                </div>
                            </td>

                            <!-- Subscription Details -->
                            <td class="d-none d-lg-table-cell">
                                <?php if (!empty($company['subscription'])): ?>
                                    <div class="subscription-info">
                                        <div class="fw-medium">
                                            <?php echo htmlspecialchars($company['subscription']['plan_name']); ?>
                                        </div>
                                        <div class="text-muted small">
                                            Expires: <?php echo date('M d, Y', strtotime($company['subscription']['end_date'])); ?>
                                        </div>
                                        <span class="badge bg-<?php echo $company['subscription']['status'] === 'Active' ? 'success' : 'warning'; ?> rounded-pill">
                                            <?php echo htmlspecialchars($company['subscription']['status']); ?>
                                        </span>
                                    </div>
                                <?php else: ?>
                                    <span class="badge bg-secondary rounded-pill">No Subscription</span>
                                <?php endif; ?>
                            </td>

                            <!-- Staff Count -->
<td class="text-center">
    <div class="staff-count">
        <div class="fw-bold">
            <?php echo number_format($company['total_staff'] ?? 0); ?>
        </div>
        <?php if (!empty($company['total_staff'])): ?>
            <button type="button" 
                    class="btn btn-link btn-sm p-0 view-staff-details" 
                    data-bs-toggle="modal" 
                    data-bs-target="#staffDetailsModal"
                    data-company-id="<?php echo $company['id']; ?>"
                    data-distribution='<?php 
                        $distribution = json_decode($company['user_type_distribution'] ?? '{}', true) ?: [
                            'Admin' => 0,
                            'Counselor' => 0,
                            'Agent' => 0
                        ];
                        echo htmlspecialchars(json_encode($distribution), ENT_QUOTES, 'UTF-8');
                    ?>'>
                View Details
            </button>
        <?php endif; ?>
    </div>
</td>

                            <!-- Status -->
                            <td class="text-center">
                                <span class="status-badge status-<?php echo strtolower($company['status']); ?>">
                                    <i class="ri-<?php echo $company['status'] === 'Active' ? 'checkbox-circle' : 'close-circle'; ?>-line"></i>
                                    <?php echo htmlspecialchars($company['status']); ?>
                                </span>
                            </td>

                            <!-- Actions -->
                            <td class="text-end">
                                <div class="action-buttons">
                                    <button type="button" 
                                            class="btn btn-sm btn-outline-primary me-1" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#viewCompanyModal"
                                            data-company='<?php echo htmlspecialchars(json_encode($company)); ?>'
                                            title="View Details">
                                        <i class="ri-eye-line"></i>
                                    </button>
                                    <button type="button" 
                                            class="btn btn-sm btn-outline-info me-1" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#editCompanyModal"
                                            data-company='<?php echo htmlspecialchars(json_encode($company)); ?>'
                                            title="Edit Company">
                                        <i class="ri-edit-line"></i>
                                    </button>
                                    <button type="button" 
                                            class="btn btn-sm btn-outline-danger" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#deleteCompanyModal"
                                            data-company-id="<?php echo $company['id']; ?>"
                                            data-company-name="<?php echo htmlspecialchars($company['company_name']); ?>"
                                            title="Delete Company">
                                        <i class="ri-delete-bin-line"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <?php if ($result['pagination']['total'] > 1): ?>
            <!-- Pagination section will be added in the next part -->
        <?php endif; ?>

    <?php else: ?>
        <!-- No Results Found -->
        <div class="text-center py-5">
            <div class="no-data-icon mb-3">
                <i class="ri-building-2-line fs-1 text-muted"></i>
            </div>
            <h5 class="text-muted">No companies found</h5>
            <p class="text-muted small mb-3">
                <?php if (!empty($filters['search']) || !empty($filters['status']) || !empty($filters['subscription_status'])): ?>
                    Try adjusting your filters or
                <?php endif; ?>
                add a new company to get started
            </p>
            <button type="button" 
                    class="btn btn-primary" 
                    data-bs-toggle="modal" 
                    data-bs-target="#addCompanyModal">
                <i class="ri-add-line me-1"></i>
                Add New Company
            </button>
        </div>
    <?php endif; ?>
</div>
<!-- Pagination -->
<?php if ($result['pagination']['total'] > 1): ?>
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mt-4">
        <!-- Pagination Info -->
        <div class="pagination-info text-muted small">
            Showing 
            <strong><?php 
                $start = ($page - 1) * 10 + 1;
                echo $start;
            ?></strong> to 
            <strong><?php 
                $end = min($start + 9, $result['pagination']['total_records']);
                echo $end;
            ?></strong> of 
            <strong><?php echo $result['pagination']['total_records']; ?></strong> companies
        </div>

        <!-- Pagination Navigation -->
        <nav aria-label="Company navigation">
            <ul class="pagination pagination-md mb-0">
                <!-- Previous Page -->
                <?php if ($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" 
                           href="?page=company_management&p=<?php echo ($page - 1); ?>&<?php 
                                echo http_build_query(array_merge($filters, ['p' => ($page - 1)])); ?>" 
                           aria-label="Previous">
                            <i class="ri-arrow-left-s-line"></i>
                        </a>
                    </li>
                <?php endif; ?>

                <!-- Page Numbers -->
                <?php
                $totalPages = $result['pagination']['total'];
                $range = 2;
                
                for ($i = 1; $i <= $totalPages; $i++):
                    if ($i == 1 || $i == $totalPages || 
                        ($i >= $page - $range && $i <= $page + $range)):
                ?>
                    <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                        <a class="page-link" 
                           href="?page=company_management&p=<?php echo $i; ?>&<?php 
                                echo http_build_query(array_merge($filters, ['p' => $i])); ?>">
                            <?php echo $i; ?>
                        </a>
                    </li>
                <?php endif; endfor; ?>

                <!-- Next Page -->
                <?php if ($page < $totalPages): ?>
                    <li class="page-item">
                        <a class="page-link" 
                           href="?page=company_management&p=<?php echo ($page + 1); ?>&<?php 
                                echo http_build_query(array_merge($filters, ['p' => ($page + 1)])); ?>" 
                           aria-label="Next">
                            <i class="ri-arrow-right-s-line"></i>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
<?php endif; ?>

<!-- Add Company Modal -->
<div class="modal fade" id="addCompanyModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-light">
                <h5 class="modal-title">
                    <i class="ri-building-line me-2"></i>
                    Add New Company
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="row g-4">
                        <!-- Company Information -->
                        <div class="col-12">
                            <h6 class="mb-3">Company Information</h6>
                        </div>

                        <!-- Company Name -->
                        <div class="col-md-12">
                            <div class="form-floating">
                                <input type="text" 
                                       class="form-control" 
                                       name="company_name" 
                                       id="add_company_name"
                                       placeholder="Enter company name"
                                       required>
                                <label for="add_company_name">Company Name</label>
                                <div class="invalid-feedback">
                                    Please provide a company name.
                                </div>
                            </div>
                        </div>

                        <!-- Contact Information -->
                        <div class="col-12">
                            <h6 class="mb-3 mt-2">Contact Information</h6>
                        </div>

                        <!-- Contact First Name -->
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="text" 
                                       class="form-control" 
                                       name="contact_first_name" 
                                       id="add_contact_first_name"
                                       placeholder="Enter first name"
                                       required>
                                <label for="add_contact_first_name">Contact First Name</label>
                                <div class="invalid-feedback">
                                    Please provide a first name.
                                </div>
                            </div>
                        </div>

                        <!-- Contact Last Name -->
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="text" 
                                       class="form-control" 
                                       name="contact_last_name" 
                                       id="add_contact_last_name"
                                       placeholder="Enter last name"
                                       required>
                                <label for="add_contact_last_name">Contact Last Name</label>
                                <div class="invalid-feedback">
                                    Please provide a last name.
                                </div>
                            </div>
                        </div>

                        <!-- Phone Number -->
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="tel" 
                                       class="form-control" 
                                       name="phone_number" 
                                       id="add_phone_number"
                                       placeholder="Enter phone number"
                                       required>
                                <label for="add_phone_number">Phone Number</label>
                                <div class="invalid-feedback">
                                    Please provide a valid phone number.
                                </div>
                            </div>
                        </div>

                        <!-- Website URL -->
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="url" 
                                       class="form-control" 
                                       name="website_url" 
                                       id="add_website_url"
                                       placeholder="Enter website URL">
                                <label for="add_website_url">Website URL</label>
                                <div class="invalid-feedback">
                                    Please provide a valid URL.
                                </div>
                            </div>
                        </div>

                        <!-- Contact Email -->
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="email" 
                                       class="form-control" 
                                       name="contact_email" 
                                       id="add_contact_email"
                                       placeholder="Enter contact email"
                                       required>
                                <label for="add_contact_email">Contact Email</label>
                                <div class="invalid-feedback">
                                    Please provide a valid email address.
                                </div>
                            </div>
                        </div>

                        <!-- System Email -->
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="email" 
                                       class="form-control" 
                                       name="system_email" 
                                       id="add_system_email"
                                       placeholder="Enter system email"
                                       required>
                                <label for="add_system_email">System Email</label>
                                <div class="invalid-feedback">
                                    Please provide a valid system email.
                                </div>
                            </div>
                        </div>
                        <!-- Address -->
                        <div class="col-12">
                            <div class="form-floating">
                                <textarea class="form-control" 
                                          name="address" 
                                          id="add_address"
                                          placeholder="Enter address"
                                          style="height: 100px"
                                          required></textarea>
                                <label for="add_address">Company Address</label>
                                <div class="invalid-feedback">
                                    Please provide a company address.
                                </div>
                            </div>
                        </div>

                        <!-- Company Logo -->
                        <div class="col-12">
                            <div class="mb-3">
                                <label for="company_logo" class="form-label">Company Logo</label>
                                <input type="file" 
                                       class="form-control" 
                                       name="company_logo" 
                                       id="company_logo"
                                       accept="image/*">
                                <div class="form-text">
                                    Recommended size: 200x200px. Max file size: 2MB. Supported formats: JPG, PNG
                                </div>
                            </div>
                            <div id="logo_preview" class="text-center d-none mb-3">
                                <img src="" alt="Logo Preview" class="img-thumbnail" style="max-width: 200px;">
                            </div>
                        </div>

                        <!-- Subscription Information -->
                        <div class="col-12">
                            <h6 class="mb-3 mt-2">Subscription Details</h6>
                        </div>

                        <!-- Subscription Plan -->
                        <div class="col-md-6">
                            <div class="form-floating">
                                <select class="form-select" 
                                        name="subscription_plan_id" 
                                        id="add_subscription_plan"
                                        required>
                                    <option value="">Select subscription plan</option>
                                    <?php foreach ($subscriptionPlans as $plan): ?>
                                        <option value="<?php echo $plan['id']; ?>">
                                            <?php echo htmlspecialchars($plan['plan_name'] . ' - £' . number_format($plan['price'], 2)); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <label for="add_subscription_plan">Subscription Plan</label>
                                <div class="invalid-feedback">
                                    Please select a subscription plan.
                                </div>
                            </div>
                        </div>

                        <!-- Payment Method -->
                        <div class="col-md-6">
                            <div class="form-floating">
                                <select class="form-select" 
                                        name="payment_method" 
                                        id="add_payment_method"
                                        required>
                                    <option value="">Select payment method</option>
                                    <option value="Credit Card">Credit Card</option>
                                    <option value="Bank Transfer">Bank Transfer</option>
                                    <option value="PayPal">PayPal</option>
                                </select>
                                <label for="add_payment_method">Payment Method</label>
                                <div class="invalid-feedback">
                                    Please select a payment method.
                                </div>
                            </div>
                        </div>

                        <!-- Company Status -->
                        <div class="col-md-6">
                            <div class="form-floating">
                                <select class="form-select" 
                                        name="status" 
                                        id="add_status"
                                        required>
                                    <option value="">Select status</option>
                                    <option value="Active">Active</option>
                                    <option value="Inactive">Inactive</option>
                                </select>
                                <label for="add_status">Company Status</label>
                                <div class="invalid-feedback">
                                    Please select a status.
                                </div>
                            </div>
                        </div>

                        <!-- Notes -->
                        <div class="col-12">
                            <div class="form-floating">
                                <textarea class="form-control" 
                                          name="notes" 
                                          id="add_notes"
                                          placeholder="Enter notes"
                                          style="height: 100px"></textarea>
                                <label for="add_notes">Additional Notes</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" 
                            class="btn btn-outline-secondary" 
                            data-bs-dismiss="modal">
                        <i class="ri-close-line me-1"></i>
                        Cancel
                    </button>
                    <button type="submit" 
                            name="create_company" 
                            class="btn btn-primary">
                        <i class="ri-save-line me-1"></i>
                        Create Company
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Company Modal -->
<div class="modal fade" id="editCompanyModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-light">
                <h5 class="modal-title">
                    <i class="ri-edit-line me-2"></i>
                    Edit Company
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" class="needs-validation" novalidate enctype="multipart/form-data">
                <input type="hidden" name="company_id" id="edit_company_id">
                <div class="modal-body">
                    <!-- Current Logo Preview -->
                    <div class="text-center mb-4">
                        <div id="current_logo_preview">
                            <img src="" alt="Current Logo" class="img-thumbnail" style="max-width: 200px;">
                        </div>
                    </div>

                    <div class="row g-4">
                        <!-- Similar structure as Add Company Modal but with 'edit_' prefix for IDs -->
                        <!-- Will be populated with JavaScript when modal opens -->
                        
                        <!-- Company Information -->
                        <div class="col-12">
                            <h6 class="mb-3">Company Information</h6>
                        </div>

                        <!-- Company Name -->
                        <div class="col-md-12">
                            <div class="form-floating">
                                <input type="text" 
                                       class="form-control" 
                                       name="company_name" 
                                       id="edit_company_name"
                                       placeholder="Enter company name"
                                       required>
                                <label for="edit_company_name">Company Name</label>
                                <div class="invalid-feedback">
                                    Please provide a company name.
                                </div>
                            </div>
                        </div>

<!-- Contact Information -->
                        <div class="col-12">
                            <h6 class="mb-3 mt-2">Contact Information</h6>
                        </div>

                        <!-- Contact First Name -->
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="text" 
                                       class="form-control" 
                                       name="contact_first_name" 
                                       id="edit_contact_first_name"
                                       placeholder="Enter first name"
                                       required>
                                <label for="edit_contact_first_name">Contact First Name</label>
                                <div class="invalid-feedback">
                                    Please provide a first name.
                                </div>
                            </div>
                        </div>

                        <!-- Contact Last Name -->
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="text" 
                                       class="form-control" 
                                       name="contact_last_name" 
                                       id="edit_contact_last_name"
                                       placeholder="Enter last name"
                                       required>
                                <label for="edit_contact_last_name">Contact Last Name</label>
                                <div class="invalid-feedback">
                                    Please provide a last name.
                                </div>
                            </div>
                        </div>

                        <!-- Contact Information Fields -->
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="tel" 
                                       class="form-control" 
                                       name="phone_number" 
                                       id="edit_phone_number"
                                       required>
                                <label for="edit_phone_number">Phone Number</label>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="url" 
                                       class="form-control" 
                                       name="website_url" 
                                       id="edit_website_url">
                                <label for="edit_website_url">Website URL</label>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="email" 
                                       class="form-control" 
                                       name="contact_email" 
                                       id="edit_contact_email"
                                       required>
                                <label for="edit_contact_email">Contact Email</label>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="email" 
                                       class="form-control" 
                                       name="system_email" 
                                       id="edit_system_email"
                                       required>
                                <label for="edit_system_email">System Email</label>
                            </div>
                        </div>

                        <!-- Address -->
                        <div class="col-12">
                            <div class="form-floating">
                                <textarea class="form-control" 
                                          name="address" 
                                          id="edit_address"
                                          style="height: 100px"
                                          required></textarea>
                                <label for="edit_address">Company Address</label>
                            </div>
                        </div>

                        <!-- Company Logo -->
                        <div class="col-12">
                            <div class="mb-3">
                                <label for="edit_company_logo" class="form-label">Update Company Logo</label>
                                <input type="file" 
                                       class="form-control" 
                                       name="company_logo" 
                                       id="edit_company_logo"
                                       accept="image/*">
                                <div class="form-text">Leave empty to keep current logo</div>
                            </div>
                        </div>

                        <!-- Subscription Information -->
                        <div class="col-12">
                            <h6 class="mb-3">Subscription Information</h6>
                        </div>

                        <div class="col-md-6">
                            <div class="form-floating">
                                <select class="form-select" 
                                        name="subscription_plan_id" 
                                        id="edit_subscription_plan">
                                    <option value="">Select subscription plan</option>
                                    <?php foreach ($subscriptionPlans as $plan): ?>
                                        <option value="<?php echo $plan['id']; ?>">
                                            <?php echo htmlspecialchars($plan['plan_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <label for="edit_subscription_plan">Subscription Plan</label>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-floating">
                                <select class="form-select" 
                                        name="status" 
                                        id="edit_status"
                                        required>
                                    <option value="Active">Active</option>
                                    <option value="Inactive">Inactive</option>
                                </select>
                                <label for="edit_status">Company Status</label>
                            </div>
                        </div>

                        <!-- Notes -->
                        <div class="col-12">
                            <div class="form-floating">
                                <textarea class="form-control" 
                                          name="notes" 
                                          id="edit_notes"
                                          style="height: 100px"></textarea>
                                <label for="edit_notes">Additional Notes</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" 
                            class="btn btn-outline-secondary" 
                            data-bs-dismiss="modal">
                        <i class="ri-close-line me-1"></i>
                        Cancel
                    </button>
                    <button type="submit" 
                            name="update_company" 
                            class="btn btn-primary">
                        <i class="ri-save-line me-1"></i>
                        Update Company
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- View Company Modal -->
<div class="modal fade" id="viewCompanyModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-light">
                <h5 class="modal-title">
                    <i class="ri-building-line me-2"></i>
                    Company Details
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="text-center mb-4">
                    <div id="view_logo_container" class="mb-3">
                        <!-- Logo will be inserted here -->
                    </div>
                    <h4 id="view_company_name" class="mb-0"></h4>
                    <p class="text-muted" id="view_company_id"></p>
                </div>

                <!-- Company Information -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h6 class="mb-0">Company Information</h6>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <!-- Will be populated with JavaScript -->
                        </div>
                    </div>
                </div>

                <!-- Contact Information -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h6 class="mb-0">Contact Information</h6>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <!-- Will be populated with JavaScript -->
                        </div>
                    </div>
                </div>

                <!-- Subscription Details -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h6 class="mb-0">Subscription Details</h6>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <!-- Will be populated with JavaScript -->
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer bg-light">
                <button type="button" 
                        class="btn btn-outline-secondary" 
                        data-bs-dismiss="modal">
                    <i class="ri-close-line me-1"></i>
                    Close
                </button>
                <button type="button" 
                        class="btn btn-primary edit-from-view"
                        data-bs-toggle="modal" 
                        data-bs-target="#editCompanyModal">
                    <i class="ri-edit-line me-1"></i>
                    Edit Company
                </button>
            </div>
        </div>
    </div>
</div>
<!-- Delete Company Modal -->
<div class="modal fade" id="deleteCompanyModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">
                    <i class="ri-delete-bin-line me-2"></i>
                    Delete Company
                </h5>
                <button type="button" 
                        class="btn-close btn-close-white" 
                        data-bs-dismiss="modal" 
                        aria-label="Close"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="company_id" id="delete_company_id">
                <div class="modal-body">
                    <div class="text-center mb-4">
                        <i class="ri-error-warning-line text-danger fs-1"></i>
                        <h5 class="mt-3">Are you sure you want to delete this company?</h5>
                        <p class="text-muted mb-0">Company Name: <strong id="delete_company_name"></strong></p>
                    </div>
                    <div class="alert alert-warning">
                        <i class="ri-alert-line me-2"></i>
                        This action cannot be undone. All associated data will be permanently removed:
                        <ul class="mb-0 mt-2">
                            <li>Company profile and settings</li>
                            <li>All user accounts associated with this company</li>
                            <li>Subscription and payment history</li>
                            <li>All related documents and data</li>
                        </ul>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" 
                            class="btn btn-outline-secondary" 
                            data-bs-dismiss="modal">
                        <i class="ri-close-line me-1"></i>
                        Cancel
                    </button>
                    <button type="submit" 
                            name="delete_company" 
                            class="btn btn-danger">
                        <i class="ri-delete-bin-line me-1"></i>
                        Delete Company
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Staff Details Modal -->
<div class="modal fade" id="staffDetailsModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-light">
                <h5 class="modal-title">
                    <i class="ri-team-line me-2"></i>
                    Staff Distribution
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="staff_distribution_chart" style="height: 300px;"></div>
                <div class="staff-stats mt-4">
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>User Type</th>
                                    <th class="text-center">Count</th>
                                    <th class="text-end">Percentage</th>
                                </tr>
                            </thead>
                            <tbody id="staff_distribution_table">
                                <!-- Will be populated by JavaScript -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Bootstrap tooltips
    const tooltips = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    tooltips.forEach(tooltip => new bootstrap.Tooltip(tooltip));

    // Logo Preview Handler
    function handleLogoPreview(input, previewId) {
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            const preview = document.getElementById(previewId);
            
            reader.onload = function(e) {
                preview.classList.remove('d-none');
                preview.querySelector('img').src = e.target.result;
            };
            
            reader.readAsDataURL(input.files[0]);
        }
    }

    // Add logo preview handlers
    document.getElementById('company_logo')?.addEventListener('change', function() {
        handleLogoPreview(this, 'logo_preview');
    });

    document.getElementById('edit_company_logo')?.addEventListener('change', function() {
        handleLogoPreview(this, 'current_logo_preview');
    });

    // Handle Edit Company Modal
    const editButtons = document.querySelectorAll('.edit-plan');
    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            const company = JSON.parse(this.dataset.company);
            populateEditForm(company);
        });
    });

    function populateEditForm(company) {
        // Populate form fields
        document.getElementById('edit_company_id').value = company.id;
        document.getElementById('edit_company_name').value = company.company_name;
        document.getElementById('edit_contact_first_name').value = company.contact_first_name;
        document.getElementById('edit_contact_last_name').value = company.contact_last_name;
        document.getElementById('edit_phone_number').value = company.phone_number;
        document.getElementById('edit_website_url').value = company.website_url;
        document.getElementById('edit_contact_email').value = company.contact_email;
        document.getElementById('edit_system_email').value = company.system_email;
        document.getElementById('edit_address').value = company.address;
        document.getElementById('edit_status').value = company.status;

        // Show current logo if exists
        const logoPreview = document.getElementById('current_logo_preview');
        if (company.logo) {
            logoPreview.querySelector('img').src = company.logo;
            logoPreview.classList.remove('d-none');
        } else {
            logoPreview.classList.add('d-none');
        }

        // Set subscription plan if exists
        if (company.subscription && company.subscription.plan_id) {
            document.getElementById('edit_subscription_plan').value = company.subscription.plan_id;
        }
    }

    // Handle View Company Modal
    const viewButtons = document.querySelectorAll('[data-bs-target="#viewCompanyModal"]');
    viewButtons.forEach(button => {
        button.addEventListener('click', function() {
            const company = JSON.parse(this.dataset.company);
            populateViewModal(company);
        });
    });

    function populateViewModal(company) {
        // Company Logo
        const logoContainer = document.getElementById('view_logo_container');
        logoContainer.innerHTML = company.logo 
            ? `<img src="${company.logo}" alt="Company Logo" class="img-thumbnail" style="max-width: 200px;">` 
            : `<div class="rounded-circle bg-light d-flex align-items-center justify-content-center" 
                   style="width: 100px; height: 100px; margin: 0 auto;">
                   <i class="ri-building-line fs-1 text-muted"></i>
               </div>`;

        // Company Name and ID
        document.getElementById('view_company_name').textContent = company.company_name;
        document.getElementById('view_company_id').textContent = `Company ID: ${company.id}`;

        // Populate company information sections
        const sections = {
            'Company Information': {
                'Status': `<span class="badge bg-${company.status === 'Active' ? 'success' : 'danger'}">${company.status}</span>`,
                'Created At': new Date(company.created_at).toLocaleDateString('en-GB', {
                    day: '2-digit',
                    month: 'short',
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                }),
                'Created By': company.created_by_name || 'System'
            },
            'Contact Information': {
                'Contact Person': `${company.contact_first_name} ${company.contact_last_name}`,
                'Phone Number': company.phone_number,
                'Website': company.website_url ? `<a href="${company.website_url}" target="_blank">${company.website_url}</a>` : 'N/A',
                'Contact Email': company.contact_email,
                'System Email': company.system_email,
                'Address': company.address
            }
        };

        // Populate each section
        Object.entries(sections).forEach(([sectionTitle, data]) => {
            const section = document.querySelector(`#viewCompanyModal .card:contains('${sectionTitle}') .card-body .row`);
            if (section) {
                section.innerHTML = Object.entries(data).map(([key, value]) => `
                    <div class="col-sm-6">
                        <p class="mb-1 text-muted small">${key}</p>
                        <p class="mb-3">${value}</p>
                    </div>
                `).join('');
            }
        });
    }
    // Staff Distribution Chart Handler
    let staffChart = null;
    function handleStaffDistribution(distribution) {
        const ctx = document.getElementById('staff_distribution_chart').getContext('2d');
        const labels = Object.keys(distribution);
        const data = Object.values(distribution);
        const total = data.reduce((a, b) => a + b, 0);

        // Destroy existing chart if it exists
        if (staffChart) {
            staffChart.destroy();
        }

        // Create new chart
        staffChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: data,
                    backgroundColor: [
                        '#4f46e5', // Primary
                        '#059669', // Success
                        '#dc2626', // Danger
                        '#d97706', // Warning
                        '#6366f1', // Indigo
                        '#8b5cf6'  // Purple
                    ],
                    borderWidth: 2,
                    borderColor: '#ffffff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            boxWidth: 12
                        }
                    }
                },
                cutout: '70%',
                animation: {
                    animateScale: true,
                    animateRotate: true
                }
            }
        });

        // Update table
        const tableBody = document.getElementById('staff_distribution_table');
        tableBody.innerHTML = Object.entries(distribution)
            .map(([type, count]) => `
                <tr>
                    <td>${type}</td>
                    <td class="text-center">${count}</td>
                    <td class="text-end">${((count / total) * 100).toFixed(1)}%</td>
                </tr>
            `).join('');
    }

    // Form Validation
    const forms = document.querySelectorAll('.needs-validation');
    forms.forEach(form => {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            } else {
                showLoading();
            }
            form.classList.add('was-validated');
        });
    });

    // Loading Spinner Functions
    function showLoading() {
        document.querySelector('.spinner-overlay').style.display = 'flex';
    }

    function hideLoading() {
        document.querySelector('.spinner-overlay').style.display = 'none';
    }

    // Handle Delete Company
    const deleteButtons = document.querySelectorAll('[data-bs-target="#deleteCompanyModal"]');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function() {
            const companyId = this.dataset.companyId;
            const companyName = this.dataset.companyName;
            
            document.getElementById('delete_company_id').value = companyId;
            document.getElementById('delete_company_name').textContent = companyName;
        });
    });

    // Handle Staff Details Modal
    const staffDetailsButtons = document.querySelectorAll('.view-staff-details');
    staffDetailsButtons.forEach(button => {
        button.addEventListener('click', function() {
            const distribution = JSON.parse(this.dataset.distribution);
            handleStaffDistribution(distribution);
        });
    });

    // AJAX Form Submission
    function submitFormAsync(formElement, successCallback) {
        formElement.addEventListener('submit', function(e) {
            e.preventDefault();
            
            if (!this.checkValidity()) {
                this.classList.add('was-validated');
                return;
            }

            showLoading();
            const formData = new FormData(this);

            fetch(window.location.href, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                hideLoading();
                if (data.status) {
                    showAlert('success', data.message);
                    if (successCallback) successCallback(data);
                    bootstrap.Modal.getInstance(formElement.closest('.modal')).hide();
                } else {
                    showAlert('danger', data.message);
                }
            })
            .catch(error => {
                hideLoading();
                showAlert('danger', 'An error occurred. Please try again.');
                console.error('Error:', error);
            });
        });
    }

    // Alert Handler
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });

    // Handle Delete Company Modal
    const deleteButtons = document.querySelectorAll('[data-bs-target="#deleteCompanyModal"]');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function() {
            document.getElementById('delete_company_id').value = this.dataset.companyId;
            document.getElementById('delete_company_name').textContent = this.dataset.companyName;
        });
    });

    // Staff Distribution Chart Handler
    const staffDetailsButtons = document.querySelectorAll('.view-staff-details');
    staffDetailsButtons.forEach(button => {
        button.addEventListener('click', function() {
            const distribution = JSON.parse(this.dataset.distribution);
            renderStaffDistribution(distribution);
        });
    });

    function renderStaffDistribution(distribution) {
        // Calculate total staff
        const total = Object.values(distribution).reduce((a, b) => a + b, 0);
        
        // Prepare data for chart and table
        const data = Object.entries(distribution).map(([type, count]) => ({
            type,
            count,
            percentage: ((count / total) * 100).toFixed(1)
        }));

        // Render table
        const tableBody = document.getElementById('staff_distribution_table');
        tableBody.innerHTML = data.map(item => `
            <tr>
                <td>${item.type}</td>
                <td class="text-center">${item.count}</td>
                <td class="text-end">${item.percentage}%</td>
            </tr>
        `).join('') + `
        <tr class="table-light fw-bold">
            <td>Total</td>
            <td class="text-center">${total}</td>
            <td class="text-end">100%</td>
        </tr>`;

        // Render chart using ApexCharts
        const chartOptions = {
            series: data.map(item => item.count),
            chart: {
                type: 'donut',
                height: 300
            },
            labels: data.map(item => item.type),
            colors: ['#4f46e5', '#059669', '#dc2626', '#d97706', '#6366f1'],
            plotOptions: {
                pie: {
                    donut: {
                        size: '65%'
                    }
                }
            },
            legend: {
                position: 'bottom'
            },
            responsive: [{
                breakpoint: 480,
                options: {
                    chart: {
                        height: 250
                    },
                    legend: {
                        position: 'bottom'
                    }
                }
            }]
        };

        const chart = new ApexCharts(document.querySelector("#staff_distribution_chart"), chartOptions);
        chart.render();
    }

    // Form Validation Handler
    const forms = document.querySelectorAll('.needs-validation');
    forms.forEach(form => {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            } else {
                showLoading();
            }
            form.classList.add('was-validated');
        });
    });

    // Loading Spinner Handler
    function showLoading() {
        document.querySelector('.spinner-overlay').style.display = 'flex';
    }

    function hideLoading() {
        document.querySelector('.spinner-overlay').style.display = 'none';
    }

    // Phone Number Formatter
    const phoneInputs = document.querySelectorAll('input[type="tel"]');
    phoneInputs.forEach(input => {
        input.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length > 0) {
                if (value.length <= 3) {
                    value = value;
                } else if (value.length <= 6) {
                    value = value.slice(0, 3) + '-' + value.slice(3);
                } else {
                    value = value.slice(0, 3) + '-' + value.slice(3, 6) + '-' + value.slice(6, 10);
                }
                e.target.value = value;
            }
        });
    });

    // Handle File Size Validation
    const MAX_FILE_SIZE = 2 * 1024 * 1024; // 2MB
    const logoInputs = document.querySelectorAll('input[type="file"]');
    logoInputs.forEach(input => {
        input.addEventListener('change', function() {
            if (this.files[0] && this.files[0].size > MAX_FILE_SIZE) {
                alert('File size must be less than 2MB');
                this.value = '';
                return false;
            }
        });
    });

    // Handle Edit from View Modal
    const editFromViewButtons = document.querySelectorAll('.edit-from-view');
    editFromViewButtons.forEach(button => {
        button.addEventListener('click', function() {
            const viewModal = bootstrap.Modal.getInstance(document.getElementById('viewCompanyModal'));
            viewModal.hide();
        });
    });

    // Dynamic Search Handler
    const searchInput = document.getElementById('search');
    let searchTimeout;
    searchInput?.addEventListener('input', function() {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            document.querySelector('form').submit();
        }, 500);
    });

    // Handle Filter Changes
    const filterInputs = document.querySelectorAll('.filters-section select, .filters-section input[type="date"]');
    filterInputs.forEach(input => {
        input.addEventListener('change', function() {
            document.querySelector('form').submit();
        });
    });

    // Refresh Data Periodically
    function refreshData() {
        fetch(window.location.href)
            .then(response => response.text())
            .then(html => {
                const parser = new DOMParser();
                const doc = parser.parseFromString(html, 'text/html');
                const newTable = doc.querySelector('.table-section');
                const currentTable = document.querySelector('.table-section');
                if (newTable && currentTable) {
                    currentTable.innerHTML = newTable.innerHTML;
                }
            })
            .catch(error => console.error('Error refreshing data:', error));
    }

    // Refresh every 5 minutes
    setInterval(refreshData, 300000);

    // Handle Modal Focus
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        modal.addEventListener('shown.bs.modal', function() {
            modal.querySelector('input, select, textarea')?.focus();
        });
    });

    // Debug Information
    console.log('Page loaded at:', new Date().toISOString());
    console.log('Current user:', '<?php echo $_SESSION['email'] ?? 'unknown'; ?>');
});
document.addEventListener('DOMContentLoaded', function() {
    // Staff Distribution Chart Handler
    let staffChart = null;
    const staffDetailsButtons = document.querySelectorAll('.view-staff-details');
    
    staffDetailsButtons.forEach(button => {
        button.addEventListener('click', function() {
            try {
                const distribution = JSON.parse(this.dataset.distribution);
                renderStaffDistribution(distribution);
            } catch (e) {
                console.error('Error parsing staff distribution:', e);
            }
        });
    });

    function renderStaffDistribution(distribution) {
        // Clean up previous chart if it exists
        if (staffChart) {
            staffChart.destroy();
        }

        const chartElement = document.querySelector("#staff_distribution_chart");
        if (!chartElement) return;

        // Calculate total
        const total = Object.values(distribution).reduce((a, b) => a + b, 0);
        
        // Prepare data
        const series = Object.values(distribution);
        const labels = Object.keys(distribution);

        // Chart options
        const options = {
            series: series,
            chart: {
                type: 'donut',
                height: 300
            },
            labels: labels,
            colors: ['#4f46e5', '#059669', '#dc2626', '#d97706', '#6366f1'],
            plotOptions: {
                pie: {
                    donut: {
                        size: '65%'
                    }
                }
            },
            legend: {
                position: 'bottom'
            }
        };

        // Create new chart
        staffChart = new ApexCharts(chartElement, options);
        staffChart.render();

        // Update table
        const tableBody = document.getElementById('staff_distribution_table');
        if (tableBody) {
            tableBody.innerHTML = Object.entries(distribution)
                .map(([type, count]) => `
                    <tr>
                        <td>${type}</td>
                        <td class="text-center">${count}</td>
                        <td class="text-end">${((count / total) * 100).toFixed(1)}%</td>
                    </tr>
                `).join('') + `
                <tr class="table-light fw-bold">
                    <td>Total</td>
                    <td class="text-center">${total}</td>
                    <td class="text-end">100%</td>
                </tr>`;
        }
    }
});
</script>

<!-- Additional Styles for Animations -->
<style>
    .modal.fade .modal-dialog {
        transform: scale(0.95);
        transition: transform 0.2s ease-out;
    }

    .modal.show .modal-dialog {
        transform: scale(1);
    }

    .card {
        transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
    }

    .card:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    }

    .status-badge {
        transition: all 0.2s ease-in-out;
    }

    .status-badge:hover {
        transform: scale(1.05);
    }

    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }

    .table-responsive {
        animation: fadeIn 0.3s ease-out;
    }

    @keyframes slideIn {
        from { transform: translateY(-10px); opacity: 0; }
        to { transform: translateY(0); opacity: 1; }
    }

    .alert {
        animation: slideIn 0.3s ease-out;
    }
</style>