<?php
/**
 * Campus Visits View
 * Created on: 2025-05-05
 * Updated on: 2025-05-05 20:01:22
 * Created by: farukdesk
 */

require_once __DIR__ . '/../../app/controllers/campus_visits_controller.php';

// Initialize controller
$officeVisitsController = new CampusVisitsController($conn);

// Check permissions
if (!$officeVisitsController->hasPermission()) {
    header("Location: /dashboard.php");
    exit();
}

// Handle form submissions
$success = $error = '';

// Get data from controller
$result = $officeVisitsController->handleRequest();

// Get the visits data
$visits = $result['visits'] ?? [];
$stats = $result['stats'] ?? [];

// Get filters and pagination
$filters = $result['filters'] ?? [];
$pagination = $result['pagination'] ?? [];

// Get success and error messages
$success = $result['success'] ?? '';
$error = $result['error'] ?? '';

// Get current date
$currentDate = date('Y-m-d');

// Debug logging
error_log('Rendering campus_visits_view with ' . count($visits) . ' visits');
error_log('Success message: ' . $success);
error_log('Error message: ' . $error);

// Add this check for POST submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mark_attended'])) {
    // This is a fallback in case the controller redirect didn't work
    echo '<script>
        window.onload = function() {
            window.location.href = window.location.pathname + "?page=campus_visits_view";
        }
    </script>';
}
?>

<div class="office-visits-container">
    <!-- Page Header -->
    <div class="page-header">
        <div>
            <h1 class="page-title">
                <i class="ri-calendar-check-line me-2"></i>
                Campus Visits
            </h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/dashboard.php">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Campus Visits</li>
                </ol>
            </nav>
        </div>
        
        <div class="d-flex gap-2">
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#filterModal">
                <i class="ri-filter-3-line me-1"></i>
                Filter Visits
            </button>
            
            <?php if (isset($filters) && !empty(array_filter($filters))): ?>
            <a href="?page=campus_visits_view" class="btn btn-outline-secondary">
                <i class="ri-refresh-line me-1"></i>
                Reset Filters
            </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Alert Messages -->
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show d-flex align-items-center" role="alert">
            <i class="ri-checkbox-circle-line me-2"></i>
            <div class="flex-grow-1">
                <?php echo htmlspecialchars($success); ?>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show d-flex align-items-center" role="alert">
            <i class="ri-error-warning-line me-2"></i>
            <div class="flex-grow-1">
                <?php echo htmlspecialchars($error); ?>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Stats Cards -->
    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-subtitle mb-1 text-muted">Today's Visits</h6>
                            <h3 class="card-title mb-0">
                                <?php echo number_format($stats['today_visits'] ?? 0); ?>
                            </h3>
                        </div>
                        <div class="fs-1 text-primary">
                            <i class="ri-calendar-event-line"></i>
                        </div>
                    </div>
                    
                    <?php if (($stats['today_visits'] ?? 0) > 0): ?>
                    <div class="mt-2">
                        <a href="?page=campus_visits_view&date=<?php echo date('Y-m-d'); ?>" class="btn btn-sm btn-outline-primary">
                            <i class="ri-eye-line me-1"></i>
                            View Today's Visits
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-subtitle mb-1 text-muted">This Week's Visits</h6>
                            <h3 class="card-title mb-0">
                                <?php echo number_format($stats['week_visits'] ?? 0); ?>
                            </h3>
                            <small class="text-muted mt-1 d-block">
                                <?php echo date('M j', strtotime('monday this week')); ?> - 
                                <?php echo date('M j', strtotime('sunday this week')); ?>
                            </small>
                        </div>
                        <div class="fs-1 text-info">
                            <i class="ri-calendar-todo-line"></i>
                        </div>
                    </div>
                    
                    <?php if (($stats['week_visits'] ?? 0) > 0): ?>
                    <div class="mt-2">
                        <a href="?page=campus_visits_view&date_from=<?php echo date('Y-m-d', strtotime('monday this week')); ?>&date_to=<?php echo date('Y-m-d', strtotime('sunday this week')); ?>" class="btn btn-sm btn-outline-info">
                            <i class="ri-eye-line me-1"></i>
                            View This Week's Visits
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-subtitle mb-1 text-muted">This Month's Visits</h6>
                            <h3 class="card-title mb-0">
                                <?php echo number_format($stats['month_visits'] ?? 0); ?>
                            </h3>
                            <small class="text-muted mt-1 d-block">
                                <?php echo date('M Y'); ?>
                            </small>
                        </div>
                        <div class="fs-1 text-success">
                            <i class="ri-calendar-check-line"></i>
                        </div>
                    </div>
                    
                    <?php if (($stats['month_visits'] ?? 0) > 0): ?>
                    <div class="mt-2">
                        <a href="?page=campus_visits_view&date_from=<?php echo date('Y-m-01'); ?>&date_to=<?php echo date('Y-m-t'); ?>" class="btn btn-sm btn-outline-success">
                            <i class="ri-eye-line me-1"></i>
                            View This Month's Visits
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Visit Schedule -->
    <div class="card mb-4">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0">
                <i class="ri-calendar-check-line me-2"></i>
                Campus Visit Schedule
            </h5>
            
            <div>
                <span class="badge bg-primary">
                    <?php echo !empty($filters) ? 'Filtered Results' : 'All Upcoming Visits'; ?>
                </span>
            </div>
        </div>
        
        <div class="card-body p-0">
            <?php if (!empty($visits)): ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th scope="col">Visit Date & Time</th>
                                <th scope="col">Lead</th>
                                <th scope="col">Contact Info</th>
                                <th scope="col">Interests</th>
                                <th scope="col">Assigned Staff</th>
                                <th scope="col" class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($visits as $visit): ?>
                                <?php 
                                    // Check if visit is today
                                    $isToday = date('Y-m-d', strtotime($visit['campus_visit_date'])) === $currentDate;
                                    
                                    // Check if visit is upcoming or past
                                    $isPast = strtotime($visit['campus_visit_date']) < time();
                                    
                                    // Check if visit has been attended
                                    $hasAttended = !empty($visit['attended_at']);
                                    
                                    // Row class based on date and attendance
                                    $rowClass = '';
                                    if ($hasAttended) {
                                        $rowClass = 'table-success bg-opacity-25';
                                    } elseif ($isToday) {
                                        $rowClass = 'table-primary';
                                    } elseif ($isPast) {
                                        $rowClass = 'table-light';
                                    }
                                ?>
                                <tr class="<?php echo $rowClass; ?>">
                                    <td width="180">
                                        <div class="d-flex align-items-center">
                                            <?php if ($hasAttended): ?>
                                                <span class="badge bg-success me-2">
                                                    <i class="ri-check-double-line me-1"></i>
                                                    Attended
                                                </span>
                                            <?php elseif ($isToday): ?>
                                                <span class="badge bg-primary me-2">Today</span>
                                            <?php elseif ($isPast): ?>
                                                <span class="badge bg-secondary me-2">Past</span>
                                            <?php else: ?>
                                                <span class="badge bg-info me-2">Upcoming</span>
                                            <?php endif; ?>
                                            <div>
                                                <div class="fw-medium"><?php echo date('M j, Y', strtotime($visit['campus_visit_date'])); ?></div>
                                                <div class="text-muted small"><?php echo date('g:i A', strtotime($visit['campus_visit_date'])); ?></div>
                                            </div>
                                        </div>
                                        
                                        <?php if ($isToday && !$hasAttended): ?>
                                            <div class="text-primary small mt-1">
                                                <i class="ri-time-line me-1"></i>
                                                <?php 
                                                    $timeDiff = strtotime($visit['campus_visit_date']) - time();
                                                    if ($timeDiff > 0) {
                                                        $hours = floor($timeDiff / 3600);
                                                        $minutes = floor(($timeDiff % 3600) / 60);
                                                        echo "In " . ($hours > 0 ? $hours . "h " : "") . $minutes . "m";
                                                    } else {
                                                        $hours = floor(abs($timeDiff) / 3600);
                                                        $minutes = floor((abs($timeDiff) % 3600) / 60);
                                                        echo ($hours > 0 ? $hours . "h " : "") . $minutes . "m ago";
                                                    }
                                                ?>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <?php if ($hasAttended): ?>
                                            <div class="text-success small mt-1">
                                                <i class="ri-calendar-check-line me-1"></i>
                                                Attended on: <?php echo date('M j, Y g:i A', strtotime($visit['attended_at'])); ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="avatar-circle avatar-sm bg-primary me-2">
                                                <span><?php echo strtoupper(substr($visit['first_name'], 0, 1) . substr($visit['last_name'], 0, 1)); ?></span>
                                            </div>
                                            <div>
                                                <div class="fw-medium"><?php echo htmlspecialchars($visit['first_name'] . ' ' . $visit['last_name']); ?></div>
                                                <?php if (!empty($visit['country_applying_from'])): ?>
                                                    <div class="text-muted small">From: <?php echo htmlspecialchars($visit['country_applying_from']); ?></div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div>
                                            <div><i class="ri-mail-line me-1 text-muted"></i> <?php echo htmlspecialchars($visit['email']); ?></div>
                                            <div><i class="ri-phone-line me-1 text-muted"></i> <?php echo htmlspecialchars($visit['phone']); ?></div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="interests-column">
                                            <?php 
                                            $interestCount = count($visit['universities'] ?? []) + count($visit['courses'] ?? []) + count($visit['intakes'] ?? []);
                                            $hasUniversities = !empty($visit['universities']);
                                            $hasCourses = !empty($visit['courses']);
                                            $hasIntakes = !empty($visit['intakes']);
                                            ?>
                                            <?php if ($interestCount === 0): ?>
                                                <span class="text-muted"><i class="ri-information-line me-1"></i> No interests specified</span>
                                            <?php else: ?>
                                                <div class="interest-tags">
                                                    <?php if ($hasUniversities && isset($visit['universities'][0])): ?>
                                                        <span class="interest-tag">
                                                            <i class="ri-building-line me-1"></i>
                                                            <?php echo htmlspecialchars($visit['universities'][0]['university_name']); ?>
                                                        </span>
                                                        <?php if (count($visit['universities']) > 1): ?>
                                                            <span class="badge rounded-pill bg-light text-dark">
                                                                +<?php echo count($visit['universities']) - 1; ?> more
                                                            </span>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                    
                                                    <?php if ($hasCourses && isset($visit['courses'][0])): ?>
                                                        <span class="interest-tag">
                                                            <i class="ri-book-open-line me-1"></i>
                                                            <?php echo htmlspecialchars($visit['courses'][0]['course_title']); ?>
                                                        </span>
                                                        <?php if (count($visit['courses']) > 1): ?>
                                                            <span class="badge rounded-pill bg-light text-dark">
                                                                +<?php echo count($visit['courses']) - 1; ?> more
                                                            </span>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if (!empty($visit['assigned_staff'])): ?>
                                            <div class="d-flex flex-wrap">
                                                <div class="avatar-group">
                                                    <?php 
                                                    $staffCount = count($visit['assigned_staff']);
                                                    $maxDisplay = 3;
                                                    $displayedCount = min($staffCount, $maxDisplay);
                                                    $remainingCount = $staffCount - $displayedCount;
                                                    
                                                    for ($i = 0; $i < $displayedCount; $i++): 
                                                        $staff = $visit['assigned_staff'][$i];
                                                    ?>
                                                        <div class="avatar-circle avatar-xs" 
                                                            data-bs-toggle="tooltip" 
                                                            data-bs-placement="top" 
                                                            title="<?php echo htmlspecialchars($staff['staff_name']); ?>">
                                                            <?php if (!empty($staff['profile_photo'])): ?>
                                                                <img src="/storage/uploads/user_profile_photo/<?php echo htmlspecialchars($staff['profile_photo']); ?>" 
                                                            alt="<?php echo htmlspecialchars($staff['staff_name']); ?>" 
                                                            class="rounded-circle">
                                                            <?php else: ?>
                                                                <span><?php echo strtoupper(substr($staff['staff_name'], 0, 2)); ?></span>
                                                            <?php endif; ?>
                                                        </div>
                                                    <?php endfor; ?>
                                                    
                                                    <?php if ($remainingCount > 0): ?>
                                                        <div class="avatar-circle avatar-xs bg-light text-dark"
                                                            data-bs-toggle="tooltip"
                                                            data-bs-placement="top"
                                                            title="<?php echo $remainingCount; ?> more staff">
                                                            <span>+<?php echo $remainingCount; ?></span>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        <?php else: ?>
                                            <span class="text-muted"><i class="ri-user-unfollow-line me-1"></i> None</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end">
                                        <div class="action-buttons">
                                            <a href="?page=lead_management_view&view_lead=<?php echo $visit['id']; ?>" 
                                               class="btn btn-sm btn-outline-primary me-1" 
                                               title="View Lead Details">
                                                <i class="ri-eye-line"></i>
                                                View Lead
                                            </a>
                                            
                                            <?php if (!$hasAttended): ?>
                                                <button type="button" 
                                                        class="btn btn-sm btn-success"
                                                        data-bs-toggle="modal"
                                                        data-bs-target="#markAttendedModal"
                                                        data-lead-id="<?php echo $visit['id']; ?>"
                                                        data-lead-name="<?php echo htmlspecialchars($visit['first_name'] . ' ' . $visit['last_name']); ?>"
                                                        title="Mark as Attended">
                                                    <i class="ri-check-double-line me-1"></i>
                                                    Mark Attended
                                                </button>
                                            <?php else: ?>
                                                <span class="badge bg-success-subtle text-success border border-success-subtle px-3 py-2">
                                                    <i class="ri-check-double-line me-1"></i>
                                                    Marked as attended
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <?php if (isset($pagination) && $pagination['total'] > 1): ?>
                    <div class="card-footer bg-white d-flex justify-content-between align-items-center">
                        <div class="pagination-info text-muted small">
                            Showing <?php echo $pagination['start']; ?> to <?php echo $pagination['end']; ?> of <?php echo $pagination['total_records']; ?> visits
                        </div>
                        
                        <nav aria-label="Visits pagination">
                            <ul class="pagination pagination-sm mb-0">
                                <!-- Previous Page -->
                                <?php if ($pagination['current'] > 1): ?>
                                    <li class="page-item">
                                        <a class="page-link" 
                                           href="?page=campus_visits_view&p=<?php echo ($pagination['current'] - 1); ?>&<?php 
                                                echo http_build_query(array_filter($filters)); ?>" 
                                           aria-label="Previous">
                                            <i class="ri-arrow-left-s-line"></i>
                                        </a>
                                    </li>
                                <?php endif; ?>
                                
                                <!-- Page Numbers -->
                                <?php
                                $totalPages = $pagination['total'];
                                $range = 2;
                                
                                for ($i = 1; $i <= $totalPages; $i++):
                                    if ($i == 1 || $i == $totalPages || ($i >= $pagination['current'] - $range && $i <= $pagination['current'] + $range)):
                                ?>
                                    <li class="page-item <?php echo $i === $pagination['current'] ? 'active' : ''; ?>">
                                        <a class="page-link" 
                                           href="?page=campus_visits_view&p=<?php echo $i; ?>&<?php 
                                                echo http_build_query(array_filter($filters)); ?>">
                                            <?php echo $i; ?>
                                        </a>
                                    </li>
                                <?php endif; endfor; ?>
                                
                                <!-- Next Page -->
                                <?php if ($pagination['current'] < $totalPages): ?>
                                    <li class="page-item">
                                        <a class="page-link" 
                                           href="?page=campus_visits_view&p=<?php echo ($pagination['current'] + 1); ?>&<?php 
                                                echo http_build_query(array_filter($filters)); ?>" 
                                           aria-label="Next">
                                            <i class="ri-arrow-right-s-line"></i>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    </div>
                <?php endif; ?>
                
            <?php else: ?>
                <div class="text-center py-5">
                    <div class="no-data-icon mb-3">
                        <i class="ri-calendar-line fs-1 text-muted"></i>
                    </div>
                    <h5 class="text-muted">No campus visits found</h5>
                    <p class="text-muted small mb-3">
                        <?php if (!empty(array_filter($filters))): ?>
                            Try adjusting your filters
                        <?php else: ?>
                            No upcoming campus visits scheduled
                        <?php endif; ?>
                    </p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Filter Modal -->
<div class="modal fade" id="filterModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="ri-filter-3-line me-2"></i>
                    Filter Campus Visits
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="GET">
                <input type="hidden" name="page" value="campus_visits_view">
                <div class="modal-body">
                    <!-- Date Range -->
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">From Date</label>
                            <input type="date" 
                                   class="form-control" 
                                   name="date_from" 
                                   value="<?php echo isset($filters['date_from']) ? htmlspecialchars($filters['date_from']) : ''; ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">To Date</label>
                            <input type="date" 
                                   class="form-control" 
                                   name="date_to" 
                                   value="<?php echo isset($filters['date_to']) ? htmlspecialchars($filters['date_to']) : ''; ?>">
                        </div>
                    </div>
                    
                    <!-- Single Date (Today, specific date) -->
                    <div class="mb-3">
                        <label class="form-label">Specific Date</label>
                        <input type="date" 
                               class="form-control" 
                               name="date" 
                               value="<?php echo isset($filters['date']) ? htmlspecialchars($filters['date']) : ''; ?>">
                        <div class="form-text">If specified, overrides from/to dates</div>
                    </div>
                    
                    <!-- Status Filter -->
                    <div class="mb-3">
                        <label class="form-label">Show Visits</label>
                        <select class="form-select" name="status">
                            <option value="" <?php echo !isset($filters['status']) ? 'selected' : ''; ?>>All Visits</option>
                            <option value="upcoming" <?php echo (isset($filters['status']) && $filters['status'] === 'upcoming') ? 'selected' : ''; ?>>Upcoming Only</option>
                            <option value="past" <?php echo (isset($filters['status']) && $filters['status'] === 'past') ? 'selected' : ''; ?>>Past Only</option>
                            <option value="today" <?php echo (isset($filters['status']) && $filters['status'] === 'today') ? 'selected' : ''; ?>>Today Only</option>
                        </select>
                    </div>
                    
                    <!-- Search Input -->
                    <div class="mb-3">
                        <label class="form-label">Search</label>
                        <input type="text" 
                               class="form-control" 
                               name="search" 
                               placeholder="Search by name, email, phone..." 
                               value="<?php echo isset($filters['search']) ? htmlspecialchars($filters['search']) : ''; ?>">
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="?page=campus_visits_view" class="btn btn-outline-secondary">
                        <i class="ri-refresh-line me-1"></i>
                        Reset
                    </a>
                    <button type="submit" class="btn btn-primary">
                        <i class="ri-filter-3-line me-1"></i>
                        Apply Filters
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Mark Attended Modal -->
<!-- Mark Attended Modal -->
<div class="modal fade" id="markAttendedModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title">
                    <i class="ri-check-double-line me-2"></i>
                    Mark Visit as Attended
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            
            <!-- THIS IS THE KEY CHANGE: Adding the correct action URL -->
            <form method="POST" action="dashboard.php?page=campus_visits_view" id="markAttendedForm">
                <input type="hidden" name="mark_attended" value="1">
                <input type="hidden" name="lead_id" id="attended_lead_id">
                
                <div class="modal-body">
                    <div class="text-center mb-4">
                        <i class="ri-user-follow-line fs-1 text-success"></i>
                        <h5 class="mt-3">Confirm Visit Attendance</h5>
                        <p class="mb-1">Lead: <strong id="attended_lead_name"></strong></p>
                        <p class="text-muted">Please confirm the lead has attended their scheduled visit.</p>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Notes About the Visit</label>
                        <textarea class="form-control" name="visit_notes" rows="3" placeholder="Optional notes about the visit..."></textarea>
                    </div>
                </div>
                
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success" id="submitMarkAttended">
                        <i class="ri-check-line me-1"></i>
                        Confirm Attendance
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Mark attended modal
    const markAttendedModal = document.getElementById('markAttendedModal');
    if (markAttendedModal) {
        // Log when modal is opened
        markAttendedModal.addEventListener('show.bs.modal', function(event) {
            const button = event.relatedTarget;
            const leadId = button.getAttribute('data-lead-id');
            const leadName = button.getAttribute('data-lead-name');
            
            console.log('Opening modal for lead:', leadId, leadName);
            
            document.getElementById('attended_lead_id').value = leadId;
            document.getElementById('attended_lead_name').textContent = leadName;
        });
        
        // Form submission handling with Visual Feedback
        const form = markAttendedModal.querySelector('form');
        const submitButton = document.getElementById('submitMarkAttended');
        
        if (form) {
            form.addEventListener('submit', function(event) {
                // Show loading state
                submitButton.disabled = true;
                submitButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...';
                
                const leadId = document.getElementById('attended_lead_id').value;
                
                console.log('Form submitted!', {
                    leadId: leadId
                });
                
                // Let the form submit naturally - no preventDefault()
                
                // Add a reload fallback in case the redirect doesn't work
                setTimeout(function() {
                    window.location.reload();
                }, 3000);
            });
        }
    }
    
    // Automatically dismiss success alerts after 5 seconds
    const successAlerts = document.querySelectorAll('.alert-success');
    successAlerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
            bsAlert.close();
        }, 5000);
    });
    
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});
</script>

<style>
.office-visits-container {
    max-width: 1400px;
    margin: 1rem auto;
    padding: 1rem;
    background: #ffffff;
    border-radius: 1rem;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
}

.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
    flex-wrap: wrap;
    gap: 1rem;
}

.avatar-circle {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    color: white;
    background-color: #0d6efd;
    font-weight: 600;
    overflow: hidden;
}

.avatar-circle.avatar-sm {
    width: 32px;
    height: 32px;
    font-size: 0.75rem;
}

.avatar-circle.avatar-xs {
    width: 24px;
    height: 24px;
    font-size: 0.625rem;
}

.avatar-group {
    display: flex;
}

.avatar-group .avatar-circle {
    margin-right: -8px;
    border: 2px solid #fff;
}

.interests-column {
    max-width: 200px;
}

.interest-tags {
    display: flex;
    flex-wrap: wrap;
    gap: 0.25rem;
    margin-top: 0.25rem;
}

.interest-tag {
    display: inline-block;
    padding: 0.25rem 0.5rem;
    background-color: #e9ecef;
    border-radius: 0.25rem;
    font-size: 0.75rem;
    white-space: nowrap;
}

@media (max-width: 768px) {
    .office-visits-container {
        margin: 0;
        padding: 1rem;
        border-radius: 0;
    }
    
    .page-header {
        flex-direction: column;
        align-items: flex-start;
    }
}
</style>