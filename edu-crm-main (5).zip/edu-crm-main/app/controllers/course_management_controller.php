<?php
/**
 * Course Management Controller
 * Restructured on: 2026-01-14
 * Purpose: Simplified course management - only Admin can create, edit, update, delete
 */

require_once __DIR__ . '/../models/course_model.php';

class CourseManagementController {
    private $conn;
    private $user_id;
    private $user_type;
    private $courseModel;

    public function __construct($conn) {
        $this->conn = $conn;
        $this->user_id = $_SESSION['user_id'] ?? 0;
        $this->user_type = $this->getUserType();
        $this->courseModel = new CourseModel($conn);
    }

    private function getUserType() {
        $stmt = $this->conn->prepare("SELECT user_type FROM users WHERE id = ?");
        $stmt->bindParam(1, $this->user_id, PDO::PARAM_INT);
        $stmt->execute();
        $userType = $stmt->fetchColumn();
        return $userType ?: '';
    }

    public function hasPermission() {
        // Only Admin, Super Admin, and Manager can view
        return in_array($this->user_type, ['Admin', 'Super Admin', 'Manager']);
    }

    public function isAdmin() {
        return in_array($this->user_type, ['Admin', 'Super Admin']);
    }

    public function handleRequest() {
        // Get filter and pagination parameters
        $perPage = 10;
        $page = isset($_GET['p']) ? max(1, (int)$_GET['p']) : 1;
        
        // Build filters from GET parameters
        $filters = [
            'search' => isset($_GET['search']) ? trim($_GET['search']) : '',
            'department' => isset($_GET['department']) ? $_GET['department'] : '',
            'sort' => isset($_GET['sort']) ? $_GET['sort'] : ''
        ];
        
        // Get courses using model
        $result = $this->courseModel->getCourses($filters, $page, $perPage);
        
        // Get data for filter dropdowns
        $result['departments'] = $this->courseModel->getDepartments();
        
        return $result;
    }
    
    public function createCourse($data) {
        if (!$this->isAdmin()) {
            return ['status' => false, 'message' => 'Permission denied. Only Admin can create courses.'];
        }
        
        // Validate required fields
        foreach (['course_title', 'department', 'credit'] as $field) {
            if (empty($data[$field])) {
                return ['status' => false, 'message' => ucfirst(str_replace('_', ' ', $field)) . ' is required.'];
            }
        }
        
        // Create course using model
        return $this->courseModel->createCourse($data, $this->user_id);
    }
    
    public function getCourse($id) {
        return $this->courseModel->getCourseById($id);
    }
    
    public function updateCourse($data) {
        if (!$this->isAdmin()) {
            return ['status' => false, 'message' => 'Permission denied. Only Admin can update courses.'];
        }
        
        // Validate required fields
        foreach (['course_id', 'course_title', 'department', 'credit'] as $field) {
            if (empty($data[$field])) {
                return ['status' => false, 'message' => ucfirst(str_replace('_', ' ', $field)) . ' is required.'];
            }
        }
        
        // Update course using model
        return $this->courseModel->updateCourse($data, $this->user_id);
    }
    
    public function deleteCourse($id) {
        if (!$this->isAdmin()) {
            return ['status' => false, 'message' => 'Permission denied. Only Admin can delete courses.'];
        }
        
        // Delete course using model
        return $this->courseModel->deleteCourse($id);
    }
    
    public function getDepartments() {
        return $this->courseModel->getDepartments();
    }
}
?>