<?php
/**
 * Agent Management Controller
 * Created on: 2026-01-14
 * Description: Handle agent management operations
 */

require_once __DIR__ . '/../models/agent_model.php';

class AgentManagementController {
    private $conn;
    private $user_id;
    private $user_type;
    private $company_id;
    private $agentModel;

    public function __construct($conn) {
        $this->conn = $conn;
        $this->user_id = $_SESSION['user_id'] ?? 0;
        $this->user_type = $this->getUserType();
        $this->company_id = $this->getCompanyId();
        $this->agentModel = new AgentModel($conn);
    }

    private function getUserType() {
        $stmt = $this->conn->prepare("SELECT user_type FROM users WHERE id = ?");
        $stmt->bindParam(1, $this->user_id, PDO::PARAM_INT);
        $stmt->execute();
        $userType = $stmt->fetchColumn();
        return $userType ?: '';
    }
    
    private function getCompanyId() {
        $stmt = $this->conn->prepare("SELECT company_id FROM users WHERE id = ?");
        $stmt->bindParam(1, $this->user_id, PDO::PARAM_INT);
        $stmt->execute();
        $companyId = $stmt->fetchColumn();
        return $companyId ?: 1;
    }

    /**
     * Check if user has permission to manage agents (Admin or Super Admin only)
     */
    public function hasPermission() {
        return in_array($this->user_type, ['Super Admin', 'Admin']);
    }

    /**
     * Get all agents
     */
    public function getAllAgents() {
        return $this->agentModel->getAllAgents();
    }

    /**
     * Get agent by ID
     */
    public function getAgentById($agentId) {
        return $this->agentModel->getAgentById($agentId);
    }

    /**
     * Create new agent
     */
    public function createAgent($data) {
        if (!$this->hasPermission()) {
            return [
                'status' => false,
                'message' => 'You do not have permission to create agents'
            ];
        }

        // Add created_by and company_id
        $data['created_by'] = $this->user_id;
        $data['company_id'] = $this->company_id;

        return $this->agentModel->createAgent($data);
    }

    /**
     * Update agent
     */
    public function updateAgent($agentId, $data) {
        if (!$this->hasPermission()) {
            return [
                'status' => false,
                'message' => 'You do not have permission to update agents'
            ];
        }

        return $this->agentModel->updateAgent($agentId, $data);
    }

    /**
     * Delete agent
     */
    public function deleteAgent($agentId) {
        if (!$this->hasPermission()) {
            return [
                'status' => false,
                'message' => 'You do not have permission to delete agents'
            ];
        }

        return $this->agentModel->deleteAgent($agentId);
    }

    /**
     * Check if user is Super Admin
     */
    public function isSuperAdmin() {
        return $this->user_type === 'Super Admin';
    }

    /**
     * Check if user is Admin
     */
    public function isAdmin() {
        return $this->user_type === 'Admin';
    }
}
