<?php
/**
 * Company Management Controller
 * Created on: 2025-01-16 03:41:10 UTC
 * Created by: farukdesk
 */

require_once __DIR__ . '/../models/company_management_Model.php';

class CompanyManagementController {
    private $companyModel;
    private $db;
    private $uploadDir;
    private $allowedImageTypes;
    private $maxFileSize;

    public function __construct($db) {
        $this->db = $db;
        $this->companyModel = new CompanyManagementModel($db);
        $this->uploadDir = __DIR__ . '/../../storage/uploads/company_logos/';
        $this->allowedImageTypes = ['image/jpeg', 'image/png'];
        $this->maxFileSize = 5 * 1024 * 1024; // 5MB
        
        // Create upload directory if it doesn't exist
        if (!file_exists($this->uploadDir)) {
            mkdir($this->uploadDir, 0755, true);
        }

        // Log controller initialization
        error_log("CompanyManagementController initialized at " . date('Y-m-d H:i:s') . " by " . ($_SESSION['email'] ?? 'unknown'));
    }

    // Permission check
    public function hasPermission() {
        if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'Super Admin') {
            error_log("Permission denied for user: " . ($_SESSION['email'] ?? 'unknown'));
            return false;
        }
        return true;
    }
    // Main request handler
    public function handleRequest() {
        if (!$this->hasPermission()) {
            return [
                'status' => false,
                'message' => 'Unauthorized access. Super Admin privileges required.',
                'data' => [],
                'pagination' => [
                    'current' => 1,
                    'total' => 0,
                    'total_records' => 0
                ],
                'stats' => [
                    'total_companies' => 0,
                    'active_companies' => 0,
                    'total_users' => 0,
                    'active_subscriptions' => 0
                ]
            ];
        }

        $action = $_POST['action'] ?? $_GET['action'] ?? 'list';
        error_log("Handling company management action: $action by user: " . ($_SESSION['email'] ?? 'unknown'));
        
        try {
            switch ($action) {
                case 'create':
                    return $this->createCompany($_POST);
                case 'update':
                    return $this->updateCompany($_POST);
                case 'delete':
                    return $this->deleteCompany($_POST['id'] ?? 0);
                case 'get':
                    return $this->getCompany($_GET['id'] ?? 0);
                case 'getStats':
                    return $this->getCompanyStats();
                default:
                    return $this->listCompanies();
            }
        } catch (Exception $e) {
            error_log("Error handling company management request: " . $e->getMessage());
            return [
                'status' => false,
                'message' => 'An unexpected error occurred',
                'data' => [],
                'pagination' => [
                    'current' => 1,
                    'total' => 0,
                    'total_records' => 0
                ],
                'stats' => [
                    'total_companies' => 0,
                    'active_companies' => 0,
                    'total_users' => 0,
                    'active_subscriptions' => 0
                ]
            ];
        }
    }
    // List companies with filters and pagination
    public function listCompanies() {
        try {
            error_log("List companies method called at: " . date('Y-m-d H:i:s'));
            
            // Get filter parameters
            $filters = [
                'search' => $_GET['search'] ?? '',
                'status' => $_GET['status'] ?? '',
                'subscription_status' => $_GET['subscription_status'] ?? '',
                'payment_status' => $_GET['payment_status'] ?? '',
                'date_from' => $_GET['date_from'] ?? '',
                'date_to' => $_GET['date_to'] ?? ''
            ];

            // Log filters
            error_log("Applied filters: " . json_encode($filters));

            // Get current page
            $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
            $limit = 10; // Items per page

            // Fetch companies from the model
            $companies = $this->companyModel->getAllCompanies($page, $limit, $filters);
            
            // Get total count for pagination
            $totalCompanies = $this->companyModel->getTotalCompanies();
            $totalPages = ceil($totalCompanies / $limit);

            // Get stats
            $stats = $this->getOverallStats();

            error_log("Found {$totalCompanies} total companies");

            return [
                'status' => true,
                'data' => $companies,
                'pagination' => [
                    'current' => $page,
                    'total' => $totalPages,
                    'total_records' => $totalCompanies
                ],
                'stats' => $stats
            ];

        } catch (Exception $e) {
            error_log("Error in listCompanies: " . $e->getMessage());
            return [
                'status' => false,
                'message' => 'System error occurred while fetching companies',
                'data' => [],
                'pagination' => [
                    'current' => 1,
                    'total' => 0,
                    'total_records' => 0
                ],
                'stats' => [
                    'total_companies' => 0,
                    'active_companies' => 0,
                    'total_users' => 0,
                    'active_subscriptions' => 0
                ]
            ];
        }
    }

    // Get company statistics
    private function getOverallStats() {
        try {
            $stats = [
                'total_companies' => $this->companyModel->getTotalCompanies(),
                'active_companies' => $this->companyModel->getActiveCompanies(),
                'total_users' => $this->companyModel->getTotalUsers(),
                'active_subscriptions' => $this->companyModel->getActiveSubscriptions(),
                'subscription_summary' => $this->companyModel->getSubscriptionSummary(),
                'payment_summary' => $this->companyModel->getPaymentSummary()
            ];

            error_log("Stats retrieved successfully: " . json_encode($stats));
            return $stats;

        } catch (Exception $e) {
            error_log("Error getting overall stats: " . $e->getMessage());
            return [
                'total_companies' => 0,
                'active_companies' => 0,
                'total_users' => 0,
                'active_subscriptions' => 0,
                'subscription_summary' => [],
                'payment_summary' => []
            ];
        }
    }

    // Get specific company stats
    public function getCompanyStats($companyId = 0) {
        try {
            if (!$companyId) {
                throw new Exception("Company ID is required");
            }

            $stats = [
                'user_count' => $this->companyModel->getCompanyUserCount($companyId),
                'subscription_status' => $this->companyModel->getCompanySubscriptionStatus($companyId),
                'last_login' => $this->companyModel->getCompanyLastLogin($companyId),
                'activity_summary' => $this->companyModel->getCompanyActivitySummary($companyId)
            ];

            error_log("Company stats retrieved for ID {$companyId}");
            return [
                'status' => true,
                'data' => $stats
            ];

        } catch (Exception $e) {
            error_log("Error getting company stats: " . $e->getMessage());
            return [
                'status' => false,
                'message' => 'Failed to retrieve company statistics',
                'data' => []
            ];
        }
    }
    // Create new company
    public function createCompany($data) {
        try {
            error_log("Creating new company: " . json_encode($data));

            // Validate input data
            $validation = $this->validateCompanyData($data);
            if (!empty($validation)) {
                return [
                    'status' => false,
                    'message' => 'Validation errors',
                    'errors' => $validation
                ];
            }

            // Start transaction
            $this->db->beginTransaction();

            try {
                // Format and sanitize data
                $companyData = $this->formatCompanyData($data);
                
                // Create company
                $companyId = $this->companyModel->createCompany($companyData);
                
                if ($companyId) {
                    // Create admin user for company
                    $adminUser = $this->createCompanyAdmin($companyId, $companyData);
                    
                    if ($adminUser) {
                        // Create subscription if plan selected
                        if (!empty($data['subscription_plan_id'])) {
                            $subscriptionCreated = $this->createCompanySubscription(
                                $companyId, 
                                $data['subscription_plan_id'],
                                $data
                            );
                            
                            if (!$subscriptionCreated) {
                                throw new Exception("Failed to create company subscription");
                            }
                        }
                        
                        // Send welcome email
                        $this->sendWelcomeEmail($adminUser);
                        
                        $this->db->commit();
                        
                        error_log("Company created successfully: {$companyData['company_name']}");
                        return [
                            'status' => true,
                            'message' => 'Company created successfully',
                            'company_id' => $companyId
                        ];
                    }
                }
                
                throw new Exception("Failed to create company or admin user");
            } catch (Exception $e) {
                $this->db->rollBack();
                throw $e;
            }
        } catch (Exception $e) {
            error_log("Error in createCompany: " . $e->getMessage());
            return [
                'status' => false,
                'message' => 'System error occurred while creating company'
            ];
        }
    }
    // Update existing company
    public function updateCompany($data) {
        try {
            error_log("Updating company at " . date('Y-m-d H:i:s') . " by " . ($_SESSION['email'] ?? 'unknown'));
            
            if (empty($data['company_id'])) {
                return [
                    'status' => false,
                    'message' => 'Company ID is required'
                ];
            }

            // Validate input data
            $validation = $this->validateCompanyData($data, true);
            if (!empty($validation)) {
                return [
                    'status' => false,
                    'message' => 'Validation errors',
                    'errors' => $validation
                ];
            }

            $this->db->beginTransaction();

            try {
                // Format and sanitize data
                $companyData = $this->formatCompanyData($data);
                $companyData['updated_at'] = date('Y-m-d H:i:s');
                $companyData['updated_by'] = $_SESSION['user_id'] ?? null;

                // Update company
                $updated = $this->companyModel->updateCompany($data['company_id'], $companyData);

                // Handle subscription update if needed
                if (!empty($data['subscription_plan_id'])) {
                    $this->updateCompanySubscription($data['company_id'], $data['subscription_plan_id'], $data);
                }

                $this->db->commit();

                error_log("Company {$data['company_id']} updated successfully");
                return [
                    'status' => true,
                    'message' => 'Company updated successfully'
                ];

            } catch (Exception $e) {
                $this->db->rollBack();
                throw $e;
            }
        } catch (Exception $e) {
            error_log("Error in updateCompany: " . $e->getMessage());
            return [
                'status' => false,
                'message' => 'System error occurred while updating company'
            ];
        }
    }

    // Delete company
    public function deleteCompany($companyId) {
        try {
            error_log("Deleting company ID {$companyId} at " . date('Y-m-d H:i:s') . " by " . ($_SESSION['email'] ?? 'unknown'));

            if (empty($companyId)) {
                return [
                    'status' => false,
                    'message' => 'Company ID is required'
                ];
            }

            $this->db->beginTransaction();

            try {
                // Check if company exists
                $company = $this->companyModel->getCompany($companyId);
                if (!$company) {
                    throw new Exception("Company not found");
                }

                // Delete related records first
                $this->companyModel->deleteCompanySubscriptions($companyId);
                $this->companyModel->deleteCompanyUsers($companyId);
                
                // Delete company logo if exists
                if (!empty($company['logo'])) {
                    $this->deleteCompanyLogo($company['logo']);
                }

                // Finally delete the company
                $deleted = $this->companyModel->deleteCompany($companyId);

                $this->db->commit();

                error_log("Company {$companyId} deleted successfully");
                return [
                    'status' => true,
                    'message' => 'Company deleted successfully'
                ];

            } catch (Exception $e) {
                $this->db->rollBack();
                throw $e;
            }
        } catch (Exception $e) {
            error_log("Error in deleteCompany: " . $e->getMessage());
            return [
                'status' => false,
                'message' => 'System error occurred while deleting company'
            ];
        }
    }
    // Validate company data
    private function validateCompanyData($data, $isUpdate = false) {
        $errors = [];

        // Required fields validation
        $requiredFields = [
            'company_name' => 'Company name',
            'contact_first_name' => 'Contact first name',
            'contact_last_name' => 'Contact last name',
            'contact_email' => 'Contact email',
            'system_email' => 'System email',
            'phone_number' => 'Phone number',
            'address' => 'Address'
        ];

        foreach ($requiredFields as $field => $label) {
            if (empty(trim($data[$field] ?? ''))) {
                $errors[] = "{$label} is required";
            }
        }

        // Email validation
        $emailFields = ['contact_email', 'system_email'];
        foreach ($emailFields as $field) {
            if (!empty($data[$field]) && !filter_var($data[$field], FILTER_VALIDATE_EMAIL)) {
                $errors[] = "Invalid {$field} format";
            }
        }

        // Website URL validation
        if (!empty($data['website_url']) && !filter_var($data['website_url'], FILTER_VALIDATE_URL)) {
            $errors[] = "Invalid website URL format";
        }

        // Logo validation for new company or when updating logo
        if (!$isUpdate || !empty($_FILES['company_logo']['name'])) {
            $logoErrors = $this->validateLogoUpload();
            $errors = array_merge($errors, $logoErrors);
        }

        error_log("Validation completed with " . count($errors) . " errors");
        return $errors;
    }

    // Format company data
    private function formatCompanyData($data) {
        $formattedData = [
            'company_name' => trim($data['company_name']),
            'contact_first_name' => trim($data['contact_first_name']),
            'contact_last_name' => trim($data['contact_last_name']),
            'phone_number' => trim($data['phone_number']),
            'website_url' => trim($data['website_url'] ?? ''),
            'contact_email' => trim($data['contact_email']),
            'system_email' => trim($data['system_email']),
            'address' => trim($data['address']),
            'status' => trim($data['status']),
            'notes' => trim($data['notes'] ?? ''),
            'created_by' => $_SESSION['user_id'] ?? null,
            'created_at' => date('Y-m-d H:i:s')
        ];

        // Handle logo upload if present
        $logo = $this->handleLogoUpload();
        if ($logo) {
            $formattedData['logo'] = $logo;
        }

        error_log("Formatted company data: " . json_encode($formattedData));
        return $formattedData;
    }
    // Handle logo upload
    private function handleLogoUpload() {
        try {
            error_log("Logo upload attempt at 2025-01-16 03:44:08 by farukdesk");

            if (empty($_FILES['company_logo']) || $_FILES['company_logo']['error'] === UPLOAD_ERR_NO_FILE) {
                return null;
            }

            $file = $_FILES['company_logo'];
            
            // Validate file
            if (!in_array($file['type'], $this->allowedImageTypes)) {
                throw new Exception("Invalid file type. Only JPEG and PNG are allowed.");
            }

            if ($file['size'] > $this->maxFileSize) {
                throw new Exception("File size exceeds limit of 5MB.");
            }

            // Generate unique filename
            $filename = 'company_' . uniqid() . '_' . time() . '.' . 
                       pathinfo($file['name'], PATHINFO_EXTENSION);
            $filepath = $this->uploadDir . $filename;

            // Move uploaded file
            if (!move_uploaded_file($file['tmp_name'], $filepath)) {
                throw new Exception("Failed to move uploaded file.");
            }

            error_log("Logo uploaded successfully: {$filename}");
            return '/uploads/company_logos/' . $filename;

        } catch (Exception $e) {
            error_log("Logo upload error: " . $e->getMessage());
            return null;
        }
    }

    // Validate logo upload
    private function validateLogoUpload() {
        $errors = [];

        if (!empty($_FILES['company_logo']['name'])) {
            $file = $_FILES['company_logo'];

            if (!in_array($file['type'], $this->allowedImageTypes)) {
                $errors[] = "Logo must be JPEG or PNG format";
            }

            if ($file['size'] > $this->maxFileSize) {
                $errors[] = "Logo size must not exceed 5MB";
            }

            if ($file['error'] !== UPLOAD_ERR_OK && $file['error'] !== UPLOAD_ERR_NO_FILE) {
                $errors[] = "Error uploading logo: " . $this->getUploadErrorMessage($file['error']);
            }
        }

        return $errors;
    }

    // Delete company logo
    private function deleteCompanyLogo($logoPath) {
        try {
            $fullPath = __DIR__ . '/../../public' . $logoPath;
            if (file_exists($fullPath)) {
                unlink($fullPath);
                error_log("Logo deleted successfully: {$logoPath}");
                return true;
            }
            return false;
        } catch (Exception $e) {
            error_log("Error deleting logo: " . $e->getMessage());
            return false;
        }
    }
    // Create company admin user
    private function createCompanyAdmin($companyId, $companyData) {
        try {
            error_log("Creating admin user for company {$companyId} at 2025-01-16 03:44:08");

            // Generate temporary password
            $tempPassword = $this->generateSecurePassword();
            
            $userData = [
                'company_id' => $companyId,
                'first_name' => $companyData['contact_first_name'],
                'last_name' => $companyData['contact_last_name'],
                'email' => $companyData['contact_email'],
                'password' => password_hash($tempPassword, PASSWORD_DEFAULT),
                'user_type' => 'Admin',
                'status' => 'Active',
                'created_by' => $_SESSION['user_id'] ?? null,
                'created_at' => date('Y-m-d H:i:s')
            ];

            $userId = $this->companyModel->createUser($userData);
            if ($userId) {
                // Store temporary password for welcome email
                $userData['temp_password'] = $tempPassword;
                error_log("Admin user created successfully for company {$companyId}");
                return $userData;
            }

            throw new Exception("Failed to create admin user");

        } catch (Exception $e) {
            error_log("Error creating admin user: " . $e->getMessage());
            return false;
        }
    }

    // Create company subscription
    private function createCompanySubscription($companyId, $planId, $data) {
        try {
            error_log("Creating subscription for company {$companyId} at 2025-01-16 03:44:08");

            $subscriptionData = [
                'company_id' => $companyId,
                'plan_id' => $planId,
                'start_date' => date('Y-m-d'),
                'end_date' => date('Y-m-d', strtotime('+1 year')),
                'status' => 'Active',
                'payment_status' => $data['payment_status'] ?? 'Pending',
                'payment_method' => $data['payment_method'] ?? null,
                'created_by' => $_SESSION['user_id'] ?? null,
                'created_at' => date('Y-m-d H:i:s')
            ];

            $subscriptionId = $this->companyModel->createSubscription($subscriptionData);
            error_log("Subscription created successfully for company {$companyId}");
            return $subscriptionId;

        } catch (Exception $e) {
            error_log("Error creating subscription: " . $e->getMessage());
            return false;
        }
    }
    // Generate secure password
    private function generateSecurePassword($length = 12) {
        $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+';
        $password = '';
        for ($i = 0; $i < $length; $i++) {
            $password .= $chars[random_int(0, strlen($chars) - 1)];
        }
        return $password;
    }

    // Send welcome email
    private function sendWelcomeEmail($userData) {
        try {
            error_log("Sending welcome email to {$userData['email']} at 2025-01-16 03:44:08");

            // Email content
            $subject = "Welcome to " . $_ENV['APP_NAME'];
            $message = "Hello {$userData['first_name']},\n\n";
            $message .= "Your company account has been created successfully.\n";
            $message .= "Your temporary password is: {$userData['temp_password']}\n";
            $message .= "Please change your password after first login.\n\n";
            $message .= "Best regards,\n";
            $message .= $_ENV['APP_NAME'] . " Team";

            // Send email (implement your email sending logic here)
            // For now, just log it
            error_log("Welcome email would be sent to: {$userData['email']}");
            error_log("Email content: {$message}");

            return true;

        } catch (Exception $e) {
            error_log("Error sending welcome email: " . $e->getMessage());
            return false;
        }
    }

    // Get upload error message
    private function getUploadErrorMessage($errorCode) {
        $errorMessages = [
            UPLOAD_ERR_INI_SIZE => 'File exceeds upload_max_filesize directive',
            UPLOAD_ERR_FORM_SIZE => 'File exceeds MAX_FILE_SIZE directive',
            UPLOAD_ERR_PARTIAL => 'File was only partially uploaded',
            UPLOAD_ERR_NO_FILE => 'No file was uploaded',
            UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder',
            UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
            UPLOAD_ERR_EXTENSION => 'A PHP extension stopped the file upload'
        ];
        return $errorMessages[$errorCode] ?? 'Unknown upload error';
    }

public function getSubscriptionPlans() {
    try {
        error_log("[2025-01-16 04:21:53] Getting subscription plans - User: farukdesk");
        
        $query = "
            SELECT 
                id,
                plan_name,
                plan_type,
                price,
                description,
                status
            FROM 
                subscription_plans
            WHERE 
                status = 'Active'
            ORDER BY 
                price ASC
        ";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $plans = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        error_log("[2025-01-16 04:21:53] Found " . count($plans) . " subscription plans - User: farukdesk");
        return $plans;
        
    } catch (Exception $e) {
        error_log("[2025-01-16 04:21:53] Error getting subscription plans: " . $e->getMessage() . " - User: farukdesk");
        return [];
    }
}



}
?>