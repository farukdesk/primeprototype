<?php
/**
 * Office Visits Controller
 * Created on: 2025-05-05
 * Updated on: 2025-05-05
 * Created by: farukdesk
 */

require_once __DIR__ . '/../models/lead_model.php';

class OfficeVisitsController {
    private $conn;
    private $leadModel;
    private $userType;
    private $userId;
    
    public function __construct($conn) {
        $this->conn = $conn;
        $this->leadModel = new LeadModel($conn);
        
        // Set user info from session
        $this->userId = $_SESSION['user_id'] ?? 0;
        $this->userType = $_SESSION['user_type'] ?? '';
    }
    
    /**
     * Check if user has permission to view office visits
     * 
     * @return bool
     */
    public function hasPermission() {
        return in_array($this->userType, ['Super Admin', 'Admin', 'Manager', 'Counselor']);
    }
    
    /**
     * Process the request based on parameters
     * 
     * @return array Result data
     */
    public function handleRequest() {
        // Handle form submissions
        $successMessage = '';
        $errorMessage = '';
        
        error_log('Office Visits handleRequest called. Method: ' . $_SERVER['REQUEST_METHOD']);
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            error_log('POST data received: ' . print_r($_POST, true));
            
            if (isset($_POST['mark_attended'])) {
                error_log('Mark attended POST action detected');
                
                $result = $this->markLeadAsAttended($_POST);
                error_log('Mark attended result: ' . print_r($result, true));
                
                if ($result['status']) {
                    $_SESSION['success_message'] = $result['message'];
                    
                    // Make sure we have a proper redirect URL with the full path
                    $redirectUrl = 'dashboard.php?page=office_visits_view';
                    
                    // Debug the redirect
                    error_log('Redirecting to: ' . $redirectUrl);
                    
                    // Use a JavaScript redirect as a fallback in case header() doesn't work
                    echo "<script>window.location.href='" . $redirectUrl . "';</script>";
                    
                    // Also try the PHP redirect
                    header('Location: ' . $redirectUrl);
                    exit;
                } else {
                    $errorMessage = $result['message'];
                }
            }
        }
        
        // Check for flash messages
        if (isset($_SESSION['success_message'])) {
            $successMessage = $_SESSION['success_message'];
            unset($_SESSION['success_message']); // Clear the message
        }
        
        if (isset($_SESSION['error_message'])) {
            $errorMessage = $_SESSION['error_message'];
            unset($_SESSION['error_message']); // Clear the message
        }
        
        // Get filters from request
        $filters = $this->getFiltersFromRequest();
        
        // Get current page
        $page = isset($_GET['p']) ? max(1, (int)$_GET['p']) : 1;
        $perPage = 10;
        
        // Get office visits
        $result = $this->getOfficeVisits($filters, $page, $perPage);
        
        // Get statistics
        $stats = $this->getOfficeVisitStats();
        
        return [
            'visits' => $result['data'],
            'pagination' => $result['pagination'],
            'stats' => $stats,
            'filters' => $filters,
            'success' => $successMessage,
            'error' => $errorMessage
        ];
    }
    
    /**
     * Get filters from request parameters
     * 
     * @return array Filters
     */
    private function getFiltersFromRequest() {
        $filters = [];
        
        // Date filters
        if (!empty($_GET['date'])) {
            $filters['date'] = $_GET['date'];
        } else {
            if (!empty($_GET['date_from'])) {
                $filters['date_from'] = $_GET['date_from'];
            }
            
            if (!empty($_GET['date_to'])) {
                $filters['date_to'] = $_GET['date_to'];
            }
        }
        
        // Status filter (upcoming, past, today)
        if (!empty($_GET['status'])) {
            $filters['status'] = $_GET['status'];
        }
        
        // Search
        if (!empty($_GET['search'])) {
            $filters['search'] = $_GET['search'];
        }
        
        return $filters;
    }
    
    /**
     * Get office visits based on filters
     * 
     * @param array $filters Filters to apply
     * @param int $page Current page
     * @param int $perPage Items per page
     * @return array Results and pagination info
     */
    public function getOfficeVisits($filters = [], $page = 1, $perPage = 10) {
        try {
            // Base query
            $query = "SELECT l.* FROM leads l WHERE l.lead_status = 'Will visit office' AND l.campus_visit_date IS NOT NULL";
            $countQuery = "SELECT COUNT(*) FROM leads l WHERE l.lead_status = 'Will visit office' AND l.campus_visit_date IS NOT NULL";
            
            // Parameters for prepared statement
            $params = [];
            $countParams = [];
            
            // Apply date filters
            if (isset($filters['date'])) {
                // Specific date filter
                $query .= " AND DATE(l.campus_visit_date) = ?";
                $countQuery .= " AND DATE(l.campus_visit_date) = ?";
                $params[] = $filters['date'];
                $countParams[] = $filters['date'];
            } else {
                // From date
                if (isset($filters['date_from'])) {
                    $query .= " AND DATE(l.campus_visit_date) >= ?";
                    $countQuery .= " AND DATE(l.campus_visit_date) >= ?";
                    $params[] = $filters['date_from'];
                    $countParams[] = $filters['date_from'];
                }
                
                // To date
                if (isset($filters['date_to'])) {
                    $query .= " AND DATE(l.campus_visit_date) <= ?";
                    $countQuery .= " AND DATE(l.campus_visit_date) <= ?";
                    $params[] = $filters['date_to'];
                    $countParams[] = $filters['date_to'];
                }
            }
            
            // Status filter
            if (isset($filters['status'])) {
                $today = date('Y-m-d');
                
                switch ($filters['status']) {
                    case 'upcoming':
                        $query .= " AND DATE(l.campus_visit_date) >= ?";
                        $countQuery .= " AND DATE(l.campus_visit_date) >= ?";
                        $params[] = $today;
                        $countParams[] = $today;
                        break;
                        
                    case 'past':
                        $query .= " AND DATE(l.campus_visit_date) < ?";
                        $countQuery .= " AND DATE(l.campus_visit_date) < ?";
                        $params[] = $today;
                        $countParams[] = $today;
                        break;
                        
                    case 'today':
                        $query .= " AND DATE(l.campus_visit_date) = ?";
                        $countQuery .= " AND DATE(l.campus_visit_date) = ?";
                        $params[] = $today;
                        $countParams[] = $today;
                        break;
                }
            }
            
            // Search filter
            if (isset($filters['search'])) {
                $searchTerm = "%" . $filters['search'] . "%";
                $query .= " AND (l.first_name LIKE ? OR l.last_name LIKE ? OR l.email LIKE ? OR l.phone LIKE ?)";
                $countQuery .= " AND (l.first_name LIKE ? OR l.last_name LIKE ? OR l.email LIKE ? OR l.phone LIKE ?)";
                $params[] = $searchTerm;
                $params[] = $searchTerm;
                $params[] = $searchTerm;
                $params[] = $searchTerm;
                $countParams[] = $searchTerm;
                $countParams[] = $searchTerm;
                $countParams[] = $searchTerm;
                $countParams[] = $searchTerm;
            }
            
            // Default sorting: upcoming visits first, then by date
            $query .= " ORDER BY 
                        CASE WHEN l.campus_visit_date >= NOW() THEN 0 ELSE 1 END, 
                        l.campus_visit_date ASC";
            
            // Get total count first
            $countStmt = $this->conn->prepare($countQuery);
            if (!empty($countParams)) {
                for ($i = 0; $i < count($countParams); $i++) {
                    $countStmt->bindValue($i + 1, $countParams[$i]);
                }
            }
            $countStmt->execute();
            $totalRecords = $countStmt->fetchColumn();
            
            // Add pagination
            $query .= " LIMIT ?, ?";
            $offset = ($page - 1) * $perPage;
            
            // Execute main query with pagination
            $stmt = $this->conn->prepare($query);
            
            // Bind where clause parameters first
            if (!empty($params)) {
                for ($i = 0; $i < count($params); $i++) {
                    $stmt->bindValue($i + 1, $params[$i]);
                }
            }
            
            // Bind pagination parameters - IMPORTANT: use bindValue with explicit integer type
            $paramIndex = count($params);
            $stmt->bindValue(++$paramIndex, $offset, PDO::PARAM_INT);
            $stmt->bindValue(++$paramIndex, $perPage, PDO::PARAM_INT);
            
            $stmt->execute();
            
            // Fetch basic lead data
            $leads = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Enhance lead data with additional information
            $enhancedLeads = $this->enhanceLeadsData($leads);
            
            // Calculate pagination info
            $totalPages = ceil($totalRecords / $perPage);
            
            return [
                'data' => $enhancedLeads,
                'pagination' => [
                    'total' => $totalPages,
                    'current' => $page,
                    'total_records' => $totalRecords,
                    'per_page' => $perPage,
                    'start' => $offset + 1,
                    'end' => min($offset + $perPage, $totalRecords)
                ]
            ];
            
        } catch (Exception $e) {
            error_log('Error in getOfficeVisits: ' . $e->getMessage());
            return [
                'data' => [],
                'pagination' => [
                    'total' => 0,
                    'current' => 1,
                    'total_records' => 0,
                    'per_page' => $perPage,
                    'start' => 0,
                    'end' => 0
                ]
            ];
        }
    }
    
    /**
     * Enhance lead data with related information
     * 
     * @param array $leads Basic lead data
     * @return array Enhanced lead data
     */
    private function enhanceLeadsData($leads) {
        if (empty($leads)) {
            return [];
        }
        
        $enhancedLeads = [];
        
        foreach ($leads as $lead) {
            try {
                // Get universities
                $lead['universities'] = $this->getLeadUniversities($lead['id']);
            } catch (Exception $e) {
                error_log('Error getting universities: ' . $e->getMessage());
                $lead['universities'] = [];
            }
            
            try {
                // Get courses
                $lead['courses'] = $this->getLeadCourses($lead['id']);
            } catch (Exception $e) {
                error_log('Error getting courses: ' . $e->getMessage());
                $lead['courses'] = [];
            }
            
            try {
                // Get intakes
                $lead['intakes'] = $this->getLeadIntakes($lead['id']);
            } catch (Exception $e) {
                error_log('Error getting intakes: ' . $e->getMessage());
                $lead['intakes'] = [];
            }
            
            try {
                // Get assigned staff
                $lead['assigned_staff'] = $this->getLeadAssignedStaff($lead['id']);
            } catch (Exception $e) {
                error_log('Error getting assigned staff: ' . $e->getMessage());
                $lead['assigned_staff'] = [];
            }
            
            $enhancedLeads[] = $lead;
        }
        
        return $enhancedLeads;
    }
    
    /**
     * Get universities for a lead
     * 
     * @param int $leadId Lead ID
     * @return array Universities data
     */
    private function getLeadUniversities($leadId) {
        try {
            // Check if table exists
            $checkQuery = "SHOW TABLES LIKE 'lead_universities'";
            $checkStmt = $this->conn->prepare($checkQuery);
            $checkStmt->execute();
            
            if ($checkStmt->rowCount() == 0) {
                // Table doesn't exist
                return [];
            }
            
            $query = "SELECT lu.university_id, u.name as university_name
                     FROM lead_universities lu
                     INNER JOIN universities u ON lu.university_id = u.id
                     WHERE lu.lead_id = ?";
                     
            $stmt = $this->conn->prepare($query);
            $stmt->bindValue(1, $leadId, PDO::PARAM_INT);
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log('Error in getLeadUniversities: ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Get courses for a lead
     * 
     * @param int $leadId Lead ID
     * @return array Courses data
     */
    private function getLeadCourses($leadId) {
        try {
            // Check if table exists
            $checkQuery = "SHOW TABLES LIKE 'lead_courses'";
            $checkStmt = $this->conn->prepare($checkQuery);
            $checkStmt->execute();
            
            if ($checkStmt->rowCount() == 0) {
                // Table doesn't exist
                return [];
            }
            
            $query = "SELECT lc.course_id, c.course_title
                     FROM lead_courses lc
                     INNER JOIN courses c ON lc.course_id = c.id
                     WHERE lc.lead_id = ?";
                     
            $stmt = $this->conn->prepare($query);
            $stmt->bindValue(1, $leadId, PDO::PARAM_INT);
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log('Error in getLeadCourses: ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Get intakes for a lead
     * 
     * @param int $leadId Lead ID
     * @return array Intakes data
     */
    private function getLeadIntakes($leadId) {
        try {
            // Check if table exists
            $checkQuery = "SHOW TABLES LIKE 'lead_intakes'";
            $checkStmt = $this->conn->prepare($checkQuery);
            $checkStmt->execute();
            
            if ($checkStmt->rowCount() == 0) {
                // Table doesn't exist
                return [];
            }
            
            $query = "SELECT li.intake_id, i.name as intake_name
                     FROM lead_intakes li
                     INNER JOIN intakes i ON li.intake_id = i.id
                     WHERE li.lead_id = ?";
                     
            $stmt = $this->conn->prepare($query);
            $stmt->bindValue(1, $leadId, PDO::PARAM_INT);
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log('Error in getLeadIntakes: ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Get assigned staff for a lead
     * 
     * @param int $leadId Lead ID
     * @return array Staff data
     */
    private function getLeadAssignedStaff($leadId) {
        try {
            // Try different table names
            $tables = ['lead_staff_assignments', 'lead_assigned_staff'];
            $staffData = [];
            
            foreach ($tables as $tableName) {
                // Check if table exists
                $checkQuery = "SHOW TABLES LIKE '$tableName'";
                $checkStmt = $this->conn->prepare($checkQuery);
                $checkStmt->execute();
                
                if ($checkStmt->rowCount() > 0) {
                    // Table exists, get data
                    $query = "SELECT las.id as assignment_id, las.staff_id, 
                                CONCAT(up.first_name, ' ', up.last_name) as staff_name,
                                up.profile_photo
                             FROM $tableName las
                             INNER JOIN users u ON las.staff_id = u.id
                             INNER JOIN user_profile up ON u.id = up.user_id
                             WHERE las.lead_id = ?";
                             
                    $stmt = $this->conn->prepare($query);
                    $stmt->bindValue(1, $leadId, PDO::PARAM_INT);
                    $stmt->execute();
                    
                    $staffData = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    if (!empty($staffData)) {
                        break;  // We found data, no need to check other tables
                    }
                }
            }
            
            return $staffData;
        } catch (Exception $e) {
            error_log('Error in getLeadAssignedStaff: ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Get office visit statistics
     * 
     * @return array Statistics
     */
    public function getOfficeVisitStats() {
        try {
            $stats = [];
            
            // Today's visits
            $today = date('Y-m-d');
            $query = "SELECT COUNT(*) as count FROM leads 
                     WHERE lead_status = 'Will visit office' 
                     AND campus_visit_date IS NOT NULL
                     AND DATE(campus_visit_date) = ?";
                     
            $stmt = $this->conn->prepare($query);
            $stmt->bindValue(1, $today, PDO::PARAM_STR);
            $stmt->execute();
            $stats['today_visits'] = $stmt->fetchColumn();
            
            // This week's visits
            $weekStart = date('Y-m-d', strtotime('monday this week'));
            $weekEnd = date('Y-m-d', strtotime('sunday this week'));
            $query = "SELECT COUNT(*) as count FROM leads 
                     WHERE lead_status = 'Will visit office' 
                     AND campus_visit_date IS NOT NULL
                     AND DATE(campus_visit_date) BETWEEN ? AND ?";
                     
            $stmt = $this->conn->prepare($query);
            $stmt->bindValue(1, $weekStart, PDO::PARAM_STR);
            $stmt->bindValue(2, $weekEnd, PDO::PARAM_STR);
            $stmt->execute();
            $stats['week_visits'] = $stmt->fetchColumn();
            
            // This month's visits
            $monthStart = date('Y-m-01');
            $monthEnd = date('Y-m-t');
            $query = "SELECT COUNT(*) as count FROM leads 
                     WHERE lead_status = 'Will visit office' 
                     AND campus_visit_date IS NOT NULL
                     AND DATE(campus_visit_date) BETWEEN ? AND ?";
                     
            $stmt = $this->conn->prepare($query);
            $stmt->bindValue(1, $monthStart, PDO::PARAM_STR);
            $stmt->bindValue(2, $monthEnd, PDO::PARAM_STR);
            $stmt->execute();
            $stats['month_visits'] = $stmt->fetchColumn();
            
            // Upcoming visits (future dates)
            $query = "SELECT COUNT(*) as count FROM leads 
                     WHERE lead_status = 'Will visit office' 
                     AND campus_visit_date IS NOT NULL
                     AND DATE(campus_visit_date) > ?";
                     
            $stmt = $this->conn->prepare($query);
            $stmt->bindValue(1, $today, PDO::PARAM_STR);
            $stmt->execute();
            $stats['upcoming_visits'] = $stmt->fetchColumn();
            
            return $stats;
            
        } catch (Exception $e) {
            error_log('Error in getOfficeVisitStats: ' . $e->getMessage());
            return [
                'today_visits' => 0,
                'week_visits' => 0,
                'month_visits' => 0,
                'upcoming_visits' => 0
            ];
        }
    }
    
    /**
     * Mark a lead as having attended their office visit
     * 
     * @param array $data Form data
     * @return array Status and message
     */
    public function markLeadAsAttended($data) {
        try {
            error_log('Starting markLeadAsAttended with data: ' . print_r($data, true));
            
            // Check if lead ID is provided
            if (empty($data['lead_id'])) {
                return ['status' => false, 'message' => 'Lead ID is required.'];
            }
            
            $leadId = (int)$data['lead_id'];
            $visitNotes = $data['visit_notes'] ?? '';
            
            error_log('Processing lead ID: ' . $leadId . ', notes length: ' . strlen($visitNotes));
            
            // Begin transaction
            $this->conn->beginTransaction();
            error_log('Transaction started');
            
            // Add a note - handle potential errors but continue
            try {
                // First check if lead_notes table exists
                $checkTableQuery = "SHOW TABLES LIKE 'lead_notes'";
                $checkTableStmt = $this->conn->prepare($checkTableQuery);
                $checkTableStmt->execute();
                
                if ($checkTableStmt->rowCount() > 0) {
                    $noteText = "Lead attended office visit on " . date('Y-m-d H:i:s');
                    if (!empty($visitNotes)) {
                        $noteText .= "\n\nNotes: " . $visitNotes;
                    }
                    
                    $noteQuery = "INSERT INTO lead_notes (lead_id, note_text, created_by) VALUES (?, ?, ?)";
                    $noteStmt = $this->conn->prepare($noteQuery);
                    $noteStmt->bindValue(1, $leadId, PDO::PARAM_INT);
                    $noteStmt->bindValue(2, $noteText, PDO::PARAM_STR);
                    $noteStmt->bindValue(3, $this->userId, PDO::PARAM_INT);
                    $noteStmt->execute();
                    
                    error_log('Note added successfully to lead_notes table');
                } else {
                    error_log('lead_notes table does not exist, skipping note creation');
                }
            } catch (Exception $e) {
                error_log('Error adding note (non-critical): ' . $e->getMessage());
                // Continue execution even if adding note fails
            }
            
            // Check available columns in the leads table
            $columnsQuery = "SHOW COLUMNS FROM leads";
            $columnsStmt = $this->conn->prepare($columnsQuery);
            $columnsStmt->execute();
            $columns = $columnsStmt->fetchAll(PDO::FETCH_COLUMN, 0);
            $columnsLower = array_map('strtolower', $columns);
            
            // Mark lead as attended
            error_log('Marking lead as attended');
            
            // Just mark as attended without changing status
            $updateQuery = "UPDATE leads SET ";
            $paramCount = 0;
            $params = [];
            
            // Only add columns that exist
            if (in_array('attended_at', $columnsLower)) {
                $updateQuery .= "attended_at = CURRENT_TIMESTAMP";
                $paramCount++;
            }
            
            if (in_array('updated_at', $columnsLower)) {
                if ($paramCount > 0) $updateQuery .= ", ";
                $updateQuery .= "updated_at = CURRENT_TIMESTAMP";
                $paramCount++;
            }
            
            if (in_array('updated_by', $columnsLower)) {
                if ($paramCount > 0) $updateQuery .= ", ";
                $updateQuery .= "updated_by = ?";
                $params[] = $this->userId;
                $paramCount++;
            }
            
            // If no columns were added, update something harmless
            if ($paramCount == 0) {
                $updateQuery .= "id = id"; // No-op update
            }
            
            $updateQuery .= " WHERE id = ?";
            $params[] = $leadId;
            
            $updateStmt = $this->conn->prepare($updateQuery);
            
            // Bind all parameters
            for ($i = 0; $i < count($params); $i++) {
                $updateStmt->bindValue($i + 1, $params[$i], PDO::PARAM_INT);
            }
            
            $updateResult = $updateStmt->execute();
            error_log('Update attended_at result: ' . ($updateResult ? 'success' : 'failed'));
            
            // Check if rows were affected
            if ($updateStmt->rowCount() == 0) {
                // No rows affected - lead might not exist
                $this->conn->rollBack();
                error_log('No rows affected by update, lead ID might not exist');
                return ['status' => false, 'message' => 'Lead not found or no changes were made.'];
            }
            
            // Commit transaction
            $this->conn->commit();
            error_log('Transaction committed successfully');
            
            // Set success message in session for display after redirect
            $_SESSION['success_message'] = 'Lead marked as attended.';
            
            return [
                'status' => true,
                'message' => 'Lead marked as attended.',
                'reload' => true
            ];
            
        } catch (Exception $e) {
            // Rollback transaction
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            
            error_log('Error in markLeadAsAttended: ' . $e->getMessage() . "\nTrace: " . $e->getTraceAsString());
            return ['status' => false, 'message' => 'Failed to mark lead as attended: ' . $e->getMessage()];
        }
    }
}
?>