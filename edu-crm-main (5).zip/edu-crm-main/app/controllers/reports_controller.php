<?php
/**
 * Reports Controller
 * Created on: 2026-01-26
 * Description: Handle report generation and data aggregation
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../models/reports_model.php';

class ReportsController {
    private $model;
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
        $this->model = new ReportsModel($conn);
    }

    /**
     * Get Top Sheet report data
     * Returns admitted students grouped by program with Previous Day, Today, and Total counts
     */
    public function getTopSheetData($company_id, $semester = null, $batch = null, $date_from = null, $date_to = null) {
        try {
            $data = $this->model->getAdmittedStudentsByProgram($company_id, $semester, $batch, $date_from, $date_to);
            return [
                'success' => true,
                'data' => $data
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Get report metadata (semester, batch info)
     */
    public function getReportMetadata($company_id) {
        try {
            $metadata = $this->model->getReportMetadata($company_id);
            return [
                'success' => true,
                'metadata' => $metadata
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
}
