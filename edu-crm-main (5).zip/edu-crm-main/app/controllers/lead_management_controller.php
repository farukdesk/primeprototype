<?php
/**
 * Lead Management Controller
 * Created on: 2025-05-05
 * Created by: farukdesk
 */

require_once __DIR__ . '/../models/lead_model.php';

class LeadManagementController {
    private $conn;
    private $user_id;
    private $user_type;
    private $company_id;
    private $leadModel;

    public function __construct($conn) {
        $this->conn = $conn;
        $this->user_id = $_SESSION['user_id'] ?? 0;
        $this->user_type = $this->getUserType();
        $this->company_id = $this->getCompanyId();
        $this->leadModel = new LeadModel($conn);
    }

    private function getUserType() {
        $stmt = $this->conn->prepare("SELECT user_type FROM users WHERE id = ?");
        $stmt->bindParam(1, $this->user_id, PDO::PARAM_INT);
        $stmt->execute();
        $userType = $stmt->fetchColumn();
        return $userType ?: '';
    }
    
    private function getCompanyId() {
        $stmt = $this->conn->prepare("SELECT company_id FROM users WHERE id = ?");
        $stmt->bindParam(1, $this->user_id, PDO::PARAM_INT);
        $stmt->execute();
        $companyId = $stmt->fetchColumn();
        return $companyId ?: 1; // Default to company 1 if not found
    }

    public function hasPermission() {
        // All users can view leads, permissions are handled at the data level
        return true;
    }

    public function handleRequest() {
    // Get filter and pagination parameters
    $perPage = 10;
    $page = isset($_GET['p']) ? max(1, (int)$_GET['p']) : 1;
    
    // Build filters from GET parameters
    $filters = [
        'search' => isset($_GET['search']) ? trim($_GET['search']) : '',
        'agent_id' => isset($_GET['agent_id']) ? (int)$_GET['agent_id'] : '',
        'university_id' => isset($_GET['university_id']) ? (int)$_GET['university_id'] : '',
        'course_id' => isset($_GET['course_id']) ? (int)$_GET['course_id'] : '',
        'intake_id' => isset($_GET['intake_id']) ? (int)$_GET['intake_id'] : '',
        'staff_id' => isset($_GET['staff_id']) ? (int)$_GET['staff_id'] : '',
        'lead_status' => isset($_GET['lead_status']) ? $_GET['lead_status'] : '',
        'lead_source' => isset($_GET['lead_source']) ? $_GET['lead_source'] : '',
        'sort' => isset($_GET['sort']) ? $_GET['sort'] : '',
        'followup_today' => isset($_GET['followup_today']) && $_GET['followup_today'] == '1',
        'followup_overdue' => isset($_GET['followup_overdue']) && $_GET['followup_overdue'] == '1',
        'company_id' => $this->company_id // Always add company_id filter
    ];
    
    // Get leads using model
    $result = $this->leadModel->getLeads($filters, $page, $perPage, $this->user_id, $this->user_type);
    
    // Get data for filter dropdowns
    $result['agents'] = $this->leadModel->getAllAgents();
    $result['staff'] = $this->leadModel->getAllStaff();
    $result['universities'] = $this->getUniversities();
    $result['courses'] = $this->getCourses();
    $result['semesters'] = $this->getSemesters();
    $result['user_type'] = $this->user_type;
    $result['user_id'] = $this->user_id;
    
    return $result;
}
    
    public function getLeadDetails($leadId) {
        return $this->leadModel->getLeadById($leadId, $this->user_id, $this->user_type);
    }
    
    public function createLead($data) {
        // Create lead using model
        return $this->leadModel->createLead($data, $this->user_id, $this->company_id);
    }
    
    public function updateLead($data) {
        // Update lead using model
        return $this->leadModel->updateLead($data, $this->user_id);
    }
    
    public function deleteLead($leadId) {
        // Delete lead using model
        return $this->leadModel->deleteLead($leadId, $this->user_id, $this->user_type);
    }
    
    public function addLeadNote($leadId, $noteText) {
        return $this->leadModel->addLeadNote($leadId, $noteText, $this->user_id);
    }
    
    public function deleteLeadNote($noteId) {
        return $this->leadModel->deleteLeadNote($noteId, $this->user_id, $this->user_type);
    }
    
    public function removeStaffFromLead($assignmentId) {
        return $this->leadModel->removeStaffFromLead($assignmentId, $this->user_id, $this->user_type);
    }
    
    public function getUniversities() {
        $query = "SELECT id, name FROM universities WHERE status = 'Active' ORDER BY name";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getCourses() {
        $query = "SELECT id, course_title FROM courses ORDER BY course_title";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getSemesters() {
        $query = "SELECT id, name FROM semesters WHERE status = 'Active' ORDER BY start_date DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getLeadStatuses() {
        return [
            'Fresh',
            '1st call',
            '2nd call',
            '3rd call',
            'Unable to reach once',
            'Unable to reach twice',
            'Unable to reach trice',
            'Dead',
            'Will visit office',
            'Admitted'
        ];
    }
    
    public function getLeadSources() {
        return [
            'Direct Online',
            'Direct Campus Visit',
            'Agent',
            'F2F Marketing'
        ];
    }
    
    public function isSuperAdmin() {
        return $this->user_type === 'Super Admin';
    }
    
    public function isAdmin() {
        return $this->user_type === 'Admin';
    }
    
    public function isManager() {
        return $this->user_type === 'Manager';
    }
    
    public function isStaff() {
        return $this->user_type === 'Counselor';
    }
    
    public function isAgent() {
        return $this->user_type === 'Agent';
    }
    
    public function canCreateLead() {
        // All user types can create leads
        return true;
    }
    
    public function canEditLead() {
        // All user types can edit leads, but with different restrictions (handled in model)
        return true;
    }
    
    public function canDeleteLead() {
        // Only Super Admin and Agent (for their own leads) can delete leads
        return $this->isSuperAdmin() || $this->isAgent();
    }
    
    public function canAssignStaff() {
        // Only Super Admin, Admin, and Manager can assign staff
        return $this->isSuperAdmin() || $this->isAdmin() || $this->isManager();
    }
}
?>