<?php
require_once __DIR__ . '/../models/UserProfile.php';

class UserProfileController {
    private $userProfileModel;
    private $db;

    public function __construct($db) {
        $this->db = $db;
        $this->userProfileModel = new UserProfile($db);
    }

    public function showProfile($user_id) {
        try {
            return $this->userProfileModel->getProfile($user_id);
        } catch (Exception $e) {
            error_log("Error fetching profile: " . $e->getMessage());
            return false;
        }
    }

    public function updateProfile($data) {
        try {
            // Validate email uniqueness (excluding current user)
            if (!$this->isEmailUnique($data['email'], $data['id'])) {
                throw new Exception("Email already exists");
            }

            // Update user email
            $emailUpdate = $this->userProfileModel->updateUserEmail($data['id'], $data['email']);
            if (!$emailUpdate) {
                throw new Exception("Failed to update email");
            }

            // Prepare profile data
            $profileData = [
                'user_id' => $data['id'],
                'first_name' => $data['first_name'],
                'last_name' => $data['last_name'],
                'date_of_birth' => $data['date_of_birth'],
                'mobile_number' => $data['mobile_number'],
                'designation' => $data['designation']
            ];

            // Add profile photo if it exists
            if (isset($data['profile_photo'])) {
                $profileData['profile_photo'] = $data['profile_photo'];
            }

            return $this->userProfileModel->updateProfile($profileData);
        } catch (Exception $e) {
            error_log("Error updating profile: " . $e->getMessage());
            return false;
        }
    }

    private function isEmailUnique($email, $userId) {
        try {
            $stmt = $this->db->prepare(
                "SELECT COUNT(*) FROM users WHERE email = ? AND id != ?"
            );
            $stmt->execute([$email, $userId]);
            return $stmt->fetchColumn() == 0;
        } catch (Exception $e) {
            error_log("Error checking email uniqueness: " . $e->getMessage());
            return false;
        }
    }

    public function handleProfilePhotoUpload($file, $oldPhoto = null) {
        try {
            $uploadDir = $_SERVER['DOCUMENT_ROOT'] . '/storage/uploads/user_profile_photo/';
            
            if (!file_exists($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }

            $fileName = uniqid() . '_' . basename($file['name']);
            $targetFile = $uploadDir . $fileName;

            // Delete old photo if exists
            if ($oldPhoto) {
                $oldFile = $uploadDir . $oldPhoto;
                if (file_exists($oldFile)) {
                    unlink($oldFile);
                }
            }

            if (move_uploaded_file($file['tmp_name'], $targetFile)) {
                return $fileName;
            }
            return false;
        } catch (Exception $e) {
            error_log("Error handling profile photo: " . $e->getMessage());
            return false;
        }
    }

    public function validateProfileData($data) {
        $errors = [];

        if (empty($data['email']) || !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Invalid email address";
        }

        if (empty($data['first_name'])) {
            $errors[] = "First name is required";
        }

        if (empty($data['last_name'])) {
            $errors[] = "Last name is required";
        }

        if (!empty($data['mobile_number']) && !preg_match("/^[0-9+\-\(\) ]+$/", $data['mobile_number'])) {
            $errors[] = "Invalid mobile number format";
        }

        return $errors;
    }
}
?>