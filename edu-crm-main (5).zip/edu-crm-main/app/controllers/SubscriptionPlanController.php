<?php
require_once __DIR__ . '/../models/SubscriptionPlan.php';

class SubscriptionPlanController {
    private $subscriptionPlanModel;
    private $db;

    public function __construct($db) {
        $this->db = $db;
        $this->subscriptionPlanModel = new SubscriptionPlan($db);
    }

    // Check user permissions
    public function hasPermission() {
        if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'Super Admin') {
            error_log("Permission denied for user: " . ($_SESSION['email'] ?? 'unknown'));
            return false;
        }
        return true;
    }

    // Handle page actions
    public function handleRequest() {
        if (!$this->hasPermission()) {
            return [
                'status' => false,
                'message' => 'Unauthorized access. Super Admin privileges required.'
            ];
        }

        $action = $_POST['action'] ?? $_GET['action'] ?? 'list';
        error_log("Handling action: $action");
        
        try {
            switch ($action) {
                case 'create':
                    return $this->createPlan($_POST);
                case 'update':
                    return $this->updatePlan($_POST);
                case 'delete':
                    return $this->deletePlan($_POST['id'] ?? 0);
                case 'get':
                    return $this->getPlan($_GET['id'] ?? 0);
                default:
                    return $this->listPlans();
            }
        } catch (Exception $e) {
            error_log("Error handling request: " . $e->getMessage());
            return [
                'status' => false,
                'message' => 'An unexpected error occurred'
            ];
        }
    }

    // List plans with filters and pagination
    public function listPlans() {
        try {
            // Get filter parameters
            $filters = [
                'plan_name' => $_GET['plan_name'] ?? '',
                'plan_type' => $_GET['plan_type'] ?? '',
                'status' => $_GET['status'] ?? ''
            ];

            // Get current page
            $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
            $limit = 10; // Items per page

            $result = $this->subscriptionPlanModel->getAllPlans($page, $limit, $filters);
            
            if ($result) {
                return [
                    'status' => true,
                    'data' => $result['plans'],
                    'pagination' => [
                        'current' => $page,
                        'total' => $result['pages'],
                        'total_records' => $result['total']
                    ],
                    'filters' => $filters
                ];
            }

            return [
                'status' => false,
                'message' => 'Error fetching subscription plans'
            ];

        } catch (Exception $e) {
            error_log("Error in listPlans: " . $e->getMessage());
            return [
                'status' => false,
                'message' => 'System error occurred while fetching plans'
            ];
        }
    }

    // Create new plan
    public function createPlan($data) {
        try {
            // Validate input data
            $validation = $this->validatePlanData($data);
            if (!empty($validation)) {
                return [
                    'status' => false,
                    'message' => 'Validation errors',
                    'errors' => $validation
                ];
            }

            // Format and sanitize data
            $planData = $this->formatPlanData($data);

            if ($this->subscriptionPlanModel->createPlan($planData)) {
                error_log("Plan created successfully: " . $planData['plan_name']);
                return [
                    'status' => true,
                    'message' => 'Subscription plan created successfully'
                ];
            }

            return [
                'status' => false,
                'message' => 'Failed to create subscription plan'
            ];

        } catch (Exception $e) {
            error_log("Error in createPlan: " . $e->getMessage());
            return [
                'status' => false,
                'message' => 'System error occurred while creating plan'
            ];
        }
    }

    // Update existing plan
    public function updatePlan($data) {
        try {
            if (!isset($data['id']) || !is_numeric($data['id'])) {
                return [
                    'status' => false,
                    'message' => 'Valid Plan ID is required'
                ];
            }

            // Validate input data
            $validation = $this->validatePlanData($data);
            if (!empty($validation)) {
                return [
                    'status' => false,
                    'message' => 'Validation errors',
                    'errors' => $validation
                ];
            }

            // Format and sanitize data
            $planData = $this->formatPlanData($data);

            if ($this->subscriptionPlanModel->updatePlan($data['id'], $planData)) {
                error_log("Plan updated successfully: ID " . $data['id']);
                return [
                    'status' => true,
                    'message' => 'Subscription plan updated successfully'
                ];
            }

            return [
                'status' => false,
                'message' => 'Failed to update subscription plan'
            ];

        } catch (Exception $e) {
            error_log("Error in updatePlan: " . $e->getMessage());
            return [
                'status' => false,
                'message' => 'System error occurred while updating plan'
            ];
        }
    }

    // Delete plan
    public function deletePlan($id) {
        try {
            if (!$id || !is_numeric($id)) {
                return [
                    'status' => false,
                    'message' => 'Valid Plan ID is required'
                ];
            }

            if ($this->subscriptionPlanModel->deletePlan($id)) {
                error_log("Plan deleted successfully: ID $id");
                return [
                    'status' => true,
                    'message' => 'Subscription plan deleted successfully'
                ];
            }

            return [
                'status' => false,
                'message' => 'Failed to delete subscription plan'
            ];

        } catch (Exception $e) {
            error_log("Error in deletePlan: " . $e->getMessage());
            return [
                'status' => false,
                'message' => 'System error occurred while deleting plan'
            ];
        }
    }

    // Get single plan
    public function getPlan($id) {
        try {
            if (!$id || !is_numeric($id)) {
                return [
                    'status' => false,
                    'message' => 'Valid Plan ID is required'
                ];
            }

            $plan = $this->subscriptionPlanModel->getPlanById($id);
            
            if ($plan) {
                return [
                    'status' => true,
                    'data' => $plan
                ];
            }

            return [
                'status' => false,
                'message' => 'Plan not found'
            ];

        } catch (Exception $e) {
            error_log("Error in getPlan: " . $e->getMessage());
            return [
                'status' => false,
                'message' => 'System error occurred while fetching plan'
            ];
        }
    }

    // Format plan data
    private function formatPlanData($data) {
        return [
            'plan_name' => trim($data['plan_name']),
            'plan_type' => trim($data['plan_type']),
            'price' => (float)$data['price'],
            'description' => trim($data['description'] ?? ''),
            'features' => array_map('trim', 
                                  array_filter(
                                      explode("\n", $data['features'] ?? '')
                                  )),
            'status' => trim($data['status'])
        ];
    }

    // Validate plan data
    private function validatePlanData($data) {
        $errors = [];

        if (empty(trim($data['plan_name']))) {
            $errors[] = "Plan name is required";
        }

        if (empty($data['plan_type']) || 
            !in_array($data['plan_type'], ['Monthly', 'Yearly', 'Lifetime'])) {
            $errors[] = "Invalid plan type. Must be Monthly, Yearly, or Lifetime";
        }

        if (!isset($data['price']) || !is_numeric($data['price']) || $data['price'] < 0) {
            $errors[] = "Valid price is required (must be a non-negative number)";
        }

        if (!isset($data['status']) || 
            !in_array($data['status'], ['Active', 'Inactive'])) {
            $errors[] = "Invalid status value. Must be Active or Inactive";
        }

        return $errors;
    }
}
?>