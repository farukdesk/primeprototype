<?php
/**
 * Call Logs Controller
 * Created on: 2025-05-05
 * Created by: farukdesk
 */

require_once __DIR__ . '/../models/call_log_model.php';

class CallLogsController {
    private $conn;
    private $callLogModel;
    private $userType;
    private $userId;
    private $companyId;
    
    public function __construct($conn) {
        $this->conn = $conn;
        $this->callLogModel = new CallLogModel($conn);
        
        // Set user info from session
        $this->userId = $_SESSION['user_id'] ?? 0;
        $this->userType = $_SESSION['user_type'] ?? '';
        $this->companyId = $_SESSION['company_id'] ?? 0;
    }
    
    /**
     * Process the request based on parameters
     * 
     * @return array Result data
     */
    public function handleRequest() {
        // Get filters from request
        $filters = $this->getFiltersFromRequest();
        
        // Get current page
        $page = isset($_GET['p']) ? max(1, (int)$_GET['p']) : 1;
        $perPage = isset($_GET['per_page']) ? (int)$_GET['per_page'] : 10;
        
        // Viewing a specific staff member's stats
        $viewStaffId = isset($_GET['view_staff']) ? (int)$_GET['view_staff'] : null;
        
        if ($viewStaffId) {
            // Get staff stats
            $staffStats = $this->callLogModel->getStaffCallStatsByStaffId($viewStaffId);
            
            // Get leads handled by this staff
            $leadsPage = isset($_GET['leads_page']) ? max(1, (int)$_GET['leads_page']) : 1;
            $leads = $this->callLogModel->getLeadsByStaffId($viewStaffId, $leadsPage, 10);
            
            return [
                'view_mode' => 'staff_detail',
                'staff_stats' => $staffStats,
                'leads' => $leads,
                'can_view_call_logs' => $this->canViewCallLogs(),
                'can_manage_call_logs' => $this->canManageCallLogs(),
                'user_id' => $this->userId,
                'user_type' => $this->userType
            ];
        } else {
            // Get all staff stats
            $staffStats = $this->callLogModel->getStaffCallStats();
            
            // Get call logs if needed
            $callLogs = [];
            if (!empty($filters)) {
                $callLogs = $this->callLogModel->getCallLogs($filters, $page, $perPage);
            }
            
            return [
                'view_mode' => 'staff_list',
                'staff_stats' => $staffStats,
                'logs' => !empty($callLogs) ? $callLogs : null,
                'can_view_call_logs' => $this->canViewCallLogs(),
                'can_manage_call_logs' => $this->canManageCallLogs(), 
                'user_id' => $this->userId,
                'user_type' => $this->userType
            ];
        }
    }
    
    /**
     * Get filters from request parameters
     * 
     * @return array Filters
     */
    private function getFiltersFromRequest() {
        $filters = [];
        
        if (!empty($_GET['staff_id'])) {
            $filters['staff_id'] = (int)$_GET['staff_id'];
        }
        
        if (!empty($_GET['lead_id'])) {
            $filters['lead_id'] = (int)$_GET['lead_id'];
        }
        
        if (!empty($_GET['call_type'])) {
            $filters['call_type'] = $_GET['call_type'];
        }
        
        if (!empty($_GET['date_from'])) {
            $filters['date_from'] = $_GET['date_from'];
        }
        
        if (!empty($_GET['date_to'])) {
            $filters['date_to'] = $_GET['date_to'];
        }
        
        if (!empty($_GET['converted'])) {
            $filters['converted'] = (bool)$_GET['converted'];
        }
        
        if (!empty($_GET['search'])) {
            $filters['search'] = $_GET['search'];
        }
        
        return $filters;
    }
    
    /**
     * Check if user can view call logs
     * 
     * @return bool Whether user can view call logs
     */
    public function canViewCallLogs() {
        return in_array($this->userType, ['Super Admin', 'Admin', 'Manager', 'Counselor']);
    }
    
    /**
     * Check if user can manage call logs
     * 
     * @return bool Whether user can manage call logs
     */
    public function canManageCallLogs() {
        return in_array($this->userType, ['Super Admin', 'Admin', 'Manager']);
    }
    
    /**
     * Get call log details by ID
     * 
     * @param int $callLogId Call log ID
     * @return array Call log details
     */
    public function getCallLogDetails($callLogId) {
        // Check if call log exists
        $query = "SELECT cl.*,
                    CONCAT(up_staff.first_name, ' ', up_staff.last_name) as staff_name,
                    CONCAT(l.first_name, ' ', l.last_name) as lead_name,
                    l.email as lead_email,
                    l.phone as lead_phone
                  FROM call_logs cl
                  INNER JOIN users u_staff ON cl.staff_id = u_staff.id
                  INNER JOIN user_profile up_staff ON u_staff.id = up_staff.user_id
                  INNER JOIN leads l ON cl.lead_id = l.id
                  WHERE cl.id = ?";
                  
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $callLogId, PDO::PARAM_INT);
        $stmt->execute();
        $callLog = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$callLog) {
            return ['status' => false, 'message' => 'Call log not found.'];
        }
        
        return ['status' => true, 'data' => $callLog];
    }
    
    /**
     * Update call log details
     * 
     * @param array $data Call log data
     * @return array Status and message
     */
    public function updateCallLog($data) {
        // Check if user has permission
        if (!$this->canManageCallLogs()) {
            return ['status' => false, 'message' => 'You do not have permission to manage call logs.'];
        }
        
        // Check if call log exists
        $callLogId = $data['call_log_id'];
        $callLogCheck = $this->getCallLogDetails($callLogId);
        
        if (!$callLogCheck['status']) {
            return $callLogCheck;
        }
        
        try {
            $query = "UPDATE call_logs SET
                        call_notes = ?,
                        call_duration = ?,
                        call_outcome = ?
                      WHERE id = ?";
                      
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(1, $data['call_notes'], PDO::PARAM_STR);
            $stmt->bindParam(2, $data['call_duration'], PDO::PARAM_INT);
            $stmt->bindParam(3, $data['call_outcome'], PDO::PARAM_STR);
            $stmt->bindParam(4, $callLogId, PDO::PARAM_INT);
            $stmt->execute();
            
            return ['status' => true, 'message' => 'Call log updated successfully.'];
        } catch (Exception $e) {
            error_log('Error in updateCallLog: ' . $e->getMessage());
            return ['status' => false, 'message' => 'Failed to update call log: ' . $e->getMessage()];
        }
    }
    
    /**
     * Delete a call log
     * 
     * @param int $callLogId Call log ID
     * @return array Status and message
     */
    public function deleteCallLog($callLogId) {
        // Check if user has permission
        if (!$this->canManageCallLogs()) {
            return ['status' => false, 'message' => 'You do not have permission to manage call logs.'];
        }
        
        // Check if call log exists
        $callLogCheck = $this->getCallLogDetails($callLogId);
        
        if (!$callLogCheck['status']) {
            return $callLogCheck;
        }
        
        try {
            $query = "DELETE FROM call_logs WHERE id = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(1, $callLogId, PDO::PARAM_INT);
            $stmt->execute();
            
            return ['status' => true, 'message' => 'Call log deleted successfully.'];
        } catch (Exception $e) {
            error_log('Error in deleteCallLog: ' . $e->getMessage());
            return ['status' => false, 'message' => 'Failed to delete call log: ' . $e->getMessage()];
        }
    }
}
?>