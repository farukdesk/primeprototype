<?php
/**
 * User Management Controller
 * Created on: 2026-01-14
 * Purpose: Handle user CRUD operations - Admin only
 */

require_once __DIR__ . '/../models/user_model.php';

class UserManagementController {
    private $conn;
    private $user_id;
    private $user_type;
    private $userModel;

    public function __construct($conn) {
        $this->conn = $conn;
        $this->user_id = $_SESSION['user_id'] ?? 0;
        $this->user_type = $this->getUserType();
        $this->userModel = new UserModel($conn);
    }

    private function getUserType() {
        $stmt = $this->conn->prepare("SELECT user_type FROM users WHERE id = ?");
        $stmt->bindParam(1, $this->user_id, PDO::PARAM_INT);
        $stmt->execute();
        $userType = $stmt->fetchColumn();
        return $userType ?: '';
    }

    public function isAdmin() {
        return in_array($this->user_type, ['Admin', 'Super Admin']);
    }

    public function handleRequest() {
        if (!$this->isAdmin()) {
            return ['error' => 'Access denied. Admin privileges required.'];
        }

        // Get filter parameters
        $filters = [
            'user_type' => isset($_GET['user_type']) ? $_GET['user_type'] : '',
            'status' => isset($_GET['status']) ? $_GET['status'] : '',
            'search' => isset($_GET['search']) ? trim($_GET['search']) : ''
        ];
        
        // Get users using model
        return $this->userModel->getUsers($filters);
    }
    
    public function createUser($data) {
        if (!$this->isAdmin()) {
            return ['status' => false, 'message' => 'Permission denied. Only Admin can create users.'];
        }
        
        // Validate required fields
        foreach (['email', 'password', 'user_type', 'first_name', 'last_name'] as $field) {
            if (empty($data[$field])) {
                return ['status' => false, 'message' => ucfirst(str_replace('_', ' ', $field)) . ' is required.'];
            }
        }
        
        // Validate email format
        if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            return ['status' => false, 'message' => 'Invalid email format.'];
        }
        
        // Create user using model
        return $this->userModel->createUser($data, $this->user_id);
    }
    
    public function getUser($id) {
        if (!$this->isAdmin()) {
            return ['status' => false, 'message' => 'Permission denied.'];
        }
        return $this->userModel->getUserById($id);
    }
    
    public function updateUser($data) {
        if (!$this->isAdmin()) {
            return ['status' => false, 'message' => 'Permission denied. Only Admin can update users.'];
        }
        
        // Validate required fields
        foreach (['user_id', 'email', 'user_type', 'first_name', 'last_name'] as $field) {
            if (empty($data[$field])) {
                return ['status' => false, 'message' => ucfirst(str_replace('_', ' ', $field)) . ' is required.'];
            }
        }
        
        // Validate email format
        if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            return ['status' => false, 'message' => 'Invalid email format.'];
        }
        
        // Update user using model
        return $this->userModel->updateUser($data, $this->user_id);
    }
    
    public function deleteUser($id) {
        if (!$this->isAdmin()) {
            return ['status' => false, 'message' => 'Permission denied. Only Admin can delete users.'];
        }
        
        // Prevent deleting self
        if ($id == $this->user_id) {
            return ['status' => false, 'message' => 'You cannot delete your own account.'];
        }
        
        // Delete user using model
        return $this->userModel->deleteUser($id);
    }
}
?>
