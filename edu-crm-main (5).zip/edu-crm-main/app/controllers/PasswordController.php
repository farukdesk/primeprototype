<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../models/Password.php';
require_once __DIR__ . '/../../email-templates/system-emails/PasswordChangedEmail.php';

class PasswordController {
    private $passwordModel;

    public function __construct($db) {
        $this->passwordModel = new Password($db);
    }

    public function changePassword($data) {
        try {
            // Validate current password
            if (!$this->passwordModel->verifyCurrentPassword($data['user_id'], $data['current_password'])) {
                throw new Exception("Current password is incorrect");
            }

            // Validate new password
            $this->validateNewPassword($data['new_password'], $data['confirm_password']);

            // Update password
            $success = $this->passwordModel->updatePassword($data['user_id'], $data['new_password']);

            if ($success) {
                // Get user data for email
                $user = $this->getUserData($data['user_id']);

                // Send password changed email notification
                $this->sendPasswordChangedEmail($user);
            }

            return $success;
        } catch (Exception $e) {
            error_log("Password change error: " . $e->getMessage());
            throw $e;
        }
    }

    private function getUserData($userId) {
        try {
            $stmt = $this->passwordModel->getConnection()->prepare("
                SELECT id, email
                FROM users
                WHERE id = :user_id
            ");
            $stmt->execute(['user_id' => $userId]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Error fetching user data: " . $e->getMessage());
            throw new Exception("Error processing request");
        }
    }

    private function sendPasswordChangedEmail($user) {
        try {
            // Create security information
            $securityInfo = [
                'timestamp' => gmdate('Y-m-d H:i:s'), // UTC time
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'Unknown',
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
                'location' => 'Unknown' // You can add location detection if needed
            ];

            // Initialize email template
            $emailTemplate = new sendPasswordChangedEmail($user, $securityInfo);

            // Set up email headers
            $headers = [
                'MIME-Version: 1.0',
                'Content-type: text/html; charset=UTF-8',
                'From: PUMIS Security Team <noreply@khanassociates.co.uk>',
                'X-Mailer: PHP/' . phpversion()
            ];

            // Send the email
            mail(
                $user['email'],
                $emailTemplate->getSubject(),
                $emailTemplate->getBody(),
                implode("\r\n", $headers)
            );

            // Log the email sending
            error_log("Password change notification email sent to user ID: {$user['id']}");
        } catch (Exception $e) {
            error_log("Error sending password changed email: " . $e->getMessage());
            // Don't throw the exception as email sending shouldn't block the password change
        }
    }

    private function validateNewPassword($newPassword, $confirmPassword) {
        // Existing validation code remains the same
        if ($newPassword !== $confirmPassword) {
            throw new Exception("New passwords do not match");
        }

        if (strlen($newPassword) < 8) {
            throw new Exception("Password must be at least 8 characters long");
        }

        if (!preg_match("/[A-Z]/", $newPassword)) {
            throw new Exception("Password must contain at least one uppercase letter");
        }

        if (!preg_match("/[a-z]/", $newPassword)) {
            throw new Exception("Password must contain at least one lowercase letter");
        }

        if (!preg_match("/[0-9]/", $newPassword)) {
            throw new Exception("Password must contain at least one number");
        }

        if (!preg_match("/[!@#$%^&*()\-_=+{};:,<.>]/", $newPassword)) {
            throw new Exception("Password must contain at least one special character");
        }

        return true;
    }
}
?>