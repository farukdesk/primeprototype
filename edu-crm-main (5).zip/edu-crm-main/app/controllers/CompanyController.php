<?php
require_once __DIR__ . '/../models/Company.php';

class CompanyController {
    private $companyModel;
    private $db;

    public function __construct($db) {
        $this->db = $db;
        $this->companyModel = new Company($db);
    }

    public function showCompany($company_id) {
        try {
            return $this->companyModel->getCompany($company_id);
        } catch (Exception $e) {
            error_log("Error fetching company: " . $e->getMessage());
            return false;
        }
    }

    public function updateCompany($data) {
        try {
            // Validate unique fields
            $validation = $this->companyModel->validateUniqueFields($data, $data['id']);
            if (!$validation['status']) {
                throw new Exception($validation['message']);
            }

            // Prepare company data
            $companyData = [
                'id' => $data['id'],
                'company_name' => $data['company_name'],
                'contact_first_name' => $data['contact_first_name'],
                'contact_last_name' => $data['contact_last_name'],
                'phone_number' => $data['phone_number'],
                'website_url' => $data['website_url'],
                'contact_email' => $data['contact_email'],
                'system_email' => $data['system_email'],
                'address' => $data['address'],
                'status' => $data['status']
            ];

            // Add logo if it exists
            if (isset($data['logo'])) {
                $companyData['logo'] = $data['logo'];
            }

            return $this->companyModel->updateCompany($companyData);
        } catch (Exception $e) {
            error_log("Error updating company: " . $e->getMessage());
            return false;
        }
    }

    public function handleLogoUpload($file, $oldLogo = null) {
        try {
            $uploadDir = $_SERVER['DOCUMENT_ROOT'] . '/storage/uploads/company_logos/';
            
            if (!file_exists($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }

            // Validate file type
            $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
            if (!in_array($file['type'], $allowedTypes)) {
                throw new Exception("Invalid file type. Only JPG, PNG and GIF are allowed.");
            }

            $fileName = uniqid() . '_' . basename($file['name']);
            $targetFile = $uploadDir . $fileName;

            // Delete old logo if exists
            if ($oldLogo) {
                $oldFile = $uploadDir . $oldLogo;
                if (file_exists($oldFile)) {
                    unlink($oldFile);
                }
            }

            if (move_uploaded_file($file['tmp_name'], $targetFile)) {
                return $fileName;
            }
            return false;
        } catch (Exception $e) {
            error_log("Error handling company logo: " . $e->getMessage());
            return false;
        }
    }

    public function validateCompanyData($data) {
        $errors = [];

        if (empty($data['company_name'])) {
            $errors[] = "Company name is required";
        }

        if (empty($data['contact_first_name'])) {
            $errors[] = "Contact first name is required";
        }

        if (empty($data['contact_last_name'])) {
            $errors[] = "Contact last name is required";
        }

        if (empty($data['phone_number']) || !preg_match("/^[0-9+\-\(\) ]+$/", $data['phone_number'])) {
            $errors[] = "Invalid phone number format";
        }

        if (empty($data['contact_email']) || !filter_var($data['contact_email'], FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Invalid contact email address";
        }

        if (empty($data['system_email']) || !filter_var($data['system_email'], FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Invalid system email address";
        }

        if (!empty($data['website_url']) && !filter_var($data['website_url'], FILTER_VALIDATE_URL)) {
            $errors[] = "Invalid website URL";
        }

        if (!in_array($data['status'], ['Active', 'Inactive'])) {
            $errors[] = "Invalid status value";
        }

        return $errors;
    }

    public function getAllCompanies($activeOnly = true) {
        try {
            return $this->companyModel->getAllCompanies($activeOnly);
        } catch (Exception $e) {
            error_log("Error fetching companies: " . $e->getMessage());
            return false;
        }
    }

    public function checkUserPermissions() {
        // Check if user is admin or super admin
        if (!isset($_SESSION['user_type']) || 
            ($_SESSION['user_type'] !== 'Super Admin' && $_SESSION['user_type'] !== 'Admin')) {
            return false;
        }
        return true;
    }
}
?>