<?php
/**
 * University Management Controller
 * Created on: 2025-04-28
 * Created by: farukdesk
 */

require_once __DIR__ . '/../models/university_model.php';

class UniversityManagementController {
    private $conn;
    private $user_id;
    private $user_type;
    private $universityModel;

    public function __construct($conn) {
        $this->conn = $conn;
        $this->user_id = $_SESSION['user_id'] ?? 0;
        $this->user_type = $this->getUserType();
        $this->universityModel = new UniversityModel($conn);
    }

    private function getUserType() {
        $stmt = $this->conn->prepare("SELECT user_type FROM users WHERE id = ?");
        $stmt->bindParam(1, $this->user_id, PDO::PARAM_INT);
        $stmt->execute();
        $userType = $stmt->fetchColumn();
        return $userType ?: '';
    }

    public function hasPermission() {
        // All users can view
        return true;
    }

    public function isSuperAdmin() {
        return $this->user_type === 'Super Admin';
    }

    public function handleRequest() {
        $perPage = 10;
        $page = isset($_GET['p']) ? max(1, (int)$_GET['p']) : 1;
        
        $filters = [
            'search' => isset($_GET['search']) ? trim($_GET['search']) : '',
            'status' => isset($_GET['status']) ? trim($_GET['status']) : ''
        ];
        
        return $this->universityModel->getUniversities($filters, $page, $perPage);
    }
    
    public function createUniversity($data) {
        if (!$this->isSuperAdmin()) {
            return ['status' => false, 'message' => 'Permission denied. Only Super Admin can create universities.'];
        }
        
        // Handle logo upload
        $logoPath = '';
        if (isset($_FILES['logo']) && $_FILES['logo']['error'] == 0) {
            $result = $this->uploadLogo($_FILES['logo']);
            if (!$result['status']) {
                return $result;
            }
            $logoPath = $result['path'];
        }
        
        // Add logo path to data
        $data['logo_path'] = $logoPath;
        
        // Create university using model
        return $this->universityModel->createUniversity($data, $this->user_id);
    }
    
    public function getUniversity($id) {
        return $this->universityModel->getUniversityById($id);
    }
    
    public function updateUniversity($data) {
        if (!$this->isSuperAdmin()) {
            return ['status' => false, 'message' => 'Permission denied. Only Super Admin can update universities.'];
        }
        
        // Validate required fields
        if (empty($data['name']) || empty($data['university_id'])) {
            return ['status' => false, 'message' => 'University name and ID are required.'];
        }
        
        // Get current university data to check for logo changes
        $currentUniversity = $this->getUniversity($data['university_id']);
        if (!$currentUniversity['status']) {
            return ['status' => false, 'message' => 'University not found.'];
        }
        
        $logoPath = $currentUniversity['data']['logo'];
        
        // Handle logo upload if new logo is provided
        if (isset($_FILES['logo']) && $_FILES['logo']['error'] == 0) {
            $result = $this->uploadLogo($_FILES['logo']);
            if (!$result['status']) {
                return $result;
            }
            $logoPath = $result['path'];
            
            // Delete old logo if it exists
            if (!empty($currentUniversity['data']['logo']) && file_exists($currentUniversity['data']['logo'])) {
                unlink($currentUniversity['data']['logo']);
            }
        }
        
        // Add logo path to data
        $data['logo_path'] = $logoPath;
        
        // Update university using model
        return $this->universityModel->updateUniversity($data, $this->user_id);
    }
    
    public function deleteUniversity($id) {
        if (!$this->isSuperAdmin()) {
            return ['status' => false, 'message' => 'Permission denied. Only Super Admin can delete universities.'];
        }
        
        // Get university to delete its logo
        $university = $this->getUniversity($id);
        if (!$university['status']) {
            return ['status' => false, 'message' => 'University not found.'];
        }
        
        // Delete logo file if it exists
        if (!empty($university['data']['logo']) && file_exists($university['data']['logo'])) {
            unlink($university['data']['logo']);
        }
        
        // Delete the university using model
        return $this->universityModel->deleteUniversity($id);
    }
    
    private function uploadLogo($file) {
        $target_dir = "uploads/university_logos/";
        
        // Create directory if it doesn't exist
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        
        // Generate unique filename
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = 'logo_' . time() . '_' . uniqid() . '.' . $ext;
        $target_file = $target_dir . $filename;
        
        // Check file size (max 2MB)
        if ($file['size'] > 2 * 1024 * 1024) {
            return ['status' => false, 'message' => 'Logo file size must be less than 2MB.'];
        }
        
        // Allow only certain image formats
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
        if (!in_array(strtolower($ext), $allowed_types)) {
            return ['status' => false, 'message' => 'Only JPG, JPEG, PNG & GIF files are allowed.'];
        }
        
        // Upload file
        if (move_uploaded_file($file['tmp_name'], $target_file)) {
            return ['status' => true, 'path' => $target_file];
        } else {
            return ['status' => false, 'message' => 'Failed to upload logo file.'];
        }
    }
}
?>