<?php
require_once __DIR__ . '/../models/CompanySubscription.php';

class CompanySubscriptionController {
    private $subscriptionModel;
    private $db;
    private $allowedRoles = ['Super Admin', 'Admin'];

    public function __construct($db) {
        $this->db = $db;
        $this->subscriptionModel = new CompanySubscription($db);
    }

    // Change this method to public
    public function hasPermission() {
        if (!isset($_SESSION['user_type']) || 
            !in_array($_SESSION['user_type'], $this->allowedRoles)) {
            return false;
        }
        return true;
    }

    /**
     * Show subscription details
     * @param int $company_id
     * @return array
     */
    public function showSubscription($company_id) {
        try {
            // Check user permission
            if (!$this->hasPermission()) {
                return [
                    'status' => false,
                    'message' => 'Unauthorized access',
                    'data' => null
                ];
            }

            // Get current subscription details
            $subscription = $this->subscriptionModel->getCompanySubscription($company_id);
            if (!$subscription) {
                return [
                    'status' => false,
                    'message' => 'No subscription found',
                    'data' => null
                ];
            }

            // Get subscription history
            $history = $this->subscriptionModel->getSubscriptionHistory($company_id);

            // Get subscription statistics
            $stats = $this->subscriptionModel->getSubscriptionStats($company_id);

            // Get expiry details
            $expiryDetails = $this->subscriptionModel->getSubscriptionExpiryDetails($company_id);

            // Format dates and calculate remaining time
            $formattedData = $this->formatSubscriptionData($subscription, $history, $stats, $expiryDetails);

            return [
                'status' => true,
                'message' => 'Subscription details retrieved successfully',
                'data' => $formattedData
            ];

        } catch (Exception $e) {
            error_log("Error in showSubscription: " . $e->getMessage());
            return [
                'status' => false,
                'message' => 'Error retrieving subscription details',
                'data' => null
            ];
        }
    }

    /**
     * Format subscription data for display
     * @param array $subscription
     * @param array $history
     * @param array $stats
     * @param array $expiryDetails
     * @return array
     */
    private function formatSubscriptionData($subscription, $history, $stats, $expiryDetails) {
        // Get current UTC timestamp
        $currentUTC = new DateTime('now', new DateTimeZone('UTC'));
        
        // Format subscription data
        $formattedSubscription = [
            'current_subscription' => [
                'plan_name' => $subscription['plan_name'],
                'status' => $subscription['current_status'],
                'start_date' => (new DateTime($subscription['start_date']))->format('Y-m-d H:i:s'),
                'end_date' => (new DateTime($subscription['end_date']))->format('Y-m-d H:i:s'),
                'price_paid' => number_format($subscription['price_paid'], 2),
                'payment_status' => $subscription['payment_status'],
                'payment_method' => $subscription['payment_method'] ?? 'Not specified',
                'transaction_id' => $subscription['transaction_id'] ?? 'Not available'
            ],
            'plan_details' => [
                'description' => $subscription['plan_description'],
                'duration' => $subscription['plan_duration'] . ' days',
                'regular_price' => number_format($subscription['plan_price'], 2)
            ],
            'subscription_history' => array_map(function($item) {
                return [
                    'start_date' => (new DateTime($item['start_date']))->format('Y-m-d H:i:s'),
                    'end_date' => (new DateTime($item['end_date']))->format('Y-m-d H:i:s'),
                    'plan_name' => $item['plan_name'],
                    'status' => $item['subscription_status'],
                    'price_paid' => number_format($item['price_paid'], 2),
                    'payment_status' => $item['payment_status']
                ];
            }, $history),
            'statistics' => [
                'total_subscriptions' => $stats['total_subscriptions'],
                'total_amount_paid' => number_format($stats['total_amount_paid'], 2),
                'subscription_since' => (new DateTime($stats['first_subscription_date']))->format('Y-m-d H:i:s')
            ]
        ];

        // Add expiry information if subscription is active
        if ($subscription['current_status'] === 'Active') {
            $formattedSubscription['expiry_details'] = [
                'days_remaining' => $expiryDetails['days_remaining'],
                'expiry_date' => (new DateTime($expiryDetails['end_date']))->format('Y-m-d H:i:s')
            ];
        }

        return $formattedSubscription;
    }

    /**
     * Check if current user has permission to view subscription details
     * @return bool
     */
    private function checkUserPermission() {
        if (!isset($_SESSION['user_type']) || 
            !in_array($_SESSION['user_type'], $this->allowedRoles)) {
            return false;
        }
        return true;
    }

    /**
     * Get subscription status with color coding
     * @param string $status
     * @return array
     */
    public function getStatusWithColor($status) {
        $statusColors = [
            'Active' => 'success',
            'Expired' => 'danger',
            'Cancelled' => 'warning',
            'Suspended' => 'secondary'
        ];

        return [
            'status' => $status,
            'color' => $statusColors[$status] ?? 'primary'
        ];
    }

    /**
     * Check if subscription needs renewal
     * @param array $expiryDetails
     * @return bool
     */
    public function needsRenewal($expiryDetails) {
        return isset($expiryDetails['days_remaining']) && 
               $expiryDetails['days_remaining'] <= 30;
    }
}
?>