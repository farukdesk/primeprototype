<?php
class Company {
    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function getCompany($company_id) {
        try {
            $stmt = $this->conn->prepare("
                SELECT id, company_name, contact_first_name, contact_last_name, 
                       phone_number, website_url, contact_email, system_email, 
                       address, logo, status, created_at, updated_at
                FROM companies 
                WHERE id = :company_id
            ");
            $stmt->execute(['company_id' => $company_id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Error in getCompany: " . $e->getMessage());
            throw $e;
        }
    }

    public function updateCompany($data) {
        try {
            $this->conn->beginTransaction();

            $stmt = $this->conn->prepare("
                UPDATE companies 
                SET company_name = :company_name,
                    contact_first_name = :contact_first_name,
                    contact_last_name = :contact_last_name,
                    phone_number = :phone_number,
                    website_url = :website_url,
                    contact_email = :contact_email,
                    system_email = :system_email,
                    address = :address,
                    logo = :logo,
                    status = :status
                WHERE id = :id
            ");

            $result = $stmt->execute([
                'id' => $data['id'],
                'company_name' => $data['company_name'],
                'contact_first_name' => $data['contact_first_name'],
                'contact_last_name' => $data['contact_last_name'],
                'phone_number' => $data['phone_number'],
                'website_url' => $data['website_url'],
                'contact_email' => $data['contact_email'],
                'system_email' => $data['system_email'],
                'address' => $data['address'],
                'logo' => $data['logo'] ?? null,
                'status' => $data['status']
            ]);

            if ($result) {
                $this->conn->commit();
                return true;
            } else {
                $this->conn->rollBack();
                return false;
            }
        } catch (PDOException $e) {
            $this->conn->rollBack();
            error_log("Error in updateCompany: " . $e->getMessage());
            return false;
        }
    }

    public function getCompanyLogo($company_id) {
        try {
            $stmt = $this->conn->prepare("
                SELECT logo 
                FROM companies 
                WHERE id = :company_id
            ");
            $stmt->execute(['company_id' => $company_id]);
            return $stmt->fetchColumn();
        } catch (PDOException $e) {
            error_log("Error getting company logo: " . $e->getMessage());
            return false;
        }
    }

    public function validateUniqueFields($data, $exclude_id = null) {
        try {
            // Check for unique company name
            $stmt = $this->conn->prepare("
                SELECT COUNT(*) 
                FROM companies 
                WHERE company_name = :company_name 
                " . ($exclude_id ? "AND id != :exclude_id" : "")
            );
            
            $params = ['company_name' => $data['company_name']];
            if ($exclude_id) {
                $params['exclude_id'] = $exclude_id;
            }
            
            $stmt->execute($params);
            if ($stmt->fetchColumn() > 0) {
                return ['status' => false, 'message' => 'Company name already exists'];
            }

            // Check for unique emails
            $stmt = $this->conn->prepare("
                SELECT COUNT(*) 
                FROM companies 
                WHERE (contact_email = :contact_email OR system_email = :system_email)
                " . ($exclude_id ? "AND id != :exclude_id" : "")
            );
            
            $params = [
                'contact_email' => $data['contact_email'],
                'system_email' => $data['system_email']
            ];
            if ($exclude_id) {
                $params['exclude_id'] = $exclude_id;
            }
            
            $stmt->execute($params);
            if ($stmt->fetchColumn() > 0) {
                return ['status' => false, 'message' => 'Email address already in use'];
            }

            return ['status' => true];
        } catch (PDOException $e) {
            error_log("Error in validateUniqueFields: " . $e->getMessage());
            return ['status' => false, 'message' => 'Database error occurred'];
        }
    }

    public function getAllCompanies($active_only = true) {
        try {
            $query = "
                SELECT id, company_name, contact_first_name, contact_last_name, 
                       phone_number, status, created_at 
                FROM companies
            ";
            
            if ($active_only) {
                $query .= " WHERE status = 'Active'";
            }
            
            $query .= " ORDER BY company_name ASC";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Error in getAllCompanies: " . $e->getMessage());
            return false;
        }
    }
}
?>