<?php
/**
 * Call Log Model
 * Created on: 2025-05-05
 * Created by: farukdesk
 */

class CallLogModel {
    private $conn;
    
    public function __construct($conn) {
        $this->conn = $conn;
    }
    
    /**
     * Record a call log when lead status changes
     * 
     * @param int $leadId Lead ID
     * @param int $staffId Staff ID who made the call
     * @param string $previousStatus Previous lead status
     * @param string $newStatus New lead status
     * @param string $callNotes Optional call notes
     * @param int $callDuration Optional call duration in seconds
     * @return array Status and message
     */
    public function recordCallLog($leadId, $staffId, $previousStatus, $newStatus, $callNotes = '', $callDuration = null) {
        try {
            // Determine call type based on status change
            $callType = $this->determineCallType($previousStatus, $newStatus);
            
            // If not a valid call type, don't create a log
            if (!$callType) {
                return ['status' => false, 'message' => 'Not a valid call status change.'];
            }
            
            // Check if conversion happened
            $callConverted = ($newStatus === 'Admitted') ? 1 : 0;
            
            // Insert call log
            $query = "INSERT INTO call_logs 
                     (lead_id, staff_id, call_type, previous_status, new_status, 
                      call_notes, call_duration, call_converted)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                     
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(1, $leadId, PDO::PARAM_INT);
            $stmt->bindParam(2, $staffId, PDO::PARAM_INT);
            $stmt->bindParam(3, $callType, PDO::PARAM_STR);
            $stmt->bindParam(4, $previousStatus, PDO::PARAM_STR);
            $stmt->bindParam(5, $newStatus, PDO::PARAM_STR);
            $stmt->bindParam(6, $callNotes, PDO::PARAM_STR);
            $stmt->bindParam(7, $callDuration, PDO::PARAM_INT);
            $stmt->bindParam(8, $callConverted, PDO::PARAM_INT);
            
            $stmt->execute();
            
            return [
                'status' => true, 
                'message' => 'Call log recorded successfully.',
                'call_id' => $this->conn->lastInsertId()
            ];
            
        } catch (Exception $e) {
            error_log('Error in recordCallLog: ' . $e->getMessage());
            return ['status' => false, 'message' => 'Failed to record call log: ' . $e->getMessage()];
        }
    }
    
    /**
     * Determine call type based on status change
     * 
     * @param string $previousStatus Previous lead status
     * @param string $newStatus New lead status
     * @return string|bool Call type or false if not a valid call
     */
    private function determineCallType($previousStatus, $newStatus) {
        // Map status changes to call types
        // ONLY count successful call progressions, not failed attempts or administrative changes
        $callTypeMap = [
            'Fresh' => [
                '1st call' => '1st call'
                // Note: Fresh → Unable to reach should NOT count as a call
            ],
            '1st call' => [
                '2nd call' => '2nd call',
                'Will visit office' => 'Office visit confirmation',
                'Admitted' => 'Final call - Admitted'
                // Note: 1st call → Unable to reach should NOT count as a call
            ],
            '2nd call' => [
                '3rd call' => '3rd call',
                'Will visit office' => 'Office visit confirmation',
                'Admitted' => 'Final call - Admitted'
                // Note: 2nd call → Unable to reach should NOT count as a call
            ],
            '3rd call' => [
                'Will visit office' => 'Office visit confirmation',
                'Admitted' => 'Final call - Admitted'
                // Note: 3rd call → Unable to reach should NOT count as a call
            ],
            'Unable to reach once' => [
                '1st call' => '1st call - Reached after attempt'
                // Note: Unable to reach → Dead should NOT count as a call
            ],
            'Unable to reach twice' => [
                '1st call' => '1st call - Reached after attempt'
                // Note: Unable to reach → Dead should NOT count as a call
            ],
            'Unable to reach trice' => [
                '1st call' => '1st call - Reached after attempt'
                // Note: Unable to reach → Dead should NOT count as a call
            ],
            'Will visit office' => [
                'Admitted' => 'Final call - Admitted'
            ]
        ];
        
        // If the previous status is in our map and the new status is valid for that change
        if (isset($callTypeMap[$previousStatus]) && isset($callTypeMap[$previousStatus][$newStatus])) {
            return $callTypeMap[$previousStatus][$newStatus];
        }
        
        // If not a tracked call type (e.g., administrative changes, backwards movements, failed attempts)
        // Return false to indicate this should NOT be logged as a call
        return false;
    }
    
    /**
     * Get call logs with filters and pagination
     * 
     * @param array $filters The filters to apply
     * @param int $page The current page number
     * @param int $perPage The number of items per page
     * @return array The result with data and pagination info
     */
    public function getCallLogs($filters = [], $page = 1, $perPage = 10) {
        $offset = ($page - 1) * $perPage;
        
        // Base query
        $query = "SELECT cl.*,
                    CONCAT(up_staff.first_name, ' ', up_staff.last_name) as staff_name,
                    CONCAT(l.first_name, ' ', l.last_name) as lead_name,
                    l.email as lead_email,
                    l.phone as lead_phone
                 FROM call_logs cl
                 INNER JOIN users u_staff ON cl.staff_id = u_staff.id
                 INNER JOIN user_profile up_staff ON u_staff.id = up_staff.user_id
                 INNER JOIN leads l ON cl.lead_id = l.id
                 WHERE 1=1";
                 
        $countQuery = "SELECT COUNT(*) as total FROM call_logs cl WHERE 1=1";
        
        $params = [];
        $countParams = [];
        
        // Apply filters
        if (!empty($filters['staff_id'])) {
            $query .= " AND cl.staff_id = ?";
            $countQuery .= " AND cl.staff_id = ?";
            $params[] = $filters['staff_id'];
            $countParams[] = $filters['staff_id'];
        }
        
        if (!empty($filters['lead_id'])) {
            $query .= " AND cl.lead_id = ?";
            $countQuery .= " AND cl.lead_id = ?";
            $params[] = $filters['lead_id'];
            $countParams[] = $filters['lead_id'];
        }
        
        if (!empty($filters['call_type'])) {
            $query .= " AND cl.call_type = ?";
            $countQuery .= " AND cl.call_type = ?";
            $params[] = $filters['call_type'];
            $countParams[] = $filters['call_type'];
        }
        
        if (!empty($filters['date_from'])) {
            $query .= " AND DATE(cl.call_date) >= ?";
            $countQuery .= " AND DATE(cl.call_date) >= ?";
            $params[] = $filters['date_from'];
            $countParams[] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $query .= " AND DATE(cl.call_date) <= ?";
            $countQuery .= " AND DATE(cl.call_date) <= ?";
            $params[] = $filters['date_to'];
            $countParams[] = $filters['date_to'];
        }
        
        if (!empty($filters['converted'])) {
            $query .= " AND cl.call_converted = 1";
            $countQuery .= " AND cl.call_converted = 1";
        }
        
        if (!empty($filters['search'])) {
            $searchTerm = "%{$filters['search']}%";
            $query .= " AND (CONCAT(up_staff.first_name, ' ', up_staff.last_name) LIKE ? 
                         OR CONCAT(l.first_name, ' ', l.last_name) LIKE ?
                         OR l.email LIKE ?
                         OR l.phone LIKE ?)";
            $countQuery .= " AND (CONCAT(up_staff.first_name, ' ', up_staff.last_name) LIKE ? 
                             OR CONCAT(l.first_name, ' ', l.last_name) LIKE ?
                             OR l.email LIKE ?
                             OR l.phone LIKE ?)";
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $countParams[] = $searchTerm;
            $countParams[] = $searchTerm;
            $countParams[] = $searchTerm;
            $countParams[] = $searchTerm;
        }
        
        // Add sorting
        $query .= " ORDER BY cl.call_date DESC";
        
        // Add pagination
        $query .= " LIMIT ? OFFSET ?";
        
        // Prepare and execute count query
        $countStmt = $this->conn->prepare($countQuery);
        if (!empty($countParams)) {
            for ($i = 0; $i < count($countParams); $i++) {
                $paramType = is_int($countParams[$i]) ? PDO::PARAM_INT : PDO::PARAM_STR;
                $countStmt->bindValue($i + 1, $countParams[$i], $paramType);
            }
        }
        $countStmt->execute();
        $totalRecords = $countStmt->fetchColumn();
        
        // Add pagination parameters
        $params[] = $perPage;
        $params[] = $offset;
        
        // Prepare and execute main query
        $stmt = $this->conn->prepare($query);
        for ($i = 0; $i < count($params); $i++) {
            $paramType = is_int($params[$i]) ? PDO::PARAM_INT : PDO::PARAM_STR;
            $stmt->bindValue($i + 1, $params[$i], $paramType);
        }
        $stmt->execute();
        
        $callLogs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Calculate pagination info
        $totalPages = ceil($totalRecords / $perPage);
        
        return [
            'data' => $callLogs,
            'pagination' => [
                'total' => $totalPages,
                'current' => $page,
                'total_records' => $totalRecords,
                'per_page' => $perPage
            ],
            'filters' => $filters
        ];
    }
    
    /**
     * Get staff call statistics
     * 
     * @return array Array of staff call statistics
     */
    public function getStaffCallStats() {
        $today = date('Y-m-d');
        $weekStart = date('Y-m-d', strtotime('monday this week'));
        $monthStart = date('Y-m-01');
        
        $query = "SELECT 
                    u.id as staff_id,
                    CONCAT(up.first_name, ' ', up.last_name) as staff_name,
                    up.profile_photo,
                    up.designation,
                    
                    /* Today's calls count */
                    (SELECT COUNT(*) FROM call_logs 
                     WHERE staff_id = u.id AND DATE(call_date) = ?) as today_calls,
                    
                    /* This week's calls count */
                    (SELECT COUNT(*) FROM call_logs 
                     WHERE staff_id = u.id AND DATE(call_date) >= ?) as week_calls,
                    
                    /* This month's calls count */
                    (SELECT COUNT(*) FROM call_logs 
                     WHERE staff_id = u.id AND DATE(call_date) >= ?) as month_calls,
                    
                    /* This month's converted leads count */
                    (SELECT COUNT(*) FROM call_logs 
                     WHERE staff_id = u.id AND DATE(call_date) >= ? AND call_converted = 1) as month_conversions,
                     
                    /* Total calls all time */
                    (SELECT COUNT(*) FROM call_logs WHERE staff_id = u.id) as total_calls
                    
                FROM users u
                INNER JOIN user_profile up ON u.id = up.user_id
                WHERE u.user_type = 'Counselor' AND u.account_status = 'Active'
                ORDER BY month_calls DESC, today_calls DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $today);
        $stmt->bindParam(2, $weekStart);
        $stmt->bindParam(3, $monthStart);
        $stmt->bindParam(4, $monthStart);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Get staff call statistics by staff ID
     * 
     * @param int $staffId Staff ID
     * @return array Staff call statistics
     */
    public function getStaffCallStatsByStaffId($staffId) {
        $today = date('Y-m-d');
        $weekStart = date('Y-m-d', strtotime('monday this week'));
        $monthStart = date('Y-m-01');
        
        $query = "SELECT 
                    u.id as staff_id,
                    CONCAT(up.first_name, ' ', up.last_name) as staff_name,
                    up.profile_photo,
                    up.designation,
                    
                    /* Today's calls count */
                    (SELECT COUNT(*) FROM call_logs 
                     WHERE staff_id = u.id AND DATE(call_date) = ?) as today_calls,
                    
                    /* This week's calls count */
                    (SELECT COUNT(*) FROM call_logs 
                     WHERE staff_id = u.id AND DATE(call_date) >= ?) as week_calls,
                    
                    /* This month's calls count */
                    (SELECT COUNT(*) FROM call_logs 
                     WHERE staff_id = u.id AND DATE(call_date) >= ?) as month_calls,
                    
                    /* This month's converted leads count */
                    (SELECT COUNT(*) FROM call_logs 
                     WHERE staff_id = u.id AND DATE(call_date) >= ? AND call_converted = 1) as month_conversions,
                     
                    /* Total calls all time */
                    (SELECT COUNT(*) FROM call_logs WHERE staff_id = u.id) as total_calls
                    
                FROM users u
                INNER JOIN user_profile up ON u.id = up.user_id
                WHERE u.id = ? AND u.account_status = 'Active'
                LIMIT 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $today);
        $stmt->bindParam(2, $weekStart);
        $stmt->bindParam(3, $monthStart);
        $stmt->bindParam(4, $monthStart);
        $stmt->bindParam(5, $staffId, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    /**
     * Get leads handled by a specific staff member
     * 
     * @param int $staffId Staff ID
     * @param int $page Page number
     * @param int $perPage Items per page
     * @return array Leads handled by staff
     */
    public function getLeadsByStaffId($staffId, $page = 1, $perPage = 10) {
        $offset = ($page - 1) * $perPage;
        
        // Get unique leads that this staff member has called
        $query = "SELECT DISTINCT cl.lead_id,
                    CONCAT(l.first_name, ' ', l.last_name) as lead_name,
                    l.email, l.phone, l.lead_status,
                    (SELECT MAX(cl2.call_date) FROM call_logs cl2 WHERE cl2.lead_id = cl.lead_id AND cl2.staff_id = ?) as last_call_date,
                    (SELECT COUNT(*) FROM call_logs cl3 WHERE cl3.lead_id = cl.lead_id AND cl3.staff_id = ?) as call_count
                  FROM call_logs cl
                  INNER JOIN leads l ON cl.lead_id = l.id
                  WHERE cl.staff_id = ?
                  ORDER BY last_call_date DESC
                  LIMIT ? OFFSET ?";
                  
        $countQuery = "SELECT COUNT(DISTINCT cl.lead_id) as total
                     FROM call_logs cl
                     WHERE cl.staff_id = ?";
        
        // Get total count
        $countStmt = $this->conn->prepare($countQuery);
        $countStmt->bindParam(1, $staffId, PDO::PARAM_INT);
        $countStmt->execute();
        $totalRecords = $countStmt->fetchColumn();
        
        // Get paginated data
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $staffId, PDO::PARAM_INT);
        $stmt->bindParam(2, $staffId, PDO::PARAM_INT);
        $stmt->bindParam(3, $staffId, PDO::PARAM_INT);
        $stmt->bindParam(4, $perPage, PDO::PARAM_INT);
        $stmt->bindParam(5, $offset, PDO::PARAM_INT);
        $stmt->execute();
        
        $leads = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Calculate pagination info
        $totalPages = ceil($totalRecords / $perPage);
        
        return [
            'data' => $leads,
            'pagination' => [
                'total' => $totalPages,
                'current' => $page,
                'total_records' => $totalRecords,
                'per_page' => $perPage
            ]
        ];
    }
}
?>