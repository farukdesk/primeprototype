<?php
/**
 * University Model
 * Created on: 2025-04-28
 * Created by: farukdesk
 */

class UniversityModel {
    private $conn;
    
    public function __construct($conn) {
        $this->conn = $conn;
    }
    
    /**
     * Get all universities with filters and pagination
     * 
     * @param array $filters The filters to apply
     * @param int $page The current page number
     * @param int $perPage The number of items per page
     * @return array The result with data and pagination info
     */
    public function getUniversities($filters = [], $page = 1, $perPage = 10) {
        $offset = ($page - 1) * $perPage;
        
        $search = $filters['search'] ?? '';
        $status = $filters['status'] ?? '';
        
        // Base query
        $query = "SELECT * FROM universities WHERE 1=1";
        $countQuery = "SELECT COUNT(*) as total FROM universities WHERE 1=1";
        $params = [];
        
        // Add search condition if provided
        if (!empty($search)) {
            $searchTerm = "%$search%";
            $query .= " AND (name LIKE ? OR address LIKE ?)";
            $countQuery .= " AND (name LIKE ? OR address LIKE ?)";
            $params[] = $searchTerm;
            $params[] = $searchTerm;
        }
        
        // Add status filter if provided
        if (!empty($status)) {
            $query .= " AND status = ?";
            $countQuery .= " AND status = ?";
            $params[] = $status;
        }
        
        // Add sorting
        $query .= " ORDER BY name ASC LIMIT ? OFFSET ?";
        
        // Prepare and execute count query
        $countStmt = $this->conn->prepare($countQuery);
        if (!empty($params)) {
            for ($i = 0; $i < count($params); $i++) {
                $countStmt->bindValue($i + 1, $params[$i]);
            }
        }
        $countStmt->execute();
        $totalRecords = $countStmt->fetchColumn();
        
        // Prepare and execute main query with pagination params
        $queryParams = $params;
        $queryParams[] = $perPage;
        $queryParams[] = $offset;
        
        $stmt = $this->conn->prepare($query);
        for ($i = 0; $i < count($queryParams); $i++) {
            $paramType = is_int($queryParams[$i]) ? PDO::PARAM_INT : PDO::PARAM_STR;
            $stmt->bindValue($i + 1, $queryParams[$i], $paramType);
        }
        $stmt->execute();
        
        $universities = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Calculate pagination
        $totalPages = ceil($totalRecords / $perPage);
        
        return [
            'data' => $universities,
            'pagination' => [
                'total' => $totalPages,
                'current' => $page,
                'total_records' => $totalRecords
            ],
            'filters' => [
                'search' => $search,
                'status' => $status
            ],
            'stats' => [
                'total_universities' => $totalRecords,
                'active_universities' => $this->countActiveUniversities()
            ]
        ];
    }
    
    /**
     * Count active universities
     * 
     * @return int The number of active universities
     */
    private function countActiveUniversities() {
        $stmt = $this->conn->prepare("SELECT COUNT(*) as total FROM universities WHERE status = 'Active'");
        $stmt->execute();
        return $stmt->fetchColumn();
    }
    
    /**
     * Get a single university by ID
     * 
     * @param int $id The university ID
     * @return array The university data or error message
     */
    public function getUniversityById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM universities WHERE id = ?");
        $stmt->bindParam(1, $id, PDO::PARAM_INT);
        $stmt->execute();
        
        $university = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($university) {
            return ['status' => true, 'data' => $university];
        } else {
            return ['status' => false, 'message' => 'University not found.'];
        }
    }
    
    /**
     * Create a new university
     * 
     * @param array $data The university data
     * @param int $userId The user creating the university
     * @return array Status and message
     */
    public function createUniversity($data, $userId) {
        // Validate required fields
        if (empty($data['name'])) {
            return ['status' => false, 'message' => 'University name is required.'];
        }
        
        // Prepare and execute query
        $stmt = $this->conn->prepare("INSERT INTO universities (name, address, website, logo, status, created_by) 
                                     VALUES (?, ?, ?, ?, ?, ?)");
        $status = $data['status'] ?? 'Active';
        $address = $data['address'] ?? '';
        $website = $data['website'] ?? '';
        $logoPath = $data['logo_path'] ?? '';
        
        $stmt->bindParam(1, $data['name'], PDO::PARAM_STR);
        $stmt->bindParam(2, $address, PDO::PARAM_STR);
        $stmt->bindParam(3, $website, PDO::PARAM_STR);
        $stmt->bindParam(4, $logoPath, PDO::PARAM_STR);
        $stmt->bindParam(5, $status, PDO::PARAM_STR);
        $stmt->bindParam(6, $userId, PDO::PARAM_INT);
        
        if ($stmt->execute()) {
            $newId = $this->conn->lastInsertId();
            return ['status' => true, 'message' => 'University created successfully.', 'id' => $newId];
        } else {
            return ['status' => false, 'message' => 'Failed to create university.'];
        }
    }
    
    /**
     * Update an existing university
     * 
     * @param array $data The university data
     * @param int $userId The user updating the university
     * @return array Status and message
     */
    public function updateUniversity($data, $userId) {
        // Validate required fields
        if (empty($data['name']) || empty($data['university_id'])) {
            return ['status' => false, 'message' => 'University name and ID are required.'];
        }
        
        // Prepare and execute update query
        $stmt = $this->conn->prepare("UPDATE universities SET name = ?, address = ?, website = ?, 
                                     logo = ?, status = ?, updated_by = ? WHERE id = ?");
        $status = $data['status'] ?? 'Active';
        $address = $data['address'] ?? '';
        $website = $data['website'] ?? '';
        $logoPath = $data['logo_path'] ?? '';
        $universityId = $data['university_id'];
        
        $stmt->bindParam(1, $data['name'], PDO::PARAM_STR);
        $stmt->bindParam(2, $address, PDO::PARAM_STR);
        $stmt->bindParam(3, $website, PDO::PARAM_STR);
        $stmt->bindParam(4, $logoPath, PDO::PARAM_STR);
        $stmt->bindParam(5, $status, PDO::PARAM_STR);
        $stmt->bindParam(6, $userId, PDO::PARAM_INT);
        $stmt->bindParam(7, $universityId, PDO::PARAM_INT);
        
        if ($stmt->execute()) {
            return ['status' => true, 'message' => 'University updated successfully.'];
        } else {
            return ['status' => false, 'message' => 'Failed to update university.'];
        }
    }
    
    /**
     * Delete a university by ID
     * 
     * @param int $id The university ID
     * @return array Status and message
     */
    public function deleteUniversity($id) {
        $stmt = $this->conn->prepare("DELETE FROM universities WHERE id = ?");
        $stmt->bindParam(1, $id, PDO::PARAM_INT);
        
        if ($stmt->execute()) {
            return ['status' => true, 'message' => 'University deleted successfully.'];
        } else {
            return ['status' => false, 'message' => 'Failed to delete university.'];
        }
    }
}
?>