<?php
/**
 * Agent Model
 * Created on: 2026-01-14
 * Description: Handle database operations for agents
 */

class AgentModel {
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    /**
     * Get all agents with their user information
     */
    public function getAllAgents() {
        $query = "
            SELECT a.id, a.user_id, a.agent_name, a.address, a.phone_number, a.email,
                   a.notes, a.is_our_student, a.student_id, a.batch, a.department,
                   a.created_at, a.updated_at,
                   u.account_status, u.created_at as user_created_at,
                   up.first_name, up.last_name, up.mobile_number as profile_phone, up.profile_photo,
                   (SELECT COUNT(*) FROM leads WHERE agent_id = u.id) as lead_count
            FROM agents a
            INNER JOIN users u ON a.user_id = u.id
            LEFT JOIN user_profile up ON u.id = up.user_id
            WHERE u.user_type = 'Agent'
            ORDER BY a.agent_name ASC
        ";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get agent by ID
     */
    public function getAgentById($agentId) {
        $query = "
            SELECT a.id, a.user_id, a.agent_name, a.address, a.phone_number, a.email,
                   a.notes, a.is_our_student, a.student_id, a.batch, a.department,
                   a.created_at, a.updated_at,
                   u.account_status, u.user_type,
                   up.first_name, up.last_name, up.profile_photo
            FROM agents a
            INNER JOIN users u ON a.user_id = u.id
            LEFT JOIN user_profile up ON u.id = up.user_id
            WHERE a.id = ?
        ";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$agentId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Get agent by user ID
     */
    public function getAgentByUserId($userId) {
        $query = "
            SELECT a.id, a.user_id, a.agent_name, a.address, a.phone_number, a.email,
                   a.notes, a.is_our_student, a.student_id, a.batch, a.department,
                   a.created_at, a.updated_at,
                   u.account_status
            FROM agents a
            INNER JOIN users u ON a.user_id = u.id
            WHERE a.user_id = ?
        ";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$userId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Create new agent
     */
    public function createAgent($data) {
        try {
            // Start transaction
            $this->conn->beginTransaction();

            // Validate required fields
            if (empty($data['agent_name']) || empty($data['email'])) {
                throw new Exception("Agent name and email are required");
            }

            // Check if email already exists
            $checkQuery = "SELECT COUNT(*) FROM agents WHERE email = ?";
            $checkStmt = $this->conn->prepare($checkQuery);
            $checkStmt->execute([$data['email']]);
            if ($checkStmt->fetchColumn() > 0) {
                throw new Exception("An agent with this email already exists");
            }

            // Create user account first
            $userQuery = "
                INSERT INTO users (email, password, user_type, account_status, company_id, created_by)
                VALUES (?, ?, 'Agent', 'Active', ?, ?)
            ";
            $defaultPassword = password_hash('Agent@123', PASSWORD_DEFAULT);
            $userStmt = $this->conn->prepare($userQuery);
            $userStmt->execute([
                $data['email'],
                $defaultPassword,
                $data['company_id'] ?? 1,
                $data['created_by']
            ]);
            
            $userId = $this->conn->lastInsertId();

            // Create user profile
            $profileQuery = "
                INSERT INTO user_profile (user_id, first_name, last_name, email, mobile_number)
                VALUES (?, ?, ?, ?, ?)
            ";
            $nameParts = explode(' ', $data['agent_name'], 2);
            $firstName = $nameParts[0];
            $lastName = isset($nameParts[1]) ? $nameParts[1] : '';
            
            $profileStmt = $this->conn->prepare($profileQuery);
            $profileStmt->execute([
                $userId,
                $firstName,
                $lastName,
                $data['email'],
                $data['phone_number'] ?? null
            ]);

            // Insert agent record
            $query = "
                INSERT INTO agents (
                    user_id, agent_name, address, phone_number, email, notes,
                    is_our_student, student_id, batch, department
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute([
                $userId,
                $data['agent_name'],
                $data['address'] ?? null,
                $data['phone_number'] ?? null,
                $data['email'],
                $data['notes'] ?? null,
                isset($data['is_our_student']) && $data['is_our_student'] == '1' ? 1 : 0,
                isset($data['is_our_student']) && $data['is_our_student'] == '1' ? ($data['student_id'] ?? null) : null,
                isset($data['is_our_student']) && $data['is_our_student'] == '1' ? ($data['batch'] ?? null) : null,
                isset($data['is_our_student']) && $data['is_our_student'] == '1' ? ($data['department'] ?? null) : null
            ]);

            $agentId = $this->conn->lastInsertId();

            // Commit transaction
            $this->conn->commit();

            return [
                'status' => true,
                'message' => 'Agent created successfully',
                'agent_id' => $agentId
            ];
        } catch (Exception $e) {
            // Rollback transaction on error
            $this->conn->rollBack();
            return [
                'status' => false,
                'message' => 'Failed to create agent: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Update agent
     */
    public function updateAgent($agentId, $data) {
        try {
            // Start transaction
            $this->conn->beginTransaction();

            // Validate required fields
            if (empty($data['agent_name']) || empty($data['email'])) {
                throw new Exception("Agent name and email are required");
            }

            // Check if email already exists for another agent
            $checkQuery = "SELECT COUNT(*) FROM agents WHERE email = ? AND id != ?";
            $checkStmt = $this->conn->prepare($checkQuery);
            $checkStmt->execute([$data['email'], $agentId]);
            if ($checkStmt->fetchColumn() > 0) {
                throw new Exception("An agent with this email already exists");
            }

            // Get agent's user_id
            $agent = $this->getAgentById($agentId);
            if (!$agent) {
                throw new Exception("Agent not found");
            }

            // Update user email if changed
            if ($agent['email'] !== $data['email']) {
                $userQuery = "UPDATE users SET email = ? WHERE id = ?";
                $userStmt = $this->conn->prepare($userQuery);
                $userStmt->execute([$data['email'], $agent['user_id']]);
            }

            // Update user profile
            $nameParts = explode(' ', $data['agent_name'], 2);
            $firstName = $nameParts[0];
            $lastName = isset($nameParts[1]) ? $nameParts[1] : '';
            
            $profileQuery = "
                UPDATE user_profile 
                SET first_name = ?, last_name = ?, email = ?, mobile_number = ?
                WHERE user_id = ?
            ";
            $profileStmt = $this->conn->prepare($profileQuery);
            $profileStmt->execute([
                $firstName,
                $lastName,
                $data['email'],
                $data['phone_number'] ?? null,
                $agent['user_id']
            ]);

            // Update agent record
            $query = "
                UPDATE agents SET
                    agent_name = ?,
                    address = ?,
                    phone_number = ?,
                    email = ?,
                    notes = ?,
                    is_our_student = ?,
                    student_id = ?,
                    batch = ?,
                    department = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ";
            
            $stmt = $this->conn->prepare($query);
            $isOurStudent = isset($data['is_our_student']) && $data['is_our_student'] == '1' ? 1 : 0;
            
            $stmt->execute([
                $data['agent_name'],
                $data['address'] ?? null,
                $data['phone_number'] ?? null,
                $data['email'],
                $data['notes'] ?? null,
                $isOurStudent,
                $isOurStudent ? ($data['student_id'] ?? null) : null,
                $isOurStudent ? ($data['batch'] ?? null) : null,
                $isOurStudent ? ($data['department'] ?? null) : null,
                $agentId
            ]);

            // Commit transaction
            $this->conn->commit();

            return [
                'status' => true,
                'message' => 'Agent updated successfully'
            ];
        } catch (Exception $e) {
            // Rollback transaction on error
            $this->conn->rollBack();
            return [
                'status' => false,
                'message' => 'Failed to update agent: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Delete agent
     */
    public function deleteAgent($agentId) {
        try {
            // Start transaction
            $this->conn->beginTransaction();

            // Get agent details
            $agent = $this->getAgentById($agentId);
            if (!$agent) {
                throw new Exception("Agent not found");
            }

            // Check if agent has leads
            $checkQuery = "SELECT COUNT(*) FROM leads WHERE agent_id = ?";
            $checkStmt = $this->conn->prepare($checkQuery);
            $checkStmt->execute([$agent['user_id']]);
            $leadCount = $checkStmt->fetchColumn();

            if ($leadCount > 0) {
                throw new Exception("Cannot delete agent with {$leadCount} associated lead(s). Please reassign or delete the leads first.");
            }

            // Delete agent record (user will be deleted via CASCADE)
            $query = "DELETE FROM agents WHERE id = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$agentId]);

            // Delete user profile
            $profileQuery = "DELETE FROM user_profile WHERE user_id = ?";
            $profileStmt = $this->conn->prepare($profileQuery);
            $profileStmt->execute([$agent['user_id']]);

            // Delete user
            $userQuery = "DELETE FROM users WHERE id = ?";
            $userStmt = $this->conn->prepare($userQuery);
            $userStmt->execute([$agent['user_id']]);

            // Commit transaction
            $this->conn->commit();

            return [
                'status' => true,
                'message' => 'Agent deleted successfully'
            ];
        } catch (Exception $e) {
            // Rollback transaction on error
            $this->conn->rollBack();
            return [
                'status' => false,
                'message' => 'Failed to delete agent: ' . $e->getMessage()
            ];
        }
    }
}
