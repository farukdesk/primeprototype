<?php
/**
 * Enhanced Company Management Model
 * Supports additional features like user grouping and subscription details.
 */

class CompanyManagementModel {
    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    // Get all companies with filters, pagination, and subscription data
/**
 * Get all companies with filters, pagination, and subscription data
 * Created on: 2025-01-16 04:01:17
 * Created by: farukdesk
 */
public function getAllCompanies($page = 1, $limit = 10, $filters = []) {
    try {
        error_log("[2025-01-16 04:01:17] Getting companies list - User: farukdesk");
        $offset = ($page - 1) * $limit;

        $query = "
            SELECT 
                c.id,
                c.company_name, 
                c.contact_first_name, 
                c.contact_last_name, 
                c.phone_number, 
                c.website_url, 
                c.contact_email, 
                c.system_email, 
                c.address, 
                c.logo, 
                c.status,
                c.created_by AS created_by_user_id,
                DATE_FORMAT(c.created_at, '%Y-%m-%d %H:%i:%s') AS created_at,
                u.email AS created_by_user_email,
                sp.id AS subscription_plan_id,
                sp.plan_name AS subscription_plan_name, 
                sp.plan_type AS subscription_plan_type,
                sp.price AS subscription_price,
                cs.id AS subscription_id,
                DATE_FORMAT(cs.start_date, '%Y-%m-%d %H:%i:%s') AS subscription_start_date, 
                DATE_FORMAT(cs.end_date, '%Y-%m-%d %H:%i:%s') AS subscription_end_date, 
                cs.subscription_status, 
                cs.price_paid, 
                cs.payment_status, 
                cs.payment_method, 
                cs.transaction_id,
                (
                    SELECT COUNT(*) 
                    FROM users 
                    WHERE company_id = c.id
                ) AS total_staff,
                CASE 
                    WHEN cs.id IS NOT NULL AND cs.subscription_status = 'Active' 
                    AND cs.end_date >= NOW() THEN 
                        CONCAT(sp.plan_name, ' (', sp.plan_type, ')')
                    ELSE 'No Subscription'
                END AS subscription_display
            FROM 
                companies c
            LEFT JOIN 
                company_subscriptions cs ON c.id = cs.company_id
                AND cs.subscription_status = 'Active'
                AND cs.end_date >= NOW()
            LEFT JOIN 
                subscription_plans sp ON cs.subscription_plan_id = sp.id
                AND sp.status = 'Active'
            LEFT JOIN 
                users u ON c.created_by = u.id
            WHERE 1=1
        ";

        // Add filter conditions
        $params = [];
        
        if (!empty($filters['company_name'])) {
            $query .= " AND c.company_name LIKE :company_name";
            $params[':company_name'] = '%' . $filters['company_name'] . '%';
        }

        if (!empty($filters['status'])) {
            $query .= " AND c.status = :status";
            $params[':status'] = $filters['status'];
        }

        // Add order by and limit
        $query .= " ORDER BY c.created_at DESC LIMIT :limit OFFSET :offset";

        $stmt = $this->conn->prepare($query);

        // Bind all parameters
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);

        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Format subscription information
        foreach ($results as &$row) {
            $row['subscription'] = [
                'plan_name' => $row['subscription_plan_name'] ?? 'No Plan',
                'plan_type' => $row['subscription_plan_type'] ?? '',
                'status' => $row['subscription_status'] ?? 'Inactive',
                'start_date' => $row['subscription_start_date'] ?? '',
                'end_date' => $row['subscription_end_date'] ?? '',
                'display' => $row['subscription_display'] ?? 'No Subscription'
            ];

            // Ensure other fields have default values
            $row['created_at'] = $row['created_at'] ?? date('Y-m-d H:i:s');
            $row['total_staff'] = $row['total_staff'] ?? 0;
        }

        error_log("[2025-01-16 04:01:17] Found " . count($results) . " companies - User: farukdesk");
        return $results;

    } catch (Exception $e) {
        error_log("[2025-01-16 04:01:17] Error in getAllCompanies: " . $e->getMessage() . " - User: farukdesk");
        return [];
    }
}
public function getActiveSubscriptions() {
    try {
        $query = "
            SELECT COUNT(*) AS active_subs 
            FROM company_subscriptions cs
            INNER JOIN subscription_plans sp ON cs.subscription_plan_id = sp.id 
            WHERE cs.subscription_status = 'Active' 
            AND cs.end_date >= NOW()
            AND sp.status = 'Active'";
        
        $stmt = $this->conn->query($query);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        error_log("[2025-01-16 03:49:04] Getting active subscriptions count by farukdesk");
        return $result['active_subs'] ?? 0;
        
    } catch (Exception $e) {
        error_log("[2025-01-16 03:49:04] Error in getActiveSubscriptions: " . $e->getMessage());
        return 0;
    }
}
    // View company profile by ID
    public function getCompanyProfile($companyId) {
        try {
$query = "
    SELECT 
        c.*, 
        sp.plan_name AS subscription_plan_name, 
        cs.start_date, 
        cs.end_date, 
        cs.subscription_status, 
        cs.price_paid, 
        cs.payment_status, 
        cs.payment_method, 
        cs.transaction_id, 
        (
            SELECT COUNT(*) 
            FROM users u 
            WHERE u.company_id = c.id
        ) AS staff_count,
        (
            SELECT JSON_ARRAYAGG(user_type) 
            FROM users u 
            WHERE u.company_id = c.id
        ) AS user_types,
        (
            SELECT JSON_OBJECTAGG(
                COALESCE(user_type, 'Unknown'),
                COUNT(*)
            )
            FROM users 
            WHERE company_id = c.id
            GROUP BY company_id
        ) as user_type_distribution
    FROM 
        companies c
    LEFT JOIN 
        company_subscriptions cs ON c.id = cs.company_id
    LEFT JOIN 
        subscription_plans sp ON cs.subscription_plan_id = sp.id
    WHERE 
        c.id = :company_id
";

// Debug log
error_log("[2025-01-16 04:17:03] Query executed by farukdesk - Getting company details with staff distribution");

            $stmt = $this->conn->prepare($query);
            $stmt->bindValue(':company_id', $companyId, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error in getCompanyProfile: " . $e->getMessage());
            return null;
        }
    }

    // Add new company with default admin user
    public function addCompany($data) {
        try {
            $this->conn->beginTransaction();

            // Insert company
            $query = "
                INSERT INTO companies 
                (company_name, contact_first_name, contact_last_name, phone_number, website_url, contact_email, system_email, address, logo, created_by, status) 
                VALUES 
                (:company_name, :contact_first_name, :contact_last_name, :phone_number, :website_url, :contact_email, :system_email, :address, :logo, :created_by, :status)
            ";

            $stmt = $this->conn->prepare($query);
            $stmt->execute([
                ':company_name' => $data['company_name'],
                ':contact_first_name' => $data['contact_first_name'],
                ':contact_last_name' => $data['contact_last_name'],
                ':phone_number' => $data['phone_number'],
                ':website_url' => $data['website_url'],
                ':contact_email' => $data['contact_email'],
                ':system_email' => $data['system_email'],
                ':address' => $data['address'],
                ':logo' => $data['logo'],
                ':created_by' => $data['created_by'],
                ':status' => $data['status']
            ]);

            $companyId = $this->conn->lastInsertId();

            // Create default admin user
            $defaultPassword = password_hash('DefaultPassword123', PASSWORD_BCRYPT);
            $userQuery = "
                INSERT INTO users 
                (email, password, user_type, company_id, created_at) 
                VALUES 
                (:email, :password, 'Admin', :company_id, NOW())
            ";

            $userStmt = $this->conn->prepare($userQuery);
            $userStmt->execute([
                ':email' => $data['contact_email'],
                ':password' => $defaultPassword,
                ':company_id' => $companyId
            ]);

            // Commit transaction
            $this->conn->commit();

            return $companyId;
        } catch (Exception $e) {
            $this->conn->rollBack();
            error_log("Error in addCompany: " . $e->getMessage());
            return false;
        }
    }

    // Delete company by ID
    public function deleteCompany($companyId) {
        try {
            $query = "DELETE FROM companies WHERE id = :company_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindValue(':company_id', $companyId, PDO::PARAM_INT);
            return $stmt->execute();
        } catch (Exception $e) {
            error_log("Error in deleteCompany: " . $e->getMessage());
            return false;
        }
    }

    // Edit company profile
    public function updateCompany($companyId, $data) {
        try {
            $query = "
                UPDATE companies 
                SET 
                    company_name = :company_name,
                    contact_first_name = :contact_first_name,
                    contact_last_name = :contact_last_name,
                    phone_number = :phone_number,
                    website_url = :website_url,
                    contact_email = :contact_email,
                    system_email = :system_email,
                    address = :address,
                    logo = :logo,
                    status = :status
                WHERE 
                    id = :company_id
            ";

            $stmt = $this->conn->prepare($query);
            $stmt->execute([
                ':company_name' => $data['company_name'],
                ':contact_first_name' => $data['contact_first_name'],
                ':contact_last_name' => $data['contact_last_name'],
                ':phone_number' => $data['phone_number'],
                ':website_url' => $data['website_url'],
                ':contact_email' => $data['contact_email'],
                ':system_email' => $data['system_email'],
                ':address' => $data['address'],
                ':logo' => $data['logo'],
                ':status' => $data['status'],
                ':company_id' => $companyId
            ]);

            return true;
        } catch (Exception $e) {
            error_log("Error in updateCompany: " . $e->getMessage());
            return false;
        }
    }

    // Get total number of companies
    public function getTotalCompanies() {
        try {
            $query = "SELECT COUNT(*) AS total FROM companies";
            $stmt = $this->conn->query($query);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result['total'] ?? 0;
        } catch (Exception $e) {
            error_log("Error in getTotalCompanies: " . $e->getMessage());
            return 0;
        }
    }

// Get total number of active companies
public function getActiveCompanies() {
    try {
        $query = "SELECT COUNT(*) AS active_total FROM companies WHERE status = 'Active'";
        $stmt = $this->conn->query($query);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['active_total'] ?? 0;
    } catch (Exception $e) {
        error_log("Error in getActiveCompanies: " . $e->getMessage());
        return 0;
    }
}
// Get total number of users
public function getTotalUsers() {
    try {
        $query = "SELECT COUNT(*) AS total_users FROM users";
        $stmt = $this->conn->query($query);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['total_users'] ?? 0;
    } catch (Exception $e) {
        error_log("Error in getTotalUsers: " . $e->getMessage());
        return 0;
    }
}

// Get subscription summary
public function getSubscriptionSummary() {
    try {
        $query = "
            SELECT 
                sp.plan_name,
                sp.plan_type,
                sp.price,
                COUNT(cs.id) AS total_subscriptions,
                SUM(CASE 
                    WHEN cs.subscription_status = 'Active' 
                    AND cs.end_date >= NOW() 
                    THEN 1 ELSE 0 
                END) AS active_subscriptions,
                SUM(CASE 
                    WHEN cs.payment_status = 'Paid' 
                    THEN cs.price_paid 
                    ELSE 0 
                END) AS total_revenue
            FROM 
                subscription_plans sp
            LEFT JOIN 
                company_subscriptions cs ON sp.id = cs.subscription_plan_id
            WHERE 
                sp.status = 'Active'
            GROUP BY 
                sp.id, sp.plan_name, sp.plan_type, sp.price
            ORDER BY 
                FIELD(sp.plan_type, 'Monthly', 'Yearly', 'Lifetime')
        ";
        
        $stmt = $this->conn->query($query);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    } catch (Exception $e) {
        error_log("[2025-01-16 03:49:04] Error in getSubscriptionSummary: " . $e->getMessage());
        return [];
    }
}
// Get payment summary
public function getPaymentSummary() {
    try {
        $query = "
            SELECT 
                cs.payment_status, 
                COUNT(cs.id) AS total_transactions,
                SUM(cs.price_paid) AS total_amount,
                COUNT(CASE 
                    WHEN cs.subscription_status = 'Active' 
                    AND cs.end_date >= NOW() 
                    THEN 1 
                END) AS active_subscriptions
            FROM 
                company_subscriptions cs
            GROUP BY 
                cs.payment_status
        ";
        
        $stmt = $this->conn->query($query);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    } catch (Exception $e) {
        error_log("[2025-01-16 03:49:04] Error in getPaymentSummary: " . $e->getMessage());
        return [];
    }
}
public function getAvailablePlans() {
    try {
        $query = "
            SELECT 
                id,
                plan_name,
                plan_type,
                price,
                description,
                features,
                status
            FROM 
                subscription_plans
            WHERE 
                status = 'Active'
            ORDER BY 
                FIELD(plan_type, 'Monthly', 'Yearly', 'Lifetime'),
                price ASC
        ";
        
        $stmt = $this->conn->query($query);
        $plans = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Parse JSON features
        foreach ($plans as &$plan) {
            $plan['features'] = json_decode($plan['features'], true) ?? [];
        }
        
        return $plans;
        
    } catch (Exception $e) {
        error_log("[2025-01-16 03:49:04] Error in getAvailablePlans: " . $e->getMessage());
        return [];
    }
}

}
