<?php
class SubscriptionPlan {
    private $conn;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    // Get all subscription plans with filters and pagination
    public function getAllPlans($page = 1, $limit = 10, $filters = []) {
        try {
            // Ensure positive integers for pagination
            $page = max(1, (int)$page);
            $limit = max(1, (int)$limit);
            $offset = ($page - 1) * $limit;
            
            $where = "WHERE 1=1";
            $params = [];
            
            // Apply filters with proper sanitization
            if (!empty($filters['plan_name'])) {
                $where .= " AND plan_name LIKE :plan_name";
                $params[':plan_name'] = '%' . trim($filters['plan_name']) . '%';
            }
            
            if (!empty($filters['plan_type']) && 
                in_array($filters['plan_type'], ['Monthly', 'Yearly', 'Lifetime'])) {
                $where .= " AND plan_type = :plan_type";
                $params[':plan_type'] = $filters['plan_type'];
            }
            
            if (!empty($filters['status']) && 
                in_array($filters['status'], ['Active', 'Inactive'])) {
                $where .= " AND status = :status";
                $params[':status'] = $filters['status'];
            }
            
            // Get total count for pagination
            $countQuery = "SELECT COUNT(*) FROM subscription_plans " . $where;
            $countStmt = $this->conn->prepare($countQuery);
            
            foreach ($params as $key => $value) {
                $countStmt->bindValue($key, $value);
            }
            
            $countStmt->execute();
            $total = (int)$countStmt->fetchColumn();
            
            // Calculate total pages
            $totalPages = max(1, ceil($total / $limit));
            
            // Adjust page if it exceeds total pages
            $page = min($page, $totalPages);
            $offset = ($page - 1) * $limit;
            
            // Get plans with pagination
            $query = "SELECT * FROM subscription_plans {$where} 
                     ORDER BY created_at DESC 
                     LIMIT :limit OFFSET :offset";
            
            $stmt = $this->conn->prepare($query);
            
            // Bind pagination parameters
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
            
            // Bind filter parameters
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            
            $stmt->execute();
            $plans = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Log successful query
            error_log("Successfully fetched plans. Page: $page, Limit: $limit, Total: $total");
            
            return [
                'plans' => $plans,
                'total' => $total,
                'pages' => $totalPages,
                'current_page' => $page
            ];
            
        } catch (PDOException $e) {
            error_log("Error in getAllPlans: " . $e->getMessage());
            return false;
        }
    }
    
    // Get single plan by ID
    public function getPlanById($id) {
        try {
            if (!$id || !is_numeric($id)) {
                error_log("Invalid ID provided to getPlanById");
                return false;
            }
            
            $stmt = $this->conn->prepare("
                SELECT * FROM subscription_plans 
                WHERE id = :id
            ");
            
            $stmt->bindValue(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
            
            $plan = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($plan) {
                // Decode JSON features
                $plan['features'] = json_decode($plan['features'], true);
            }
            
            return $plan;
        } catch (PDOException $e) {
            error_log("Error in getPlanById: " . $e->getMessage());
            return false;
        }
    }
    
    // Create new plan
    public function createPlan($data) {
        try {
            // Validate required fields
            if (!$this->validatePlanData($data)) {
                error_log("Invalid plan data provided to createPlan");
                return false;
            }
            
            $query = "INSERT INTO subscription_plans 
                     (plan_name, plan_type, price, description, features, status) 
                     VALUES (:plan_name, :plan_type, :price, :description, :features, :status)";
            
            $stmt = $this->conn->prepare($query);
            
            // Bind parameters with proper type casting
            $stmt->bindValue(':plan_name', trim($data['plan_name']), PDO::PARAM_STR);
            $stmt->bindValue(':plan_type', $data['plan_type'], PDO::PARAM_STR);
            $stmt->bindValue(':price', (float)$data['price'], PDO::PARAM_STR);
            $stmt->bindValue(':description', trim($data['description'] ?? ''), PDO::PARAM_STR);
            $stmt->bindValue(':features', json_encode(array_map('trim', $data['features'])), PDO::PARAM_STR);
            $stmt->bindValue(':status', $data['status'], PDO::PARAM_STR);
            
            $result = $stmt->execute();
            
            if ($result) {
                error_log("Successfully created new plan: " . $data['plan_name']);
            }
            
            return $result;
        } catch (PDOException $e) {
            error_log("Error in createPlan: " . $e->getMessage());
            return false;
        }
    }
    
    // Update existing plan
    public function updatePlan($id, $data) {
        try {
            // Validate required fields
            if (!$this->validatePlanData($data) || !$id) {
                error_log("Invalid plan data or ID provided to updatePlan");
                return false;
            }
            
            $query = "UPDATE subscription_plans 
                     SET plan_name = :plan_name, 
                         plan_type = :plan_type, 
                         price = :price, 
                         description = :description, 
                         features = :features, 
                         status = :status 
                     WHERE id = :id";
            
            $stmt = $this->conn->prepare($query);
            
            // Bind parameters with proper type casting
            $stmt->bindValue(':id', $id, PDO::PARAM_INT);
            $stmt->bindValue(':plan_name', trim($data['plan_name']), PDO::PARAM_STR);
            $stmt->bindValue(':plan_type', $data['plan_type'], PDO::PARAM_STR);
            $stmt->bindValue(':price', (float)$data['price'], PDO::PARAM_STR);
            $stmt->bindValue(':description', trim($data['description'] ?? ''), PDO::PARAM_STR);
            $stmt->bindValue(':features', json_encode(array_map('trim', $data['features'])), PDO::PARAM_STR);
            $stmt->bindValue(':status', $data['status'], PDO::PARAM_STR);
            
            $result = $stmt->execute();
            
            if ($result) {
                error_log("Successfully updated plan ID: $id");
            }
            
            return $result;
        } catch (PDOException $e) {
            error_log("Error in updatePlan: " . $e->getMessage());
            return false;
        }
    }
    
    // Delete plan
    public function deletePlan($id) {
        try {
            if (!$id || !is_numeric($id)) {
                error_log("Invalid ID provided to deletePlan");
                return false;
            }
            
            $stmt = $this->conn->prepare("
                DELETE FROM subscription_plans 
                WHERE id = :id
            ");
            
            $stmt->bindValue(':id', $id, PDO::PARAM_INT);
            $result = $stmt->execute();
            
            if ($result) {
                error_log("Successfully deleted plan ID: $id");
            }
            
            return $result;
        } catch (PDOException $e) {
            error_log("Error in deletePlan: " . $e->getMessage());
            return false;
        }
    }
    
    // Validate plan data
    private function validatePlanData($data) {
        return (
            !empty($data['plan_name']) &&
            !empty($data['plan_type']) &&
            in_array($data['plan_type'], ['Monthly', 'Yearly', 'Lifetime']) &&
            isset($data['price']) && is_numeric($data['price']) &&
            !empty($data['status']) &&
            in_array($data['status'], ['Active', 'Inactive']) &&
            (empty($data['features']) || is_array($data['features']))
        );
    }
}
?>