<?php
/**
 * User Model
 * Created on: 2026-01-14
 * Purpose: Handle user database operations
 */

class UserModel {
    private $conn;
    
    public function __construct($conn) {
        $this->conn = $conn;
    }
    
    /**
     * Get all users with filters
     * 
     * @param array $filters The filters to apply
     * @return array The users list
     */
    public function getUsers($filters = []) {
        // Base query
        $query = "SELECT u.id, u.email, u.user_type, u.account_status, u.created_at,
                         up.first_name, up.last_name, up.mobile_number, up.profile_photo
                  FROM users u
                  LEFT JOIN user_profile up ON u.id = up.user_id
                  WHERE 1=1";
        
        $params = [];
        
        // Apply filters
        if (!empty($filters['user_type'])) {
            $query .= " AND u.user_type = ?";
            $params[] = $filters['user_type'];
        }
        
        if (!empty($filters['status'])) {
            $query .= " AND u.account_status = ?";
            $params[] = $filters['status'];
        }
        
        if (!empty($filters['search'])) {
            $searchTerm = "%" . $filters['search'] . "%";
            $query .= " AND (u.email LIKE ? OR up.first_name LIKE ? OR up.last_name LIKE ? OR up.mobile_number LIKE ?)";
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
        }
        
        $query .= " ORDER BY u.user_type ASC, up.first_name ASC, up.last_name ASC";
        
        $stmt = $this->conn->prepare($query);
        $paramCount = count($params);
        if ($paramCount > 0) {
            for ($i = 0; $i < $paramCount; $i++) {
                $stmt->bindValue($i + 1, $params[$i]);
            }
        }
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Get a single user by ID
     * 
     * @param int $id The user ID
     * @return array The user data or error message
     */
    public function getUserById($id) {
        $query = "SELECT u.*, up.first_name, up.last_name, up.mobile_number, up.profile_photo
                  FROM users u
                  LEFT JOIN user_profile up ON u.id = up.user_id
                  WHERE u.id = ?";
                 
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $id, PDO::PARAM_INT);
        $stmt->execute();
        
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($user) {
            return ['status' => true, 'data' => $user];
        } else {
            return ['status' => false, 'message' => 'User not found.'];
        }
    }
    
    /**
     * Create a new user
     * 
     * @param array $data The user data
     * @param int $createdBy The user creating this record
     * @return array Status and message
     */
    public function createUser($data, $createdBy) {
        try {
            $this->conn->beginTransaction();
            
            // Check if email already exists
            $stmt = $this->conn->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$data['email']]);
            if ($stmt->fetch()) {
                $this->conn->rollBack();
                return ['status' => false, 'message' => 'Email already exists.'];
            }
            
            // Hash password
            $hashedPassword = password_hash($data['password'], PASSWORD_BCRYPT);
            
            // Get company_id from the user creating this record
            $stmt = $this->conn->prepare("SELECT company_id FROM users WHERE id = ?");
            $stmt->execute([$createdBy]);
            $companyId = $stmt->fetchColumn();
            
            // Insert into users table
            $stmt = $this->conn->prepare("
                INSERT INTO users (email, password, user_type, account_status, company_id, created_by) 
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            
            $accountStatus = $data['account_status'] ?? 'Active';
            $stmt->execute([
                $data['email'],
                $hashedPassword,
                $data['user_type'],
                $accountStatus,
                $companyId,
                $createdBy
            ]);
            
            $userId = $this->conn->lastInsertId();
            
            // Insert into user_profile table
            $stmt = $this->conn->prepare("
                INSERT INTO user_profile (user_id, first_name, last_name, email, mobile_number) 
                VALUES (?, ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $userId,
                $data['first_name'],
                $data['last_name'],
                $data['email'],
                $data['mobile_number'] ?? ''
            ]);
            
            $this->conn->commit();
            return ['status' => true, 'message' => 'User created successfully.', 'id' => $userId];
            
        } catch (Exception $e) {
            $this->conn->rollBack();
            error_log("Error creating user: " . $e->getMessage());
            return ['status' => false, 'message' => 'Failed to create user: ' . $e->getMessage()];
        }
    }
    
    /**
     * Update an existing user
     * 
     * @param array $data The user data
     * @param int $updatedBy The user updating this record
     * @return array Status and message
     */
    public function updateUser($data, $updatedBy) {
        try {
            $this->conn->beginTransaction();
            
            // Check if email is being changed and if it already exists
            $stmt = $this->conn->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
            $stmt->execute([$data['email'], $data['user_id']]);
            if ($stmt->fetch()) {
                $this->conn->rollBack();
                return ['status' => false, 'message' => 'Email already exists.'];
            }
            
            // Update users table
            if (!empty($data['password'])) {
                // Update with new password
                $hashedPassword = password_hash($data['password'], PASSWORD_BCRYPT);
                $stmt = $this->conn->prepare("
                    UPDATE users 
                    SET email = ?, password = ?, user_type = ?, account_status = ?
                    WHERE id = ?
                ");
                $stmt->execute([
                    $data['email'],
                    $hashedPassword,
                    $data['user_type'],
                    $data['account_status'] ?? 'Active',
                    $data['user_id']
                ]);
            } else {
                // Update without changing password
                $stmt = $this->conn->prepare("
                    UPDATE users 
                    SET email = ?, user_type = ?, account_status = ?
                    WHERE id = ?
                ");
                $stmt->execute([
                    $data['email'],
                    $data['user_type'],
                    $data['account_status'] ?? 'Active',
                    $data['user_id']
                ]);
            }
            
            // Update user_profile table
            $stmt = $this->conn->prepare("
                UPDATE user_profile 
                SET first_name = ?, last_name = ?, email = ?, mobile_number = ?
                WHERE user_id = ?
            ");
            
            $stmt->execute([
                $data['first_name'],
                $data['last_name'],
                $data['email'],
                $data['mobile_number'] ?? '',
                $data['user_id']
            ]);
            
            $this->conn->commit();
            return ['status' => true, 'message' => 'User updated successfully.'];
            
        } catch (Exception $e) {
            $this->conn->rollBack();
            error_log("Error updating user: " . $e->getMessage());
            return ['status' => false, 'message' => 'Failed to update user: ' . $e->getMessage()];
        }
    }
    
    /**
     * Delete a user by ID
     * 
     * @param int $id The user ID
     * @return array Status and message
     */
    public function deleteUser($id) {
        try {
            $this->conn->beginTransaction();
            
            // Delete user profile first (foreign key constraint)
            $stmt = $this->conn->prepare("DELETE FROM user_profile WHERE user_id = ?");
            $stmt->execute([$id]);
            
            // Delete user
            $stmt = $this->conn->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$id]);
            
            $this->conn->commit();
            return ['status' => true, 'message' => 'User deleted successfully.'];
            
        } catch (Exception $e) {
            $this->conn->rollBack();
            error_log("Error deleting user: " . $e->getMessage());
            return ['status' => false, 'message' => 'Failed to delete user: ' . $e->getMessage()];
        }
    }
}
?>
