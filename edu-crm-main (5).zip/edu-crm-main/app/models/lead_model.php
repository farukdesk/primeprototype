<?php
/**
 * Lead Model
 * Created on: 2025-05-05
 * Created by: farukdesk
 */

class LeadModel {
    private $conn;
    
    public function __construct($conn) {
        $this->conn = $conn;
    }
    
    /**
     * Get all leads with filters and pagination
     * 
     * @param array $filters The filters to apply
     * @param int $page The current page number
     * @param int $perPage The number of items per page
     * @param int $userId Current user ID
     * @param string $userType Current user type
     * @return array The result with data and pagination info
     */
    public function getLeads($filters = [], $page = 1, $perPage = 10, $userId = null, $userType = null) {
        $offset = ($page - 1) * $perPage;
        
        // Base query - join with users to get creator names
        $query = "SELECT l.*, 
                    CONCAT(up.first_name, ' ', up.last_name) as created_by_name,
                    CONCAT(upa.first_name, ' ', upa.last_name) as agent_name,
                    (SELECT COUNT(*) FROM lead_staff_assignments lsa WHERE lsa.lead_id = l.id) as staff_assigned_count
                 FROM leads l 
                 LEFT JOIN users u ON l.created_by = u.id 
                 LEFT JOIN user_profile up ON u.id = up.user_id
                 LEFT JOIN users ua ON l.agent_id = ua.id 
                 LEFT JOIN user_profile upa ON ua.id = upa.user_id
                 WHERE 1=1";
        
        $countQuery = "SELECT COUNT(*) as total FROM leads l WHERE 1=1";
        
        $params = [];
        $countParams = [];
        
        // Access restrictions based on user type
        if ($userType !== 'Super Admin' && $userType !== 'Admin' && $userType !== 'Manager') {
            if ($userType === 'Counselor') {
                // Counselor can only see leads assigned to them or created by them
                $query .= " AND (l.created_by = ? OR l.id IN (SELECT lead_id FROM lead_staff_assignments WHERE staff_id = ?))";
                $countQuery .= " AND (l.created_by = ? OR l.id IN (SELECT lead_id FROM lead_staff_assignments WHERE staff_id = ?))";
                $params[] = $userId;
                $params[] = $userId;
                $countParams[] = $userId;
                $countParams[] = $userId;
            } elseif ($userType === 'Agent') {
                // Agents can only see leads created by them or assigned to them
                $query .= " AND (l.created_by = ? OR l.agent_id = ?)";
                $countQuery .= " AND (l.created_by = ? OR l.agent_id = ?)";
                $params[] = $userId;
                $params[] = $userId;
                $countParams[] = $userId;
                $countParams[] = $userId;
            }
        }
        
        // Apply filters
        if (!empty($filters['search'])) {
            $searchTerm = "%" . $filters['search'] . "%";
            $query .= " AND (l.first_name LIKE ? OR l.last_name LIKE ? OR l.email LIKE ? OR l.phone LIKE ?)";
            $countQuery .= " AND (l.first_name LIKE ? OR l.last_name LIKE ? OR l.email LIKE ? OR l.phone LIKE ?)";
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $countParams[] = $searchTerm;
            $countParams[] = $searchTerm;
            $countParams[] = $searchTerm;
            $countParams[] = $searchTerm;
        }
        
        if (!empty($filters['agent_id'])) {
            $query .= " AND l.agent_id = ?";
            $countQuery .= " AND l.agent_id = ?";
            $params[] = $filters['agent_id'];
            $countParams[] = $filters['agent_id'];
        }
        
        if (!empty($filters['university_id'])) {
            $query .= " AND l.id IN (SELECT lead_id FROM lead_universities WHERE university_id = ?)";
            $countQuery .= " AND l.id IN (SELECT lead_id FROM lead_universities WHERE university_id = ?)";
            $params[] = $filters['university_id'];
            $countParams[] = $filters['university_id'];
        }
        
        if (!empty($filters['course_id'])) {
            $query .= " AND l.id IN (SELECT lead_id FROM lead_courses WHERE course_id = ?)";
            $countQuery .= " AND l.id IN (SELECT lead_id FROM lead_courses WHERE course_id = ?)";
            $params[] = $filters['course_id'];
            $countParams[] = $filters['course_id'];
        }
        
        if (!empty($filters['semester_id'])) {
            $query .= " AND l.id IN (SELECT lead_id FROM lead_semesters WHERE semester_id = ?)";
            $countQuery .= " AND l.id IN (SELECT lead_id FROM lead_semesters WHERE semester_id = ?)";
            $params[] = $filters['semester_id'];
            $countParams[] = $filters['semester_id'];
        }
        
        if (!empty($filters['lead_status'])) {
            $query .= " AND l.lead_status = ?";
            $countQuery .= " AND l.lead_status = ?";
            $params[] = $filters['lead_status'];
            $countParams[] = $filters['lead_status'];
        }
        
        if (!empty($filters['lead_source'])) {
            $query .= " AND l.lead_source = ?";
            $countQuery .= " AND l.lead_source = ?";
            $params[] = $filters['lead_source'];
            $countParams[] = $filters['lead_source'];
        }
        
        
        if (!empty($filters['staff_id'])) {
            $query .= " AND l.id IN (SELECT lead_id FROM lead_staff_assignments WHERE staff_id = ?)";
            $countQuery .= " AND l.id IN (SELECT lead_id FROM lead_staff_assignments WHERE staff_id = ?)";
            $params[] = $filters['staff_id'];
            $countParams[] = $filters['staff_id'];
        }

        // Add company filter - important for multi-company system
        if (!empty($filters['company_id'])) {
            $query .= " AND l.company_id = ?";
            $countQuery .= " AND l.company_id = ?";
            $params[] = $filters['company_id'];
            $countParams[] = $filters['company_id'];
        }
        
        // Follow-up filters
        if (!empty($filters['followup_today'])) {
            // Leads that need follow-up today (next_followup_date = today)
            $query .= " AND l.next_followup_date = CURDATE()";
            $countQuery .= " AND l.next_followup_date = CURDATE()";
        }
        
        if (!empty($filters['followup_overdue'])) {
            // Leads with overdue follow-ups (next_followup_date < today and status not Dead/Admitted)
            $query .= " AND l.next_followup_date < CURDATE() AND l.lead_status NOT IN ('Dead', 'Admitted')";
            $countQuery .= " AND l.next_followup_date < CURDATE() AND l.lead_status NOT IN ('Dead', 'Admitted')";
        }


        // Add sorting
        if (!empty($filters['sort'])) {
            switch ($filters['sort']) {
                case 'name_asc':
                    $query .= " ORDER BY l.first_name ASC, l.last_name ASC";
                    break;
                case 'name_desc':
                    $query .= " ORDER BY l.first_name DESC, l.last_name DESC";
                    break;
                case 'date_asc':
                    $query .= " ORDER BY l.created_at ASC";
                    break;
                case 'date_desc':
                    $query .= " ORDER BY l.created_at DESC";
                    break;
                case 'status_asc':
                    $query .= " ORDER BY l.lead_status ASC";
                    break;
                case 'status_desc':
                    $query .= " ORDER BY l.lead_status DESC";
                    break;
                default:
                    $query .= " ORDER BY l.created_at DESC";
            }
        } else {
            $query .= " ORDER BY l.created_at DESC";
        }
        
        // Add pagination
        $query .= " LIMIT ? OFFSET ?";
        
        // Prepare and execute count query
        $countStmt = $this->conn->prepare($countQuery);
        if (!empty($countParams)) {
            for ($i = 0; $i < count($countParams); $i++) {
                $paramType = is_int($countParams[$i]) ? PDO::PARAM_INT : PDO::PARAM_STR;
                $countStmt->bindValue($i + 1, $countParams[$i], $paramType);
            }
        }
        $countStmt->execute();
        $totalRecords = $countStmt->fetchColumn();
        
        // Add pagination parameters
        $params[] = $perPage;
        $params[] = $offset;
        
        // Prepare and execute main query
        $stmt = $this->conn->prepare($query);
        for ($i = 0; $i < count($params); $i++) {
            $paramType = is_int($params[$i]) ? PDO::PARAM_INT : PDO::PARAM_STR;
            $stmt->bindValue($i + 1, $params[$i], $paramType);
        }
        $stmt->execute();
        
        $leads = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Get additional data for each lead
        foreach ($leads as &$lead) {
            // Get assigned staff members
            $lead['assigned_staff'] = $this->getLeadAssignedStaff($lead['id']);
            
            // Get interested courses
            $lead['courses'] = $this->getLeadCourses($lead['id']);
            
            // Get interested universities
            $lead['universities'] = $this->getLeadUniversities($lead['id']);
            
            // Get interested semesters
            $lead['semesters'] = $this->getLeadIntakes($lead['id']);
            
            // Calculate follow-up status
            $followupStatus = $this->calculateFollowupStatus(
                $lead['last_followup_action_date'] ?? null,
                $lead['next_followup_date'] ?? null
            );
            $lead['followup_status'] = $followupStatus['alert_status'];
            $lead['days_overdue'] = $followupStatus['days_overdue'];
        }
        
        // Calculate pagination info
        $totalPages = ceil($totalRecords / $perPage);
        
        // Get lead statistics for current filter criteria
        $stats = $this->getLeadStats($filters, $userId, $userType);
        
        return [
            'data' => $leads,
            'pagination' => [
                'total' => $totalPages,
                'current' => $page,
                'total_records' => $totalRecords
            ],
            'filters' => $filters,
            'stats' => $stats
        ];
    }
    
    /**
     * Get a single lead by ID with all related data
     * 
     * @param int $id The lead ID
     * @param int $userId Current user ID
     * @param string $userType Current user type
     * @return array The lead data or error message
     */
    public function getLeadById($id, $userId = null, $userType = null) {
        // Check permissions first
        if (!$this->canAccessLead($id, $userId, $userType)) {
            return ['status' => false, 'message' => 'You do not have permission to access this lead.'];
        }
        
        // Get lead basic information
        $query = "SELECT l.*, 
                    CONCAT(up.first_name, ' ', up.last_name) as created_by_name,
                    CONCAT(upa.first_name, ' ', upa.last_name) as agent_name,
                    c.course_title as interested_course_name,
                    c.department as interested_course_department
                 FROM leads l 
                 LEFT JOIN users u ON l.created_by = u.id 
                 LEFT JOIN user_profile up ON u.id = up.user_id
                 LEFT JOIN users ua ON l.agent_id = ua.id 
                 LEFT JOIN user_profile upa ON ua.id = upa.user_id
                 LEFT JOIN courses c ON l.interested_course_id = c.id
                 WHERE l.id = ?";
                 
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $id, PDO::PARAM_INT);
        $stmt->execute();
        
        $lead = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$lead) {
            return ['status' => false, 'message' => 'Lead not found.'];
        }
        
        // Get assigned staff members
        $lead['assigned_staff'] = $this->getLeadAssignedStaff($id);
        
        // Get interested courses
        $lead['courses'] = $this->getLeadCourses($id);
        
        // Get interested universities
        $lead['universities'] = $this->getLeadUniversities($id);
        
        // Get interested semesters
        $lead['semesters'] = $this->getLeadIntakes($id);
        
        // Get lead notes
        $lead['notes'] = $this->getLeadNotes($id);
        
        // Get edit history
        $lead['edit_history'] = $this->getLeadEditHistory($id);
        
        return ['status' => true, 'data' => $lead];
    }
    
    /**
     * Check if a user can access a specific lead
     * 
     * @param int $leadId Lead ID
     * @param int $userId User ID
     * @param string $userType User type
     * @return bool Whether the user can access the lead
     */
    private function canAccessLead($leadId, $userId, $userType) {
        // Super admin, admin, and manager can access all leads
        if (in_array($userType, ['Super Admin', 'Admin', 'Manager'])) {
            return true;
        }
        
        // Counselor can access leads assigned to them or created by them
        if ($userType === 'Counselor') {
            $query = "SELECT COUNT(*) FROM leads l 
                      LEFT JOIN lead_staff_assignments lsa ON l.id = lsa.lead_id
                      WHERE l.id = ? AND (l.created_by = ? OR lsa.staff_id = ?)";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(1, $leadId, PDO::PARAM_INT);
            $stmt->bindParam(2, $userId, PDO::PARAM_INT);
            $stmt->bindParam(3, $userId, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchColumn() > 0;
        }
        
        // Agent can access leads created by them or assigned to them
        if ($userType === 'Agent') {
            $query = "SELECT COUNT(*) FROM leads WHERE id = ? AND (created_by = ? OR agent_id = ?)";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(1, $leadId, PDO::PARAM_INT);
            $stmt->bindParam(2, $userId, PDO::PARAM_INT);
            $stmt->bindParam(3, $userId, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchColumn() > 0;
        }
        
        return false;
    }
    
    /**
     * Get staff members assigned to a lead
     * 
     * @param int $leadId The lead ID
     * @return array List of assigned staff
     */
    private function getLeadAssignedStaff($leadId) {
        $query = "SELECT lsa.id as assignment_id, lsa.staff_id, 
                    CONCAT(up.first_name, ' ', up.last_name) as staff_name,
                    up.profile_photo,
                    lsa.assigned_at,
                    CONCAT(upa.first_name, ' ', upa.last_name) as assigned_by_name
                 FROM lead_staff_assignments lsa 
                 LEFT JOIN users u ON lsa.staff_id = u.id 
                 LEFT JOIN user_profile up ON u.id = up.user_id
                 LEFT JOIN users ua ON lsa.assigned_by = ua.id 
                 LEFT JOIN user_profile upa ON ua.id = upa.user_id
                 WHERE lsa.lead_id = ?
                 ORDER BY lsa.assigned_at DESC";
                 
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $leadId, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Get courses interested by a lead
     * 
     * @param int $leadId The lead ID
     * @return array List of interested courses
     */
    private function getLeadCourses($leadId) {
        $query = "SELECT lc.id as link_id, c.id as course_id, c.course_title, 
                    c.department, c.credit, lc.added_at
                 FROM lead_courses lc 
                 LEFT JOIN courses c ON lc.course_id = c.id 
                 WHERE lc.lead_id = ?
                 ORDER BY lc.added_at DESC";
                 
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $leadId, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Get universities interested by a lead
     * 
     * @param int $leadId The lead ID
     * @return array List of interested universities
     */
    private function getLeadUniversities($leadId) {
        $query = "SELECT lu.id as link_id, u.id as university_id, u.name as university_name,
                    u.logo, lu.added_at
                 FROM lead_universities lu 
                 LEFT JOIN universities u ON lu.university_id = u.id 
                 WHERE lu.lead_id = ?
                 ORDER BY lu.added_at DESC";
                 
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $leadId, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Get semesters interested by a lead
     * 
     * @param int $leadId The lead ID
     * @return array List of interested semesters
     */
    private function getLeadIntakes($leadId) {
        $query = "SELECT li.id as link_id, i.id as semester_id, i.name as intake_name,
                    i.start_date, li.added_at
                 FROM lead_semesters li 
                 LEFT JOIN semesters i ON li.semester_id = i.id 
                 WHERE li.lead_id = ?
                 ORDER BY li.added_at DESC";
                 
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $leadId, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Get notes for a lead
     * 
     * @param int $leadId The lead ID
     * @return array List of notes
     */
    private function getLeadNotes($leadId) {
        $query = "SELECT ln.id, ln.note_text, ln.created_at, 
                    CONCAT(up.first_name, ' ', up.last_name) as created_by_name,
                    up.profile_photo
                 FROM lead_notes ln 
                 LEFT JOIN users u ON ln.created_by = u.id 
                 LEFT JOIN user_profile up ON u.id = up.user_id
                 WHERE ln.lead_id = ?
                 ORDER BY ln.created_at DESC";
                 
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $leadId, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Get edit history for a lead
     * 
     * @param int $leadId The lead ID
     * @return array Edit history
     */
    private function getLeadEditHistory($leadId) {
        $query = "SELECT leh.id, leh.field_name, leh.old_value, leh.new_value, 
                    leh.edited_at, CONCAT(up.first_name, ' ', up.last_name) as edited_by_name,
                    up.profile_photo
                 FROM lead_edit_history leh 
                 LEFT JOIN users u ON leh.edited_by = u.id 
                 LEFT JOIN user_profile up ON u.id = up.user_id
                 WHERE leh.lead_id = ?
                 ORDER BY leh.edited_at DESC";
                 
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $leadId, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Create a new lead
     * 
     * @param array $data The lead data
     * @param int $userId The user creating the lead
     * @param int $companyId Company ID
     * @return array Status and message
     */
    public function createLead($data, $userId, $companyId) {
        try {
            $this->conn->beginTransaction();
            
            // Build agent logic
            $agentId = null;
            if ($data['lead_source'] === 'Agent') {
                // If user is an agent, set agent_id to the user
                $userType = $this->getUserType($userId);
                if ($userType === 'Agent') {
                    $agentId = $userId;
                } elseif (!empty($data['agent_id'])) {
                    $agentId = $data['agent_id'];
                }
            }
            
            // Prepare insert query for lead
                $query = "INSERT INTO leads (
                            first_name, last_name, email, phone, address, current_city,
                            applying_for, semester, ssc_gpa, hsc_gpa, bachelor_subject, bachelor_cgpa,
                            interested_course_id, lead_source, lead_status, campus_visit_date,
                            created_by, agent_id, company_id
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    
            $stmt = $this->conn->prepare($query);
            
            // Set default values for lead status
            $leadStatus = $data['lead_status'] ?? 'Fresh';
            if ($data['lead_source'] === 'Direct Online') {
                $leadStatus = 'Fresh';
            }
            
            $officeVisitDate = null;
            if ($leadStatus === 'Will visit office' && !empty($data['campus_visit_date'])) {
                $officeVisitDate = $data['campus_visit_date'];
            }
            
            // Convert decimal values
            $sscGpa = !empty($data['ssc_gpa']) ? floatval($data['ssc_gpa']) : null;
            $hscGpa = !empty($data['hsc_gpa']) ? floatval($data['hsc_gpa']) : null;
            $bachelorCgpa = !empty($data['bachelor_cgpa']) ? floatval($data['bachelor_cgpa']) : null;
            $interestedCourseId = !empty($data['interested_course_id']) ? (int)$data['interested_course_id'] : null;
            
            // Bind parameters
            $stmt->bindParam(1, $data['first_name'], PDO::PARAM_STR);
            $stmt->bindParam(2, $data['last_name'], PDO::PARAM_STR);
            $stmt->bindParam(3, $data['email'], PDO::PARAM_STR);
            $stmt->bindParam(4, $data['phone'], PDO::PARAM_STR);
            $stmt->bindParam(5, $data['address'], PDO::PARAM_STR);
            $stmt->bindParam(6, $data['current_city'], PDO::PARAM_STR);
            $stmt->bindParam(7, $data['applying_for'], PDO::PARAM_STR);
            $stmt->bindParam(8, $data['semester'], PDO::PARAM_STR);
            $stmt->bindParam(9, $sscGpa, PDO::PARAM_STR);
            $stmt->bindParam(10, $hscGpa, PDO::PARAM_STR);
            $stmt->bindParam(11, $data['bachelor_subject'], PDO::PARAM_STR);
            $stmt->bindParam(12, $bachelorCgpa, PDO::PARAM_STR);
            $stmt->bindParam(13, $interestedCourseId, PDO::PARAM_INT);
            $stmt->bindParam(14, $data['lead_source'], PDO::PARAM_STR);
            $stmt->bindParam(15, $leadStatus, PDO::PARAM_STR);
            $stmt->bindParam(16, $officeVisitDate, PDO::PARAM_STR);
            $stmt->bindParam(17, $userId, PDO::PARAM_INT);
            $stmt->bindParam(18, $agentId, PDO::PARAM_INT);
            $stmt->bindParam(19, $companyId, PDO::PARAM_INT);
            
            $stmt->execute();
            $leadId = $this->conn->lastInsertId();
            
            // Handle custom follow-up date or initialize auto tracking
            if (!empty($data['next_followup_date'])) {
                // User manually set a follow-up date
                $query = "UPDATE leads SET next_followup_date = ? WHERE id = ?";
                $stmt = $this->conn->prepare($query);
                $stmt->bindParam(1, $data['next_followup_date'], PDO::PARAM_STR);
                $stmt->bindParam(2, $leadId, PDO::PARAM_INT);
                $stmt->execute();
            } else {
                // Initialize follow-up tracking with auto-calculated date
                $this->updateFollowupTracking($leadId, $leadStatus);
            }
            
            // Auto-assign lead to counselor if they created it
            $userType = $this->getUserType($userId);
            if ($userType === 'Counselor') {
                // Auto-assign the lead to the counselor who created it
                if (empty($data['assigned_staff'])) {
                    $data['assigned_staff'] = $userId;
                } else {
                    // Ensure the counselor is in the assigned staff list
                    $assignedStaffIds = is_array($data['assigned_staff']) 
                        ? $data['assigned_staff'] 
                        : explode(',', $data['assigned_staff']);
                    if (!in_array($userId, $assignedStaffIds)) {
                        $assignedStaffIds[] = $userId;
                        $data['assigned_staff'] = implode(',', $assignedStaffIds);
                    }
                }
            }
            
            // Process staff assignments
            if (!empty($data['assigned_staff'])) {
                $this->processLeadStaffAssignments($leadId, $data['assigned_staff'], $userId);
            }
            
            // Add initial note if provided
            if (!empty($data['initial_note'])) {
                $this->addLeadNote($leadId, $data['initial_note'], $userId);
            }
            
            $this->conn->commit();
            
            return ['status' => true, 'message' => 'Lead created successfully.', 'id' => $leadId];
        } catch (Exception $e) {
            $this->conn->rollBack();
            error_log('Error in createLead: ' . $e->getMessage());
            return ['status' => false, 'message' => 'Failed to create lead: ' . $e->getMessage()];
        }
    }
    
    /**
     * Update an existing lead
/**
 * Update an existing lead
 * 
 * @param array $data The lead data
 * @param int $userId The user updating the lead
 * @return array Status and message
 */
public function updateLead($data, $userId) {
    // Check if lead exists and user has permission
    $leadId = $data['lead_id'];
    $leadCheck = $this->getLeadById($leadId, $userId, $this->getUserType($userId));
    
    if (!$leadCheck['status']) {
        return $leadCheck; // Return the error
    }
    
    $currentLead = $leadCheck['data'];
    
    try {
        $this->conn->beginTransaction();
        
        // Build agent logic
        $agentId = $currentLead['agent_id'];
        if ($data['lead_source'] === 'Agent') {
            // If user is an agent, keep agent_id as the user or update if provided
            $userType = $this->getUserType($userId);
            if ($userType === 'Agent') {
                $agentId = $userId;
            } elseif (!empty($data['agent_id'])) {
                $agentId = $data['agent_id'];
                // Track change in agent
                if ($agentId != $currentLead['agent_id']) {
                    $this->trackFieldChange($leadId, 'agent_id', $currentLead['agent_id'], $agentId, $userId);
                }
            }
        } else {
            // If lead source changed from Agent to something else
            if ($currentLead['lead_source'] === 'Agent' && $data['lead_source'] !== 'Agent') {
                $this->trackFieldChange($leadId, 'agent_id', $currentLead['agent_id'], null, $userId);
                $agentId = null;
            }
        }
        
        // Prepare update query for lead (with follow-up tracking)
        // Note: last_followup_action_date is updated on ANY lead update to track activity.
        // This includes status changes, field updates, and note additions.
        // This marks that some action/interaction occurred with this lead.
            $query = "UPDATE leads SET
                        first_name = ?, last_name = ?, email = ?, phone = ?, address = ?, current_city = ?,
                        applying_for = ?, semester = ?, ssc_gpa = ?, hsc_gpa = ?, bachelor_subject = ?, bachelor_cgpa = ?,
                        interested_course_id = ?, lead_source = ?, lead_status = ?, campus_visit_date = ?,
                        agent_id = ?, last_followup_action_date = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?";
                  
        // Set default values for lead status
        $leadStatus = $data['lead_status'] ?? $currentLead['lead_status'];
        
        $officeVisitDate = null;
        if ($leadStatus === 'Will visit office' && !empty($data['campus_visit_date'])) {
            $officeVisitDate = $data['campus_visit_date'];
        }
        
        // Convert decimal values
        $sscGpa = !empty($data['ssc_gpa']) ? floatval($data['ssc_gpa']) : null;
        $hscGpa = !empty($data['hsc_gpa']) ? floatval($data['hsc_gpa']) : null;
        $bachelorCgpa = !empty($data['bachelor_cgpa']) ? floatval($data['bachelor_cgpa']) : null;
        $interestedCourseId = !empty($data['interested_course_id']) ? (int)$data['interested_course_id'] : null;
        
        // Track changes for edit history
        $this->trackChanges($currentLead, $data, $leadId, $userId);
        
        $stmt = $this->conn->prepare($query);
        
        // Bind parameters
        $stmt->bindParam(1, $data['first_name'], PDO::PARAM_STR);
        $stmt->bindParam(2, $data['last_name'], PDO::PARAM_STR);
        $stmt->bindParam(3, $data['email'], PDO::PARAM_STR);
        $stmt->bindParam(4, $data['phone'], PDO::PARAM_STR);
        $stmt->bindParam(5, $data['address'], PDO::PARAM_STR);
        $stmt->bindParam(6, $data['current_city'], PDO::PARAM_STR);
        $stmt->bindParam(7, $data['applying_for'], PDO::PARAM_STR);
        $stmt->bindParam(8, $data['semester'], PDO::PARAM_STR);
        $stmt->bindParam(9, $sscGpa, PDO::PARAM_STR);
        $stmt->bindParam(10, $hscGpa, PDO::PARAM_STR);
        $stmt->bindParam(11, $data['bachelor_subject'], PDO::PARAM_STR);
        $stmt->bindParam(12, $bachelorCgpa, PDO::PARAM_STR);
        $stmt->bindParam(13, $interestedCourseId, PDO::PARAM_INT);
        $stmt->bindParam(14, $data['lead_source'], PDO::PARAM_STR);
        $stmt->bindParam(15, $leadStatus, PDO::PARAM_STR);
        $stmt->bindParam(16, $officeVisitDate, PDO::PARAM_STR);
        $stmt->bindParam(17, $agentId, PDO::PARAM_INT);
        $stmt->bindParam(18, $leadId, PDO::PARAM_INT);
        
        $stmt->execute();
        
        // Handle manual follow-up date if provided
        if (isset($data['next_followup_date']) && !empty($data['next_followup_date'])) {
            // User manually set a follow-up date - update it directly
            $query = "UPDATE leads SET next_followup_date = ? WHERE id = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(1, $data['next_followup_date'], PDO::PARAM_STR);
            $stmt->bindParam(2, $leadId, PDO::PARAM_INT);
            $stmt->execute();
        }
        
        // *** NEW CODE: Record call log if status has changed ***
        if ($currentLead['lead_status'] !== $leadStatus) {
            // Include the CallLogModel
            require_once __DIR__ . '/call_log_model.php';
            $callLogModel = new CallLogModel($this->conn);
            
            // Record the call log
            $callNotes = !empty($data['note']) ? $data['note'] : '';
            $callLogResult = $callLogModel->recordCallLog(
                $leadId,
                $userId,
                $currentLead['lead_status'],
                $leadStatus,
                $callNotes
            );
            
            // If call log was recorded, add it to the response
            if ($callLogResult['status']) {
                $callLogRecorded = true;
                $callLogId = $callLogResult['call_id'];
            }
            
            // Update follow-up tracking when status changes (only if user didn't manually set a date)
            if (!isset($data['next_followup_date']) || empty($data['next_followup_date'])) {
                $this->updateFollowupTracking($leadId, $leadStatus);
            }
        }
        
        // Process staff assignments
        if (isset($data['assigned_staff'])) {
            $this->processLeadStaffAssignments($leadId, $data['assigned_staff'], $userId);
        }
        
        // Add note if provided
        if (!empty($data['note'])) {
            $this->addLeadNote($leadId, $data['note'], $userId);
        }
        
        $this->conn->commit();
        
        $response = ['status' => true, 'message' => 'Lead updated successfully.'];
        
        // Add call log information to response if applicable
        if (isset($callLogRecorded) && $callLogRecorded) {
            $response['call_log_recorded'] = true;
            $response['call_log_id'] = $callLogId;
        }
        
        return $response;
        
    } catch (Exception $e) {
        $this->conn->rollBack();
        error_log('Error in updateLead: ' . $e->getMessage());
        return ['status' => false, 'message' => 'Failed to update lead: ' . $e->getMessage()];
    }
}
    
    /**
     * Track changes between current and new data for a lead
     * 
     * @param array $currentLead Current lead data
     * @param array $newData New lead data
     * @param int $leadId Lead ID
     * @param int $userId User making changes
     */
    private function trackChanges($currentLead, $newData, $leadId, $userId) {
        // Fields to track
        $trackFields = [
            'first_name', 'last_name', 'email', 'phone', 'address', 'current_city',
            'applying_for', 'semester', 'ssc_gpa', 'hsc_gpa', 'bachelor_subject', 'bachelor_cgpa',
            'interested_course_id', 'lead_source', 'lead_status'
        ];
        
        foreach ($trackFields as $field) {
            if (isset($newData[$field]) && $currentLead[$field] != $newData[$field]) {
                $this->trackFieldChange($leadId, $field, $currentLead[$field], $newData[$field], $userId);
            }
        }
        
        // Special handling for campus_visit_date
        if (isset($newData['lead_status']) && $newData['lead_status'] === 'Will visit office') {
            if (isset($newData['campus_visit_date']) && $currentLead['campus_visit_date'] != $newData['campus_visit_date']) {
                $this->trackFieldChange($leadId, 'campus_visit_date', $currentLead['campus_visit_date'], $newData['campus_visit_date'], $userId);
            }
        }
    }
    
    /**
     * Track a single field change in lead edit history
     * 
     * @param int $leadId Lead ID
     * @param string $field Field name
     * @param mixed $oldValue Old value
     * @param mixed $newValue New value
     * @param int $userId User making changes
     */
    private function trackFieldChange($leadId, $field, $oldValue, $newValue, $userId) {
        $query = "INSERT INTO lead_edit_history (lead_id, field_name, old_value, new_value, edited_by) 
                 VALUES (?, ?, ?, ?, ?)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $leadId, PDO::PARAM_INT);
        $stmt->bindParam(2, $field, PDO::PARAM_STR);
        $stmt->bindParam(3, $oldValue, PDO::PARAM_STR);
        $stmt->bindParam(4, $newValue, PDO::PARAM_STR);
        $stmt->bindParam(5, $userId, PDO::PARAM_INT);
        $stmt->execute();
    }
    
    /**
     * Delete a lead
     * 
     * @param int $id The lead ID
     * @param int $userId User ID
     * @param string $userType User type
     * @return array Status and message
     */
    public function deleteLead($id, $userId, $userType) {
        // Check permissions
        if (!$this->canDeleteLead($id, $userId, $userType)) {
            return ['status' => false, 'message' => 'You do not have permission to delete this lead.'];
        }
        
        try {
            $this->conn->beginTransaction();
            
            // Delete lead notes
            $stmtNotes = $this->conn->prepare("DELETE FROM lead_notes WHERE lead_id = ?");
            $stmtNotes->bindParam(1, $id, PDO::PARAM_INT);
            $stmtNotes->execute();
            
            // Delete edit history
            $stmtHistory = $this->conn->prepare("DELETE FROM lead_edit_history WHERE lead_id = ?");
            $stmtHistory->bindParam(1, $id, PDO::PARAM_INT);
            $stmtHistory->execute();
            
            // Delete staff assignments
            $stmtStaff = $this->conn->prepare("DELETE FROM lead_staff_assignments WHERE lead_id = ?");
            $stmtStaff->bindParam(1, $id, PDO::PARAM_INT);
            $stmtStaff->execute();
            
            // Delete course links
            $stmtCourses = $this->conn->prepare("DELETE FROM lead_courses WHERE lead_id = ?");
            $stmtCourses->bindParam(1, $id, PDO::PARAM_INT);
            $stmtCourses->execute();
            
            // Delete university links
            $stmtUniversities = $this->conn->prepare("DELETE FROM lead_universities WHERE lead_id = ?");
            $stmtUniversities->bindParam(1, $id, PDO::PARAM_INT);
            $stmtUniversities->execute();
            
            // Delete intake links
            $stmtIntakes = $this->conn->prepare("DELETE FROM lead_semesters WHERE lead_id = ?");
            $stmtIntakes->bindParam(1, $id, PDO::PARAM_INT);
            $stmtIntakes->execute();
            
            // Delete the lead
            $stmtLead = $this->conn->prepare("DELETE FROM leads WHERE id = ?");
            $stmtLead->bindParam(1, $id, PDO::PARAM_INT);
            $stmtLead->execute();
            
            $this->conn->commit();
            
            return ['status' => true, 'message' => 'Lead deleted successfully.'];
        } catch (Exception $e) {
            $this->conn->rollBack();
            error_log('Error in deleteLead: ' . $e->getMessage());
            return ['status' => false, 'message' => 'Failed to delete lead: ' . $e->getMessage()];
        }
    }
    
    /**
     * Check if a user can delete a specific lead
     * 
     * @param int $leadId Lead ID
     * @param int $userId User ID
     * @param string $userType User type
     * @return bool Whether the user can delete the lead
     */
    private function canDeleteLead($leadId, $userId, $userType) {
        // Only super admin can delete any lead
        if ($userType === 'Super Admin') {
            return true;
        }
        
        // Agents can only delete leads they created
        if ($userType === 'Agent') {
            $query = "SELECT COUNT(*) FROM leads WHERE id = ? AND created_by = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(1, $leadId, PDO::PARAM_INT);
            $stmt->bindParam(2, $userId, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchColumn() > 0;
        }
        
        // Other user types cannot delete leads
        return false;
    }
    
    /**
     * Add a note to a lead
     * 
     * @param int $leadId Lead ID
     * @param string $noteText Note text
     * @param int $userId User adding the note
     * @return array Status and message
     */
    public function addLeadNote($leadId, $noteText, $userId) {
        if (empty(trim($noteText))) {
            return ['status' => false, 'message' => 'Note text cannot be empty.'];
        }
        
        try {
            $query = "INSERT INTO lead_notes (lead_id, note_text, created_by) VALUES (?, ?, ?)";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(1, $leadId, PDO::PARAM_INT);
            $stmt->bindParam(2, $noteText, PDO::PARAM_STR);
            $stmt->bindParam(3, $userId, PDO::PARAM_INT);
            $stmt->execute();
            
            $noteId = $this->conn->lastInsertId();
            
            // Get the note with user info
            $queryGet = "SELECT ln.id, ln.note_text, ln.created_at, 
                        CONCAT(up.first_name, ' ', up.last_name) as created_by_name,
                        up.profile_photo
                     FROM lead_notes ln 
                     LEFT JOIN users u ON ln.created_by = u.id 
                     LEFT JOIN user_profile up ON u.id = up.user_id
                     WHERE ln.id = ?";
            $stmtGet = $this->conn->prepare($queryGet);
            $stmtGet->bindParam(1, $noteId, PDO::PARAM_INT);
            $stmtGet->execute();
            $note = $stmtGet->fetch(PDO::FETCH_ASSOC);
            
            return ['status' => true, 'message' => 'Note added successfully.', 'note' => $note];
        } catch (Exception $e) {
            error_log('Error in addLeadNote: ' . $e->getMessage());
            return ['status' => false, 'message' => 'Failed to add note: ' . $e->getMessage()];
        }
    }
    
    /**
     * Delete a lead note
     * 
     * @param int $noteId Note ID
     * @param int $userId User deleting the note
     * @param string $userType User type
     * @return array Status and message
     */
    public function deleteLeadNote($noteId, $userId, $userType) {
        try {
            // Check if the note exists and if user has permission to delete it
            $query = "SELECT ln.*, l.created_by as lead_created_by 
                     FROM lead_notes ln 
                     JOIN leads l ON ln.lead_id = l.id
                     WHERE ln.id = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(1, $noteId, PDO::PARAM_INT);
            $stmt->execute();
            $note = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$note) {
                return ['status' => false, 'message' => 'Note not found.'];
            }
            
            // Check permissions
            if (!($userType === 'Super Admin' || 
                $note['created_by'] === $userId || 
                ($userType === 'Admin' && $note['lead_created_by'] !== $userId))) {
                return ['status' => false, 'message' => 'You do not have permission to delete this note.'];
            }
            
            // Delete the note
            $deleteQuery = "DELETE FROM lead_notes WHERE id = ?";
            $deleteStmt = $this->conn->prepare($deleteQuery);
            $deleteStmt->bindParam(1, $noteId, PDO::PARAM_INT);
            $deleteStmt->execute();
            
            return ['status' => true, 'message' => 'Note deleted successfully.'];
        } catch (Exception $e) {
            error_log('Error in deleteLeadNote: ' . $e->getMessage());
            return ['status' => false, 'message' => 'Failed to delete note: ' . $e->getMessage()];
        }
    }
    
    /**
     * Assign a staff member to a lead
     * 
     * @param int $leadId Lead ID
     * @param int $staffId Staff user ID
     * @param int $assignedBy User making the assignment
     * @return bool Success status
     */
    public function assignStaffToLead($leadId, $staffId, $assignedBy) {
        try {
            // Check if staff exists and is of type Counselor
            $staffQuery = "SELECT COUNT(*) FROM users WHERE id = ? AND user_type = 'Counselor' AND account_status = 'Active'";
            $staffStmt = $this->conn->prepare($staffQuery);
            $staffStmt->bindParam(1, $staffId, PDO::PARAM_INT);
            $staffStmt->execute();
            
            if ($staffStmt->fetchColumn() === 0) {
                // Not a valid staff member
                error_log('Invalid staff member in assignStaffToLead: ' . $staffId);
                return false;
            }
            
            // Check if assignment already exists
            $checkQuery = "SELECT COUNT(*) FROM lead_staff_assignments 
                          WHERE lead_id = ? AND staff_id = ?";
            $checkStmt = $this->conn->prepare($checkQuery);
            $checkStmt->bindParam(1, $leadId, PDO::PARAM_INT);
            $checkStmt->bindParam(2, $staffId, PDO::PARAM_INT);
            $checkStmt->execute();
            
            if ($checkStmt->fetchColumn() > 0) {
                // Assignment already exists
                return true;
            }
            
            // Add new assignment
            $query = "INSERT INTO lead_staff_assignments (lead_id, staff_id, assigned_by) 
                     VALUES (?, ?, ?)";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(1, $leadId, PDO::PARAM_INT);
            $stmt->bindParam(2, $staffId, PDO::PARAM_INT);
            $stmt->bindParam(3, $assignedBy, PDO::PARAM_INT);
            return $stmt->execute();
        } catch (Exception $e) {
            error_log('Error in assignStaffToLead: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Remove a staff member from a lead
     * 
     * @param int $assignmentId Assignment ID
     * @param int $userId User making the change
     * @param string $userType User type
     * @return array Status and message
     */
    public function removeStaffFromLead($assignmentId, $userId, $userType) {
        try {
            // Check if the assignment exists
            $query = "SELECT lsa.*, l.created_by as lead_created_by 
                     FROM lead_staff_assignments lsa 
                     JOIN leads l ON lsa.lead_id = l.id
                     WHERE lsa.id = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(1, $assignmentId, PDO::PARAM_INT);
            $stmt->execute();
            $assignment = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$assignment) {
                return ['status' => false, 'message' => 'Assignment not found.'];
            }
            
            // Check permissions
            if (!($userType === 'Super Admin' || $userType === 'Admin' || $userType === 'Manager')) {
                return ['status' => false, 'message' => 'You do not have permission to remove staff assignments.'];
            }
            
            // Delete the assignment
            $deleteQuery = "DELETE FROM lead_staff_assignments WHERE id = ?";
            $deleteStmt = $this->conn->prepare($deleteQuery);
            $deleteStmt->bindParam(1, $assignmentId, PDO::PARAM_INT);
            $deleteStmt->execute();
            
            return ['status' => true, 'message' => 'Staff removed from lead successfully.'];
        } catch (Exception $e) {
            error_log('Error in removeStaffFromLead: ' . $e->getMessage());
            return ['status' => false, 'message' => 'Failed to remove staff: ' . $e->getMessage()];
        }
    }
    
    /**
     * Remove all staff from a lead
     * 
     * @param int $leadId Lead ID
     * @return bool Success status
     */
    private function removeAllStaffFromLead($leadId) {
        try {
            $query = "DELETE FROM lead_staff_assignments WHERE lead_id = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(1, $leadId, PDO::PARAM_INT);
            return $stmt->execute();
        } catch (Exception $e) {
            error_log('Error in removeAllStaffFromLead: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Add a course to a lead
     * 
     * @param int $leadId Lead ID
     * @param int $courseId Course ID
     * @param int $addedBy User adding the course
     * @return bool Success status
     */
    public function addCourseToLead($leadId, $courseId, $addedBy) {
        try {
            // Check if course exists
            $courseQuery = "SELECT COUNT(*) FROM courses WHERE id = ?";
            $courseStmt = $this->conn->prepare($courseQuery);
            $courseStmt->bindParam(1, $courseId, PDO::PARAM_INT);
            $courseStmt->execute();
            
            if ($courseStmt->fetchColumn() === 0) {
                // Course doesn't exist
                error_log('Invalid course in addCourseToLead: ' . $courseId);
                return false;
            }
            
            // Check if link already exists
            $checkQuery = "SELECT COUNT(*) FROM lead_courses 
                          WHERE lead_id = ? AND course_id = ?";
            $checkStmt = $this->conn->prepare($checkQuery);
            $checkStmt->bindParam(1, $leadId, PDO::PARAM_INT);
            $checkStmt->bindParam(2, $courseId, PDO::PARAM_INT);
            $checkStmt->execute();
            
            if ($checkStmt->fetchColumn() > 0) {
                // Link already exists
                return true;
            }
            
            // Add new link
            $query = "INSERT INTO lead_courses (lead_id, course_id, added_by) 
                     VALUES (?, ?, ?)";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(1, $leadId, PDO::PARAM_INT);
            $stmt->bindParam(2, $courseId, PDO::PARAM_INT);
            $stmt->bindParam(3, $addedBy, PDO::PARAM_INT);
            return $stmt->execute();
        } catch (Exception $e) {
            error_log('Error in addCourseToLead: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Process multiple courses for a lead by parsing a comma-separated string
     * 
     * @param int $leadId Lead ID
     * @param string $coursesString Comma-separated course IDs
     * @param int $userId User making the changes
     * @return void
     */
    public function processLeadCourses($leadId, $coursesString, $userId) {
        // First remove existing courses
        $this->removeAllCoursesFromLead($leadId);
        
        // If no courses provided, we're done
        if (empty($coursesString)) {
            return;
        }
        
        // Split the string and add each course
        $courseIds = explode(',', $coursesString);
        foreach ($courseIds as $courseId) {
            if (is_numeric($courseId) && $courseId > 0) {
                $this->addCourseToLead($leadId, $courseId, $userId);
            }
        }
    }
    
    /**
     * Remove all courses from a lead
     * 
     * @param int $leadId Lead ID
     * @return bool Success status
     */
    private function removeAllCoursesFromLead($leadId) {
        try {
            $query = "DELETE FROM lead_courses WHERE lead_id = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(1, $leadId, PDO::PARAM_INT);
            return $stmt->execute();
        } catch (Exception $e) {
            error_log('Error in removeAllCoursesFromLead: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Add a university to a lead
     * 
     * @param int $leadId Lead ID
     * @param int $universityId University ID
     * @param int $addedBy User adding the university
     * @return bool Success status
     */
    public function addUniversityToLead($leadId, $universityId, $addedBy) {
        try {
            // Check if university exists
            $universityQuery = "SELECT COUNT(*) FROM universities WHERE id = ?";
            $universityStmt = $this->conn->prepare($universityQuery);
            $universityStmt->bindParam(1, $universityId, PDO::PARAM_INT);
            $universityStmt->execute();
            
            if ($universityStmt->fetchColumn() === 0) {
                // University doesn't exist
                error_log('Invalid university in addUniversityToLead: ' . $universityId);
                return false;
            }
            
            // Check if link already exists
            $checkQuery = "SELECT COUNT(*) FROM lead_universities 
                          WHERE lead_id = ? AND university_id = ?";
            $checkStmt = $this->conn->prepare($checkQuery);
            $checkStmt->bindParam(1, $leadId, PDO::PARAM_INT);
            $checkStmt->bindParam(2, $universityId, PDO::PARAM_INT);
            $checkStmt->execute();
            
            if ($checkStmt->fetchColumn() > 0) {
                // Link already exists
                return true;
            }
            
            // Add new link
            $query = "INSERT INTO lead_universities (lead_id, university_id, added_by) 
                     VALUES (?, ?, ?)";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(1, $leadId, PDO::PARAM_INT);
            $stmt->bindParam(2, $universityId, PDO::PARAM_INT);
            $stmt->bindParam(3, $addedBy, PDO::PARAM_INT);
            return $stmt->execute();
        } catch (Exception $e) {
            error_log('Error in addUniversityToLead: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Process multiple universities for a lead by parsing a comma-separated string
     * 
     * @param int $leadId Lead ID
     * @param string $universitiesString Comma-separated university IDs
     * @param int $userId User making the changes
     * @return void
     */
    public function processLeadUniversities($leadId, $universitiesString, $userId) {
        // First remove existing universities
        $this->removeAllUniversitiesFromLead($leadId);
        
        // If no universities provided, we're done
        if (empty($universitiesString)) {
            return;
        }
        
        // Split the string and add each university
        $universityIds = explode(',', $universitiesString);
        foreach ($universityIds as $universityId) {
            if (is_numeric($universityId) && $universityId > 0) {
                $this->addUniversityToLead($leadId, $universityId, $userId);
            }
        }
    }
    
    /**
     * Remove all universities from a lead
     * 
     * @param int $leadId Lead ID
     * @return bool Success status
     */
    private function removeAllUniversitiesFromLead($leadId) {
        try {
            $query = "DELETE FROM lead_universities WHERE lead_id = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(1, $leadId, PDO::PARAM_INT);
            return $stmt->execute();
        } catch (Exception $e) {
            error_log('Error in removeAllUniversitiesFromLead: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Add an intake to a lead
     * 
     * @param int $leadId Lead ID
     * @param int $intakeId Intake ID
     * @param int $addedBy User adding the intake
     * @return bool Success status
     */
    public function addIntakeToLead($leadId, $intakeId, $addedBy) {
        try {
            // Check if intake exists
            $intakeQuery = "SELECT COUNT(*) FROM semesters WHERE id = ?";
            $intakeStmt = $this->conn->prepare($intakeQuery);
            $intakeStmt->bindParam(1, $intakeId, PDO::PARAM_INT);
            $intakeStmt->execute();
            
            if ($intakeStmt->fetchColumn() === 0) {
                // Intake doesn't exist
                error_log('Invalid intake in addIntakeToLead: ' . $intakeId);
                return false;
            }
            
            // Check if link already exists
            $checkQuery = "SELECT COUNT(*) FROM lead_semesters 
                          WHERE lead_id = ? AND semester_id = ?";
            $checkStmt = $this->conn->prepare($checkQuery);
            $checkStmt->bindParam(1, $leadId, PDO::PARAM_INT);
            $checkStmt->bindParam(2, $intakeId, PDO::PARAM_INT);
            $checkStmt->execute();
            
            if ($checkStmt->fetchColumn() > 0) {
                // Link already exists
                return true;
            }
            
            // Add new link
            $query = "INSERT INTO lead_semesters (lead_id, semester_id, added_by) 
                     VALUES (?, ?, ?)";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(1, $leadId, PDO::PARAM_INT);
            $stmt->bindParam(2, $intakeId, PDO::PARAM_INT);
            $stmt->bindParam(3, $addedBy, PDO::PARAM_INT);
            return $stmt->execute();
        } catch (Exception $e) {
            error_log('Error in addIntakeToLead: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Process multiple semesters for a lead by parsing a comma-separated string
     * 
     * @param int $leadId Lead ID
     * @param string $semestersString Comma-separated intake IDs
     * @param int $userId User making the changes
     * @return void
     */
    public function processLeadIntakes($leadId, $semestersString, $userId) {
        // First remove existing semesters
        $this->removeAllIntakesFromLead($leadId);
        
        // If no semesters provided, we're done
        if (empty($semestersString)) {
            return;
        }
        
        // Split the string and add each intake
        $intakeIds = explode(',', $semestersString);
        foreach ($intakeIds as $intakeId) {
            if (is_numeric($intakeId) && $intakeId > 0) {
                $this->addIntakeToLead($leadId, $intakeId, $userId);
            }
        }
    }
    
    /**
     * Remove all semesters from a lead
     * 
     * @param int $leadId Lead ID
     * @return bool Success status
     */
    private function removeAllIntakesFromLead($leadId) {
        try {
            $query = "DELETE FROM lead_semesters WHERE lead_id = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(1, $leadId, PDO::PARAM_INT);
            return $stmt->execute();
        } catch (Exception $e) {
            error_log('Error in removeAllIntakesFromLead: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Process multiple staff assignments for a lead by parsing a comma-separated string
     * 
     * @param int $leadId Lead ID
     * @param string $staffString Comma-separated staff IDs
     * @param int $userId User making the changes
     * @return void
     */
    public function processLeadStaffAssignments($leadId, $staffString, $userId) {
        // First remove existing staff assignments
        $this->removeAllStaffFromLead($leadId);
        
        // If no staff provided, we're done
        if (empty($staffString)) {
            return;
        }
        
        // Split the string and add each staff member
        $staffIds = explode(',', $staffString);
        foreach ($staffIds as $staffId) {
            if (is_numeric($staffId) && $staffId > 0) {
                $this->assignStaffToLead($leadId, $staffId, $userId);
            }
        }
    }
    
    /**
     * Get user type for a specific user
     * 
     * @param int $userId User ID
     * @return string User type
     */
    private function getUserType($userId) {
        $query = "SELECT user_type FROM users WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $userId, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchColumn();
    }
    
    /**
     * Get all active staff users for dropdowns
     * 
     * @return array List of staff members
     */
        public function getAllStaff() {
        $query = "SELECT u.id, CONCAT(up.first_name, ' ', up.last_name) as name, up.profile_photo, 
                 up.designation, u.account_status
                 FROM users u 
                 INNER JOIN user_profile up ON u.id = up.user_id
                 WHERE u.user_type = 'Counselor' AND u.account_status = 'Active'
                 ORDER BY up.first_name, up.last_name";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Get all active agents for dropdowns
     * 
     * @return array List of agents
     */
    public function getAllAgents() {
        $query = "SELECT u.id, CONCAT(up.first_name, ' ', up.last_name) as name, up.profile_photo, 
                 up.designation, u.account_status
                 FROM users u 
                 INNER JOIN user_profile up ON u.id = up.user_id
                 WHERE u.user_type = 'Agent' AND u.account_status = 'Active'
                 ORDER BY up.first_name, up.last_name";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Get statistics for leads
     * 
     * @param array $filters Filters to apply to the stats
     * @param int $userId User ID for restricted access
     * @param string $userType User type
     * @return array Lead statistics
     */
    public function getLeadStats($filters = [], $userId = null, $userType = null) {
        // Base where clause
        $whereClause = "WHERE 1=1";
        $params = [];
        
        // Access restrictions based on user type
        if ($userType !== 'Super Admin' && $userType !== 'Admin' && $userType !== 'Manager') {
            if ($userType === 'Counselor') {
                // Counselor can only see leads assigned to them or created by them
                $whereClause .= " AND (l.created_by = ? OR l.id IN (SELECT lead_id FROM lead_staff_assignments WHERE staff_id = ?))";
                $params[] = $userId;
                $params[] = $userId;
            } elseif ($userType === 'Agent') {
                // Agents can only see leads created by them or assigned to them
                $whereClause .= " AND (l.created_by = ? OR l.agent_id = ?)";
                $params[] = $userId;
                $params[] = $userId;
            }
        }
        
        // Additional filters
        if (!empty($filters['agent_id'])) {
            $whereClause .= " AND l.agent_id = ?";
            $params[] = $filters['agent_id'];
        }
        
        if (!empty($filters['university_id'])) {
            $whereClause .= " AND l.id IN (SELECT lead_id FROM lead_universities WHERE university_id = ?)";
            $params[] = $filters['university_id'];
        }
        
        if (!empty($filters['course_id'])) {
            $whereClause .= " AND l.id IN (SELECT lead_id FROM lead_courses WHERE course_id = ?)";
            $params[] = $filters['course_id'];
        }
        
        if (!empty($filters['semester_id'])) {
            $whereClause .= " AND l.id IN (SELECT lead_id FROM lead_semesters WHERE semester_id = ?)";
            $params[] = $filters['semester_id'];
        }
        
        if (!empty($filters['staff_id'])) {
            $whereClause .= " AND l.id IN (SELECT lead_id FROM lead_staff_assignments WHERE staff_id = ?)";
            $params[] = $filters['staff_id'];
        }
        
        if (!empty($filters['company_id'])) {
            $whereClause .= " AND l.company_id = ?";
            $params[] = $filters['company_id'];
        }
        
        
        // Total leads by source
        $totalLeadsBySource = $this->getLeadCountsBySource($whereClause, $params);
        
        // Total leads by status
        $totalLeadsByStatus = $this->getLeadCountsByStatus($whereClause, $params);
        
        // Calculate follow-up stats
        $followupTodayCount = $this->getFollowupCount('today', $whereClause, $params);
        $followupOverdueCount = $this->getFollowupCount('overdue', $whereClause, $params);
        
        return [
            'total_leads' => array_sum(array_column($totalLeadsBySource, 'count')),
            'by_source' => $totalLeadsBySource,
            'by_status' => $totalLeadsByStatus,
            'fresh_leads' => $this->getStatusCount('Fresh', $whereClause, $params),
            'unable_to_reach' => $this->getStatusCounts(['Unable to reach once', 'Unable to reach twice', 'Unable to reach trice'], $whereClause, $params),
            'dead_leads' => $this->getStatusCount('Dead', $whereClause, $params),
            'followup_today_count' => $followupTodayCount,
            'followup_overdue_count' => $followupOverdueCount
        ];
    }
    
    /**
     * Get lead counts by source
     * 
     * @param string $whereClause Where clause for filtering
     * @param array $params Parameters for the query
     * @return array Counts by source
     */
    private function getLeadCountsBySource($whereClause, $params) {
        $query = "SELECT lead_source, COUNT(*) as count 
                 FROM leads l 
                 $whereClause 
                 GROUP BY lead_source";
        
        $stmt = $this->conn->prepare($query);
        
        foreach ($params as $i => $param) {
            $paramType = is_int($param) ? PDO::PARAM_INT : PDO::PARAM_STR;
            $stmt->bindValue($i + 1, $params[$i], $paramType);
        }
        
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Get lead counts by status
     * 
     * @param string $whereClause Where clause for filtering
     * @param array $params Parameters for the query
     * @return array Counts by status
     */
    private function getLeadCountsByStatus($whereClause, $params) {
        $query = "SELECT lead_status, COUNT(*) as count 
                 FROM leads l 
                 $whereClause 
                 GROUP BY lead_status";
        
        $stmt = $this->conn->prepare($query);
        
        foreach ($params as $i => $param) {
            $paramType = is_int($param) ? PDO::PARAM_INT : PDO::PARAM_STR;
            $stmt->bindValue($i + 1, $params[$i], $paramType);
        }
        
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Get count of leads with a specific status
     * 
     * @param string $status Status to count
     * @param string $whereClause Where clause for filtering
     * @param array $params Parameters for the query
     * @return int Count of leads with the status
     */
    private function getStatusCount($status, $whereClause, $params) {
        $query = "SELECT COUNT(*) 
                 FROM leads l 
                 $whereClause 
                 AND l.lead_status = ?";
        
        $allParams = $params;
        $allParams[] = $status;
        
        $stmt = $this->conn->prepare($query);
        
        foreach ($allParams as $i => $param) {
            $paramType = is_int($param) ? PDO::PARAM_INT : PDO::PARAM_STR;
            $stmt->bindValue($i + 1, $allParams[$i], $paramType);
        }
        
        $stmt->execute();
        return $stmt->fetchColumn();
    }
    
    /**
     * Get count of leads with any of the specified statuses
     * 
     * @param array $statuses Statuses to count
     * @param string $whereClause Where clause for filtering
     * @param array $params Parameters for the query
     * @return int Count of leads with the statuses
     */
    private function getStatusCounts($statuses, $whereClause, $params) {
        $placeholders = implode(',', array_fill(0, count($statuses), '?'));
        $query = "SELECT COUNT(*) 
                 FROM leads l 
                 $whereClause 
                 AND l.lead_status IN ($placeholders)";
        
        $allParams = array_merge($params, $statuses);
        
        $stmt = $this->conn->prepare($query);
        
        foreach ($allParams as $i => $param) {
            $paramType = is_int($param) ? PDO::PARAM_INT : PDO::PARAM_STR;
            $stmt->bindValue($i + 1, $allParams[$i], $paramType);
        }
        
        $stmt->execute();
        return $stmt->fetchColumn();
    }
    
    /**
     * Get count of leads needing follow-up
     * 
     * @param string $type Type of follow-up count ('today' or 'overdue')
     * @param string $whereClause Where clause for filtering
     * @param array $params Parameters for the query
     * @return int Count of leads needing follow-up
     */
    private function getFollowupCount($type, $whereClause, $params) {
        if ($type === 'today') {
            $query = "SELECT COUNT(*) 
                     FROM leads l 
                     $whereClause 
                     AND l.next_followup_date = CURDATE()
                     AND l.lead_status NOT IN ('Dead', 'Admitted')";
        } elseif ($type === 'overdue') {
            $query = "SELECT COUNT(*) 
                     FROM leads l 
                     $whereClause 
                     AND l.next_followup_date < CURDATE()
                     AND l.lead_status NOT IN ('Dead', 'Admitted')";
        } else {
            return 0;
        }
        
        $stmt = $this->conn->prepare($query);
        
        foreach ($params as $i => $param) {
            $paramType = is_int($param) ? PDO::PARAM_INT : PDO::PARAM_STR;
            $stmt->bindValue($i + 1, $param, $paramType);
        }
        
        $stmt->execute();
        return $stmt->fetchColumn();
    }
    
    /**
     * Update follow-up tracking when lead status changes
     * 
     * @param int $leadId Lead ID
     * @param string $newStatus New lead status
     * @return bool Success status
     */
    private function updateFollowupTracking($leadId, $newStatus) {
        try {
            // Check if status should trigger follow-up tracking
            // Exclude 'Dead' and 'Admitted' statuses from follow-up tracking
            if (in_array($newStatus, ['Dead', 'Admitted'])) {
                // Clear follow-up dates for terminated leads
                $query = "UPDATE leads 
                         SET last_status_change_date = CURRENT_TIMESTAMP,
                             next_followup_date = NULL
                         WHERE id = ?";
                
                $stmt = $this->conn->prepare($query);
                $stmt->bindParam(1, $leadId, PDO::PARAM_INT);
                return $stmt->execute();
            } else {
                // Determine follow-up interval based on status
                $followupDays = 2; // Default: 2 days for most statuses
                
                // Fresh status: same day (0 days)
                if ($newStatus === 'Fresh') {
                    $followupDays = 0;
                }
                // Unable to reach statuses: 1 day gap
                elseif (in_array($newStatus, ['Unable to reach once', 'Unable to reach twice', 'Unable to reach trice'])) {
                    $followupDays = 1;
                }
                // All other statuses: 2 days (default)
                
                // Set last_status_change_date to now
                // Calculate next_followup_date based on the status-specific interval
                // Note: This auto-calculates the date, but users can manually override via UI
                $query = "UPDATE leads 
                         SET last_status_change_date = CURRENT_TIMESTAMP,
                             next_followup_date = DATE(DATE_ADD(CURRENT_TIMESTAMP, INTERVAL ? DAY))
                         WHERE id = ?";
                
                $stmt = $this->conn->prepare($query);
                $stmt->bindParam(1, $followupDays, PDO::PARAM_INT);
                $stmt->bindParam(2, $leadId, PDO::PARAM_INT);
                return $stmt->execute();
            }
        } catch (Exception $e) {
            error_log('Error in updateFollowupTracking: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Get leads that need follow-up today
     * 
     * @param int $userId Current user ID
     * @param string $userType Current user type
     * @return array List of leads needing follow-up
     */
    public function getLeadsNeedingFollowupToday($userId = null, $userType = null) {
        $filters = ['followup_today' => true];
        return $this->getLeads($filters, 1, 100, $userId, $userType);
    }
    
    /**
     * Get leads with overdue follow-ups
     * 
     * @param int $userId Current user ID
     * @param string $userType Current user type
     * @return array List of leads with overdue follow-ups
     */
    public function getLeadsWithOverdueFollowup($userId = null, $userType = null) {
        $filters = ['followup_overdue' => true];
        return $this->getLeads($filters, 1, 100, $userId, $userType);
    }
    
    /**
     * Calculate days since last follow-up action
     * 
     * @param string $lastFollowupDate Last follow-up action date
     * @param string $nextFollowupDate Next scheduled follow-up date
     * @return array Array with days_overdue and alert_status
     */
    public function calculateFollowupStatus($lastFollowupDate, $nextFollowupDate) {
        if (empty($nextFollowupDate)) {
            return ['days_overdue' => 0, 'alert_status' => 'none'];
        }
        
        $today = new DateTime();
        $today->setTime(0, 0, 0); // Reset to start of day
        
        $followupDate = new DateTime($nextFollowupDate);
        $followupDate->setTime(0, 0, 0);
        
        $interval = $today->diff($followupDate);
        $daysUntilFollowup = (int) $interval->format('%r%a'); // Negative if overdue
        
        // If next_followup_date is today or in the past
        if ($daysUntilFollowup <= 0) {
            // Check if any action was taken on or after the scheduled date
            if (!empty($lastFollowupDate)) {
                $lastAction = new DateTime($lastFollowupDate);
                $lastAction->setTime(0, 0, 0);
                
                // If last action was on or after the follow-up date, no alert
                if ($lastAction >= $followupDate) {
                    return ['days_overdue' => 0, 'alert_status' => 'completed'];
                }
            }
            
            // Calculate days overdue (absolute value)
            $daysOverdue = abs($daysUntilFollowup);
            
            if ($daysOverdue === 0) {
                return ['days_overdue' => 0, 'alert_status' => 'due_today'];
            } else {
                return ['days_overdue' => $daysOverdue, 'alert_status' => 'overdue'];
            }
        }
        
        // Follow-up is scheduled for future
        return ['days_overdue' => 0, 'alert_status' => 'scheduled'];
    }
    
}
?>