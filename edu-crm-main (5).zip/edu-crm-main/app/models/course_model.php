<?php
/**
 * Course Model
 * Restructured on: 2026-01-14
 * Purpose: Simplified course management with only title, department, and credit
 */

class CourseModel {
    private $conn;
    private $hasDepartmentColumn = null; // Cache column existence check
    
    public function __construct($conn) {
        $this->conn = $conn;
    }
    
    /**
     * Check if department column exists (cached for performance)
     * 
     * @return bool True if department column exists
     */
    private function checkDepartmentColumn() {
        if ($this->hasDepartmentColumn === null) {
            try {
                $checkQuery = "SHOW COLUMNS FROM courses LIKE 'department'";
                $checkStmt = $this->conn->prepare($checkQuery);
                $checkStmt->execute();
                $this->hasDepartmentColumn = ($checkStmt->rowCount() > 0);
            } catch (PDOException $e) {
                error_log("Error checking for department column: " . $e->getMessage());
                $this->hasDepartmentColumn = false;
            }
        }
        return $this->hasDepartmentColumn;
    }
    
    /**
     * Get all courses with filters and pagination
     * 
     * @param array $filters The filters to apply
     * @param int $page The current page number
     * @param int $perPage The number of items per page
     * @return array The result with data and pagination info
     */
    public function getCourses($filters = [], $page = 1, $perPage = 10) {
        $offset = ($page - 1) * $perPage;
        
        // Check if department column exists (cached for performance)
        $hasDepartment = $this->checkDepartmentColumn();
        
        // Determine credit column name based on schema (with whitelist validation)
        // Whitelist validation for security - only allow known column names
        $creditColumn = $hasDepartment ? 'c.credit' : 'c.total_credit';
        // Validate against whitelist
        $allowedCreditColumns = ['c.credit', 'c.total_credit'];
        if (!in_array($creditColumn, $allowedCreditColumns)) {
            $creditColumn = 'c.credit'; // fallback to safe default
        }
        
        // Base query - using WHERE 1=1 for easier dynamic filter building
        $query = "SELECT c.* FROM courses c WHERE 1=1";
        $countQuery = "SELECT COUNT(*) as total FROM courses c WHERE 1=1";
        
        $params = [];
        
        // Apply search filter (searches course title and department if column exists)
        if (!empty($filters['search'])) {
            $searchTerm = "%" . $filters['search'] . "%";
            if ($hasDepartment) {
                $query .= " AND (c.course_title LIKE ? OR c.department LIKE ?)";
                $countQuery .= " AND (c.course_title LIKE ? OR c.department LIKE ?)";
                $params[] = $searchTerm;
                $params[] = $searchTerm;
            } else {
                $query .= " AND c.course_title LIKE ?";
                $countQuery .= " AND c.course_title LIKE ?";
                $params[] = $searchTerm;
            }
        }
        
        // Apply department filter (only if column exists)
        if ($hasDepartment && !empty($filters['department'])) {
            $query .= " AND c.department = ?";
            $countQuery .= " AND c.department = ?";
            $params[] = $filters['department'];
        }

        // Add sorting
        if (!empty($filters['sort'])) {
            switch ($filters['sort']) {
                case 'title_asc':
                    $query .= " ORDER BY c.course_title ASC";
                    break;
                case 'title_desc':
                    $query .= " ORDER BY c.course_title DESC";
                    break;
                case 'department_asc':
                    if ($hasDepartment) {
                        $query .= " ORDER BY c.department ASC";
                    } else {
                        $query .= " ORDER BY c.created_at DESC";
                    }
                    break;
                case 'department_desc':
                    if ($hasDepartment) {
                        $query .= " ORDER BY c.department DESC";
                    } else {
                        $query .= " ORDER BY c.created_at DESC";
                    }
                    break;
                case 'credit_asc':
                    $query .= " ORDER BY {$creditColumn} ASC";
                    break;
                case 'credit_desc':
                    $query .= " ORDER BY {$creditColumn} DESC";
                    break;
                default:
                    $query .= " ORDER BY c.created_at DESC";
            }
        } else {
            $query .= " ORDER BY c.created_at DESC";
        }
        
        // Add pagination
        $query .= " LIMIT ? OFFSET ?";
        
        // Prepare and execute count query
        $countStmt = $this->conn->prepare($countQuery);
        if (!empty($params)) {
            for ($i = 0; $i < count($params); $i++) {
                $countStmt->bindValue($i + 1, $params[$i]);
            }
        }
        $countStmt->execute();
        $totalRecords = $countStmt->fetchColumn();
        
        // Add pagination parameters
        $queryParams = $params;
        $queryParams[] = $perPage;
        $queryParams[] = $offset;
        
        // Prepare and execute main query
        $stmt = $this->conn->prepare($query);
        for ($i = 0; $i < count($queryParams); $i++) {
            $paramType = is_int($queryParams[$i]) ? PDO::PARAM_INT : PDO::PARAM_STR;
            $stmt->bindValue($i + 1, $queryParams[$i], $paramType);
        }
        $stmt->execute();
        
        $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Calculate pagination info
        $totalPages = ceil($totalRecords / $perPage);
        
        return [
            'data' => $courses,
            'pagination' => [
                'total' => $totalPages,
                'current' => $page,
                'total_records' => $totalRecords
            ],
            'filters' => $filters,
            'stats' => [
                'total_courses' => $totalRecords
            ]
        ];
    }
    
    /**
     * Get a single course by ID
     * 
     * @param int $id The course ID
     * @return array The course data or error message
     */
    public function getCourseById($id) {
        $query = "SELECT c.* FROM courses c WHERE c.id = ?";
                 
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $id, PDO::PARAM_INT);
        $stmt->execute();
        
        $course = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($course) {
            return ['status' => true, 'data' => $course];
        } else {
            return ['status' => false, 'message' => 'Course not found.'];
        }
    }
    
    /**
     * Create a new course
     * 
     * @param array $data The course data
     * @param int $userId The user creating the course
     * @return array Status and message
     */
    public function createCourse($data, $userId) {
        // Check if department column exists (cached for performance)
        $hasDepartment = $this->checkDepartmentColumn();
        
        // Validate required fields
        if (empty($data['course_title'])) {
            return ['status' => false, 'message' => 'Course title is required.'];
        }
        
        if ($hasDepartment && empty($data['department'])) {
            return ['status' => false, 'message' => 'Department is required.'];
        }
        
        if (!$hasDepartment) {
            // Old schema - department column doesn't exist
            return ['status' => false, 'message' => 'This feature is currently unavailable. Please contact administrator.'];
        }
        
        // Prepare insert query
        $query = "INSERT INTO courses (
                    course_title, department, credit, created_by
                ) VALUES (?, ?, ?, ?)";
        
        // Set default values if not provided
        $credit = isset($data['credit']) ? intval($data['credit']) : 0;
        
        // Prepare statement
        $stmt = $this->conn->prepare($query);
        
        // Bind parameters
        $stmt->bindParam(1, $data['course_title'], PDO::PARAM_STR);
        $stmt->bindParam(2, $data['department'], PDO::PARAM_STR);
        $stmt->bindParam(3, $credit, PDO::PARAM_INT);
        $stmt->bindParam(4, $userId, PDO::PARAM_INT);
        
        // Execute the query
        if ($stmt->execute()) {
            $newId = $this->conn->lastInsertId();
            return ['status' => true, 'message' => 'Course created successfully.', 'id' => $newId];
        } else {
            return ['status' => false, 'message' => 'Failed to create course.'];
        }
    }
    
    /**
     * Update an existing course
     * 
     * @param array $data The course data
     * @param int $userId The user updating the course
     * @return array Status and message
     */
    public function updateCourse($data, $userId) {
        // Check if department column exists (cached for performance)
        $hasDepartment = $this->checkDepartmentColumn();
        
        // Validate required fields
        if (empty($data['course_title']) || empty($data['course_id'])) {
            return ['status' => false, 'message' => 'Course title and course ID are required.'];
        }
        
        if ($hasDepartment && empty($data['department'])) {
            return ['status' => false, 'message' => 'Department is required.'];
        }
        
        if (!$hasDepartment) {
            // Old schema - department column doesn't exist
            return ['status' => false, 'message' => 'This feature is currently unavailable. Please contact administrator.'];
        }
        
        // Prepare update query
        $query = "UPDATE courses SET
                    course_title = ?, department = ?, credit = ?, updated_by = ?
                  WHERE id = ?";
        
        // Set default values if not provided
        $credit = isset($data['credit']) ? intval($data['credit']) : 0;
        
        // Prepare statement
        $stmt = $this->conn->prepare($query);
        
        // Bind parameters
        $stmt->bindParam(1, $data['course_title'], PDO::PARAM_STR);
        $stmt->bindParam(2, $data['department'], PDO::PARAM_STR);
        $stmt->bindParam(3, $credit, PDO::PARAM_INT);
        $stmt->bindParam(4, $userId, PDO::PARAM_INT);
        $stmt->bindParam(5, $data['course_id'], PDO::PARAM_INT);
        
        // Execute the query
        if ($stmt->execute()) {
            return ['status' => true, 'message' => 'Course updated successfully.'];
        } else {
            return ['status' => false, 'message' => 'Failed to update course.'];
        }
    }
    
    /**
     * Delete a course by ID
     * 
     * @param int $id The course ID
     * @return array Status and message
     */
    public function deleteCourse($id) {
        $stmt = $this->conn->prepare("DELETE FROM courses WHERE id = ?");
        $stmt->bindParam(1, $id, PDO::PARAM_INT);
        
        if ($stmt->execute()) {
            return ['status' => true, 'message' => 'Course deleted successfully.'];
        } else {
            return ['status' => false, 'message' => 'Failed to delete course.'];
        }
    }
    
    /**
     * Get unique departments for filtering
     * 
     * @return array List of departments
     */
    public function getDepartments() {
        try {
            // Check if department column exists (cached for performance)
            if (!$this->checkDepartmentColumn()) {
                // Department column doesn't exist (old schema)
                // Return empty array instead of failing
                return [];
            }
            
            $query = "SELECT DISTINCT department FROM courses ORDER BY department ASC";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_COLUMN);
        } catch (PDOException $e) {
            // Return empty array on error instead of failing
            error_log("Error in getDepartments: " . $e->getMessage());
            return [];
        }
    }
}
?>