<?php
class CompanySubscription {
    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    /**
     * Get current subscription details for a company
     * @param int $company_id
     * @return array|false
     */
    public function getCompanySubscription($company_id) {
        try {
            $stmt = $this->conn->prepare("
                SELECT 
                    cs.*,
                    sp.plan_name,
                    sp.description as plan_description,
                    sp.price as plan_price,

                    c.company_name,
                    CASE 
                        WHEN cs.end_date < UTC_TIMESTAMP() THEN 'Expired'
                        WHEN cs.subscription_status = 'Active' AND cs.payment_status = 'Paid' THEN 'Active'
                        ELSE cs.subscription_status 
                    END as current_status,
                    u.email as created_by_email
                FROM company_subscriptions cs
                JOIN subscription_plans sp ON cs.subscription_plan_id = sp.id
                JOIN companies c ON cs.company_id = c.id
                LEFT JOIN users u ON cs.created_by = u.id
                WHERE cs.company_id = :company_id
                ORDER BY cs.created_at DESC
                LIMIT 1
            ");
            
            $stmt->bindValue(':company_id', $company_id, PDO::PARAM_INT);
            $stmt->execute();
            
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Debug logging
            error_log("CompanySubscription::getCompanySubscription - Query result for company_id $company_id: " . print_r($result, true));
            
            return $result;
        } catch (PDOException $e) {
            error_log("Error in getCompanySubscription: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Get subscription history
     * @param int $company_id
     * @return array
     */
    public function getSubscriptionHistory($company_id) {
        try {
            $stmt = $this->conn->prepare("
                SELECT 
                    cs.id,
                    cs.start_date,
                    cs.end_date,
                    cs.subscription_status,
                    cs.price_paid,
                    cs.payment_status,
                    cs.payment_method,
                    cs.created_at,
                    sp.plan_name
                FROM company_subscriptions cs
                JOIN subscription_plans sp ON cs.subscription_plan_id = sp.id
                WHERE cs.company_id = :company_id
                ORDER BY cs.created_at DESC
            ");
            
            $stmt->bindValue(':company_id', $company_id, PDO::PARAM_INT);
            $stmt->execute();
            
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Debug logging
            error_log("CompanySubscription::getSubscriptionHistory - Found " . count($result) . " records for company_id $company_id");
            
            return $result;
        } catch (PDOException $e) {
            error_log("Error in getSubscriptionHistory: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Get subscription statistics
     * @param int $company_id
     * @return array
     */
    public function getSubscriptionStats($company_id) {
        try {
            $stmt = $this->conn->prepare("
                SELECT 
                    COUNT(*) as total_subscriptions,
                    COALESCE(SUM(price_paid), 0) as total_amount_paid,
                    MIN(created_at) as first_subscription_date
                FROM company_subscriptions
                WHERE company_id = :company_id
            ");
            
            $stmt->bindValue(':company_id', $company_id, PDO::PARAM_INT);
            $stmt->execute();
            
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Debug logging
            error_log("CompanySubscription::getSubscriptionStats - Stats for company_id $company_id: " . print_r($result, true));
            
            return $result;
        } catch (PDOException $e) {
            error_log("Error in getSubscriptionStats: " . $e->getMessage());
            return [
                'total_subscriptions' => 0,
                'total_amount_paid' => 0,
                'first_subscription_date' => null
            ];
        }
    }

    /**
     * Get subscription expiry details
     * @param int $company_id
     * @return array
     */
    public function getSubscriptionExpiryDetails($company_id) {
        try {
            $stmt = $this->conn->prepare("
                SELECT 
                    end_date,
                    DATEDIFF(end_date, UTC_TIMESTAMP()) as days_remaining
                FROM company_subscriptions 
                WHERE company_id = :company_id 
                AND subscription_status = 'Active'
                AND end_date > UTC_TIMESTAMP()
                ORDER BY end_date DESC
                LIMIT 1
            ");
            
            $stmt->bindValue(':company_id', $company_id, PDO::PARAM_INT);
            $stmt->execute();
            
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Debug logging
            error_log("CompanySubscription::getSubscriptionExpiryDetails - Expiry details for company_id $company_id: " . print_r($result, true));
            
            return $result ?: ['days_remaining' => 0, 'end_date' => null];
        } catch (PDOException $e) {
            error_log("Error in getSubscriptionExpiryDetails: " . $e->getMessage());
            return ['days_remaining' => 0, 'end_date' => null];
        }
    }
}
?>