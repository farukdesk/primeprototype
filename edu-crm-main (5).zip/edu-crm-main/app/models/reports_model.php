<?php
/**
 * Reports Model
 * Created on: 2026-01-26
 * Description: Data access layer for reports
 */

class ReportsModel {
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    /**
     * Get admitted students grouped by program
     * Calculates Previous Day, Today, and Total counts
     */
    public function getAdmittedStudentsByProgram($company_id, $semester = null, $batch = null, $date_from = null, $date_to = null) {
        // Use custom date range if provided, otherwise use today
        $today = $date_to ? date('Y-m-d', strtotime($date_to)) : date('Y-m-d');
        $yesterday = date('Y-m-d', strtotime($today . ' -1 day'));

        // Query to get admitted students grouped by program/applying_for
        $sql = "
            SELECT 
                COALESCE(c.course_title, l.applying_for, 'Uncategorized') as program_name,
                l.applying_for as degree_type,
                COUNT(CASE WHEN DATE(l.updated_at) < :today THEN 1 END) as previous_day,
                COUNT(CASE WHEN DATE(l.updated_at) = :today THEN 1 END) as today,
                COUNT(*) as total
            FROM leads l
            LEFT JOIN lead_courses lc ON l.id = lc.lead_id
            LEFT JOIN courses c ON lc.course_id = c.id
            WHERE l.company_id = :company_id 
            AND l.lead_status = 'Admitted'
        ";

        $params = [
            ':company_id' => $company_id,
            ':today' => $today
        ];

        // Add date range filter
        if ($date_from) {
            $sql .= " AND DATE(l.updated_at) >= :date_from";
            $params[':date_from'] = date('Y-m-d', strtotime($date_from));
        }
        
        if ($date_to) {
            $sql .= " AND DATE(l.updated_at) <= :date_to";
            $params[':date_to'] = date('Y-m-d', strtotime($date_to));
        }

        if ($semester) {
            $sql .= " AND l.semester = :semester";
            $params[':semester'] = $semester;
        }

        $sql .= " GROUP BY program_name, degree_type ORDER BY total DESC";

        $stmt = $this->conn->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get report metadata (semesters, batches, date)
     */
    public function getReportMetadata($company_id) {
        // Get current semester
        $stmt = $this->conn->prepare("
            SELECT name FROM semesters 
            WHERE status = 'active' 
            ORDER BY created_at DESC 
            LIMIT 1
        ");
        $stmt->execute();
        $current_semester = $stmt->fetchColumn();

        // Get total admitted count
        $stmt = $this->conn->prepare("
            SELECT COUNT(*) FROM leads 
            WHERE company_id = ? AND lead_status = 'Admitted'
        ");
        $stmt->execute([$company_id]);
        $total_admitted = $stmt->fetchColumn();

        return [
            'current_semester' => $current_semester ?: 'Spring Semester – 2026',
            'report_date' => date('jS F Y'),
            'total_admitted' => $total_admitted,
            'batch' => '68th and 14th' // This could be made dynamic if batch info is stored
        ];
    }

    /**
     * Get company details for report header
     */
    public function getCompanyDetails($company_id) {
        $stmt = $this->conn->prepare("
            SELECT company_name, address, phone_number 
            FROM companies 
            WHERE id = ?
        ");
        $stmt->execute([$company_id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
