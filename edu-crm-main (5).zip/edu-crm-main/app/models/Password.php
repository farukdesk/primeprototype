<?php
require_once 'config/config.php';

class Password {
    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function verifyCurrentPassword($userId, $password) {
        try {
            $stmt = $this->conn->prepare("SELECT password FROM users WHERE id = :user_id");
            $stmt->execute(['user_id' => $userId]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            return password_verify($password, $user['password']);
        } catch (PDOException $e) {
            error_log("Error verifying current password: " . $e->getMessage());
            throw new Exception("Error processing request");
        }
    }

    public function updatePassword($userId, $newPassword) {
        try {
            $newPasswordHash = password_hash($newPassword, PASSWORD_DEFAULT);
            $stmt = $this->conn->prepare("UPDATE users SET password = :password WHERE id = :user_id");
            $stmt->execute(['password' => $newPasswordHash, 'user_id' => $userId]);

            return $stmt->rowCount() ? true : false;
        } catch (PDOException $e) {
            error_log("Error updating password: " . $e->getMessage());
            throw new Exception("Error processing request");
        }
    }

    public function getConnection() {
        return $this->conn;
    }
}
?>