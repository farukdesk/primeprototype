<?php
class UserProfile {
    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function getProfile($user_id) {
        try {
            $stmt = $this->conn->prepare("
                SELECT u.id, u.email, u.user_type, 
                       p.first_name, p.last_name, p.profile_photo, 
                       p.date_of_birth, p.mobile_number, p.designation,
                       c.company_name 
                FROM users u 
                LEFT JOIN user_profile p ON u.id = p.user_id 
                LEFT JOIN companies c ON u.company_id = c.id
                WHERE u.id = :user_id
            ");
            $stmt->execute(['user_id' => $user_id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Error in getProfile: " . $e->getMessage());
            throw $e;
        }
    }

    public function updateUserEmail($user_id, $email) {
        try {
            $stmt = $this->conn->prepare("
                UPDATE users 
                SET email = :email 
                WHERE id = :user_id
            ");
            return $stmt->execute([
                'email' => $email,
                'user_id' => $user_id
            ]);
        } catch (PDOException $e) {
            error_log("Error updating email: " . $e->getMessage());
            return false;
        }
    }

    public function updateProfile($data) {
        try {
            $this->conn->beginTransaction();

            // First check if profile exists
            $stmt = $this->conn->prepare("
                SELECT COUNT(*) 
                FROM user_profile 
                WHERE user_id = :user_id
            ");
            $stmt->execute(['user_id' => $data['user_id']]);
            $exists = $stmt->fetchColumn();

            if ($exists) {
                // Update existing profile
                $stmt = $this->conn->prepare("
                    UPDATE user_profile 
                    SET first_name = :first_name,
                        last_name = :last_name,
                        date_of_birth = :date_of_birth,
                        mobile_number = :mobile_number,
                        designation = :designation,
                        profile_photo = :profile_photo
                    WHERE user_id = :user_id
                ");
            } else {
                // Insert new profile
                $stmt = $this->conn->prepare("
                    INSERT INTO user_profile (
                        user_id,
                        first_name,
                        last_name,
                        date_of_birth,
                        mobile_number,
                        designation,
                        profile_photo
                    ) VALUES (
                        :user_id,
                        :first_name,
                        :last_name,
                        :date_of_birth,
                        :mobile_number,
                        :designation,
                        :profile_photo
                    )
                ");
            }

            $result = $stmt->execute([
                'user_id' => $data['user_id'],
                'first_name' => $data['first_name'],
                'last_name' => $data['last_name'],
                'date_of_birth' => $data['date_of_birth'],
                'mobile_number' => $data['mobile_number'],
                'designation' => $data['designation'],
                'profile_photo' => $data['profile_photo'] ?? null
            ]);

            if ($result) {
                $this->conn->commit();
                return true;
            } else {
                $this->conn->rollBack();
                return false;
            }
        } catch (PDOException $e) {
            $this->conn->rollBack();
            error_log("Error in updateProfile: " . $e->getMessage());
            return false;
        }
    }

    public function getProfilePhoto($user_id) {
        try {
            $stmt = $this->conn->prepare("
                SELECT profile_photo 
                FROM user_profile 
                WHERE user_id = :user_id
            ");
            $stmt->execute(['user_id' => $user_id]);
            return $stmt->fetchColumn();
        } catch (PDOException $e) {
            error_log("Error getting profile photo: " . $e->getMessage());
            return false;
        }
    }
}
?>