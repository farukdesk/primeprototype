-- Database Migration to Remove "Lead converted to Applicant" Status
-- Date: 2026-01-19
-- Purpose: Remove deprecated "Lead converted to Applicant" status from enum

-- First, update any existing leads with this status to a more appropriate status
-- (assuming they should be marked as 'Admitted' or another status)
UPDATE `leads` 
SET `lead_status` = 'Admitted' 
WHERE `lead_status` = 'Lead converted to Applicant';

-- Now modify the enum to remove "Lead converted to Applicant"
ALTER TABLE `leads` 
MODIFY COLUMN `lead_status` ENUM(
    'Fresh',
    '1st call',
    '2nd call',
    '3rd call',
    'Unable to reach once',
    'Unable to reach twice',
    'Unable to reach trice',
    'Dead',
    'Will visit office',
    'Admitted'
) DEFAULT 'Fresh';
