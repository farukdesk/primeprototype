-- ============================================
-- Database Migration Script
-- Purpose: Restructure EDU-CRM for Single University
-- Date: 2026-01-14
-- ============================================

-- Step 1: Rename intakes table to semesters
RENAME TABLE `intakes` TO `semesters`;

-- Step 2: Rename related junction table
RENAME TABLE `lead_intakes` TO `lead_semesters`;

-- Step 3: Update foreign key column name in lead_semesters
ALTER TABLE `lead_semesters` 
CHANGE COLUMN `intake_id` `semester_id` INT NOT NULL;

-- Step 4: Add degree_type column to courses table
ALTER TABLE `courses` 
ADD COLUMN `degree_type` ENUM('Bachelor', 'Masters', 'PhD', 'Diploma', 'Certificate') NULL AFTER `academic_level`;

-- Step 5: Update degree_type based on existing academic_level data
UPDATE `courses` 
SET `degree_type` = CASE 
    WHEN `academic_level` LIKE '%Bachelor%' THEN 'Bachelor'
    WHEN `academic_level` LIKE '%Master%' THEN 'Masters'
    WHEN `academic_level` LIKE '%PhD%' OR `academic_level` LIKE '%Doctorate%' THEN 'PhD'
    WHEN `academic_level` LIKE '%Diploma%' THEN 'Diploma'
    WHEN `academic_level` LIKE '%Certificate%' THEN 'Certificate'
    ELSE 'Bachelor'
END;

-- Step 6: Rename office_visit_date to campus_visit_date in leads table
ALTER TABLE `leads` 
CHANGE COLUMN `office_visit_date` `campus_visit_date` DATETIME NULL DEFAULT NULL;

-- Step 7: Add campus_visit_attended_at column if it doesn't exist
-- (Check if the column exists in the original schema)
ALTER TABLE `leads` 
ADD COLUMN `campus_visit_attended_at` DATETIME NULL DEFAULT NULL AFTER `campus_visit_date`;

-- Step 8: Update assigned_office column name to assigned_campus
ALTER TABLE `leads` 
CHANGE COLUMN `assigned_office` `assigned_campus` VARCHAR(100) NULL DEFAULT NULL;

-- Step 9: Update lead source values from 'Direct Office Visit' to 'Direct Campus Visit'
UPDATE `leads` 
SET `lead_source` = 'Direct Campus Visit' 
WHERE `lead_source` = 'Direct Office Visit';

-- Step 10: Update lead status from 'Will visit office' to 'Will visit campus'
UPDATE `leads` 
SET `lead_status` = 'Will visit campus' 
WHERE `lead_status` = 'Will visit office';

-- Step 11: Make university_id nullable in courses table (for single university use)
ALTER TABLE `courses` 
MODIFY COLUMN `university_id` INT NULL;

-- Step 12: Add notes about university removal
-- Note: We're keeping university tables for data integrity but making them optional
-- The system will now focus on courses and semesters instead

-- ============================================
-- IMPORTANT NOTES:
-- 1. Backup your database before running this migration
-- 2. This script assumes the database schema matches the provided SQL dump
-- 3. After migration, update application code to use new terminology
-- 4. Test thoroughly in a development environment first
-- ============================================

-- Verification queries (run after migration to check)
-- SELECT COUNT(*) FROM semesters;
-- SELECT COUNT(*) FROM lead_semesters;
-- SELECT DISTINCT degree_type FROM courses;
-- SELECT DISTINCT lead_source FROM leads;
-- SELECT DISTINCT lead_status FROM leads;
