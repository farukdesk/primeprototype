<?php
/**
 * Public Lead Landing Page
 * Created on: 2026-01-19
 * Purpose: Allow students to directly submit their information online
 * This page is accessible without authentication
 */

// Include database connection
require_once 'config/config.php';

// Function to get all active courses
function getActiveCourses($conn) {
    $query = "SELECT id, course_title, department FROM courses ORDER BY course_title ASC";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Function to get all active semesters
function getActiveSemesters($conn) {
    $query = "SELECT id, name FROM semesters WHERE status = 'Active' ORDER BY start_date DESC";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

$courses = getActiveCourses($conn);
$semesters = getActiveSemesters($conn);
$submitted = false;
$error = '';

// Start session for captcha
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Generate captcha on every page load (GET request) or if not exists
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['captcha_num1']) || !isset($_SESSION['captcha_num2'])) {
    $_SESSION['captcha_num1'] = random_int(1, 10);
    $_SESSION['captcha_num2'] = random_int(1, 10);
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Validate captcha first
        if (empty($_POST['captcha_answer'])) {
            throw new Exception('Please answer the security question.');
        }
        
        // Validate that captcha answer is numeric
        if (!is_numeric($_POST['captcha_answer'])) {
            // Regenerate captcha on invalid input
            $_SESSION['captcha_num1'] = random_int(1, 10);
            $_SESSION['captcha_num2'] = random_int(1, 10);
            throw new Exception('Please enter a valid number for the security question.');
        }
        
        $captcha_answer = (int)$_POST['captcha_answer'];
        $expected_answer = $_SESSION['captcha_num1'] + $_SESSION['captcha_num2'];
        
        if ($captcha_answer !== $expected_answer) {
            // Regenerate captcha on wrong answer
            $_SESSION['captcha_num1'] = random_int(1, 10);
            $_SESSION['captcha_num2'] = random_int(1, 10);
            throw new Exception('Incorrect answer to the security question. Please try again.');
        }
        
        // Validate required fields
        $applying_for_sanitized = !empty($_POST['applying_for']) ? htmlspecialchars(trim($_POST['applying_for'])) : '';
        
        if (empty($_POST['first_name']) || empty($_POST['last_name']) || 
            empty($_POST['email']) || empty($_POST['phone']) ||
            empty($_POST['address']) || empty($_POST['current_city']) ||
            empty($applying_for_sanitized) || empty($_POST['interested_course_id']) ||
            empty($_POST['semester'])) {
            throw new Exception('Please fill in all required fields.');
        }
        
        // Validate interested_course_id is a positive integer
        if (!is_numeric($_POST['interested_course_id']) || (int)$_POST['interested_course_id'] <= 0) {
            throw new Exception('Please select a valid course.');
        }
        
        // Validate education fields based on degree type
        if ($applying_for_sanitized === 'Bachelor Degree') {
            if (empty($_POST['ssc_gpa']) || empty($_POST['hsc_gpa'])) {
                throw new Exception('Please fill in SSC and HSC GPA for Bachelor Degree application.');
            }
            // Validate GPA values are numeric
            if (!is_numeric($_POST['ssc_gpa']) || !is_numeric($_POST['hsc_gpa'])) {
                throw new Exception('Please enter valid numeric values for GPA.');
            }
        } elseif ($applying_for_sanitized === 'Master Degree') {
            if (empty($_POST['ssc_gpa']) || empty($_POST['hsc_gpa']) || 
                empty($_POST['bachelor_subject']) || empty($_POST['bachelor_cgpa'])) {
                throw new Exception('Please fill in all education information for Master Degree application.');
            }
            // Validate GPA values are numeric
            if (!is_numeric($_POST['ssc_gpa']) || !is_numeric($_POST['hsc_gpa']) || 
                !is_numeric($_POST['bachelor_cgpa'])) {
                throw new Exception('Please enter valid numeric values for GPA and CGPA.');
            }
        } else {
            throw new Exception('Please select a valid degree type.');
        }

        // Validate email format
        if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
            throw new Exception('Please provide a valid email address.');
        }

        // Check for duplicate submission by email or phone
        $email = htmlspecialchars(trim($_POST['email']));
        $phone = htmlspecialchars(trim($_POST['phone']));
        
        $duplicateCheckQuery = "SELECT id FROM leads WHERE email = ? OR phone = ? LIMIT 1";
        $duplicateStmt = $conn->prepare($duplicateCheckQuery);
        $duplicateStmt->execute([$email, $phone]);
        
        if ($duplicateStmt->fetch()) {
            throw new Exception('We have already received your application. Our admissions team will contact you soon. If you need to update your information, please contact us directly.');
        }

        // Start transaction
        $conn->beginTransaction();

        // Insert lead data
        // Using Super Admin (ID 3) as creator for public submissions
        $query = "INSERT INTO leads (
                    first_name, last_name, email, phone, address, current_city,
                    applying_for, semester, interested_course_id,
                    ssc_gpa, hsc_gpa, bachelor_subject, bachelor_cgpa,
                    lead_source, lead_status, created_by, company_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Direct Online', 'Fresh', 3, 1)";

        $stmt = $conn->prepare($query);
        
        // Sanitize inputs
        $first_name = htmlspecialchars(trim($_POST['first_name']));
        $last_name = htmlspecialchars(trim($_POST['last_name']));
        $email = htmlspecialchars(trim($_POST['email']));
        $phone = htmlspecialchars(trim($_POST['phone']));
        $address = htmlspecialchars(trim($_POST['address']));
        $current_city = htmlspecialchars(trim($_POST['current_city']));
        $applying_for = $applying_for_sanitized;
        $semester = htmlspecialchars(trim($_POST['semester']));
        $interested_course_id = (int)$_POST['interested_course_id'];
        
        // Educational details - now always required based on degree type
        $ssc_gpa = floatval($_POST['ssc_gpa']);
        $hsc_gpa = floatval($_POST['hsc_gpa']);
        
        // Bachelor fields required only for Master Degree
        if ($applying_for === 'Master Degree') {
            $bachelor_subject = htmlspecialchars(trim($_POST['bachelor_subject']));
            $bachelor_cgpa = floatval($_POST['bachelor_cgpa']);
        } else {
            $bachelor_subject = null;
            $bachelor_cgpa = null;
        }

        // Bind parameters
        $stmt->bindParam(1, $first_name, PDO::PARAM_STR);
        $stmt->bindParam(2, $last_name, PDO::PARAM_STR);
        $stmt->bindParam(3, $email, PDO::PARAM_STR);
        $stmt->bindParam(4, $phone, PDO::PARAM_STR);
        $stmt->bindParam(5, $address, PDO::PARAM_STR);
        $stmt->bindParam(6, $current_city, PDO::PARAM_STR);
        $stmt->bindParam(7, $applying_for, PDO::PARAM_STR);
        $stmt->bindParam(8, $semester, PDO::PARAM_STR);
        $stmt->bindParam(9, $interested_course_id, PDO::PARAM_INT);
        $stmt->bindParam(10, $ssc_gpa, PDO::PARAM_STR);
        $stmt->bindParam(11, $hsc_gpa, PDO::PARAM_STR);
        $stmt->bindParam(12, $bachelor_subject, PDO::PARAM_STR);
        $stmt->bindParam(13, $bachelor_cgpa, PDO::PARAM_STR);

        $stmt->execute();
        
        $conn->commit();
        $submitted = true;
        
        // Regenerate captcha for next submission
        $_SESSION['captcha_num1'] = random_int(1, 10);
        $_SESSION['captcha_num2'] = random_int(1, 10);
    } catch (Exception $e) {
        $conn->rollBack();
        $error = $e->getMessage();
        error_log('Error in public lead form: ' . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Apply Now - Prime University</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Submit your application to Prime University" name="description" />
    
    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">
    
    <!-- Theme Config Js -->
    <script src="assets/js/config.js"></script>
    
    <!-- App css -->
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" id="app-style" />
    
    <!-- Icons css -->
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    
    <style>
        .public-form-container {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 40px 20px;
        }
        
        .form-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            padding: 40px;
            margin: 0 auto;
            max-width: 800px;
        }
        
        .form-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .form-header img {
            max-height: 80px;
            width: auto;
            max-width: 100%;
            height: auto;
            margin-bottom: 20px;
        }
        
        .form-header h1 {
            color: #333;
            font-size: 32px;
            margin-bottom: 10px;
        }
        
        .form-header p {
            color: #666;
            font-size: 16px;
        }
        
        .success-message {
            background: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            margin: 20px 0;
        }
        
        .success-message h2 {
            color: #155724;
            font-size: 24px;
            margin-bottom: 10px;
        }
        
        .error-message {
            background: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        
        .section-title {
            font-size: 20px;
            font-weight: 600;
            color: #333;
            margin: 30px 0 20px 0;
            padding-bottom: 10px;
            border-bottom: 2px solid #667eea;
        }
        
        .required-indicator {
            color: #dc3545;
        }
        
        .captcha-input {
            font-size: 1.2rem;
            font-weight: 600;
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
            .public-form-container {
                padding: 20px 10px;
            }
            
            .form-card {
                padding: 20px 15px;
                border-radius: 10px;
            }
            
            .form-header h1 {
                font-size: 24px;
            }
            
            .form-header p {
                font-size: 14px;
            }
            
            .form-header img {
                max-height: 60px;
                margin-bottom: 15px;
            }
            
            .section-title {
                font-size: 18px;
                margin: 20px 0 15px 0;
            }
            
            .success-message h2 {
                font-size: 20px;
            }
            
            .success-message i {
                font-size: 36px !important;
            }
            
            .btn-lg {
                width: 100%;
                padding: 12px 20px;
            }
        }
        
        @media (max-width: 480px) {
            .form-header h1 {
                font-size: 20px;
            }
            
            .form-header img {
                max-height: 50px;
            }
            
            .section-title {
                font-size: 16px;
            }
        }
    </style>
</head>

<body>
    <div class="public-form-container">
        <div class="form-card">
            <div class="form-header">
                <img src="https://www.primeuniversity.ac.bd/prime/assets/images/logo-dark.png" alt="Prime University">
                <h1>Apply to Prime University</h1>
                <p>Fill in your details and we'll get back to you soon</p>
            </div>

            <?php if ($submitted): ?>
                <div class="success-message">
                    <i class="ri-checkbox-circle-fill" style="font-size: 48px; color: #28a745;"></i>
                    <h2>Thank You!</h2>
                    <p>Your application has been submitted successfully. Our admissions team will contact you shortly.</p>
                    <a href="apply-now.php" class="btn btn-primary mt-3">Submit Another Application</a>
                </div>
            <?php else: ?>
                <?php if ($error): ?>
                    <div class="error-message">
                        <i class="ri-error-warning-fill me-2"></i>
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="" id="leadForm" novalidate>
                    <!-- Personal Information Section -->
                    <div class="section-title">
                        <i class="ri-user-line me-2"></i>Personal Information
                    </div>
                    
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="text" class="form-control" id="first_name" name="first_name" 
                                       placeholder="First Name" required>
                                <label for="first_name">First Name <span class="required-indicator">*</span></label>
                                <div class="invalid-feedback">Please provide your first name.</div>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="text" class="form-control" id="last_name" name="last_name" 
                                       placeholder="Last Name" required>
                                <label for="last_name">Last Name <span class="required-indicator">*</span></label>
                                <div class="invalid-feedback">Please provide your last name.</div>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="email" class="form-control" id="email" name="email" 
                                       placeholder="Email" required>
                                <label for="email">Email <span class="required-indicator">*</span></label>
                                <div class="invalid-feedback">Please provide a valid email.</div>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="tel" class="form-control" id="phone" name="phone" 
                                       placeholder="Phone" required>
                                <label for="phone">Phone <span class="required-indicator">*</span></label>
                                <div class="invalid-feedback">Please provide your phone number.</div>
                            </div>
                        </div>
                        
                        <div class="col-md-12">
                            <div class="form-floating">
                                <textarea class="form-control" id="address" name="address" 
                                          placeholder="Address" style="height: 100px" required></textarea>
                                <label for="address">Address <span class="required-indicator">*</span></label>
                                <div class="invalid-feedback">Please provide your address.</div>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="text" class="form-control" id="current_city" name="current_city" 
                                       placeholder="Current City" required>
                                <label for="current_city">Current City <span class="required-indicator">*</span></label>
                                <div class="invalid-feedback">Please provide your current city.</div>
                            </div>
                        </div>
                    </div>

                    <!-- Education Information Section -->
                    <div class="section-title">
                        <i class="ri-book-open-line me-2"></i>Education Information
                    </div>
                    
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="form-floating">
                                <select class="form-select" id="applying_for" name="applying_for" required>
                                    <option value="">Select Degree</option>
                                    <option value="Bachelor Degree">Bachelor Degree</option>
                                    <option value="Master Degree">Master Degree</option>
                                </select>
                                <label for="applying_for">Applying For <span class="required-indicator">*</span></label>
                                <div class="invalid-feedback">Please select the degree you are applying for.</div>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-floating">
                                <select class="form-select" id="interested_course_id" name="interested_course_id" required>
                                    <option value="">Select Course</option>
                                    <?php foreach ($courses as $course): ?>
                                        <option value="<?php echo $course['id']; ?>">
                                            <?php echo htmlspecialchars($course['course_title']); ?>
                                            <?php if (!empty($course['department'])): ?>
                                                - <?php echo htmlspecialchars($course['department']); ?>
                                            <?php endif; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <label for="interested_course_id">Interested Course <span class="required-indicator">*</span></label>
                                <div class="invalid-feedback">Please select a course.</div>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-floating">
                                <select class="form-select" id="semester" name="semester" required>
                                    <option value="">Select Semester</option>
                                    <?php foreach ($semesters as $semester): ?>
                                        <option value="<?php echo htmlspecialchars($semester['name']); ?>">
                                            <?php echo htmlspecialchars($semester['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <label for="semester">Preferred Semester <span class="required-indicator">*</span></label>
                                <div class="invalid-feedback">Please select a semester.</div>
                            </div>
                        </div>
                        
                        <div class="col-md-6 degree-field" id="ssc_gpa_container" style="display: none;">
                            <div class="form-floating">
                                <input type="number" class="form-control" id="ssc_gpa" name="ssc_gpa" 
                                       placeholder="SSC GPA" min="0" max="5" step="0.01">
                                <label for="ssc_gpa">SSC GPA <span class="required-indicator">*</span></label>
                                <div class="invalid-feedback">Please provide your SSC GPA.</div>
                            </div>
                        </div>
                        
                        <div class="col-md-6 degree-field" id="hsc_gpa_container" style="display: none;">
                            <div class="form-floating">
                                <input type="number" class="form-control" id="hsc_gpa" name="hsc_gpa" 
                                       placeholder="HSC GPA" min="0" max="5" step="0.01">
                                <label for="hsc_gpa">HSC GPA <span class="required-indicator">*</span></label>
                                <div class="invalid-feedback">Please provide your HSC GPA.</div>
                            </div>
                        </div>
                        
                        <div class="col-md-6 master-field" id="bachelor_subject_container" style="display: none;">
                            <div class="form-floating">
                                <input type="text" class="form-control" id="bachelor_subject" name="bachelor_subject" 
                                       placeholder="Bachelor Subject">
                                <label for="bachelor_subject">Bachelor Subject <span class="required-indicator">*</span></label>
                                <div class="invalid-feedback">Please provide your bachelor subject.</div>
                            </div>
                        </div>
                        
                        <div class="col-md-6 master-field" id="bachelor_cgpa_container" style="display: none;">
                            <div class="form-floating">
                                <input type="number" class="form-control" id="bachelor_cgpa" name="bachelor_cgpa" 
                                       placeholder="CGPA" min="0" max="4" step="0.01">
                                <label for="bachelor_cgpa">Bachelor CGPA <span class="required-indicator">*</span></label>
                                <div class="invalid-feedback">Please provide your bachelor CGPA.</div>
                            </div>
                        </div>
                    </div>

                    <!-- Security Captcha Section -->
                    <div class="section-title">
                        <i class="ri-shield-check-line me-2"></i>Security Verification
                    </div>
                    
                    <div class="row g-3">
                        <div class="col-md-12">
                            <div class="alert alert-info d-flex align-items-center" role="alert">
                                <i class="ri-information-line me-2" style="font-size: 24px;"></i>
                                <div>
                                    <strong>Security Question:</strong> Please solve this simple math problem to verify you're human.
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6 mx-auto">
                            <div class="form-floating">
                                <input type="number" class="form-control form-control-lg text-center captcha-input" 
                                       id="captcha_answer" name="captcha_answer" 
                                       placeholder="Your Answer" required>
                                <label for="captcha_answer">
                                    What is <?php echo $_SESSION['captcha_num1']; ?> + <?php echo $_SESSION['captcha_num2']; ?> ? 
                                    <span class="required-indicator">*</span>
                                </label>
                                <div class="invalid-feedback">Please answer the security question correctly.</div>
                            </div>
                        </div>
                    </div>

                    <div class="mt-4 text-center">
                        <button type="submit" class="btn btn-primary btn-lg px-5">
                            <i class="ri-send-plane-fill me-2"></i>Submit Application
                        </button>
                    </div>
                    
                    <div class="mt-3 text-center text-muted small">
                        <p>By submitting this form, you agree to be contacted by Prime University regarding your application.</p>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>

    <!-- Vendor js -->
    <script src="assets/js/vendor.min.js"></script>
    
    <script>
        // Form validation
        (function() {
            'use strict';
            
            const form = document.getElementById('leadForm');
            
            if (form) {
                form.addEventListener('submit', function(event) {
                    if (!form.checkValidity()) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            }
            
            // Handle degree selection to show/hide education fields
            const applyingForSelect = document.getElementById('applying_for');
            if (applyingForSelect) {
                applyingForSelect.addEventListener('change', function() {
                    const sscContainer = document.getElementById('ssc_gpa_container');
                    const hscContainer = document.getElementById('hsc_gpa_container');
                    const bachelorSubjectContainer = document.getElementById('bachelor_subject_container');
                    const bachelorCgpaContainer = document.getElementById('bachelor_cgpa_container');
                    
                    const sscInput = document.getElementById('ssc_gpa');
                    const hscInput = document.getElementById('hsc_gpa');
                    const bachelorSubjectInput = document.getElementById('bachelor_subject');
                    const bachelorCgpaInput = document.getElementById('bachelor_cgpa');
                    
                    if (this.value === '') {
                        // Hide all fields and clear required attributes
                        sscContainer.style.display = 'none';
                        hscContainer.style.display = 'none';
                        bachelorSubjectContainer.style.display = 'none';
                        bachelorCgpaContainer.style.display = 'none';
                        
                        sscInput.removeAttribute('required');
                        hscInput.removeAttribute('required');
                        bachelorSubjectInput.removeAttribute('required');
                        bachelorCgpaInput.removeAttribute('required');
                    } else if (this.value === 'Bachelor Degree') {
                        // Show SSC and HSC only
                        sscContainer.style.display = 'block';
                        hscContainer.style.display = 'block';
                        bachelorSubjectContainer.style.display = 'none';
                        bachelorCgpaContainer.style.display = 'none';
                        
                        sscInput.setAttribute('required', 'required');
                        hscInput.setAttribute('required', 'required');
                        bachelorSubjectInput.removeAttribute('required');
                        bachelorCgpaInput.removeAttribute('required');
                    } else if (this.value === 'Master Degree') {
                        // Show all fields
                        sscContainer.style.display = 'block';
                        hscContainer.style.display = 'block';
                        bachelorSubjectContainer.style.display = 'block';
                        bachelorCgpaContainer.style.display = 'block';
                        
                        sscInput.setAttribute('required', 'required');
                        hscInput.setAttribute('required', 'required');
                        bachelorSubjectInput.setAttribute('required', 'required');
                        bachelorCgpaInput.setAttribute('required', 'required');
                    }
                });
            }
        })();
    </script>
    
    <script src="assets/js/app.min.js"></script>
</body>
</html>
