# Follow-up Tracking Feature - Deployment & Testing Guide

## Pre-Deployment Checklist

Before deploying this feature to production, ensure:

- [ ] Code review completed
- [ ] All team members understand the new feature
- [ ] Database backup created
- [ ] Staging environment tested (if available)
- [ ] User documentation prepared

## Deployment Steps

### Step 1: Database Migration

**⚠️ IMPORTANT: Backup your database first!**

```bash
# Create a backup
mysqldump -u khansmams334 -p crmkhan2244611 > backup_before_followup_$(date +%Y%m%d_%H%M%S).sql
```

**Run the migration:**

Option A: Using MySQL command line
```bash
mysql -u khansmams334 -p crmkhan2244611 < database_migration_followup_tracking.sql
```

Option B: Using phpMyAdmin
1. Log into phpMyAdmin
2. Select database `crmkhan2244611`
3. Go to "Import" tab
4. Choose file `database_migration_followup_tracking.sql`
5. Click "Go" to execute

**Verify migration:**
```sql
-- Check new fields exist
DESCRIBE leads;

-- Verify indexes created
SHOW INDEX FROM leads WHERE Key_name IN ('idx_next_followup_date', 'idx_last_status_change');

-- Check data was initialized
SELECT COUNT(*) as total_leads, 
       COUNT(next_followup_date) as with_followup_date 
FROM leads 
WHERE lead_status NOT IN ('Dead', 'Admitted');
```

### Step 2: Deploy Code

1. **Pull the latest code** from the repository
2. **Clear any PHP cache** (if using OPcache)
3. **Test on staging first** if available

### Step 3: Post-Deployment Verification

After deployment, verify the feature works:

## Testing Scenarios

### Test 1: Status Change Triggers Follow-up

**Steps:**
1. Go to Lead Management page
2. Select any existing lead (not Dead/Admitted)
3. Click "Edit Lead"
4. Change the status (e.g., from "Fresh" to "1st call")
5. Save the lead

**Expected Results:**
- ✅ Lead updates successfully
- ✅ In database: `last_status_change_date` = current timestamp
- ✅ In database: `next_followup_date` = current date + 2 days
- ✅ In database: `last_followup_action_date` = current timestamp

**Verify in database:**
```sql
SELECT id, first_name, last_name, lead_status, 
       last_status_change_date, next_followup_date, last_followup_action_date
FROM leads 
WHERE id = [LEAD_ID];
```

### Test 2: New Lead Creation

**Steps:**
1. Click "Add New Lead"
2. Fill in required fields
3. Set initial status (e.g., "Fresh")
4. Save the lead

**Expected Results:**
- ✅ Lead created successfully
- ✅ Follow-up date automatically set to 2 days from now
- ✅ All tracking dates initialized

### Test 3: Today's Follow-ups Filter

**Steps:**
1. **Setup**: Manually set some leads' `next_followup_date` to today:
   ```sql
   UPDATE leads 
   SET next_followup_date = CURDATE(),
       last_status_change_date = DATE_SUB(NOW(), INTERVAL 2 DAY)
   WHERE id IN (1, 2, 3) -- Use actual lead IDs
   AND lead_status NOT IN ('Dead', 'Admitted');
   ```

2. Go to Lead Management page
3. Click "Today's Follow-ups" button

**Expected Results:**
- ✅ Button shows count badge (e.g., "3")
- ✅ Only leads with today's follow-up date are shown
- ✅ Yellow "Today" badge displayed in follow-up column
- ✅ Message shows "Follow-up due today"

### Test 4: Overdue Follow-ups Filter & Red Alerts

**Steps:**
1. **Setup**: Create overdue leads:
   ```sql
   UPDATE leads 
   SET next_followup_date = DATE_SUB(CURDATE(), INTERVAL 3 DAY),
       last_status_change_date = DATE_SUB(NOW(), INTERVAL 5 DAY),
       last_followup_action_date = DATE_SUB(NOW(), INTERVAL 5 DAY)
   WHERE id IN (4, 5, 6) -- Use actual lead IDs
   AND lead_status NOT IN ('Dead', 'Admitted');
   ```

2. Go to Lead Management page
3. Look for red badges in the follow-up column
4. Click "Overdue Follow-ups" button

**Expected Results:**
- ✅ Red pulsing badges appear on overdue leads
- ✅ Shows "3 days overdue" message (or actual days)
- ✅ "Overdue Follow-ups" button shows count badge
- ✅ Filter shows only overdue leads
- ✅ Red alert prominently displayed

### Test 5: Lead Detail View

**Steps:**
1. Open any lead with a scheduled follow-up
2. Check the lead detail page

**Expected Results:**
- ✅ Alert box at top shows follow-up information
- ✅ Color matches status (red=overdue, yellow=today, blue=scheduled)
- ✅ Shows exact follow-up date
- ✅ Shows days overdue if applicable
- ✅ Shows last status change date

### Test 6: Dead/Admitted Lead Exclusion

**Steps:**
1. Select a lead with a follow-up scheduled
2. Change status to "Dead"
3. Save the lead

**Expected Results:**
- ✅ `next_followup_date` becomes NULL
- ✅ Lead no longer appears in follow-up filters
- ✅ No follow-up alerts shown for this lead
- ✅ Follow-up column shows "Complete" or "N/A"

**Database check:**
```sql
SELECT id, first_name, last_name, lead_status, next_followup_date
FROM leads 
WHERE lead_status IN ('Dead', 'Admitted');
-- All should have next_followup_date = NULL
```

### Test 7: Action Updates Follow-up Tracking

**Steps:**
1. Select a lead with an overdue follow-up
2. Add a note or make any update
3. Save

**Expected Results:**
- ✅ `last_followup_action_date` updates to current timestamp
- ✅ Alert changes from red to completed (if action after scheduled date)
- ✅ Overdue message no longer shows (action was taken)

### Test 8: Mobile Responsiveness

**Steps:**
1. Open Lead Management page on mobile device or use browser dev tools
2. Resize to mobile width (< 768px)
3. Check all follow-up features

**Expected Results:**
- ✅ Quick filter buttons stack vertically
- ✅ Follow-up column is readable
- ✅ Badges and alerts display correctly
- ✅ Lead detail alert box adapts to mobile width

## Performance Testing

### Test Query Performance

Run these queries and check execution time:

```sql
-- Should be fast (< 100ms) due to index
EXPLAIN SELECT * FROM leads 
WHERE next_followup_date = CURDATE() 
AND lead_status NOT IN ('Dead', 'Admitted');

-- Check index usage
SHOW INDEX FROM leads;

-- Count queries should be fast
SELECT COUNT(*) FROM leads WHERE next_followup_date = CURDATE();
SELECT COUNT(*) FROM leads WHERE next_followup_date < CURDATE();
```

**Expected:** All queries use index, execution time < 100ms even with 10,000+ leads.

## Common Issues & Solutions

### Issue 1: Follow-up dates not being set

**Symptoms:**
- Status changes but `next_followup_date` remains NULL
- No follow-up information shown

**Check:**
```sql
-- Check if fields exist
DESCRIBE leads;

-- Check for errors in logs
tail -f /var/log/apache2/error.log  # or nginx error log
```

**Solutions:**
1. Verify database migration ran successfully
2. Check PHP error logs for exceptions
3. Verify `updateFollowupTracking()` is being called

### Issue 2: Counts not showing

**Symptoms:**
- Quick filter buttons show no count badges
- Count is always 0

**Check:**
```sql
-- Manually check counts
SELECT COUNT(*) FROM leads WHERE next_followup_date = CURDATE();
SELECT COUNT(*) FROM leads WHERE next_followup_date < CURDATE();
```

**Solutions:**
1. Verify leads have valid `next_followup_date` values
2. Check that `getFollowupCount()` method is working
3. Verify no PHP errors in stats calculation

### Issue 3: Red alerts not appearing

**Symptoms:**
- Overdue leads don't show red badges
- No animation on alerts

**Check browser console for:**
- JavaScript errors
- CSS not loading
- Badge elements not rendering

**Solutions:**
1. Clear browser cache
2. Check that CSS is loaded properly
3. Verify `calculateFollowupStatus()` returns correct status
4. Check that lead data includes `followup_status` field

### Issue 4: Permission issues (counselors/agents)

**Symptoms:**
- Some users don't see follow-up features
- Filters don't work for certain user types

**Check:**
```sql
-- Verify user permissions
SELECT id, username, user_type FROM users WHERE id = [USER_ID];
```

**Solutions:**
1. Verify user role has access to lead management
2. Check access control logic in `getLeads()` method
3. Test with different user roles

## Rollback Procedure

If you need to rollback the feature:

### Step 1: Restore Database

```bash
# Stop the application (optional)
# Restore from backup
mysql -u khansmams334 -p crmkhan2244611 < backup_before_followup_YYYYMMDD_HHMMSS.sql
```

### Step 2: Revert Code

```bash
# If using git
git revert [commit-hash]
git push
```

### Alternative: Remove fields only

If you want to keep the code but remove the database fields:

```sql
-- Remove indexes
ALTER TABLE leads DROP INDEX idx_next_followup_date;
ALTER TABLE leads DROP INDEX idx_last_status_change;

-- Remove fields
ALTER TABLE leads 
DROP COLUMN last_status_change_date,
DROP COLUMN next_followup_date,
DROP COLUMN last_followup_action_date;
```

## Monitoring After Deployment

### Week 1: Monitor Closely

Check daily:
- [ ] PHP error logs for exceptions
- [ ] Database slow query log
- [ ] User feedback and questions
- [ ] Follow-up completion rates

### Week 2-4: Regular Checks

Check weekly:
- [ ] Feature usage statistics
- [ ] System performance metrics
- [ ] User satisfaction
- [ ] Bug reports

### Metrics to Track

```sql
-- Follow-up completion rate
SELECT 
    COUNT(*) as total_followups_scheduled,
    SUM(CASE WHEN last_followup_action_date >= next_followup_date THEN 1 ELSE 0 END) as completed,
    ROUND(SUM(CASE WHEN last_followup_action_date >= next_followup_date THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) as completion_rate
FROM leads 
WHERE next_followup_date IS NOT NULL;

-- Average days to complete follow-up
SELECT AVG(DATEDIFF(last_followup_action_date, next_followup_date)) as avg_days_to_followup
FROM leads 
WHERE next_followup_date IS NOT NULL 
AND last_followup_action_date IS NOT NULL
AND last_followup_action_date >= next_followup_date;

-- Current overdue leads
SELECT COUNT(*) as overdue_count
FROM leads 
WHERE next_followup_date < CURDATE() 
AND lead_status NOT IN ('Dead', 'Admitted');
```

## User Training

### For Staff/Counselors

**Key Points to Communicate:**
1. Every status change automatically schedules follow-up for 2 days later
2. Red badges = urgent (overdue) - prioritize these!
3. Yellow badges = due today - try to complete today
4. Any update to the lead (note, status change) marks it as "action taken"
5. Use quick filter buttons to see today's and overdue follow-ups
6. Dead/Admitted leads don't need follow-ups anymore

**Quick Start Guide:**
1. Each morning, click "Today's Follow-ups"
2. Contact each lead shown
3. Update status or add notes
4. Check "Overdue Follow-ups" for any missed leads
5. Take action on red alerts immediately

### For Admins/Managers

**Monitoring Dashboard Ideas:**
- Daily report of overdue follow-ups by staff member
- Follow-up completion rates
- Average response time to follow-ups
- Conversion rates based on follow-up timing

## Success Criteria

The feature is successful if:

- ✅ No critical bugs reported in first week
- ✅ Users understand and use the feature
- ✅ Follow-up completion rate improves
- ✅ No performance degradation
- ✅ Positive user feedback
- ✅ Helps identify and prevent lead neglect

## Support & Maintenance

**For ongoing support:**
1. Document any customizations or changes
2. Keep this testing guide updated
3. Monitor user feedback channels
4. Plan for future enhancements (see FOLLOWUP_TRACKING_README.md)

**Contact:**
- Development Team: [Your contact info]
- Database Admin: [DBA contact]
- Support: [Support email/channel]

---

**Last Updated:** 2026-01-19
**Version:** 1.0
**Author:** Development Team
