# Lead Landing Page Feature - Implementation Documentation

## Overview
This document describes the implementation of the public lead landing page feature that allows students to directly submit their application information online.

## Feature Summary
- **Public Lead Form**: A dedicated public-facing page for students to submit their information
- **Interested Course Field**: New field in the Education section to track which course a student is interested in
- **Automatic Lead Classification**: All submissions through the public form are automatically marked as:
  - Lead Source: "Direct Online"
  - Lead Status: "Fresh"

## Files Changed/Created

### 1. Database Migration
**File**: `database_migration_add_interested_course.sql`
- Adds `interested_course_id` column to the `leads` table
- Creates foreign key relationship with the `courses` table
- Updates lead_source and lead_status enums to ensure compatibility

### 2. Public Lead Landing Page
**File**: `public-lead-form.php`
- New public-facing form accessible without authentication
- Responsive design with branded university styling
- Form sections:
  - Personal Information (first name, last name, email, phone, address, city)
  - Education Information (degree, interested course, semester, GPAs)
- Client-side and server-side validation
- Success/error message handling
- Automatically sets lead_source to "Direct Online" and status to "Fresh"

### 3. Lead Model Updates
**File**: `app/models/lead_model.php`
- Modified `createLead()` method to support `interested_course_id` field
- Modified `updateLead()` method to support `interested_course_id` field
- Added `interested_course_id` to change tracking in `trackChanges()` method
- Updated `getLeadById()` query to fetch interested course name and department

### 4. Lead Management View
**File**: `app/views/lead_management_view.php`
- Added "Interested Course" dropdown in Add Lead form's Education tab
- Dropdown populated with all courses from course management
- Displays course title and department

### 5. Edit Lead Form
**File**: `app/views/partials/edit_lead_form.php`
- Added "Interested Course" dropdown in Education tab
- Pre-selects the current interested course when editing
- Displays course title and department for each option

### 6. Lead Detail View
**File**: `app/views/partials/lead_detail.php`
- Added display of interested course in Education Information card
- Shows course title with department in parentheses
- Only displays if a course is selected

## Database Schema Changes

### New Column: `interested_course_id`
```sql
ALTER TABLE `leads` 
ADD COLUMN `interested_course_id` INT NULL DEFAULT NULL AFTER `bachelor_cgpa`,
ADD KEY `fk_leads_interested_course` (`interested_course_id`);

ALTER TABLE `leads`
ADD CONSTRAINT `fk_leads_interested_course` 
FOREIGN KEY (`interested_course_id`) 
REFERENCES `courses` (`id`) 
ON DELETE SET NULL 
ON UPDATE CASCADE;
```

## How to Deploy

### Step 1: Run Database Migration
Execute the SQL migration file to add the new field:
```bash
mysql -u username -p database_name < database_migration_add_interested_course.sql
```

### Step 2: Access Public Form
The public lead form is accessible at:
```
https://your-domain.com/public-lead-form.php
```

### Step 3: Share the Link
- Share the public form link on your website, social media, or marketing materials
- Students can directly submit their information without needing to log in
- All submissions will appear in the Lead Management system with:
  - Lead Source: "Direct Online"
  - Lead Status: "Fresh"

## User Experience Flow

### For Students (Public)
1. Visit the public lead form page
2. Fill in personal information (required: name, email, phone)
3. Fill in education information (optional but recommended)
4. Select interested course from dropdown
5. Submit the form
6. Receive confirmation message

### For Staff (Internal)
1. View all leads in Lead Management system
2. Identify online leads by "Direct Online" source
3. View the interested course in the lead details
4. Edit lead information and update the interested course if needed
5. Track all changes in edit history

## Features

### Public Form Features
- ✅ Responsive design works on mobile, tablet, and desktop
- ✅ Form validation (client-side and server-side)
- ✅ Automatic lead source assignment
- ✅ Course selection from active courses
- ✅ Semester selection from active semesters
- ✅ Conditional fields based on degree selection
- ✅ Success confirmation message
- ✅ Error handling and user feedback

### Internal System Features
- ✅ Interested course field in Add Lead form
- ✅ Interested course field in Edit Lead form
- ✅ Interested course display in Lead Details
- ✅ Change tracking for interested course
- ✅ Integration with existing course management
- ✅ Database referential integrity

## Data Flow

```
Public Form Submission
       ↓
Validation & Sanitization
       ↓
Insert into leads table
- lead_source = "Direct Online"
- lead_status = "Fresh"
- interested_course_id = selected course
       ↓
Lead appears in Lead Management
       ↓
Staff can view, edit, and manage the lead
```

## Security Considerations

1. **Input Sanitization**: All user inputs are sanitized using `htmlspecialchars()` and type casting
2. **SQL Injection Prevention**: All database queries use prepared statements with parameter binding
3. **CSRF Protection**: Future enhancement needed - add CSRF tokens
4. **Email Validation**: Server-side email format validation
5. **Foreign Key Constraints**: Ensures data integrity for course references

## Future Enhancements

1. **CSRF Protection**: Add CSRF tokens to the public form
2. **reCAPTCHA**: Implement Google reCAPTCHA to prevent spam submissions
3. **Email Notifications**: Send confirmation emails to students and alerts to admissions staff
4. **Analytics**: Track conversion rates and popular courses
5. **Multi-language Support**: Translate the form into multiple languages
6. **File Upload**: Allow students to upload documents (transcripts, certificates)
7. **Progress Tracking**: Allow students to check their application status

## Testing Checklist

- [ ] Database migration runs successfully
- [ ] Public form is accessible without login
- [ ] Form validation works (client and server side)
- [ ] Successful submissions create leads with correct source and status
- [ ] Interested course is saved correctly
- [ ] Interested course displays in lead details
- [ ] Edit form pre-selects correct interested course
- [ ] Change tracking works for interested course updates
- [ ] Mobile responsive design works properly
- [ ] Error messages display correctly
- [ ] Success message displays after submission

## Support

For issues or questions about this feature, contact the development team or refer to the main project documentation.

---
**Last Updated**: 2026-01-19
**Version**: 1.0
**Author**: Development Team
