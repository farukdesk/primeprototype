-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 31, 2026 at 09:50 AM
-- Server version: 8.0.45
-- PHP Version: 8.1.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `primeuniadmin_crm25`
--

DELIMITER $$
--
-- Functions
--
CREATE FUNCTION `format_company_date` (`company_id` INT, `date_value` DATETIME) RETURNS VARCHAR(50) CHARSET utf8mb4 DETERMINISTIC BEGIN
    DECLARE format_string VARCHAR(20);
    
    SELECT date_format INTO format_string
    FROM companies 
    WHERE id = company_id;
    
    IF format_string IS NULL THEN
        SET format_string = 'YYYY-MM-DD';
    END IF;
    
    SET format_string = REPLACE(format_string, 'YYYY', '%Y');
    SET format_string = REPLACE(format_string, 'MM', '%m');
    SET format_string = REPLACE(format_string, 'DD', '%d');
    
    RETURN DATE_FORMAT(date_value, format_string);
END$$

CREATE FUNCTION `get_user_full_name` (`p_user_id` INT) RETURNS VARCHAR(101) CHARSET utf8mb4 DETERMINISTIC READS SQL DATA BEGIN
    DECLARE v_full_name VARCHAR(101);
    
    SELECT CONCAT(first_name, ' ', last_name)
    INTO v_full_name
    FROM user_profile
    WHERE user_id = p_user_id;
    
    RETURN COALESCE(v_full_name, 'Unknown User');
END$$

CREATE FUNCTION `get_user_hierarchy` (`p_user_id` INT) RETURNS TEXT CHARSET utf8mb4 DETERMINISTIC READS SQL DATA BEGIN
    DECLARE v_hierarchy TEXT;
    DECLARE v_current_id INT;
    DECLARE v_manager_name VARCHAR(101);
    
    SET v_hierarchy = '';
    SET v_current_id = p_user_id;
    
    WHILE v_current_id IS NOT NULL DO
        SELECT 
            CONCAT(up.first_name, ' ', up.last_name),
            up2.user_id
        INTO v_manager_name, v_current_id
        FROM user_profile up
        LEFT JOIN user_profile up2 ON up.reports_to = up2.user_id
        WHERE up.user_id = v_current_id;
        
        IF v_manager_name IS NOT NULL THEN
            SET v_hierarchy = CONCAT_WS(' > ', v_hierarchy, v_manager_name);
        END IF;
    END WHILE;
    
    RETURN TRIM(BOTH ' > ' FROM v_hierarchy);
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `agents`
--

CREATE TABLE `agents` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `agent_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `phone_number` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `is_our_student` tinyint(1) DEFAULT '0',
  `student_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `batch` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `department` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `agents`
--

INSERT INTO `agents` (`id`, `user_id`, `agent_name`, `address`, `phone_number`, `email`, `notes`, `is_our_student`, `student_id`, `batch`, `department`, `created_at`, `updated_at`) VALUES
(2, 23, 'Test Promoter ', 'asdasd', 'asdasd', 'sdfsdf@gmal.com', 'asdasd', 1, '', '', '', '2026-01-14 19:15:24', '2026-01-15 09:42:10'),
(4, 32, 'Yeasian Ahmed', 'Jahnarabad', '01318037476', 'na@gmail.com', 'PU Student', 1, '02826104081093', '68', 'BBA', '2026-01-22 06:19:50', '2026-01-22 06:19:50'),
(5, 34, 'Naimur Rahman', 'Tolerbag', '01831014008', 'naimurrahman720908@gmail.com', '', 1, '102841300051017', '64', 'CSE', '2026-01-26 04:33:21', '2026-01-26 04:33:21'),
(6, 35, 'Sadia Akter', '', '01327415961', 'tanuafrine@gmail.com', '', 1, '02806108131045', '68', 'LAW', '2026-01-26 06:32:31', '2026-01-26 06:32:31'),
(7, 36, 'Md Hasibur Rahman Hasib', '', '01788052661', '11hasib111@gmail.com', '', 1, '2824205101066', '65', 'CSE', '2026-01-26 09:06:45', '2026-01-26 09:06:45'),
(8, 38, 'Saidur Rahman Newton', 'Mirpur-1', '01787727948', 'saiudurnewton1@gmail.com', '', 1, '02825104081072', '66', 'BBA', '2026-01-30 07:10:00', '2026-01-30 07:10:00');

-- --------------------------------------------------------

--
-- Table structure for table `call_logs`
--

CREATE TABLE `call_logs` (
  `id` int NOT NULL,
  `lead_id` int NOT NULL,
  `staff_id` int NOT NULL,
  `call_type` enum('1st call','2nd call','3rd call','Follow-up call','Office visit confirmation','Final call') COLLATE utf8mb4_unicode_ci NOT NULL,
  `previous_status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `new_status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `call_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `call_duration` int DEFAULT NULL COMMENT 'Call duration in seconds',
  `call_notes` text COLLATE utf8mb4_unicode_ci,
  `call_outcome` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `call_converted` tinyint(1) DEFAULT '0' COMMENT '1 if call led to conversion, 0 otherwise',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `call_logs`
--

INSERT INTO `call_logs` (`id`, `lead_id`, `staff_id`, `call_type`, `previous_status`, `new_status`, `call_date`, `call_duration`, `call_notes`, `call_outcome`, `call_converted`, `created_at`) VALUES
(15, 75, 27, '1st call', 'Fresh', '1st call', '2026-01-20 13:52:07', NULL, 'student applied BA in English but hw wants Ba in bng . he will contact within 1 week', NULL, 0, '2026-01-20 07:52:07'),
(16, 81, 3, '1st call', 'Fresh', '1st call', '2026-01-20 15:32:47', NULL, '', NULL, 0, '2026-01-20 09:32:47'),
(17, 71, 27, '1st call', 'Fresh', '1st call', '2026-01-20 15:37:10', NULL, 'interested . Ai week er modheee aste casce', NULL, 0, '2026-01-20 09:37:10'),
(18, 70, 27, '1st call', 'Fresh', '1st call', '2026-01-20 16:13:17', NULL, 'Decision niye janaben ', NULL, 0, '2026-01-20 10:13:17'),
(19, 66, 27, '1st call', 'Fresh', '1st call', '2026-01-20 16:32:27', NULL, 'Number ti beabohar hosse na ', NULL, 0, '2026-01-20 10:32:27'),
(20, 77, 27, '1st call', 'Fresh', '1st call', '2026-01-20 16:47:32', NULL, 'not picked', NULL, 0, '2026-01-20 10:47:32'),
(21, 64, 27, '1st call', 'Fresh', '1st call', '2026-01-20 16:50:19', NULL, 'not picked', NULL, 0, '2026-01-20 10:50:19'),
(22, 81, 27, '2nd call', '1st call', '2nd call', '2026-01-21 10:43:26', NULL, 'Ajke admit hobe & aksathe 2 jon admit hobe ( 10:42 am call time_ unara already rouna hoise)', NULL, 0, '2026-01-21 04:43:26'),
(23, 101, 27, '1st call', 'Fresh', '1st call', '2026-01-21 12:14:12', NULL, '', NULL, 0, '2026-01-21 06:14:12'),
(24, 102, 27, '1st call', 'Fresh', '1st call', '2026-01-21 12:28:20', NULL, '', NULL, 0, '2026-01-21 06:28:20'),
(25, 102, 27, '2nd call', '1st call', '2nd call', '2026-01-21 12:37:41', NULL, 'Hostel information dawa hoise 1 week er modheee asbe admit hote ', NULL, 0, '2026-01-21 06:37:41'),
(26, 104, 27, '1st call', 'Fresh', '1st call', '2026-01-21 13:12:12', NULL, '', NULL, 0, '2026-01-21 07:12:12'),
(27, 105, 27, '1st call', 'Fresh', '1st call', '2026-01-21 13:12:54', NULL, '', NULL, 0, '2026-01-21 07:12:54'),
(28, 103, 27, '1st call', 'Fresh', '1st call', '2026-01-21 13:14:06', NULL, '', NULL, 0, '2026-01-21 07:14:06'),
(29, 107, 27, '1st call', 'Fresh', '1st call', '2026-01-21 13:24:53', NULL, '', NULL, 0, '2026-01-21 07:24:53'),
(30, 113, 31, '1st call', 'Fresh', '1st call', '2026-01-21 16:54:05', NULL, '', NULL, 0, '2026-01-21 10:54:05'),
(31, 96, 27, '1st call', 'Fresh', '1st call', '2026-01-21 17:25:00', NULL, 'not picked', NULL, 0, '2026-01-21 11:25:00'),
(32, 92, 27, '1st call', 'Fresh', '1st call', '2026-01-21 17:30:32', NULL, 'Not picked', NULL, 0, '2026-01-21 11:30:32'),
(33, 53, 29, '1st call', 'Fresh', '1st call', '2026-01-21 17:39:49', NULL, '', NULL, 0, '2026-01-21 11:39:49'),
(34, 91, 30, '1st call', 'Fresh', '1st call', '2026-01-22 11:40:11', NULL, '', NULL, 0, '2026-01-22 05:40:11'),
(35, 87, 30, '1st call', 'Fresh', '1st call', '2026-01-22 11:45:04', NULL, '', NULL, 0, '2026-01-22 05:45:04'),
(36, 117, 30, '1st call', 'Fresh', '1st call', '2026-01-22 11:49:52', NULL, '', NULL, 0, '2026-01-22 05:49:52'),
(37, 119, 29, '1st call', 'Fresh', '1st call', '2026-01-22 11:55:14', NULL, '', NULL, 0, '2026-01-22 05:55:14'),
(38, 118, 29, '1st call', 'Fresh', '1st call', '2026-01-22 11:55:52', NULL, '', NULL, 0, '2026-01-22 05:55:52'),
(39, 120, 29, '1st call', 'Fresh', '1st call', '2026-01-22 11:56:18', NULL, '', NULL, 0, '2026-01-22 05:56:18'),
(40, 121, 29, '1st call', 'Fresh', '1st call', '2026-01-22 12:09:56', NULL, '', NULL, 0, '2026-01-22 06:09:56'),
(41, 93, 30, '1st call', 'Fresh', '1st call', '2026-01-22 12:26:10', NULL, '', NULL, 0, '2026-01-22 06:26:10'),
(42, 123, 30, '1st call', 'Fresh', '1st call', '2026-01-22 12:47:03', NULL, '', NULL, 0, '2026-01-22 06:47:03'),
(43, 130, 29, '1st call', 'Fresh', '1st call', '2026-01-22 13:58:02', NULL, '', NULL, 0, '2026-01-22 07:58:02'),
(44, 131, 29, '1st call', 'Fresh', '1st call', '2026-01-22 14:10:56', NULL, '', NULL, 0, '2026-01-22 08:10:56'),
(45, 135, 29, '1st call', 'Fresh', '1st call', '2026-01-22 16:12:12', NULL, '', NULL, 0, '2026-01-22 10:12:12'),
(46, 126, 30, '1st call', 'Fresh', '1st call', '2026-01-22 16:26:16', NULL, '', NULL, 0, '2026-01-22 10:26:16'),
(47, 128, 30, '1st call', 'Fresh', '1st call', '2026-01-22 16:27:47', NULL, '', NULL, 0, '2026-01-22 10:27:47'),
(48, 55, 29, '3rd call', '2nd call', '3rd call', '2026-01-22 16:32:30', NULL, '', NULL, 0, '2026-01-22 10:32:30'),
(49, 126, 30, '1st call', 'Fresh', '1st call', '2026-01-22 16:36:28', NULL, '', NULL, 0, '2026-01-22 10:36:28'),
(50, 116, 30, '1st call', 'Fresh', '1st call', '2026-01-22 16:42:20', NULL, '', NULL, 0, '2026-01-22 10:42:20'),
(51, 86, 30, '1st call', 'Fresh', '1st call', '2026-01-22 16:49:07', NULL, '', NULL, 0, '2026-01-22 10:49:07'),
(52, 114, 29, '1st call', 'Fresh', '1st call', '2026-01-22 17:12:07', NULL, '', NULL, 0, '2026-01-22 11:12:07'),
(53, 94, 30, '1st call', 'Fresh', '1st call', '2026-01-22 17:25:42', NULL, '', NULL, 0, '2026-01-22 11:25:42'),
(54, 76, 27, '2nd call', '1st call', '2nd call', '2026-01-22 17:28:44', NULL, 'not picked', NULL, 0, '2026-01-22 11:28:44'),
(55, 90, 30, '1st call', 'Fresh', '1st call', '2026-01-22 17:31:08', NULL, '', NULL, 0, '2026-01-22 11:31:08'),
(56, 74, 27, 'Final call', 'Unable to reach trice', 'Dead', '2026-01-22 17:41:07', NULL, 'Again phn off and she provide faluse information ', NULL, 0, '2026-01-22 11:41:07'),
(57, 66, 27, '2nd call', '1st call', '2nd call', '2026-01-22 18:01:37', NULL, 'Student provide unused nuber, so ati r used hoi na ', NULL, 0, '2026-01-22 12:01:37'),
(58, 61, 27, 'Final call', 'Unable to reach twice', 'Dead', '2026-01-22 18:26:43', NULL, 'Unable to reached', NULL, 0, '2026-01-22 12:26:43'),
(59, 115, 27, '1st call', 'Fresh', '1st call', '2026-01-22 18:29:57', NULL, 'Call kete dicce', NULL, 0, '2026-01-22 12:29:57'),
(60, 95, 27, '1st call', 'Fresh', '1st call', '2026-01-22 18:47:54', NULL, 'Evening batch chasce but tarporew decision niye janabe', NULL, 0, '2026-01-22 12:47:54'),
(61, 137, 30, '1st call', 'Fresh', '1st call', '2026-01-23 10:16:22', NULL, '', NULL, 0, '2026-01-23 04:16:22'),
(62, 139, 29, '1st call', 'Fresh', '1st call', '2026-01-23 10:29:02', NULL, '', NULL, 0, '2026-01-23 04:29:02'),
(63, 134, 24, '1st call', 'Fresh', '1st call', '2026-01-23 10:33:10', NULL, '', NULL, 0, '2026-01-23 04:33:10'),
(64, 133, 24, '1st call', 'Fresh', '1st call', '2026-01-23 10:41:09', NULL, '', NULL, 0, '2026-01-23 04:41:09'),
(65, 127, 24, '1st call', 'Fresh', '1st call', '2026-01-23 10:58:37', NULL, 'his phone is off', NULL, 0, '2026-01-23 04:58:37'),
(66, 125, 24, '1st call', 'Fresh', '1st call', '2026-01-23 10:59:38', NULL, 'phone number is off', NULL, 0, '2026-01-23 04:59:38'),
(67, 124, 24, '1st call', 'Fresh', '1st call', '2026-01-23 11:02:40', NULL, 'he will let us know', NULL, 0, '2026-01-23 05:02:40'),
(68, 53, 30, '2nd call', '1st call', '2nd call', '2026-01-23 11:24:17', NULL, '', NULL, 0, '2026-01-23 05:24:17'),
(69, 89, 24, '1st call', 'Fresh', '1st call', '2026-01-23 11:28:00', NULL, 'let us know with talking in home', NULL, 0, '2026-01-23 05:28:00'),
(70, 51, 24, '1st call', 'Fresh', '1st call', '2026-01-23 11:36:53', NULL, '', NULL, 0, '2026-01-23 05:36:53'),
(71, 50, 24, '1st call', 'Fresh', '1st call', '2026-01-23 11:39:40', NULL, '', NULL, 0, '2026-01-23 05:39:40'),
(72, 140, 24, '1st call', 'Fresh', '1st call', '2026-01-23 14:22:00', NULL, 'Kichu DIscount chasse, will let us know', NULL, 0, '2026-01-23 08:22:00'),
(73, 138, 30, '1st call', 'Fresh', '1st call', '2026-01-23 14:48:56', NULL, '', NULL, 0, '2026-01-23 08:48:56'),
(74, 101, 30, '2nd call', '1st call', '2nd call', '2026-01-23 15:37:37', NULL, '', NULL, 0, '2026-01-23 09:37:37'),
(75, 96, 30, '2nd call', '1st call', '2nd call', '2026-01-23 15:42:43', NULL, '', NULL, 0, '2026-01-23 09:42:43'),
(76, 144, 24, '1st call', 'Fresh', '1st call', '2026-01-23 15:55:45', NULL, 'not picked', NULL, 0, '2026-01-23 09:55:45'),
(77, 148, 24, '1st call', 'Fresh', '1st call', '2026-01-23 16:30:00', NULL, '', NULL, 0, '2026-01-23 10:30:00'),
(78, 142, 24, 'Final call', 'Will visit office', 'Admitted', '2026-01-23 17:07:04', NULL, '', NULL, 1, '2026-01-23 11:07:04'),
(79, 149, 29, '1st call', 'Fresh', '1st call', '2026-01-23 17:07:29', NULL, '', NULL, 0, '2026-01-23 11:07:29'),
(80, 132, 29, 'Final call', 'Will visit office', 'Admitted', '2026-01-23 17:52:13', NULL, '', NULL, 1, '2026-01-23 11:52:13'),
(81, 112, 27, '2nd call', '1st call', '2nd call', '2026-01-23 18:51:30', NULL, 'kotha hoyese parents er sathe kotha bole janabe shomoi nise', NULL, 0, '2026-01-23 12:51:30'),
(82, 105, 27, '2nd call', '1st call', '2nd call', '2026-01-23 19:49:29', NULL, '', NULL, 0, '2026-01-23 13:49:29'),
(83, 88, 27, '1st call', 'Fresh', '1st call', '2026-01-23 19:55:02', NULL, 'Not reached', NULL, 0, '2026-01-23 13:55:02'),
(84, 120, 24, '2nd call', '1st call', '2nd call', '2026-01-24 10:26:55', NULL, '', NULL, 0, '2026-01-24 04:26:55'),
(85, 93, 24, '2nd call', '1st call', '2nd call', '2026-01-24 10:33:34', NULL, '', NULL, 0, '2026-01-24 04:33:34'),
(86, 83, 24, '1st call', 'Unable to reach once', '1st call', '2026-01-24 10:37:04', NULL, 'Will admit next semester', NULL, 0, '2026-01-24 04:37:04'),
(87, 150, 24, '1st call', 'Fresh', '1st call', '2026-01-24 11:01:52', NULL, '', NULL, 0, '2026-01-24 05:01:52'),
(88, 151, 24, '1st call', 'Fresh', '1st call', '2026-01-24 11:39:04', NULL, '', NULL, 0, '2026-01-24 05:39:04'),
(89, 153, 24, '1st call', 'Fresh', '1st call', '2026-01-24 11:39:10', NULL, '', NULL, 0, '2026-01-24 05:39:10'),
(90, 155, 24, '1st call', 'Fresh', '1st call', '2026-01-24 11:51:06', NULL, '', NULL, 0, '2026-01-24 05:51:06'),
(91, 154, 24, '1st call', 'Fresh', '1st call', '2026-01-24 11:51:17', NULL, '', NULL, 0, '2026-01-24 05:51:17'),
(92, 156, 24, '1st call', 'Fresh', '1st call', '2026-01-24 12:42:34', NULL, '', NULL, 0, '2026-01-24 06:42:34'),
(93, 158, 24, '1st call', 'Fresh', '1st call', '2026-01-24 14:31:25', NULL, '', NULL, 0, '2026-01-24 08:31:25'),
(94, 157, 24, '1st call', 'Fresh', '1st call', '2026-01-24 14:31:35', NULL, '', NULL, 0, '2026-01-24 08:31:35'),
(95, 159, 24, '1st call', 'Fresh', '1st call', '2026-01-24 14:38:32', NULL, '', NULL, 0, '2026-01-24 08:38:32'),
(96, 160, 24, '1st call', 'Fresh', '1st call', '2026-01-24 15:13:05', NULL, '', NULL, 0, '2026-01-24 09:13:05'),
(97, 161, 24, '1st call', 'Fresh', '1st call', '2026-01-24 15:25:13', NULL, '', NULL, 0, '2026-01-24 09:25:13'),
(98, 162, 24, '1st call', 'Fresh', '1st call', '2026-01-24 15:28:19', NULL, '', NULL, 0, '2026-01-24 09:28:19'),
(99, 164, 24, '1st call', 'Fresh', '1st call', '2026-01-24 15:40:52', NULL, '', NULL, 0, '2026-01-24 09:40:52'),
(100, 163, 24, '1st call', 'Fresh', '1st call', '2026-01-24 15:47:17', NULL, '', NULL, 0, '2026-01-24 09:47:17'),
(101, 165, 24, '1st call', 'Fresh', '1st call', '2026-01-24 15:57:59', NULL, '', NULL, 0, '2026-01-24 09:57:59'),
(102, 121, 27, '2nd call', '1st call', '2nd call', '2026-01-24 16:58:12', NULL, 'Not picked', NULL, 0, '2026-01-24 10:58:12'),
(103, 115, 27, '2nd call', '1st call', '2nd call', '2026-01-24 17:03:23', NULL, 'Interested & 1 week er modhee visit korbe', NULL, 0, '2026-01-24 11:03:23'),
(104, 95, 27, '2nd call', '1st call', '2nd call', '2026-01-24 17:23:31', NULL, 'Jodi vorti hoi tobe janabe  all informationa provide kora hoise (call e birokto hosse)', NULL, 0, '2026-01-24 11:23:31'),
(105, 79, 27, '3rd call', '2nd call', '3rd call', '2026-01-24 17:38:26', NULL, 'aro kisu uni khuj nibe tn decision nibe ', NULL, 0, '2026-01-24 11:38:26'),
(106, 76, 27, '3rd call', '2nd call', '3rd call', '2026-01-24 17:41:41', NULL, 'Decision niye janabe akhono family te discussed kore ni ', NULL, 0, '2026-01-24 11:41:41'),
(107, 152, 27, '1st call', 'Fresh', '1st call', '2026-01-24 17:52:27', NULL, 'Information niyese interested for next semester ', NULL, 0, '2026-01-24 11:52:27'),
(108, 168, 24, '1st call', 'Fresh', '1st call', '2026-01-25 09:22:50', NULL, '', NULL, 0, '2026-01-25 03:22:50'),
(109, 148, 24, '2nd call', '1st call', '2nd call', '2026-01-25 09:43:39', NULL, 'Number is busy,called twice', NULL, 0, '2026-01-25 03:43:39'),
(110, 130, 30, '2nd call', '1st call', '2nd call', '2026-01-25 10:12:29', NULL, '', NULL, 0, '2026-01-25 04:12:29'),
(111, 147, 24, '2nd call', '1st call', '2nd call', '2026-01-25 10:14:02', NULL, '', NULL, 0, '2026-01-25 04:14:02'),
(112, 128, 30, '2nd call', '1st call', '2nd call', '2026-01-25 10:19:54', NULL, '', NULL, 0, '2026-01-25 04:19:54'),
(113, 126, 30, '2nd call', '1st call', '2nd call', '2026-01-25 10:23:11', NULL, '', NULL, 0, '2026-01-25 04:23:11'),
(114, 123, 30, '2nd call', '1st call', '2nd call', '2026-01-25 10:26:20', NULL, '', NULL, 0, '2026-01-25 04:26:20'),
(115, 116, 30, '2nd call', '1st call', '2nd call', '2026-01-25 10:38:56', NULL, '', NULL, 0, '2026-01-25 04:38:56'),
(116, 114, 30, '2nd call', '1st call', '2nd call', '2026-01-25 10:40:20', NULL, '', NULL, 0, '2026-01-25 04:40:20'),
(117, 91, 30, '2nd call', '1st call', '2nd call', '2026-01-25 10:41:24', NULL, '', NULL, 0, '2026-01-25 04:41:24'),
(118, 87, 30, '2nd call', '1st call', '2nd call', '2026-01-25 10:43:24', NULL, '', NULL, 0, '2026-01-25 04:43:24'),
(119, 149, 30, '2nd call', '1st call', '2nd call', '2026-01-25 10:44:13', NULL, '', NULL, 0, '2026-01-25 04:44:13'),
(120, 137, 30, '2nd call', '1st call', '2nd call', '2026-01-25 10:48:32', NULL, '', NULL, 0, '2026-01-25 04:48:32'),
(121, 101, 30, '3rd call', '2nd call', '3rd call', '2026-01-25 10:58:51', NULL, '', NULL, 0, '2026-01-25 04:58:51'),
(122, 96, 30, '3rd call', '2nd call', '3rd call', '2026-01-25 10:59:41', NULL, '', NULL, 0, '2026-01-25 04:59:41'),
(123, 53, 30, '3rd call', '2nd call', '3rd call', '2026-01-25 11:01:58', NULL, '', NULL, 0, '2026-01-25 05:01:58'),
(124, 169, 24, '1st call', 'Fresh', '1st call', '2026-01-25 11:13:11', NULL, '', NULL, 0, '2026-01-25 05:13:11'),
(125, 170, 24, '1st call', 'Fresh', '1st call', '2026-01-25 11:13:18', NULL, '', NULL, 0, '2026-01-25 05:13:18'),
(126, 145, 24, 'Final call', 'Will visit office', 'Admitted', '2026-01-25 11:37:06', NULL, 'Already admitted with his friend reference', NULL, 1, '2026-01-25 05:37:06'),
(127, 171, 24, '1st call', 'Fresh', '1st call', '2026-01-25 12:21:30', NULL, '', NULL, 0, '2026-01-25 06:21:30'),
(128, 144, 24, '2nd call', '1st call', '2nd call', '2026-01-25 12:25:15', NULL, 'Basai kotha bole admit hoben ', NULL, 0, '2026-01-25 06:25:15'),
(129, 141, 24, 'Final call', 'Will visit office', 'Admitted', '2026-01-25 12:32:48', NULL, 'he is promoter taking admission ', NULL, 1, '2026-01-25 06:32:48'),
(130, 172, 24, '1st call', 'Fresh', '1st call', '2026-01-25 12:40:02', NULL, '', NULL, 0, '2026-01-25 06:40:02'),
(131, 140, 24, '2nd call', '1st call', '2nd call', '2026-01-25 12:42:28', NULL, 'let us know', NULL, 0, '2026-01-25 06:42:28'),
(132, 127, 24, '2nd call', '1st call', '2nd call', '2026-01-25 13:01:26', NULL, '2,00,000 taka hole se porte pare', NULL, 0, '2026-01-25 07:01:26'),
(133, 125, 24, '2nd call', '1st call', '2nd call', '2026-01-25 13:03:23', NULL, 'he was in the bus will call us later', NULL, 0, '2026-01-25 07:03:23'),
(134, 124, 24, '2nd call', '1st call', '2nd call', '2026-01-25 13:06:57', NULL, 'let us know', NULL, 0, '2026-01-25 07:06:57'),
(135, 89, 24, '2nd call', '1st call', '2nd call', '2026-01-25 14:25:28', NULL, 'didn\'t picked', NULL, 0, '2026-01-25 08:25:28'),
(136, 51, 24, '2nd call', '1st call', '2nd call', '2026-01-25 14:37:00', NULL, 'Not picked', NULL, 0, '2026-01-25 08:37:00'),
(137, 50, 24, '2nd call', '1st call', '2nd call', '2026-01-25 14:38:25', NULL, 'Not picked', NULL, 0, '2026-01-25 08:38:25'),
(138, 173, 24, '1st call', 'Fresh', '1st call', '2026-01-25 15:08:13', NULL, 'will visit campus', NULL, 0, '2026-01-25 09:08:13'),
(139, 175, 24, '1st call', 'Fresh', '1st call', '2026-01-25 15:48:52', NULL, '', NULL, 0, '2026-01-25 09:48:52'),
(140, 176, 24, '1st call', 'Fresh', '1st call', '2026-01-25 16:03:04', NULL, '', NULL, 0, '2026-01-25 10:03:04'),
(141, 178, 24, '1st call', 'Fresh', '1st call', '2026-01-25 16:45:30', NULL, '', NULL, 0, '2026-01-25 10:45:30'),
(142, 179, 24, '1st call', 'Fresh', '1st call', '2026-01-25 16:53:57', NULL, '', NULL, 0, '2026-01-25 10:53:57'),
(143, 119, 27, '2nd call', '1st call', '2nd call', '2026-01-25 17:50:22', NULL, 'Vorti hole janabe', NULL, 0, '2026-01-25 11:50:22'),
(144, 118, 27, '2nd call', '1st call', '2nd call', '2026-01-25 17:59:24', NULL, '31 tarik admit hobe jessore theke asbe, khub request kortese 1 ta sit rakhar jonno ', NULL, 0, '2026-01-25 11:59:24'),
(145, 102, 27, 'Office visit confirmation', '3rd call', 'Will visit office', '2026-01-25 18:32:35', NULL, '', NULL, 0, '2026-01-25 12:32:35'),
(146, 104, 27, 'Office visit confirmation', '3rd call', 'Will visit office', '2026-01-25 18:38:23', NULL, '', NULL, 0, '2026-01-25 12:38:23'),
(147, 103, 27, 'Office visit confirmation', '3rd call', 'Will visit office', '2026-01-25 18:47:44', NULL, '', NULL, 0, '2026-01-25 12:47:44'),
(148, 112, 27, '3rd call', '2nd call', '3rd call', '2026-01-25 19:03:18', NULL, 'Appeared , next semester e hote parbe ', NULL, 0, '2026-01-25 13:03:18'),
(149, 107, 27, 'Office visit confirmation', '3rd call', 'Will visit office', '2026-01-25 19:07:52', NULL, '', NULL, 0, '2026-01-25 13:07:52'),
(150, 111, 27, 'Office visit confirmation', '3rd call', 'Will visit office', '2026-01-25 19:16:46', NULL, 'dupur 1 ta -2 tar modhee asbe kal admit hote', NULL, 0, '2026-01-25 13:16:46'),
(151, 166, 27, '1st call', 'Fresh', '1st call', '2026-01-25 19:20:14', NULL, 'Busy ase ', NULL, 0, '2026-01-25 13:20:14'),
(152, 174, 27, '1st call', 'Fresh', '1st call', '2026-01-25 19:35:31', NULL, 'Not picked', NULL, 0, '2026-01-25 13:35:31'),
(153, 152, 27, '2nd call', '1st call', '2nd call', '2026-01-26 09:38:20', NULL, 'next semester ', NULL, 0, '2026-01-26 03:38:20'),
(154, 108, 27, 'Office visit confirmation', '3rd call', 'Will visit office', '2026-01-26 10:04:36', NULL, '', NULL, 0, '2026-01-26 04:04:36'),
(155, 108, 27, 'Final call', 'Will visit office', 'Admitted', '2026-01-26 10:09:36', NULL, '', NULL, 1, '2026-01-26 04:09:36'),
(156, 62, 27, '3rd call', '2nd call', '3rd call', '2026-01-26 10:26:47', NULL, 'Busy ase pore call dibe', NULL, 0, '2026-01-26 04:26:47'),
(157, 177, 30, '1st call', 'Fresh', '1st call', '2026-01-26 11:03:49', NULL, '', NULL, 0, '2026-01-26 05:03:49'),
(158, 181, 30, '1st call', 'Fresh', '1st call', '2026-01-26 11:06:55', NULL, '', NULL, 0, '2026-01-26 05:06:55'),
(159, 180, 30, '1st call', 'Fresh', '1st call', '2026-01-26 11:10:47', NULL, '', NULL, 0, '2026-01-26 05:10:47'),
(160, 76, 27, 'Office visit confirmation', '3rd call', 'Will visit office', '2026-01-26 11:18:49', NULL, '', NULL, 0, '2026-01-26 05:18:49'),
(161, 116, 30, '3rd call', '2nd call', '3rd call', '2026-01-26 11:32:40', NULL, '', NULL, 0, '2026-01-26 05:32:40'),
(162, 79, 27, 'Office visit confirmation', '3rd call', 'Will visit office', '2026-01-26 11:36:15', NULL, 'decision pending..', NULL, 0, '2026-01-26 05:36:15'),
(163, 95, 27, '3rd call', '2nd call', '3rd call', '2026-01-26 11:37:24', NULL, 'Decision pending pore janabe', NULL, 0, '2026-01-26 05:37:24'),
(164, 71, 27, 'Office visit confirmation', '3rd call', 'Will visit office', '2026-01-26 11:42:36', NULL, '', NULL, 0, '2026-01-26 05:42:36'),
(165, 97, 27, 'Office visit confirmation', '3rd call', 'Will visit office', '2026-01-26 12:32:49', NULL, '', NULL, 0, '2026-01-26 06:32:49'),
(166, 110, 27, 'Office visit confirmation', '3rd call', 'Will visit office', '2026-01-26 12:40:51', NULL, '30 tarik admit hobe ', NULL, 0, '2026-01-26 06:40:51'),
(167, 184, 27, 'Office visit confirmation', '2nd call', 'Will visit office', '2026-01-26 13:03:32', NULL, '', NULL, 0, '2026-01-26 07:03:32'),
(168, 185, 29, '1st call', 'Fresh', '1st call', '2026-01-26 16:29:43', NULL, '', NULL, 0, '2026-01-26 10:29:43'),
(169, 188, 27, '1st call', 'Fresh', '1st call', '2026-01-26 16:37:08', NULL, '', NULL, 0, '2026-01-26 10:37:08'),
(170, 190, 27, '1st call', 'Fresh', '1st call', '2026-01-26 16:58:57', NULL, '', NULL, 0, '2026-01-26 10:58:57'),
(171, 165, 24, 'Office visit confirmation', '1st call', 'Will visit office', '2026-01-26 17:08:10', NULL, 'The number is from UAE but his wife will be admit that  date', NULL, 0, '2026-01-26 11:08:10'),
(172, 121, 27, '3rd call', '2nd call', '3rd call', '2026-01-26 17:11:32', NULL, 'Kutubuddin . Referred ase', NULL, 0, '2026-01-26 11:11:32'),
(173, 179, 24, '2nd call', '1st call', '2nd call', '2026-01-26 17:13:42', NULL, 'He will let us know very soon', NULL, 0, '2026-01-26 11:13:42'),
(174, 115, 27, 'Office visit confirmation', '2nd call', 'Will visit office', '2026-01-26 17:18:34', NULL, '', NULL, 0, '2026-01-26 11:18:34'),
(175, 163, 24, '2nd call', '1st call', '2nd call', '2026-01-26 17:55:03', NULL, 'Not picked', NULL, 0, '2026-01-26 11:55:03'),
(176, 192, 24, '1st call', 'Fresh', '1st call', '2026-01-26 20:13:27', NULL, '', NULL, 0, '2026-01-26 14:13:27'),
(177, 162, 24, '2nd call', '1st call', '2nd call', '2026-01-26 20:15:52', NULL, 'will call us very soon', NULL, 0, '2026-01-26 14:15:52'),
(178, 161, 24, '2nd call', '1st call', '2nd call', '2026-01-26 20:17:06', NULL, 'Number is off', NULL, 0, '2026-01-26 14:17:06'),
(179, 160, 24, '2nd call', '1st call', '2nd call', '2026-01-26 20:19:01', NULL, 'will call us very soon', NULL, 0, '2026-01-26 14:19:01'),
(180, 193, 24, '1st call', 'Fresh', '1st call', '2026-01-26 20:22:51', NULL, '', NULL, 0, '2026-01-26 14:22:51'),
(181, 159, 24, '2nd call', '1st call', '2nd call', '2026-01-26 20:24:47', NULL, 'Agmaikal ba porsu asben ', NULL, 0, '2026-01-26 14:24:47'),
(182, 157, 24, '2nd call', '1st call', '2nd call', '2026-01-26 20:29:09', NULL, 'Not picked , office Number', NULL, 0, '2026-01-26 14:29:09'),
(183, 154, 24, '2nd call', '1st call', '2nd call', '2026-01-26 20:37:01', NULL, '', NULL, 0, '2026-01-26 14:37:01'),
(184, 151, 24, '2nd call', '1st call', '2nd call', '2026-01-26 20:59:53', NULL, 'Not picked', NULL, 0, '2026-01-26 14:59:53'),
(185, 83, 24, '2nd call', '1st call', '2nd call', '2026-01-26 21:08:44', NULL, 'will call us later', NULL, 0, '2026-01-26 15:08:44'),
(186, 149, 30, '3rd call', '2nd call', '3rd call', '2026-01-27 09:53:51', NULL, '', NULL, 0, '2026-01-27 03:53:51'),
(187, 137, 30, '3rd call', '2nd call', '3rd call', '2026-01-27 09:55:45', NULL, '', NULL, 0, '2026-01-27 03:55:45'),
(188, 129, 30, '3rd call', '2nd call', '3rd call', '2026-01-27 10:00:23', NULL, '', NULL, 0, '2026-01-27 04:00:23'),
(189, 128, 30, '3rd call', '2nd call', '3rd call', '2026-01-27 10:11:19', NULL, '', NULL, 0, '2026-01-27 04:11:19'),
(190, 190, 27, '2nd call', '1st call', '2nd call', '2026-01-27 10:12:36', NULL, 'Ajke admit hobe', NULL, 0, '2026-01-27 04:12:36'),
(191, 190, 27, 'Office visit confirmation', '2nd call', 'Will visit office', '2026-01-27 10:14:25', NULL, '', NULL, 0, '2026-01-27 04:14:25'),
(192, 191, 30, '1st call', 'Fresh', '1st call', '2026-01-27 10:29:29', NULL, '', NULL, 0, '2026-01-27 04:29:29'),
(193, 194, 27, '1st call', 'Fresh', '1st call', '2026-01-27 11:08:42', NULL, 'Projpur theke admit howa problem tai online admit hobe ', NULL, 0, '2026-01-27 05:08:42'),
(194, 174, 27, '2nd call', '1st call', '2nd call', '2026-01-27 11:12:25', NULL, 'Not picked', NULL, 0, '2026-01-27 05:12:25'),
(195, 166, 27, '2nd call', '1st call', '2nd call', '2026-01-27 11:14:33', NULL, 'Not Picked', NULL, 0, '2026-01-27 05:14:33'),
(196, 123, 30, '3rd call', '2nd call', '3rd call', '2026-01-27 11:39:48', NULL, '', NULL, 0, '2026-01-27 05:39:48'),
(197, 198, 29, '1st call', 'Fresh', '1st call', '2026-01-27 12:23:09', NULL, '', NULL, 0, '2026-01-27 06:23:09'),
(198, 199, 29, '1st call', 'Fresh', '1st call', '2026-01-27 12:27:05', NULL, '', NULL, 0, '2026-01-27 06:27:05'),
(199, 195, 30, '1st call', 'Fresh', '1st call', '2026-01-27 12:35:22', NULL, '', NULL, 0, '2026-01-27 06:35:22'),
(200, 200, 27, '1st call', 'Fresh', '1st call', '2026-01-27 12:44:26', NULL, '', NULL, 0, '2026-01-27 06:44:26'),
(201, 200, 27, 'Office visit confirmation', '1st call', 'Will visit office', '2026-01-27 12:48:59', NULL, '', NULL, 0, '2026-01-27 06:48:59'),
(202, 114, 30, '3rd call', '2nd call', '3rd call', '2026-01-27 12:53:30', NULL, '', NULL, 0, '2026-01-27 06:53:30'),
(203, 196, 29, '1st call', 'Fresh', '1st call', '2026-01-27 12:57:35', NULL, '', NULL, 0, '2026-01-27 06:57:35'),
(204, 91, 30, '3rd call', '2nd call', '3rd call', '2026-01-27 15:19:52', NULL, '', NULL, 0, '2026-01-27 09:19:52'),
(205, 87, 30, '3rd call', '2nd call', '3rd call', '2026-01-27 15:22:13', NULL, '', NULL, 0, '2026-01-27 09:22:13'),
(206, 139, 27, 'Office visit confirmation', '3rd call', 'Will visit office', '2026-01-27 15:26:55', NULL, '', NULL, 0, '2026-01-27 09:26:55'),
(207, 118, 27, 'Office visit confirmation', '2nd call', 'Will visit office', '2026-01-27 15:35:17', NULL, '31 Tarik admit hobe', NULL, 0, '2026-01-27 09:35:17'),
(208, 119, 27, '3rd call', '2nd call', '3rd call', '2026-01-27 15:48:52', NULL, 'Informed kora hoise, admit hole janabe', NULL, 0, '2026-01-27 09:48:52'),
(209, 112, 27, 'Office visit confirmation', '3rd call', 'Will visit office', '2026-01-27 15:50:35', NULL, '', NULL, 0, '2026-01-27 09:50:35'),
(210, 178, 24, '2nd call', '1st call', '2nd call', '2026-01-27 17:02:58', NULL, 'will let us know come in 30 January', NULL, 0, '2026-01-27 11:02:58'),
(211, 176, 24, '2nd call', '1st call', '2nd call', '2026-01-27 17:04:04', NULL, 'not picked', NULL, 0, '2026-01-27 11:04:04'),
(212, 175, 24, '2nd call', '1st call', '2nd call', '2026-01-27 17:04:50', NULL, 'his number is off', NULL, 0, '2026-01-27 11:04:50'),
(213, 173, 24, '2nd call', '1st call', '2nd call', '2026-01-27 17:09:16', NULL, 'will let us know very soon', NULL, 0, '2026-01-27 11:09:16'),
(214, 172, 24, '2nd call', '1st call', '2nd call', '2026-01-27 17:17:15', NULL, 'want to admit next semester. But he will try to admit this semester. i said our cost can be increase on the next semester', NULL, 0, '2026-01-27 11:17:15'),
(215, 171, 24, '2nd call', '1st call', '2nd call', '2026-01-27 17:18:30', NULL, 'Not picked', NULL, 0, '2026-01-27 11:18:30'),
(216, 170, 24, '2nd call', '1st call', '2nd call', '2026-01-27 17:21:42', NULL, 'will come very soon, and admit', NULL, 0, '2026-01-27 11:21:42'),
(217, 163, 24, '3rd call', '2nd call', '3rd call', '2026-01-27 17:26:03', NULL, 'Not picked', NULL, 0, '2026-01-27 11:26:03'),
(218, 161, 24, '3rd call', '2nd call', '3rd call', '2026-01-27 17:27:30', NULL, 'will call us later, he was in the work', NULL, 0, '2026-01-27 11:27:30'),
(219, 151, 24, '3rd call', '2nd call', '3rd call', '2026-01-27 17:28:50', NULL, 'will admit on 1 or 2 february', NULL, 0, '2026-01-27 11:28:50'),
(220, 160, 24, '3rd call', '2nd call', '3rd call', '2026-01-27 17:31:59', NULL, 'will not admit this semester, will be try next semester, waiting for the publc university result', NULL, 0, '2026-01-27 11:31:59'),
(221, 146, 24, '3rd call', '2nd call', '3rd call', '2026-01-27 17:38:28', NULL, 'Not picked', NULL, 0, '2026-01-27 11:38:28'),
(222, 143, 24, '2nd call', '1st call', '2nd call', '2026-01-27 17:43:47', NULL, 'will call me later', NULL, 0, '2026-01-27 11:43:47'),
(223, 140, 24, '3rd call', '2nd call', '3rd call', '2026-01-27 18:04:33', NULL, 'Not picked', NULL, 0, '2026-01-27 12:04:33'),
(224, 127, 24, '3rd call', '2nd call', '3rd call', '2026-01-27 18:08:45', NULL, 'his financial condition is not good if 200000, he can study', NULL, 0, '2026-01-27 12:08:45'),
(225, 125, 24, '3rd call', '2nd call', '3rd call', '2026-01-27 18:14:57', NULL, 'he will let us know very soon,...his job posting in commilla he will be happy if online class , ', NULL, 0, '2026-01-27 12:14:57'),
(226, 89, 24, '3rd call', '2nd call', '3rd call', '2026-01-27 21:11:05', NULL, 'didn\'t picked', NULL, 0, '2026-01-27 15:11:05'),
(227, 51, 24, '3rd call', '2nd call', '3rd call', '2026-01-27 21:14:45', NULL, 'not picked', NULL, 0, '2026-01-27 15:14:45'),
(228, 119, 27, 'Office visit confirmation', '3rd call', 'Will visit office', '2026-01-28 09:45:33', NULL, '', NULL, 0, '2026-01-28 03:45:33'),
(229, 194, 27, '2nd call', '1st call', '2nd call', '2026-01-28 09:59:39', NULL, 'online a admit howar posibilty  ase', NULL, 0, '2026-01-28 03:59:39'),
(230, 205, 27, '1st call', 'Fresh', '1st call', '2026-01-28 10:07:48', NULL, '', NULL, 0, '2026-01-28 04:07:48'),
(231, 204, 27, '1st call', 'Fresh', '1st call', '2026-01-28 10:08:09', NULL, '', NULL, 0, '2026-01-28 04:08:09'),
(232, 180, 30, '2nd call', '1st call', '2nd call', '2026-01-28 10:14:36', NULL, '', NULL, 0, '2026-01-28 04:14:36'),
(233, 62, 27, 'Office visit confirmation', '3rd call', 'Will visit office', '2026-01-28 10:21:20', NULL, 'call kete dicce', NULL, 0, '2026-01-28 04:21:20'),
(234, 152, 27, '3rd call', '2nd call', '3rd call', '2026-01-28 10:28:01', NULL, 'next semester', NULL, 0, '2026-01-28 04:28:01'),
(235, 181, 30, '2nd call', '1st call', '2nd call', '2026-01-28 10:35:33', NULL, '', NULL, 0, '2026-01-28 04:35:33'),
(236, 207, 27, 'Office visit confirmation', '1st call', 'Will visit office', '2026-01-28 11:08:12', NULL, '', NULL, 0, '2026-01-28 05:08:12'),
(237, 209, 27, '1st call', 'Fresh', '1st call', '2026-01-28 11:22:21', NULL, '', NULL, 0, '2026-01-28 05:22:21'),
(238, 203, 30, '1st call', 'Fresh', '1st call', '2026-01-28 11:34:26', NULL, '', NULL, 0, '2026-01-28 05:34:26'),
(239, 212, 27, '1st call', 'Fresh', '1st call', '2026-01-28 11:52:17', NULL, '', NULL, 0, '2026-01-28 05:52:17'),
(240, 213, 27, '1st call', 'Fresh', '1st call', '2026-01-28 11:52:40', NULL, '', NULL, 0, '2026-01-28 05:52:40'),
(241, 177, 30, '2nd call', '1st call', '2nd call', '2026-01-28 12:01:05', NULL, '', NULL, 0, '2026-01-28 06:01:05'),
(242, 210, 27, '1st call', 'Fresh', '1st call', '2026-01-28 12:05:30', NULL, '', NULL, 0, '2026-01-28 06:05:30'),
(243, 219, 27, '1st call', 'Fresh', '1st call', '2026-01-28 13:30:53', NULL, '', NULL, 0, '2026-01-28 07:30:53'),
(244, 227, 27, '1st call', 'Fresh', '1st call', '2026-01-28 15:25:26', NULL, '', NULL, 0, '2026-01-28 09:25:26'),
(245, 231, 27, '1st call', 'Fresh', '1st call', '2026-01-28 15:26:37', NULL, '', NULL, 0, '2026-01-28 09:26:37'),
(246, 230, 27, '1st call', 'Fresh', '1st call', '2026-01-28 15:58:43', NULL, '', NULL, 0, '2026-01-28 09:58:43'),
(247, 228, 27, '1st call', 'Fresh', '1st call', '2026-01-28 15:59:29', NULL, '', NULL, 0, '2026-01-28 09:59:29'),
(248, 229, 30, '1st call', 'Fresh', '1st call', '2026-01-28 15:59:31', NULL, '', NULL, 0, '2026-01-28 09:59:31'),
(249, 226, 27, '1st call', 'Fresh', '1st call', '2026-01-28 16:00:17', NULL, '', NULL, 0, '2026-01-28 10:00:17'),
(250, 223, 30, '1st call', 'Fresh', '1st call', '2026-01-28 16:10:02', NULL, '', NULL, 0, '2026-01-28 10:10:02'),
(251, 206, 27, '1st call', 'Fresh', '1st call', '2026-01-28 16:16:35', NULL, 'Not sure decision nibe ', NULL, 0, '2026-01-28 10:16:35'),
(252, 223, 30, '2nd call', '1st call', '2nd call', '2026-01-28 16:18:15', NULL, '', NULL, 0, '2026-01-28 10:18:15'),
(253, 221, 30, '1st call', 'Fresh', '1st call', '2026-01-28 16:19:59', NULL, '', NULL, 0, '2026-01-28 10:19:59'),
(254, 220, 30, '1st call', 'Fresh', '1st call', '2026-01-28 17:19:45', NULL, '', NULL, 0, '2026-01-28 11:19:45'),
(255, 235, 27, '1st call', 'Fresh', '1st call', '2026-01-28 17:24:13', NULL, '', NULL, 0, '2026-01-28 11:24:13'),
(256, 237, 27, '1st call', 'Fresh', '1st call', '2026-01-28 17:37:26', NULL, '', NULL, 0, '2026-01-28 11:37:26'),
(257, 193, 24, '2nd call', '1st call', '2nd call', '2026-01-28 19:44:20', NULL, '', NULL, 0, '2026-01-28 13:44:20'),
(258, 192, 24, '2nd call', '1st call', '2nd call', '2026-01-28 19:46:20', NULL, 'vai osusto thakai late hocche ,', NULL, 0, '2026-01-28 13:46:20'),
(259, 193, 24, '3rd call', '2nd call', '3rd call', '2026-01-28 19:48:57', NULL, '', NULL, 0, '2026-01-28 13:48:57'),
(260, 179, 24, '3rd call', '2nd call', '3rd call', '2026-01-28 19:51:35', NULL, '', NULL, 0, '2026-01-28 13:51:35'),
(261, 171, 24, '3rd call', '2nd call', '3rd call', '2026-01-28 19:52:38', NULL, 'Not picked', NULL, 0, '2026-01-28 13:52:38'),
(262, 159, 24, '3rd call', '2nd call', '3rd call', '2026-01-28 19:58:38', NULL, 'Not picked', NULL, 0, '2026-01-28 13:58:38'),
(263, 143, 24, '3rd call', '2nd call', '3rd call', '2026-01-28 20:10:07', NULL, 'he can\'t during  network should call tomorrow', NULL, 0, '2026-01-28 14:10:07'),
(264, 242, 24, '1st call', 'Fresh', '1st call', '2026-01-29 09:30:32', NULL, '', NULL, 0, '2026-01-29 03:30:32'),
(265, 193, 24, '3rd call', '2nd call', '3rd call', '2026-01-29 09:35:45', NULL, 'Not picked', NULL, 0, '2026-01-29 03:35:45'),
(266, 178, 24, '3rd call', '2nd call', '3rd call', '2026-01-29 10:42:23', NULL, 'will come tomorrow', NULL, 0, '2026-01-29 04:42:23'),
(267, 244, 24, '1st call', 'Fresh', '1st call', '2026-01-29 10:56:14', NULL, '', NULL, 0, '2026-01-29 04:56:14'),
(268, 175, 24, '3rd call', '2nd call', '3rd call', '2026-01-29 11:17:12', NULL, '', NULL, 0, '2026-01-29 05:17:12'),
(269, 195, 30, '2nd call', '1st call', '2nd call', '2026-01-29 11:17:45', NULL, '', NULL, 0, '2026-01-29 05:17:45'),
(270, 170, 24, '3rd call', '2nd call', '3rd call', '2026-01-29 11:30:41', NULL, 'will admit in sunday or Monday', NULL, 0, '2026-01-29 05:30:41'),
(271, 157, 24, '3rd call', '2nd call', '3rd call', '2026-01-29 11:35:17', NULL, 'didn\'t talked', NULL, 0, '2026-01-29 05:35:17'),
(272, 158, 24, '2nd call', '1st call', '2nd call', '2026-01-29 11:35:35', NULL, '', NULL, 0, '2026-01-29 05:35:35'),
(273, 247, 24, '1st call', 'Fresh', '1st call', '2026-01-29 12:06:57', NULL, '', NULL, 0, '2026-01-29 06:06:57'),
(274, 246, 24, '1st call', 'Fresh', '1st call', '2026-01-29 12:07:09', NULL, '', NULL, 0, '2026-01-29 06:07:09'),
(275, 211, 29, '1st call', 'Fresh', '1st call', '2026-01-29 12:10:53', NULL, '', NULL, 0, '2026-01-29 06:10:53'),
(276, 195, 30, '3rd call', '2nd call', '3rd call', '2026-01-29 12:11:05', NULL, '', NULL, 0, '2026-01-29 06:11:05'),
(277, 191, 30, '2nd call', '1st call', '2nd call', '2026-01-29 12:13:24', NULL, '', NULL, 0, '2026-01-29 06:13:24'),
(278, 249, 30, '1st call', 'Fresh', '1st call', '2026-01-29 12:45:44', NULL, '', NULL, 0, '2026-01-29 06:45:44'),
(279, 241, 30, '1st call', 'Fresh', '1st call', '2026-01-29 13:01:47', NULL, '', NULL, 0, '2026-01-29 07:01:47'),
(280, 250, 24, '1st call', 'Fresh', '1st call', '2026-01-29 13:53:08', NULL, '', NULL, 0, '2026-01-29 07:53:08'),
(281, 251, 24, '1st call', 'Fresh', '1st call', '2026-01-29 13:53:18', NULL, '', NULL, 0, '2026-01-29 07:53:18'),
(282, 248, 24, '1st call', 'Fresh', '1st call', '2026-01-29 13:53:30', NULL, '', NULL, 0, '2026-01-29 07:53:30'),
(283, 239, 30, '1st call', 'Fresh', '1st call', '2026-01-29 14:08:06', NULL, '', NULL, 0, '2026-01-29 08:08:06'),
(284, 238, 24, '1st call', 'Fresh', '1st call', '2026-01-29 14:52:41', NULL, 'Will inform us soon', NULL, 0, '2026-01-29 08:52:41'),
(285, 255, 24, '1st call', 'Fresh', '1st call', '2026-01-29 15:49:53', NULL, '', NULL, 0, '2026-01-29 09:49:53'),
(286, 237, 27, 'Office visit confirmation', '1st call', 'Will visit office', '2026-01-29 19:59:36', NULL, 'kalke admit hobe ( family crisis)  ', NULL, 0, '2026-01-29 13:59:36'),
(287, 235, 27, '2nd call', '1st call', '2nd call', '2026-01-29 21:32:23', NULL, 'Kalke admit hobe', NULL, 0, '2026-01-29 15:32:23'),
(288, 231, 27, '2nd call', '1st call', '2nd call', '2026-01-29 21:33:36', NULL, 'Janabe', NULL, 0, '2026-01-29 15:33:36'),
(289, 230, 27, '2nd call', '1st call', '2nd call', '2026-01-29 21:34:37', NULL, 'Janabe', NULL, 0, '2026-01-29 15:34:37'),
(290, 210, 27, '2nd call', '1st call', '2nd call', '2026-01-29 21:46:51', NULL, 'kalke call dibo', NULL, 0, '2026-01-29 15:46:51'),
(291, 199, 27, '2nd call', '1st call', '2nd call', '2026-01-29 21:49:57', NULL, '', NULL, 0, '2026-01-29 15:49:57'),
(292, 166, 27, '3rd call', '2nd call', '3rd call', '2026-01-29 21:54:30', NULL, 'Not picked', NULL, 0, '2026-01-29 15:54:30'),
(293, 251, 24, '2nd call', '1st call', '2nd call', '2026-01-30 11:18:51', NULL, 'will let us know', NULL, 0, '2026-01-30 05:18:51'),
(294, 250, 24, '2nd call', '1st call', '2nd call', '2026-01-30 11:19:26', NULL, 'will let us know', NULL, 0, '2026-01-30 05:19:26'),
(295, 247, 24, '2nd call', '1st call', '2nd call', '2026-01-30 11:27:34', NULL, 'will let us know', NULL, 0, '2026-01-30 05:27:34'),
(296, 244, 24, '2nd call', '1st call', '2nd call', '2026-01-30 11:29:24', NULL, 'Not picked', NULL, 0, '2026-01-30 05:29:24'),
(297, 176, 24, '3rd call', '2nd call', '3rd call', '2026-01-30 11:42:21', NULL, '', NULL, 0, '2026-01-30 05:42:21'),
(298, 255, 24, '2nd call', '1st call', '2nd call', '2026-01-30 11:46:16', NULL, 'not picked', NULL, 0, '2026-01-30 05:46:16'),
(299, 173, 24, '3rd call', '2nd call', '3rd call', '2026-01-30 12:13:17', NULL, '2,3 February will come', NULL, 0, '2026-01-30 06:13:17'),
(300, 172, 24, '3rd call', '2nd call', '3rd call', '2026-01-30 12:32:59', NULL, 'Not picked,next semester', NULL, 0, '2026-01-30 06:32:59'),
(301, 236, 27, '1st call', 'Fresh', '1st call', '2026-01-30 12:40:38', NULL, 'Not reached', NULL, 0, '2026-01-30 06:40:38'),
(302, 236, 27, '2nd call', '1st call', '2nd call', '2026-01-30 12:40:54', NULL, '', NULL, 0, '2026-01-30 06:40:54'),
(303, 233, 27, '2nd call', '1st call', '2nd call', '2026-01-30 12:44:00', NULL, 'Unreachable', NULL, 0, '2026-01-30 06:44:00'),
(304, 234, 27, '2nd call', '1st call', '2nd call', '2026-01-30 12:45:35', NULL, 'Unreachable', NULL, 0, '2026-01-30 06:45:35'),
(305, 228, 27, '2nd call', '1st call', '2nd call', '2026-01-30 12:49:15', NULL, 'Not picked', NULL, 0, '2026-01-30 06:49:15'),
(306, 227, 27, '2nd call', '1st call', '2nd call', '2026-01-30 12:50:52', NULL, 'Not picked', NULL, 0, '2026-01-30 06:50:52'),
(307, 226, 27, '2nd call', '1st call', '2nd call', '2026-01-30 12:51:45', NULL, 'not picked', NULL, 0, '2026-01-30 06:51:45'),
(308, 219, 27, '2nd call', '1st call', '2nd call', '2026-01-30 12:56:31', NULL, 'Janabe', NULL, 0, '2026-01-30 06:56:31'),
(309, 155, 24, '2nd call', '1st call', '2nd call', '2026-01-30 13:58:00', NULL, 'taka manage korte paren ni', NULL, 0, '2026-01-30 07:58:00'),
(310, 255, 24, '3rd call', '2nd call', '3rd call', '2026-01-30 14:02:22', NULL, 'not picked', NULL, 0, '2026-01-30 08:02:22'),
(311, 271, 24, '1st call', 'Fresh', '1st call', '2026-01-30 16:37:03', NULL, '', NULL, 0, '2026-01-30 10:37:03'),
(312, 270, 24, '1st call', 'Fresh', '1st call', '2026-01-30 16:37:09', NULL, '', NULL, 0, '2026-01-30 10:37:09'),
(313, 257, 24, '1st call', 'Fresh', '1st call', '2026-01-30 16:52:17', NULL, 'will let us know after talking with home ', NULL, 0, '2026-01-30 10:52:17'),
(314, 235, 27, '3rd call', '2nd call', '3rd call', '2026-01-30 17:45:25', NULL, 'Next semester', NULL, 0, '2026-01-30 11:45:25'),
(315, 231, 27, '3rd call', '2nd call', '3rd call', '2026-01-30 17:54:45', NULL, 'baba mara gese decision nite deri hosse', NULL, 0, '2026-01-30 11:54:45'),
(316, 230, 27, '3rd call', '2nd call', '3rd call', '2026-01-30 17:55:43', NULL, 'baba mara gese decision nite deri hosse', NULL, 0, '2026-01-30 11:55:43'),
(317, 276, 24, '1st call', 'Fresh', '1st call', '2026-01-30 17:56:41', NULL, '', NULL, 0, '2026-01-30 11:56:41'),
(318, 273, 24, '1st call', 'Fresh', '1st call', '2026-01-30 17:56:52', NULL, '', NULL, 0, '2026-01-30 11:56:52'),
(319, 210, 27, '3rd call', '2nd call', '3rd call', '2026-01-30 18:33:34', NULL, 'Kalke adnit hote chasce', NULL, 0, '2026-01-30 12:33:34'),
(320, 274, 27, '1st call', 'Fresh', '1st call', '2026-01-30 18:34:11', NULL, '', NULL, 0, '2026-01-30 12:34:11'),
(321, 209, 27, '2nd call', '1st call', '2nd call', '2026-01-30 18:39:10', NULL, 'Monday admit hote chasce', NULL, 0, '2026-01-30 12:39:10'),
(322, 207, 27, 'Office visit confirmation', '2nd call', 'Will visit office', '2026-01-30 18:51:09', NULL, 'Kal visit korbe & admit hobe( FDAE te hote chascilo but now CSE/EEE)', NULL, 0, '2026-01-30 12:51:09'),
(323, 205, 27, 'Office visit confirmation', '1st call', 'Will visit office', '2026-01-30 18:55:30', NULL, 'Kalke admit hobe', NULL, 0, '2026-01-30 12:55:30'),
(324, 204, 27, 'Office visit confirmation', '1st call', 'Will visit office', '2026-01-30 18:56:30', NULL, 'Kalke admit hobe', NULL, 0, '2026-01-30 12:56:30'),
(325, 196, 27, '2nd call', '1st call', '2nd call', '2026-01-30 18:58:03', NULL, 'Kalke online admit hobe or next semester ', NULL, 0, '2026-01-30 12:58:03'),
(326, 199, 27, '3rd call', '2nd call', '3rd call', '2026-01-30 19:00:20', NULL, 'Not reached', NULL, 0, '2026-01-30 13:00:20'),
(327, 194, 27, '3rd call', '2nd call', '3rd call', '2026-01-30 19:03:13', NULL, 'Next semester ', NULL, 0, '2026-01-30 13:03:13'),
(328, 187, 27, '2nd call', '1st call', '2nd call', '2026-01-30 19:09:51', NULL, 'Busy', NULL, 0, '2026-01-30 13:09:51'),
(329, 243, 27, '1st call', 'Fresh', '1st call', '2026-01-30 19:49:07', NULL, 'only information', NULL, 0, '2026-01-30 13:49:07'),
(330, 259, 27, '1st call', 'Fresh', '1st call', '2026-01-30 19:53:23', NULL, 'next semester ', NULL, 0, '2026-01-30 13:53:23'),
(331, 260, 27, '1st call', 'Fresh', '1st call', '2026-01-30 20:16:52', NULL, 'next semester ', NULL, 0, '2026-01-30 14:16:52'),
(332, 263, 27, '1st call', 'Fresh', '1st call', '2026-01-30 20:28:02', NULL, 'Kal call', NULL, 0, '2026-01-30 14:28:02');

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `id` int NOT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_first_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_last_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `website_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `system_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` enum('Active','Inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `company_name`, `contact_first_name`, `contact_last_name`, `phone_number`, `website_url`, `contact_email`, `system_email`, `address`, `logo`, `created_by`, `created_at`, `updated_at`, `status`) VALUES
(1, 'Technofic Lab LTD', 'John', 'Doe', '+1234567890', '', 'contact@testcompany.com', 'system@testcompany.com', '', '67870eee2ca73_Logo-1-1024x407 (3).png', 3, '2025-01-11 23:17:03', '2025-01-15 01:27:10', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `company_subscriptions`
--

CREATE TABLE `company_subscriptions` (
  `id` int NOT NULL,
  `company_id` int NOT NULL,
  `subscription_plan_id` int NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime DEFAULT NULL,
  `subscription_status` enum('Active','Expired','Cancelled','Suspended') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `price_paid` decimal(10,2) NOT NULL,
  `payment_status` enum('Paid','Pending','Failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `payment_method` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `notes` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `company_subscriptions`
--

INSERT INTO `company_subscriptions` (`id`, `company_id`, `subscription_plan_id`, `start_date`, `end_date`, `subscription_status`, `price_paid`, `payment_status`, `payment_method`, `transaction_id`, `created_by`, `created_at`, `updated_at`, `notes`) VALUES
(1, 1, 2, '2025-01-11 23:17:03', '2025-02-11 23:17:03', 'Active', 49.99, 'Pending', NULL, NULL, 3, '2025-01-11 23:17:03', '2025-01-11 23:17:03', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int NOT NULL,
  `course_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `department` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `credit` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `course_title`, `department`, `credit`, `created_at`, `updated_at`, `created_by`, `updated_by`) VALUES
(33, 'BSc in Civil Engineering', 'Faculty of Engineering', 1, '2026-01-19 07:08:04', '2026-01-19 07:08:04', 26, NULL),
(34, 'BSc in Computer Science & Engineering (CSE)', 'Faculty of Engineering', 1, '2026-01-19 07:08:44', '2026-01-19 07:08:44', 26, NULL),
(35, 'BSc in Electrical & Electronic Engineering (EEE)', 'Faculty of Engineering', 1, '2026-01-19 07:09:04', '2026-01-19 07:09:04', 26, NULL),
(36, 'Bachelor of Laws (Hons)', 'Faculty of Law', 1, '2026-01-19 07:09:40', '2026-01-19 07:09:40', 26, NULL),
(37, 'Master of Laws (LLM-Regular)', 'Faculty of Law', 1, '2026-01-19 07:10:09', '2026-01-19 07:10:09', 26, NULL),
(38, 'Master of Laws (Preli & Final)', 'Faculty of Law', 1, '2026-01-19 07:10:33', '2026-01-19 07:10:33', 26, NULL),
(39, 'BA (Hons) in Bangla', 'Faculty of Arts', 1, '2026-01-19 07:10:52', '2026-01-19 07:10:52', 26, NULL),
(40, 'BA (Hons) in English', 'Faculty of Arts', 1, '2026-01-19 07:11:07', '2026-01-19 07:11:07', 26, NULL),
(41, 'MA in English', 'Faculty of Arts', 1, '2026-01-19 07:11:25', '2026-01-19 07:11:25', 26, NULL),
(42, 'Bachelor of Education (BEd)', 'Faculty of Arts', 1, '2026-01-19 07:11:53', '2026-01-19 07:11:53', 26, NULL),
(43, 'Master of Education (MEd)', 'Faculty of Arts', 1, '2026-01-19 07:12:10', '2026-01-19 07:12:10', 26, NULL),
(44, 'Bachelor of Business Administration (BBA)', 'Faculty of Business Studies', 1, '2026-01-19 07:12:35', '2026-01-19 07:12:35', 26, NULL),
(45, 'Bachelor of Business Information System (BBIS)', 'Faculty of Business Studies', 1, '2026-01-19 07:12:52', '2026-01-19 07:12:52', 26, NULL),
(46, 'Master of Business Administration (MBA)', 'Faculty of Business Studies', 1, '2026-01-19 07:13:04', '2026-01-19 07:13:04', 26, NULL),
(47, 'BSc in Fashion Design and Apparel Engineering', 'Fashion Design', 1, '2026-01-19 08:09:33', '2026-01-19 08:09:33', 26, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `leads`
--

CREATE TABLE `leads` (
  `id` int NOT NULL,
  `first_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `current_city` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `applying_for` enum('Bachelor Degree','Master Degree') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `semester` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ssc_gpa` decimal(3,2) DEFAULT NULL,
  `hsc_gpa` decimal(3,2) DEFAULT NULL,
  `bachelor_subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bachelor_cgpa` decimal(3,2) DEFAULT NULL,
  `interested_course_id` int DEFAULT NULL,
  `most_recent_degree` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gpa` decimal(3,2) DEFAULT NULL,
  `ielts_overall` decimal(2,1) DEFAULT NULL,
  `ielts_reading` decimal(2,1) DEFAULT NULL,
  `ielts_writing` decimal(2,1) DEFAULT NULL,
  `ielts_speaking` decimal(2,1) DEFAULT NULL,
  `ielts_listening` decimal(2,1) DEFAULT NULL,
  `country_applying_from` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nationality` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `budget` decimal(10,2) DEFAULT NULL,
  `lead_source` enum('Direct Online','Direct Campus Visit','Agent','F2F Marketing') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `assigned_campus` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lead_status` enum('Fresh','1st call','2nd call','3rd call','Unable to reach once','Unable to reach twice','Unable to reach trice','Dead','Will visit office','Admitted') COLLATE utf8mb4_unicode_ci DEFAULT 'Fresh',
  `last_status_change_date` datetime DEFAULT NULL COMMENT 'Date when lead status was last changed',
  `next_followup_date` date DEFAULT NULL COMMENT 'Calculated date for next follow-up (status change + 2 days)',
  `last_followup_action_date` datetime DEFAULT NULL COMMENT 'Date when last follow-up action was taken',
  `campus_visit_date` datetime DEFAULT NULL,
  `campus_visit_attended_at` datetime DEFAULT NULL,
  `attended_at` timestamp NULL DEFAULT NULL COMMENT 'When the lead attended their office visit',
  `created_by` int NOT NULL,
  `updated_by` int DEFAULT NULL COMMENT 'User ID who last updated this lead',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `agent_id` int DEFAULT NULL,
  `company_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `leads`
--

INSERT INTO `leads` (`id`, `first_name`, `last_name`, `email`, `phone`, `address`, `current_city`, `applying_for`, `semester`, `ssc_gpa`, `hsc_gpa`, `bachelor_subject`, `bachelor_cgpa`, `interested_course_id`, `most_recent_degree`, `gpa`, `ielts_overall`, `ielts_reading`, `ielts_writing`, `ielts_speaking`, `ielts_listening`, `country_applying_from`, `nationality`, `budget`, `lead_source`, `assigned_campus`, `lead_status`, `last_status_change_date`, `next_followup_date`, `last_followup_action_date`, `campus_visit_date`, `campus_visit_attended_at`, `attended_at`, `created_by`, `updated_by`, `created_at`, `updated_at`, `agent_id`, `company_id`) VALUES
(49, 'Md Hamidul', 'Islam', 'mdhamidul0862@gmail.com', '+8801910245542', 'Mymensingh', 'Dhaka', 'Bachelor Degree', 'Spring 2026', NULL, NULL, '', NULL, 39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-23 11:42:45', NULL, '2026-01-23 11:42:45', NULL, NULL, NULL, 3, NULL, '2026-01-19 18:04:00', '2026-01-23 05:42:45', NULL, 1),
(50, 'Juli', 'Juli', 'msaiful9526@gmail.com', '01880749526', 'Hathazari', 'Chittagong', 'Bachelor Degree', 'Spring 2026', NULL, NULL, '', NULL, 39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-25 14:38:25', '2026-01-27', '2026-01-27 21:16:37', NULL, NULL, NULL, 3, NULL, '2026-01-19 18:04:45', '2026-01-27 15:16:37', NULL, 1),
(51, 'Mang', 'Raj', 'mdarmanhossainakashakash4@gmail.com', '01312579437', 'Ashulia', 'Savar', 'Bachelor Degree', 'Spring 2026', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Unable to reach trice', '2026-01-25 14:37:00', '2026-01-31', '2026-01-30 16:49:18', NULL, NULL, NULL, 3, NULL, '2026-01-19 18:04:52', '2026-01-30 10:49:18', NULL, 1),
(52, 'Md', 'Saiful', 'msaiful9526@gmail.com', '01880749526', 'Chittagong', 'Chittagong', 'Bachelor Degree', 'Spring 2026', NULL, NULL, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-22 16:40:00', NULL, '2026-01-22 16:40:00', NULL, NULL, NULL, 3, NULL, '2026-01-19 18:05:38', '2026-01-22 10:40:00', NULL, 1),
(53, 'Md', 'Khadimul', 'mdkhadimulislam009@gmail.com', '01797427208', 'Dhaka', 'Dhaka', 'Bachelor Degree', 'Spring 2026', NULL, NULL, '', NULL, 39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Unable to reach once', '2026-01-25 11:01:58', '2026-02-04', '2026-01-29 14:11:00', NULL, NULL, NULL, 3, NULL, '2026-01-19 18:10:27', '2026-01-29 08:11:00', NULL, 1),
(55, 'Sijan', 'Alam', 'daudebrahim8649@gmail.com', '01570216810', 'Narayanganj', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 5.00, 3.08, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-25 14:35:42', '2026-01-31', '2026-01-30 16:48:05', NULL, NULL, NULL, 3, NULL, '2026-01-19 18:28:35', '2026-01-30 10:48:05', NULL, 1),
(57, 'নুর', 'আলাম', 'mdroni126435@gmail.com', '01897150905', 'নোয়াখালী \r\nসুবর্ণচর', 'নোয়াখালী', 'Bachelor Degree', 'Spring 2026', 1.00, 2.00, '', NULL, 39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-21 17:06:32', NULL, '2026-01-21 17:06:32', NULL, NULL, NULL, 3, NULL, '2026-01-19 18:53:26', '2026-01-21 11:06:32', NULL, 1),
(60, 'Pushpita', 'Nur', 'pushpitanur151@gmail.com', '1765633426', 'R. K mission road', 'Mymensingh', 'Bachelor Degree', 'Spring 2026', 4.83, 4.50, '', NULL, 39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-21 16:49:54', NULL, '2026-01-21 16:49:54', NULL, NULL, NULL, 3, NULL, '2026-01-19 20:00:06', '2026-01-21 10:49:54', NULL, 1),
(61, 'MST', 'Tamanna', 'tamannamst741@gmail.com', '01332624098', 'Chandina', 'Bangladesh', 'Bachelor Degree', 'Spring 2026', 3.33, 2.24, '', NULL, 39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-22 18:26:43', NULL, '2026-01-22 18:26:43', NULL, NULL, NULL, 3, NULL, '2026-01-20 02:04:17', '2026-01-22 12:26:43', NULL, 1),
(62, 'Mohammad', 'Sohel', 'sohelranavivoy12s@gmail.com', '01615193449', 'Cumilla', 'Cumilla', 'Bachelor Degree', 'Spring 2026', 4.00, 4.00, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-26 10:26:47', '2026-02-10', '2026-01-30 16:45:01', NULL, NULL, NULL, 3, NULL, '2026-01-20 03:38:45', '2026-01-30 10:45:01', NULL, 1),
(63, 'Mim akther', 'Shova', 'mimakthershova@gmail.com', '01335703637', 'Hashail', 'Bangladesh', 'Bachelor Degree', 'Spring 2026', 3.67, 3.58, '', NULL, 39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-20 16:55:08', NULL, '2026-01-20 16:55:25', NULL, NULL, NULL, 3, NULL, '2026-01-20 03:47:52', '2026-01-20 10:55:25', NULL, 1),
(64, 'md..', 'Ashidul', 'mdasidul817@gmail.com', '01611240271', 'Bogura', 'Bangladesh', 'Bachelor Degree', 'Spring 2026', 4.29, 4.13, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-22 18:17:16', NULL, '2026-01-22 18:17:16', NULL, NULL, NULL, 3, NULL, '2026-01-20 04:10:07', '2026-01-22 12:17:16', NULL, 1),
(65, 'Humon', 'Halder', 'deys4954@gmail.com', '01408445250', 'Chittagong', 'Hallkwm para', 'Bachelor Degree', 'January 2025', 3.56, 4.11, '', NULL, 39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-20 16:37:20', NULL, '2026-01-20 16:37:20', NULL, NULL, NULL, 3, NULL, '2026-01-20 04:20:12', '2026-01-20 10:37:20', NULL, 1),
(66, 'Ehujs', 'Jkkm', 'deys954@gmail.com', '01681377905', 'Chittagong', 'hazara', 'Bachelor Degree', 'January 2025', 2.86, 4.51, '', NULL, 39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-22 18:02:44', NULL, '2026-01-22 18:02:44', NULL, NULL, NULL, 3, NULL, '2026-01-20 04:25:40', '2026-01-22 12:02:44', NULL, 1),
(67, 'Asiqul islam', 'Fahad', 'asiqulislamfahad@gmail.com', '1868702417', 'চান্দুরা', 'বাম্ণবাড়িয়া', 'Bachelor Degree', 'Spring 2026', 2.00, 3.00, '', NULL, 39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-20 16:30:06', NULL, '2026-01-20 16:30:06', NULL, NULL, NULL, 3, NULL, '2026-01-20 04:52:40', '2026-01-20 10:30:06', NULL, 1),
(68, 'Esha', 'Moni', 'mestesha8@gmail.com', '01752518428', 'Dinajpure', 'Dinajpur', 'Bachelor Degree', 'Spring 2026', 4.69, 4.63, '', NULL, 39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-20 16:24:20', NULL, '2026-01-20 16:24:20', NULL, NULL, NULL, 3, NULL, '2026-01-20 04:58:01', '2026-01-20 10:24:20', NULL, 1),
(69, 'Md.', 'Nur uddin', 'm46619163@gmail.com', '01868232860', 'Oli pur', 'Noakhali', 'Bachelor Degree', 'January 2025', 3.22, 2.77, '', NULL, 39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-20 16:19:25', NULL, '2026-01-20 16:19:25', NULL, NULL, NULL, 3, NULL, '2026-01-20 05:21:44', '2026-01-20 10:19:25', NULL, 1),
(70, 'Md Jamal', 'Badsha', 'mdjamalbadsha65@gamil.com', '01957891957', 'Sylhet', 'Sylhet', 'Bachelor Degree', 'Spring 2026', 4.68, 3.48, '', NULL, 33, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-22 17:58:39', NULL, '2026-01-22 17:58:39', NULL, NULL, NULL, 3, NULL, '2026-01-20 05:30:07', '2026-01-22 11:58:39', NULL, 1),
(71, 'Raisul Islam', 'Rajon', 'raisul30648@gmail.com', '01921130658', 'Jessore sader satighata', 'Dhaka mirpur', 'Bachelor Degree', 'Spring 2026', 5.00, 4.50, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-26 11:42:36', '2026-01-30', '2026-01-30 19:14:43', NULL, NULL, '2026-01-27 04:54:28', 3, 27, '2026-01-20 05:44:13', '2026-01-30 13:14:43', NULL, 1),
(72, 'Sanjida', 'Any', 'anysanjida08@gmail.com', '01335986972', 'Karnaphuli', 'Shikalbaha', 'Bachelor Degree', 'Spring 2026', 3.67, 3.00, '', NULL, 39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-20 14:45:00', NULL, '2026-01-20 14:45:00', NULL, NULL, NULL, 3, NULL, '2026-01-20 06:16:55', '2026-01-20 08:45:00', NULL, 1),
(73, 'Abul', 'Abul', 'info@abul.com', '096555523548', 'gshdjdhdh', 'dgaka', 'Bachelor Degree', 'January 2025', 4.60, 4.79, '', NULL, 42, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-20 14:01:15', NULL, '2026-01-20 14:01:15', NULL, NULL, NULL, 3, NULL, '2026-01-20 06:53:56', '2026-01-20 08:01:15', NULL, 1),
(74, 'Asiya', 'Khatun', 'mdrapu83@gmail.com', '01343422655', 'Onupnogor', 'Baba', 'Master Degree', 'Spring 2026', 1.00, 2.00, 'Bangala', 3.00, 39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-22 17:41:07', NULL, '2026-01-22 17:41:07', NULL, NULL, NULL, 3, NULL, '2026-01-20 07:23:51', '2026-01-22 11:41:07', NULL, 1),
(75, 'অভি', 'Mondol', 'ovimondol1336@gmail.com', '01881538336', 'মাগুরা', 'মাগুরা জেলা', 'Bachelor Degree', 'Spring 2026', 3.22, 3.33, '', NULL, 39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-26 11:17:33', '2026-01-29', '2026-01-29 18:07:07', NULL, NULL, NULL, 3, NULL, '2026-01-20 07:34:31', '2026-01-29 12:07:07', NULL, 1),
(76, 'Angle Torpi ', 'haldar', 'angletorpi.bd07@gmail.com', '01533928446', '', '', 'Bachelor Degree', 'Spring 2026', 5.00, 4.75, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Campus Visit', NULL, 'Will visit office', '2026-01-26 11:18:49', '2026-02-15', '2026-01-28 17:28:14', '2026-02-20 11:00:00', NULL, NULL, 27, NULL, '2026-01-20 08:06:29', '2026-01-28 11:28:14', NULL, 1),
(77, 'Mostafa Oasif', 'Jefan', 'jefan01738291535@gmail.com', '01616858689', 'Cumilla', 'Cumilla', 'Bachelor Degree', 'Spring 2026', 3.83, 3.96, '', NULL, 39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-22 17:23:44', NULL, '2026-01-22 17:23:44', NULL, NULL, NULL, 3, NULL, '2026-01-20 08:13:05', '2026-01-22 11:23:44', NULL, 1),
(78, 'Ibrahim', 'Miah', 'ibrahimalhasan975@gmail.com', '01788987530', 'Dhaka, Mirpur', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 5.00, 3.75, '', NULL, 35, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Admitted', '2026-01-20 14:51:16', NULL, '2026-01-24 18:15:10', NULL, NULL, NULL, 27, NULL, '2026-01-20 08:13:25', '2026-01-24 12:15:10', NULL, 1),
(79, 'Mira', 'N/A', 'NA@yahoo.com', '01719922777', '', '', 'Master Degree', 'Spring 2026', NULL, NULL, '', NULL, 38, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Admitted', '2026-01-26 11:36:15', '2026-01-30', '2026-01-30 16:18:57', NULL, NULL, NULL, 27, NULL, '2026-01-20 08:16:43', '2026-01-30 10:18:57', NULL, 1),
(80, 'Khalid Bin ', 'Azad', 'na@gmail.com', '01311658180', '', '', 'Bachelor Degree', 'Spring 2026', 3.33, 3.35, '', NULL, 35, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-25 14:32:36', NULL, '2026-01-25 14:32:36', NULL, NULL, '2026-01-20 10:58:37', 27, 3, '2026-01-20 09:13:32', '2026-01-25 08:32:36', NULL, 1),
(81, 'Monir ', 'Islam', 'na@gmail.com', '01317464147', '', '', 'Bachelor Degree', '', 4.09, 3.96, '', NULL, 33, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Admitted', '2026-01-21 11:18:11', NULL, '2026-01-21 11:37:58', NULL, NULL, NULL, 27, NULL, '2026-01-20 09:30:32', '2026-01-21 05:37:58', NULL, 1),
(82, 'Sabrina Akter ', 'Priya', 'na@gmail.com', '013282333000', 'Mirpur 1', '', 'Bachelor Degree', 'Spring 2026', 5.00, 5.00, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Agent', NULL, 'Admitted', '2026-01-20 15:48:50', NULL, NULL, NULL, NULL, NULL, 27, NULL, '2026-01-20 09:48:50', '2026-01-20 09:48:50', NULL, 1),
(83, 'Fatema Akter ', 'Saiya', 'na@gmail.com', '01537170644', '', '', 'Bachelor Degree', 'Spring 2026', 4.50, 4.94, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Campus Visit', NULL, '2nd call', '2026-01-24 10:37:04', '2026-02-02', '2026-01-26 21:08:44', NULL, NULL, NULL, 3, NULL, '2026-01-20 09:56:39', '2026-01-26 15:08:44', NULL, 1),
(84, 'Md Tawsif', 'Ahmed', 'ffaabb99999@gmail.com', '01748113118', 'Dhara bohor', 'Dhara bohor', 'Bachelor Degree', 'Spring 2026', 2.00, 1.00, '', NULL, 39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-20 17:10:21', NULL, '2026-01-20 17:10:21', NULL, NULL, NULL, 3, NULL, '2026-01-20 09:58:34', '2026-01-20 11:10:21', NULL, 1),
(85, 'MANHA', 'ISLAM', 'manhaislam5577@gmail.com', '1968365234', 'Dhaka', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 5.00, 5.00, '', NULL, 33, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-20 17:07:47', NULL, '2026-01-20 17:07:47', NULL, NULL, NULL, 3, NULL, '2026-01-20 10:43:10', '2026-01-20 11:07:47', NULL, 1),
(86, 'Samia', 'Ms', 'miharahim321@gamil.com', '01954878202', 'Narayanganj. Fotullah', 'Narayanganj', 'Bachelor Degree', 'Spring 2026', 4.80, 4.20, '', NULL, 39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-24 17:32:02', NULL, '2026-01-24 17:32:02', NULL, NULL, NULL, 3, NULL, '2026-01-20 11:32:19', '2026-01-24 11:32:02', NULL, 1),
(87, 'FoyaJ', 'Ahmed', 'foyajahmedjuri@gmail.com', '01835849263', 'Kulawra', 'Kulawra', 'Bachelor Degree', 'Spring 2026', 4.38, 4.96, '', NULL, 39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-25 10:43:24', '2026-02-01', '2026-01-29 14:11:24', NULL, NULL, NULL, 3, NULL, '2026-01-20 11:53:47', '2026-01-29 08:11:24', NULL, 1),
(88, 'Billal', 'Babu', 'billalbabu654@gmail.com', '01757741775', 'pakundiya', 'Kishorganj', 'Bachelor Degree', 'Spring 2026', 5.00, 4.00, '', NULL, 45, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-25 18:13:14', '2026-01-27', '2026-01-27 15:19:47', NULL, NULL, NULL, 3, NULL, '2026-01-20 12:05:10', '2026-01-27 09:19:47', NULL, 1),
(89, 'Marzia', 'Akter', 'marziaakter421@gmail.com', '01880595052', 'Dhaka', 'Dhaka', 'Master Degree', 'Spring 2026', 4.00, 5.00, 'Since', 3.00, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-25 14:25:28', '2026-02-10', '2026-01-30 16:41:49', NULL, NULL, NULL, 3, NULL, '2026-01-20 13:45:16', '2026-01-30 10:41:49', NULL, 1),
(90, 'Md', 'Samir', 'humayaraaktarrasa07ct@gmail.com', '1814477941', 'Agrabad', 'Ctg', 'Bachelor Degree', 'Spring 2026', 4.00, 2.00, '', NULL, 39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-25 10:42:49', NULL, '2026-01-25 10:42:49', NULL, NULL, NULL, 3, NULL, '2026-01-20 14:48:33', '2026-01-25 04:42:49', NULL, 1),
(91, 'Md Rashidul', 'Islam', 'mdrashidul75.islam@gmail.com', '01796019824', 'Village :Mukondopur, Post:Jogodishpur, Upozila:Gobindaganj, Zila: Gaibandha- Rangpur', 'Kochasahor (কোচাশহর) Gobindaganj, Gaibandha', 'Bachelor Degree', 'Spring 2026', 3.78, 2.42, '', NULL, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-25 10:41:24', '2026-02-02', '2026-01-29 14:10:31', NULL, NULL, NULL, 3, NULL, '2026-01-20 15:42:23', '2026-01-29 08:10:31', NULL, 1),
(92, 'Tasnova Tansin', 'Pranty', 'tasnova@512.com', '01918408690', 'Lalmonirhat', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 4.39, 4.08, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Campus Visit', NULL, 'Will visit office', '2026-01-24 10:35:17', '2026-02-01', '2026-01-26 21:07:14', '2026-01-31 22:35:00', NULL, NULL, 3, NULL, '2026-01-20 16:31:41', '2026-01-26 15:07:14', NULL, 1),
(93, 'Md Rubel', 'Hossain', 'rubelhossainah53@gmail.com', '01761220653', 'Mirpur 2, Road: 60 fit', 'Mirpur', 'Bachelor Degree', 'Spring 2026', 4.33, 3.65, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Admitted', '2026-01-24 16:19:31', NULL, '2026-01-24 16:19:31', NULL, NULL, NULL, 3, NULL, '2026-01-21 03:59:08', '2026-01-24 10:19:31', NULL, 1),
(94, 'Parami', 'Chakma', 'paramichakma64@gmail.com', '01873780030', 'Khagrachari', 'Khagrachari', 'Bachelor Degree', 'Spring 2026', 4.22, 2.83, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-25 10:52:32', NULL, '2026-01-25 10:52:32', NULL, NULL, NULL, 3, NULL, '2026-01-21 04:00:02', '2026-01-25 04:52:32', NULL, 1),
(95, 'Jit Kumar', 'Saha', 'mail.jitsaha@gmail.com', '01601111994', 'Jattrapur , Holding No 381', 'Jashore', 'Bachelor Degree', 'Spring 2026', 4.28, 4.08, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-26 11:37:24', '2026-01-28', '2026-01-28 10:37:34', NULL, NULL, NULL, 3, NULL, '2026-01-21 04:31:43', '2026-01-28 04:37:34', NULL, 1),
(96, 'Hridoy', 'Hossain', 'houssenhridoy@gamil.com', '01821043547', 'Hematpur savar', 'Hematpur', 'Bachelor Degree', 'Spring 2026', 3.11, 3.17, '', NULL, 39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-25 10:59:41', '2026-01-27', '2026-01-27 15:18:02', NULL, NULL, NULL, 3, NULL, '2026-01-21 04:34:03', '2026-01-27 09:18:02', NULL, 1),
(97, 'Rashadul Hasan', 'Shuvo', 'rasedulhasanshuvo19@gmail.com', '01955106121', 'Sirajganj', 'Sirajganj', 'Bachelor Degree', 'Spring 2026', 3.61, 3.75, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Will visit office', '2026-01-24 17:15:39', '2026-01-31', '2026-01-30 19:08:09', '2026-01-31 11:00:00', NULL, NULL, 3, NULL, '2026-01-21 04:34:08', '2026-01-30 13:08:09', NULL, 1),
(98, 'Rabeya ', 'Busra', 'na@gmail.com', '01716479411', 'Pollobi', '', 'Bachelor Degree', 'Spring 2026', 3.00, 4.00, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Campus Visit', NULL, '3rd call', '2026-01-25 13:53:21', '2026-02-10', '2026-01-27 21:09:51', NULL, NULL, NULL, 27, NULL, '2026-01-21 05:16:10', '2026-01-27 15:09:51', NULL, 1),
(99, 'Md.Shariful ', 'Islam', 'shaminful98sin@gmail.com', '01744978279', 'Dhanmondi', '', 'Master Degree', 'Spring 2026', 4.78, 4.75, 'BBA', NULL, 46, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Admitted', '2026-01-21 11:58:19', NULL, '2026-01-21 11:58:19', NULL, NULL, NULL, 27, NULL, '2026-01-21 05:56:50', '2026-01-21 05:58:19', NULL, 1),
(100, 'Israt Jahan ', 'Borsa', 'isratborsha493@gmail.com', '01991879947', '', '', 'Bachelor Degree', 'Spring 2026', 5.00, 4.67, '', NULL, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Admitted', '2026-01-21 12:07:04', NULL, '2026-01-21 12:07:04', NULL, NULL, NULL, 27, NULL, '2026-01-21 06:06:02', '2026-01-21 06:07:04', NULL, 1),
(101, 'Jenarul', 'Islam', 'na@gmail.com', '01335076755', '', '', 'Bachelor Degree', 'Spring 2026', 3.39, 4.29, '', NULL, 39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-25 10:58:51', '2026-01-27', '2026-01-27 13:02:16', NULL, NULL, NULL, 27, NULL, '2026-01-21 06:13:35', '2026-01-27 07:02:16', NULL, 1),
(102, 'Mohammad Mohatabul ', 'Kabir', 'na@gmail.com', '01757323300', 'foridur', '', 'Bachelor Degree', 'Spring 2026', 3.00, 3.63, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-25 18:32:35', '2026-01-29', '2026-01-29 19:35:21', NULL, NULL, NULL, 27, NULL, '2026-01-21 06:27:56', '2026-01-29 13:35:21', NULL, 1),
(103, 'Tahomina ', 'Trisha', 'na@gmail.com', '01324932412', 'Lalgagh kamranggir chor', '', 'Bachelor Degree', 'Spring 2026', 3.58, 3.78, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Will visit office', '2026-01-25 18:47:44', '2026-01-31', '2026-01-29 22:01:27', '2026-02-04 11:00:00', NULL, NULL, 27, NULL, '2026-01-21 07:11:45', '2026-01-29 16:01:27', NULL, 1),
(104, 'Tahomina ', 'Trisha', 'na@gmail.com', '01324932412', 'Lalgagh kamranggir chor', '', 'Bachelor Degree', 'Spring 2026', 3.58, 3.78, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Will visit office', '2026-01-25 18:38:23', '2026-01-31', '2026-01-29 22:00:45', '2026-02-04 11:00:00', NULL, NULL, 27, NULL, '2026-01-21 07:11:47', '2026-01-29 16:00:45', NULL, 1),
(105, 'Saifulah ', 'Jubayer', 'na@gmial.com', '01608112763', 'Diabari ', 'Dhaka', 'Bachelor Degree', '', 4.71, 2.92, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Campus Visit', NULL, 'Admitted', '2026-01-25 18:58:11', '2026-01-27', '2026-01-27 15:39:06', NULL, NULL, NULL, 27, NULL, '2026-01-21 07:11:51', '2026-01-27 09:39:06', NULL, 1),
(106, 'Hayder Mahmood', 'Mahmood', 'na@gmial.com', '01916100807', 'Vhola', 'Bangladesh', 'Bachelor Degree', 'Spring 2026', 3.00, 4.00, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Admitted', '2026-01-23 19:22:53', NULL, '2026-01-23 19:22:53', NULL, NULL, NULL, 27, NULL, '2026-01-21 07:16:37', '2026-01-23 13:22:53', NULL, 1),
(107, 'Ismat', 'Jahan mumu', 'mumu98808@gmail.com', '01642085882', 'Mirpur-1', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 5.00, 4.92, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-25 19:07:52', '2026-01-27', '2026-01-27 15:44:15', NULL, NULL, NULL, 27, NULL, '2026-01-21 07:24:37', '2026-01-27 09:44:15', NULL, 1),
(108, 'Mina ', 'Akter', 'na@gmail.com', '01962598600', 'Majar road', '', 'Bachelor Degree', 'Spring 2026', 4.54, 3.44, 'BBA', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Agent', NULL, 'Admitted', '2026-01-26 10:09:36', NULL, '2026-01-26 11:17:50', NULL, NULL, '2026-01-26 04:07:19', 27, 27, '2026-01-21 08:11:06', '2026-01-26 05:17:50', NULL, 1),
(109, 'Mohammad Hyder', 'Mahmud', 'na@gmail.com', '01916100807', 'mirpur 1', '', 'Master Degree', 'Spring 2026', 5.00, 5.00, 'BBA', 2.50, 46, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Campus Visit', NULL, 'Admitted', '2026-01-21 14:22:40', NULL, '2026-01-21 14:22:40', NULL, NULL, NULL, 27, NULL, '2026-01-21 08:21:40', '2026-01-21 08:22:40', NULL, 1),
(110, 'MD KAMRUJJAMAN', 'MD KAMRUJJAMAN', 'talk2kamrul998@gmail.com', '01983492147', 'Panchbibi Joypurhat', 'Bhaluka mymensingh', 'Bachelor Degree', 'Spring 2026', 4.19, 2.75, '', NULL, 35, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-24 17:06:04', '2026-01-31', '2026-01-30 19:17:45', NULL, NULL, NULL, 3, NULL, '2026-01-21 09:17:52', '2026-01-30 13:17:45', NULL, 1),
(111, 'Antor', 'Ahmed', 'na@gmial.com', '01839837642', 'Tolarbag , Mirpur-01', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 4.00, 3.00, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Campus Visit', NULL, '3rd call', '2026-01-25 19:16:46', '2026-01-31', '2026-01-30 19:23:37', NULL, NULL, NULL, 27, NULL, '2026-01-21 09:29:16', '2026-01-30 13:23:37', NULL, 1),
(112, 'Md. Kutub', 'Uddin', 'na@gmial.com', '01410771229', 'Rupnagaor', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 4.61, NULL, '', NULL, 35, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Will visit office', '2026-01-25 19:03:18', '2026-02-15', '2026-01-27 15:50:35', '2026-02-15 10:46:00', NULL, NULL, 27, NULL, '2026-01-21 09:53:47', '2026-01-27 09:50:35', NULL, 1),
(113, 'Prince', 'power', 'na@gmail.com', '01851907408', 'Mirpur', '', 'Bachelor Degree', 'Spring 2026', 5.00, 3.85, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-25 13:15:47', '2026-01-31', '2026-01-30 16:17:13', NULL, NULL, NULL, 31, NULL, '2026-01-21 10:53:40', '2026-01-30 10:17:13', NULL, 1),
(114, 'Afsana', 'Jahan', 'afsanaj222222@gmail.com', '1920938811', '282/4 Bangla shorok, rayer bazaar,', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 3.50, 2.83, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-25 10:40:20', '2026-02-01', '2026-01-29 14:10:11', NULL, NULL, NULL, 3, NULL, '2026-01-21 17:43:25', '2026-01-29 08:10:11', NULL, 1),
(115, 'Shekh Hossain', 'Al Araf', 'tointowar@gmail.com', '01933361956', 'Mirpur 1 Dhaka 1216', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 4.17, 3.50, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-24 17:03:23', '2026-01-29', '2026-01-29 21:56:38', NULL, NULL, NULL, 3, NULL, '2026-01-21 19:08:33', '2026-01-29 15:56:38', NULL, 1),
(116, 'Ramjan Islam', 'Ratul', 'ratulsheikh4511807@gmail.com', '01870896089', 'Mirpur-2,Shiyalbari,Rupnagar,Dhaka', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 3.89, 3.50, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-26 11:32:40', '2026-01-28', '2026-01-28 10:18:31', NULL, NULL, NULL, 3, NULL, '2026-01-22 04:31:44', '2026-01-28 04:18:31', NULL, 1),
(117, 'Jeba', '.', 'na@gmail.com', '01518953179', 'Dhaka', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 5.00, 5.00, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-25 10:31:11', NULL, '2026-01-25 10:31:11', NULL, NULL, NULL, 29, NULL, '2026-01-22 04:48:52', '2026-01-25 04:31:11', NULL, 1),
(118, 'Tasnim Jahan', '.', 'na@gmail.com', '01954685869', 'Btennagar,Mirpur-01,Dhaka-1216', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 4.39, 4.50, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Campus Visit', NULL, 'Will visit office', '2026-01-25 17:59:24', '2026-01-31', '2026-01-30 12:58:25', '2026-01-31 11:00:00', NULL, NULL, 31, NULL, '2026-01-22 05:44:54', '2026-01-30 06:58:25', NULL, 1),
(119, 'Joita', 'j', 'na@gmail.com', '01739288945', 'Lalkuhti', '', 'Bachelor Degree', 'Spring 2026', 4.89, 4.00, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-25 17:50:22', '2026-01-29', '2026-01-29 18:00:20', NULL, NULL, NULL, 31, NULL, '2026-01-22 05:47:38', '2026-01-29 12:00:20', NULL, 1),
(120, 'Fahim', 'Faysal', 'na@gmial.com', '01641014420', 'Nowakhali', 'ctg.', 'Bachelor Degree', 'Spring 2026', 4.73, 3.33, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '2nd call', '2026-01-24 10:26:55', '2026-02-28', '2026-01-26 21:05:59', NULL, NULL, NULL, 29, NULL, '2026-01-22 05:52:41', '2026-01-26 15:05:59', NULL, 1),
(121, 'Imtaj', 'Sharif', 'na@gmail.com', '01410771229', 'Lohkipur ', 'Dhaka', 'Bachelor Degree', '', 2.89, 3.08, '', NULL, 39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-24 16:58:12', '2026-03-26', '2026-01-26 17:11:55', NULL, NULL, NULL, 29, NULL, '2026-01-22 06:09:22', '2026-01-26 11:11:55', NULL, 1),
(122, 'Nusrat', 'Jahan', 'na@gmial.com', '01940378876', 'Golartak', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 4.72, 3.92, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Agent', NULL, 'Admitted', '2026-01-22 12:26:14', NULL, NULL, NULL, NULL, NULL, 29, NULL, '2026-01-22 06:26:14', '2026-01-22 06:26:14', NULL, 1),
(123, 'aklima', 'akter', 'na@gmail.com', '01607653705', 'mirpur 1', '', 'Bachelor Degree', 'Spring 2026', 4.77, 2.83, '', NULL, 35, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-25 10:26:20', '2026-02-10', '2026-01-27 11:39:48', NULL, NULL, NULL, 30, NULL, '2026-01-22 06:45:01', '2026-01-27 05:39:48', NULL, 1),
(124, 'SIAM', 'Siam', 'siam@gmail.com', '01609081646', 'Narayanganj Sonargaon', 'Sonargaon', 'Bachelor Degree', 'Spring 2026', 4.50, 4.08, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-25 13:06:57', '2026-01-27', '2026-01-27 18:16:52', NULL, NULL, NULL, 3, NULL, '2026-01-22 07:08:50', '2026-01-27 12:16:52', NULL, 1),
(125, 'Fahim Muntasir', 'Maruf', 'fahimmostasir55@gmail.com', '01771663383', 'Majhira,shajahanpur,bogura', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 4.50, 3.00, '', NULL, 33, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-25 13:03:23', '2026-01-31', '2026-01-30 16:14:56', NULL, NULL, NULL, 3, NULL, '2026-01-22 07:11:54', '2026-01-30 10:14:56', NULL, 1),
(126, 'Meherin', 'Rahman Tanisha', 'meherinrahman4800@gmail.com', '01340782815', 'Navana garden , Kallayanpur', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 5.00, 4.25, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Admitted', '2026-01-26 11:20:47', NULL, '2026-01-26 11:20:47', NULL, NULL, NULL, 3, NULL, '2026-01-22 07:26:03', '2026-01-26 05:20:47', NULL, 1),
(127, 'Md Arif', 'Arif', 'ariful7101@gmail.com', '01788122634', 'House:2Road:2A GhatarcharMohammadpur Dhaka', 'dhaka', 'Bachelor Degree', 'January 2025', 4.39, 3.88, '', NULL, 35, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Agent', NULL, '3rd call', '2026-01-25 13:01:26', '2026-01-31', '2026-01-30 16:05:46', NULL, NULL, NULL, 3, NULL, '2026-01-22 07:26:23', '2026-01-30 10:05:46', NULL, 1),
(128, 'Mohsanara', 'Mim', 'muhsinamim90@gmail.com', '01724518054', 'College gate, Tongi', 'Gazipur.', 'Bachelor Degree', 'Spring 2026', 5.00, 4.93, '', NULL, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-25 10:19:54', '2026-02-02', '2026-01-29 14:09:45', NULL, NULL, NULL, 3, NULL, '2026-01-22 07:26:46', '2026-01-29 08:09:45', NULL, 1),
(129, 'Nafijur', 'Rahman', 'na@gmail.com', '01740733264', 'Mazar Road-1', 'dhaka', 'Bachelor Degree', 'Spring 2026', 5.00, 4.90, '', NULL, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Campus Visit', NULL, '3rd call', '2026-01-25 10:18:21', '2026-02-01', '2026-01-29 14:08:57', NULL, NULL, NULL, 29, NULL, '2026-01-22 07:34:47', '2026-01-29 08:08:57', NULL, 1),
(130, 'Md Sakline', 'Moujudad', 'na@gmail.com', '01518412906', 'Rangpur', 'dhaka', 'Master Degree', 'Spring 2026', NULL, NULL, 'BBA', 2.50, 38, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-26 11:17:04', NULL, '2026-01-26 11:17:04', NULL, NULL, NULL, 29, NULL, '2026-01-22 07:57:42', '2026-01-26 05:17:04', NULL, 1),
(131, 'Udoy sazzad', 'Utshow', 'udoysazzad77@gmail.com', '01887103562', 'Jhenidha', 'Kotchandpur', 'Bachelor Degree', 'Spring 2026', 4.67, 4.50, '', NULL, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Admitted', '2026-01-25 12:58:06', NULL, '2026-01-25 12:58:06', NULL, NULL, NULL, 3, NULL, '2026-01-22 08:04:53', '2026-01-25 06:58:06', NULL, 1),
(132, 'Abdur', 'Rahman Borno', 'na@gmail.com', '01410032515', 'jatrabari', 'dhaka', 'Bachelor Degree', 'Spring 2026', 4.00, 3.00, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Admitted', '2026-01-23 17:52:13', NULL, '2026-01-24 09:29:01', NULL, NULL, NULL, 29, NULL, '2026-01-22 08:18:02', '2026-01-24 03:29:01', NULL, 1),
(133, 'Udoy sazzad', 'Utshow', 'rifatpritom976@gmail.con', '01725776854', 'Jenedhai', 'Kotchandpur', 'Bachelor Degree', 'Spring 2026', 4.50, 4.67, '', NULL, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Admitted', '2026-01-25 12:55:45', NULL, '2026-01-25 12:55:45', NULL, NULL, NULL, 3, NULL, '2026-01-22 09:28:32', '2026-01-25 06:55:45', NULL, 1),
(134, 'MD BAYEZID', 'HASAN', 'baizidsarkar70@gmail.com', '01997984146', 'Sherpur', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 3.39, 4.50, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-25 12:46:18', NULL, '2026-01-25 12:46:18', NULL, NULL, NULL, 3, NULL, '2026-01-22 10:05:01', '2026-01-25 06:46:18', NULL, 1),
(135, 'Monir Ahmed Rafi', 'Ahmed Rafi', 'na@gmail.com', '01610595637', 'Manikgonj', 'dhaka', 'Bachelor Degree', 'Spring 2026', 3.33, 3.33, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Admitted', '2026-01-24 16:52:50', NULL, '2026-01-24 16:52:50', NULL, NULL, NULL, 29, NULL, '2026-01-22 10:11:08', '2026-01-24 10:52:50', NULL, 1),
(136, 'Anik ', 'Bura', 'na@gmail.com', '01630922278', 'Ctg', 'Ctg.', 'Bachelor Degree', 'Spring 2026', 4.56, 4.25, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-25 12:43:30', '2026-02-10', '2026-01-30 15:55:32', NULL, NULL, NULL, 29, NULL, '2026-01-22 10:17:14', '2026-01-30 09:55:32', NULL, 1),
(137, 'Tejourshi', 'Chakma', 'tejourshichakma@gmail.com', '01889759456', 'Rangamati', 'Rangamati', 'Bachelor Degree', 'Spring 2026', 4.72, 4.08, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Unable to reach once', '2026-01-25 10:48:32', '2026-02-01', '2026-01-29 12:33:45', NULL, NULL, NULL, 3, NULL, '2026-01-22 12:35:28', '2026-01-29 06:33:45', NULL, 1),
(138, 'Israt Jahan Eva', 'Eva', 'kohinorakter5555@gmail.com', '01819993952', 'Panwala para ,Hadid company more,Agrabad', 'Chittagong', 'Bachelor Degree', 'Spring 2026', 4.28, 3.92, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-25 10:47:53', NULL, '2026-01-25 10:47:53', NULL, NULL, NULL, 3, NULL, '2026-01-23 04:20:32', '2026-01-25 04:47:53', NULL, 1),
(139, 'kahairun', 'nisahikha', 'na@gmail.com', '01576818513', 'Narshindi', '', 'Bachelor Degree', 'Spring 2026', 5.00, 4.92, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-25 18:48:09', '2026-03-18', '2026-01-30 19:37:37', NULL, NULL, NULL, 29, NULL, '2026-01-23 04:28:31', '2026-01-30 13:37:37', NULL, 1),
(140, 'Aahnaf Shariar', 'Fayek', 'fayek2580@gmail.com', '01341195586', 'Dhanmondi 32', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 3.43, 2.83, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-25 12:42:28', '2026-01-30', '2026-01-30 15:53:40', NULL, NULL, NULL, 3, NULL, '2026-01-23 04:29:43', '2026-01-30 09:53:40', NULL, 1),
(141, 'Abbas ALI', 'Ali', 'abbas@gm', '01689988890', '', '', 'Bachelor Degree', 'Spring 2026', NULL, NULL, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Agent', NULL, 'Admitted', '2026-01-25 12:32:48', NULL, '2026-01-25 12:32:48', NULL, NULL, NULL, 24, NULL, '2026-01-23 04:44:23', '2026-01-25 06:32:48', NULL, 1),
(142, 'Mahfuz Khan', 'Khan', 'mahfuz@g', '01716501230', '', '', 'Master Degree', '', NULL, NULL, '', NULL, 38, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Admitted', '2026-01-23 17:07:04', NULL, '2026-01-23 17:07:04', NULL, NULL, NULL, 24, NULL, '2026-01-23 04:46:05', '2026-01-23 11:07:04', NULL, 1),
(143, 'Plabon', 'plabon', 'plabon@g', '01781372585', '', '', 'Bachelor Degree', '', 4.50, 3.19, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Campus Visit', NULL, '3rd call', '2026-01-25 12:28:18', '2026-02-10', '2026-01-30 15:50:39', NULL, NULL, NULL, 24, NULL, '2026-01-23 06:55:42', '2026-01-30 09:50:39', NULL, 1),
(144, 'Soyed', 'Sojib', 'mdsojib018595@gmail.com', '01533752808', 'Mirpur1', 'Dhaka', 'Bachelor Degree', 'January 2025', 3.72, 3.83, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-25 12:25:15', '2026-01-27', '2026-01-27 17:40:56', NULL, NULL, NULL, 3, NULL, '2026-01-23 08:45:48', '2026-01-27 11:40:56', NULL, 1),
(145, 'Khalid ', 'Khalid ', 'pialnahidhasan3@gmail.com', '01755582806', '', '', 'Bachelor Degree', 'Spring 2026', NULL, NULL, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Admitted', '2026-01-25 11:37:06', NULL, '2026-01-25 11:37:06', NULL, NULL, NULL, 24, NULL, '2026-01-23 09:17:09', '2026-01-25 05:37:06', NULL, 1),
(146, 'Sumaiya', 'Binte Ahsan', 'sumaiyabinteahsan6464@gmail.com', '01329278737', 'Munshiganj', 'Munshiganj', 'Bachelor Degree', 'Spring 2026', 3.11, 3.75, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-25 10:45:38', '2026-02-04', '2026-01-30 14:51:13', NULL, NULL, NULL, 3, NULL, '2026-01-23 09:29:15', '2026-01-30 08:51:13', NULL, 1),
(147, 'md  shaharul hossain', 'md  shaharul hossain', 'na@gmail.com', '01879298920', '', '', 'Bachelor Degree', '', NULL, NULL, '', NULL, 33, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Agent', NULL, '2nd call', '2026-01-25 10:14:02', '2026-01-31', '2026-01-30 14:08:59', NULL, NULL, NULL, 24, NULL, '2026-01-23 10:18:53', '2026-01-30 08:08:59', NULL, 1),
(148, 'tejoshi chakma', 'tejoshi chakma', 'na@gmail.com', '01906892772', '', '', 'Bachelor Degree', 'Spring 2026', 4.72, 4.00, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-25 09:43:39', '2026-01-27', '2026-01-27 17:35:45', NULL, NULL, NULL, 24, NULL, '2026-01-23 10:29:18', '2026-01-27 11:35:45', NULL, 1),
(149, 'Jinia', 'Prova', 'na@gmial.com', '01711167125', 'noga', 'Noga', 'Bachelor Degree', '', 5.00, 5.00, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Unable to reach twice', '2026-01-25 10:44:13', '2026-02-02', '2026-01-29 14:09:24', NULL, NULL, NULL, 29, NULL, '2026-01-23 10:55:48', '2026-01-29 08:09:24', NULL, 1),
(150, 'Kawser Hossain Bijoy', 'Kawser Hossain Bijoy', 'Bijoy@gm', '01810222809', '', '', 'Bachelor Degree', 'Spring 2026', 4.34, 3.00, '', NULL, 35, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-24 11:01:52', '2026-01-26', '2026-01-26 21:03:59', NULL, NULL, NULL, 24, NULL, '2026-01-24 05:01:11', '2026-01-26 15:03:59', NULL, 1),
(151, 'Rashu Islam ', 'Ranju', 'pialnahidhasan3@gmail.com', '01796019824', '', '', 'Bachelor Degree', 'Spring 2026', 3.78, 2.42, '', NULL, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-24 11:39:04', '2026-02-07', '2026-01-30 14:00:48', NULL, NULL, NULL, 24, NULL, '2026-01-24 05:15:27', '2026-01-30 08:00:48', NULL, 1),
(152, 'Ruman Islam', 'Hridoy', 'binzamantaohid@gmail.com', '01750436163', 'Pirojpur ,Barishal', 'Khalispur,Khulna', 'Master Degree', 'Spring 2026', 3.33, 3.50, 'N/A', 0.00, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-26 09:38:20', '2026-02-15', '2026-01-28 10:28:01', NULL, NULL, NULL, 3, NULL, '2026-01-24 05:15:39', '2026-01-28 04:28:01', NULL, 1),
(153, 'Md Nakib ', 'munsif', 'munsif@gm', '01738378555', '', '', 'Bachelor Degree', 'Spring 2026', 4.63, 4.30, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Admitted', '2026-01-24 11:39:10', '2026-01-26', '2026-01-26 20:57:46', NULL, NULL, NULL, 24, NULL, '2026-01-24 05:38:51', '2026-01-26 14:57:46', NULL, 1),
(154, 'Tanvir Ahmed', 'Tanvir Ahmed', 'pialnahidhasan3@gmail.com', '01577406272', '', '', 'Bachelor Degree', 'Spring 2026', 4.00, 4.00, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '2nd call', '2026-01-24 11:51:17', '2026-01-31', '2026-01-30 13:58:11', NULL, NULL, NULL, 24, NULL, '2026-01-24 05:50:45', '2026-01-30 07:58:11', NULL, 1),
(155, 'Tanvir Ahmed', 'Tanvir Ahmed', 'pialnahidhasan3@gmail.com', '01577406272', '', '', 'Bachelor Degree', 'Spring 2026', 4.00, 4.00, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '2nd call', '2026-01-24 11:51:06', '2026-01-31', '2026-01-30 13:58:00', NULL, NULL, NULL, 24, NULL, '2026-01-24 05:50:47', '2026-01-30 07:58:00', NULL, 1),
(156, 'Mina  ', 'Islam', 'pialnahidhasan3@gmail.com', '01962598600', '', '', 'Bachelor Degree', '', 4.54, 3.44, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Admitted', '2026-01-24 12:42:34', '2026-01-26', '2026-01-26 20:31:17', NULL, NULL, NULL, 24, NULL, '2026-01-24 06:42:26', '2026-01-26 14:31:17', NULL, 1),
(157, 'Fahim ', 'Foysal', 'pialnahidhasan3@gmail.com', '09638379929', '', 'Mohakhali', 'Bachelor Degree', 'Spring 2026', 3.33, 4.73, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-24 14:31:35', '2026-01-31', '2026-01-30 12:56:41', NULL, NULL, NULL, 24, NULL, '2026-01-24 07:42:36', '2026-01-30 06:56:41', NULL, 1),
(158, 'Fahim ', 'Foysal', 'pialnahidhasan3@gmail.com', '09638379929', '', 'Mohakhali', 'Bachelor Degree', 'Spring 2026', 3.33, 4.73, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '2nd call', '2026-01-24 14:31:25', '2026-01-31', '2026-01-30 12:56:28', NULL, NULL, NULL, 24, NULL, '2026-01-24 07:42:37', '2026-01-30 06:56:28', NULL, 1),
(159, 'Opu', 'Opu', 'pialnahidhasan3@gmail.com', '01328560714', 'Panchagar,', '', 'Bachelor Degree', 'Spring 2026', 3.72, 3.08, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-24 14:38:32', '2026-01-31', '2026-01-30 12:54:35', NULL, NULL, NULL, 24, NULL, '2026-01-24 08:37:21', '2026-01-30 06:54:35', NULL, 1),
(160, 'Faria Nowsin ', 'tushi', 'ushi@tgdfgds', '01303596567', '', '', 'Bachelor Degree', 'Spring 2026', 4.72, 4.50, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-24 15:13:05', '2026-02-20', '2026-01-27 17:31:59', NULL, NULL, NULL, 24, NULL, '2026-01-24 09:12:56', '2026-01-27 11:31:59', NULL, 1),
(161, 'md mehedi ', 'hasan', 'pialnahidhasan3@gmail.com', '01633138594', '', '', 'Bachelor Degree', 'Spring 2026', 3.83, 3.00, '', NULL, 35, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-24 15:25:13', '2026-01-31', '2026-01-30 12:52:34', NULL, NULL, NULL, 24, NULL, '2026-01-24 09:22:23', '2026-01-30 06:52:34', NULL, 1),
(162, 'Afsana ', 'Khanom', 'pialnahidhasan3@gmail.com', '01822630646', 'kushtia ', '', 'Bachelor Degree', 'Spring 2026', 4.17, 4.39, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '2nd call', '2026-01-24 15:28:19', '2026-02-02', '2026-01-30 12:50:37', NULL, NULL, NULL, 24, NULL, '2026-01-24 09:28:10', '2026-01-30 06:50:37', NULL, 1),
(163, 'Rubel ', 'Hossain', 'pialnahidhasan3@gmail.com', '01611075328', '', '', 'Bachelor Degree', 'Spring 2026', 4.33, 3.65, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Admitted', '2026-01-24 15:47:17', '2026-01-27', '2026-01-28 19:47:47', NULL, NULL, NULL, 24, NULL, '2026-01-24 09:40:38', '2026-01-28 13:47:47', NULL, 1),
(164, 'Rubel ', 'Hossain', 'pialnahidhasan3@gmail.com', '01611075328', '', '', 'Bachelor Degree', 'Spring 2026', 4.33, 3.65, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Admitted', '2026-01-24 16:19:53', NULL, '2026-01-25 09:23:55', NULL, NULL, NULL, 24, NULL, '2026-01-24 09:40:39', '2026-01-25 03:23:55', NULL, 1),
(165, 'Md Rabeya ', 'Akter', 'pialnahidhasan3@gmail.com', '+97157965829', '', '', 'Bachelor Degree', 'Spring 2026', 3.63, 3.33, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Will visit office', '2026-01-24 15:57:59', '2026-01-31', '2026-01-27 17:24:58', '2026-01-31 17:08:00', NULL, NULL, 24, NULL, '2026-01-24 09:57:50', '2026-01-27 11:24:58', NULL, 1),
(166, 'Jerin Ahmed', 'Ahmed', 'jerinahmed085@gmail.com', '01516097067', 'Keranigonj Dhaka', 'Keranigonj', 'Bachelor Degree', 'Spring 2026', 3.44, 3.33, '', NULL, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-25 19:20:14', '2026-01-31', '2026-01-29 21:55:00', NULL, NULL, NULL, 3, NULL, '2026-01-24 14:19:09', '2026-01-29 15:55:00', NULL, 1),
(167, 'Bimostic', 'Tripura', 'bimostic@gmail.com', '01932380278', 'Dhaka Ashulia', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 4.61, 3.83, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Admitted', '2026-01-25 19:29:31', '2026-01-29', '2026-01-29 19:53:23', NULL, NULL, '2026-01-26 07:50:06', 3, 27, '2026-01-24 18:20:33', '2026-01-29 13:53:23', NULL, 1),
(168, 'Afsarul ', 'Islam', 'pialnahidhasan3@gmail.com', '01300962227', '', '', 'Bachelor Degree', 'Spring 2026', 5.00, 5.00, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Agent', NULL, 'Admitted', '2026-01-25 11:45:33', NULL, '2026-01-25 11:49:42', NULL, NULL, NULL, 24, NULL, '2026-01-25 03:22:37', '2026-01-25 05:49:42', NULL, 1),
(169, 'Abdullah', 'Abdullah', 'pialnahidhasan3@gmail.com', '01755582806', '', 'Uttora', 'Master Degree', 'Spring 2026', NULL, NULL, 'BBA', NULL, 46, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-25 11:13:11', '2026-01-27', '2026-01-27 17:24:09', NULL, NULL, NULL, 24, NULL, '2026-01-25 05:01:22', '2026-01-27 11:24:09', NULL, 1),
(170, 'Farzana Akter', 'Farzana Akter', 'pialnahidhasan3@gmail.com', '01620588266', '', '', 'Bachelor Degree', 'Spring 2026', 3.50, 3.67, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-25 11:13:18', '2026-02-01', '2026-01-29 11:30:41', NULL, NULL, NULL, 24, NULL, '2026-01-25 05:09:31', '2026-01-29 05:30:41', NULL, 1),
(171, 'Marzia ', 'Khatun', 'pialnahidhasan3@gmail.com', '01609622303', '', '', 'Bachelor Degree', 'Spring 2026', 5.00, 4.83, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-25 12:21:30', '2026-01-31', '2026-01-30 12:38:11', NULL, NULL, NULL, 24, NULL, '2026-01-25 06:21:21', '2026-01-30 06:38:11', NULL, 1),
(172, 'Abdul Aziz', 'Abdul Aziz', 'pialnahidhasan3@gmail.com', '01895419143', '', '', 'Bachelor Degree', 'Spring 2026', 5.00, 4.58, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-25 12:40:02', '2026-02-11', '2026-01-30 12:32:59', NULL, NULL, NULL, 24, NULL, '2026-01-25 06:35:52', '2026-01-30 06:32:59', NULL, 1),
(173, 'Mushfiq Bin', 'Hossain', 'pialnahidhasan3@gmail.com', '01339157019', 'Dinajpur', '', 'Bachelor Degree', 'Spring 2026', 3.00, 3.60, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-25 15:08:13', '2026-02-02', '2026-01-30 12:13:17', NULL, NULL, NULL, 24, NULL, '2026-01-25 09:07:42', '2026-01-30 06:13:17', NULL, 1),
(174, 'Atifa', 'Reya', 'atifaanzum025@gmail.com', '01766925113', 'BAF Base AKR', 'Dhaka, Bangladesh', 'Bachelor Degree', 'Spring 2026', 4.67, 4.67, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-25 19:35:31', '2026-01-30', '2026-01-30 19:29:16', NULL, NULL, NULL, 3, NULL, '2026-01-25 09:43:52', '2026-01-30 13:29:16', NULL, 1),
(175, 'Mahmudul ', 'Hossain', 'pialnahidhasan3@gmail.com', '01991648064', '', '', 'Bachelor Degree', 'Spring 2026', 5.00, 4.00, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-25 15:48:52', '2026-01-31', '2026-01-30 12:11:33', NULL, NULL, NULL, 24, NULL, '2026-01-25 09:48:44', '2026-01-30 06:11:33', NULL, 1),
(176, 'Maria ', 'Afroz', 'pialnahidhasan3@gmail.com', '01643577713', '', '', 'Bachelor Degree', '', 4.67, 3.80, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-25 16:03:04', '2026-02-01', '2026-01-30 11:42:21', NULL, NULL, NULL, 24, NULL, '2026-01-25 10:02:55', '2026-01-30 05:42:21', NULL, 1),
(177, 'Joysree Devi  majumder', 'Priya', 'joysree0099@gmail.com', '01766492027', 'Chandpur mission  road bagan bari', 'Chandpur  sador chandpur', 'Bachelor Degree', 'Spring 2026', 4.33, 3.33, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Admitted', '2026-01-26 11:03:49', '2026-01-30', '2026-01-30 14:18:11', NULL, NULL, NULL, 3, NULL, '2026-01-25 10:36:03', '2026-01-30 08:18:11', NULL, 1),
(178, 'Md Rifat ', 'Mahmud', 'pialnahidhasan3@gmail.com', '01315130467', '', '', 'Bachelor Degree', 'Spring 2026', 4.04, 3.34, '', NULL, 35, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Unable to reach once', '2026-01-25 16:45:30', '2026-01-31', '2026-01-30 11:36:20', NULL, NULL, NULL, 24, NULL, '2026-01-25 10:44:19', '2026-01-30 05:36:20', NULL, 1),
(179, 'Momin', 'Momin', 'mr.pialgaming@gamil.com', '01712815367', '', 'Dhaka', 'Master Degree', 'Spring 2026', 5.00, 5.00, '2nd class', NULL, 46, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Unable to reach twice', '2026-01-25 16:53:57', '2026-01-31', '2026-01-30 11:34:47', NULL, NULL, NULL, 24, NULL, '2026-01-25 10:53:39', '2026-01-30 05:34:47', NULL, 1),
(180, 'Pranto', 'Sharma', 'prantosharma60@gmail.com', '01756845419', 'Kalukhali,Rajbari', 'Rajbari', 'Bachelor Degree', 'Spring 2026', 3.83, 3.92, '', NULL, 39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '2nd call', '2026-01-26 11:10:47', '2026-02-15', '2026-01-28 10:14:36', NULL, NULL, NULL, 3, NULL, '2026-01-25 11:48:25', '2026-01-28 04:14:36', NULL, 1);
INSERT INTO `leads` (`id`, `first_name`, `last_name`, `email`, `phone`, `address`, `current_city`, `applying_for`, `semester`, `ssc_gpa`, `hsc_gpa`, `bachelor_subject`, `bachelor_cgpa`, `interested_course_id`, `most_recent_degree`, `gpa`, `ielts_overall`, `ielts_reading`, `ielts_writing`, `ielts_speaking`, `ielts_listening`, `country_applying_from`, `nationality`, `budget`, `lead_source`, `assigned_campus`, `lead_status`, `last_status_change_date`, `next_followup_date`, `last_followup_action_date`, `campus_visit_date`, `campus_visit_attended_at`, `attended_at`, `created_by`, `updated_by`, `created_at`, `updated_at`, `agent_id`, `company_id`) VALUES
(181, 'Md', 'Tarikul', 'tarikul.islam141108@gmail.com', '01709177767', 'Narayanganj', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 3.61, 3.92, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '2nd call', '2026-01-26 11:06:55', '2026-01-30', '2026-01-28 10:35:33', NULL, NULL, NULL, 3, NULL, '2026-01-25 13:48:27', '2026-01-28 04:35:33', NULL, 1),
(182, 'Ramjan Islam ', 'Ratul', 'na@gmail.com', '01870896089', 'Mirpur 1', '', 'Bachelor Degree', 'Spring 2026', 3.89, 3.50, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Admitted', '2026-01-26 10:59:24', '2026-01-28', '2026-01-28 10:07:11', NULL, NULL, '2026-01-26 05:05:40', 27, 27, '2026-01-26 04:41:48', '2026-01-28 04:07:11', NULL, 1),
(183, 'dsfdsf', 'sdfsdf', 'sdfsdf@gmail.com', '1212121', 'sdfsdf', 'sdfsdf', 'Bachelor Degree', 'Spring 2026', 4.00, 5.00, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'F2F Marketing', NULL, 'Dead', NULL, '2026-01-29', '2026-01-26 16:29:07', NULL, NULL, NULL, 3, NULL, '2026-01-26 06:32:45', '2026-01-26 10:29:07', NULL, 1),
(184, 'Md Nakib ', 'munsif', 'na@gmail.com', '01738378555', 'kollanpur', '', 'Bachelor Degree', 'Spring 2026', 4.61, 4.30, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Admitted', '2026-01-26 12:55:30', '2026-01-26', '2026-01-26 14:28:06', NULL, NULL, '2026-01-26 07:04:39', 27, 27, '2026-01-26 06:55:30', '2026-01-26 08:28:06', NULL, 1),
(185, 'Md', 'Sajib', 'na@gmail.com', '01814572158', 'Dhahaka', 'dhaka', 'Bachelor Degree', 'Spring 2026', 4.09, 3.60, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Admitted', NULL, '2026-01-30', '2026-01-30 19:27:14', NULL, NULL, NULL, 27, NULL, '2026-01-26 08:55:48', '2026-01-30 13:27:14', NULL, 1),
(186, 'Md Mostakin Hossain', 'Sakin', 'na@gmail.com', '01624810778', '', '', 'Bachelor Degree', 'Spring 2026', 3.67, 3.17, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Admitted', '2026-01-26 15:28:27', '2026-01-26', '2026-01-26 16:47:21', NULL, NULL, '2026-01-26 09:54:53', 27, 27, '2026-01-26 09:28:27', '2026-01-26 10:47:21', NULL, 1),
(187, ' Fahmida ', 'Rahman', 'na@gmail.com', '01770123769', 'Puran Dhaka', '', 'Bachelor Degree', 'Spring 2026', 4.56, 4.17, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Campus Visit', NULL, '2nd call', NULL, '2026-02-26', '2026-01-30 19:09:51', NULL, NULL, NULL, 27, NULL, '2026-01-26 10:14:17', '2026-01-30 13:09:51', NULL, 1),
(188, 'Kabita', 'Akter', 'na@gmail.com', '01722442526', '', '', 'Bachelor Degree', 'Spring 2026', 3.00, 3.42, '', NULL, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Admitted', '2026-01-26 16:36:10', '2026-01-26', '2026-01-26 16:40:38', NULL, NULL, NULL, 27, NULL, '2026-01-26 10:36:10', '2026-01-26 10:40:38', NULL, 1),
(189, 'Kabita', 'Akter', 'na@gmail.com', '01722442526', '', '', 'Bachelor Degree', 'Spring 2026', 3.00, 3.42, '', NULL, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Admitted', '2026-01-26 16:36:11', '2026-01-26', '2026-01-26 16:38:16', NULL, NULL, NULL, 27, NULL, '2026-01-26 10:36:11', '2026-01-26 10:38:16', NULL, 1),
(190, 'Angelina Methela ', 'Halder', 'na@gmail.com', '01707749889', 'mirpur 2 ', '', 'Bachelor Degree', '', 3.67, 3.08, '', NULL, 47, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Campus Visit', NULL, 'Admitted', '2026-01-26 16:58:14', '2026-01-27', '2026-01-28 09:44:29', NULL, NULL, NULL, 27, NULL, '2026-01-26 10:58:14', '2026-01-28 03:44:29', NULL, 1),
(191, 'Supriyo Roy', 'Bishal', 'bishalroy4029352@gmail.com', '01608861574', 'Gopalpur, Tangail', 'Ghatail,Tangail', 'Bachelor Degree', 'Spring 2026', 4.78, 4.92, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '2nd call', '2026-01-27 10:29:29', '2026-02-01', '2026-01-29 12:13:35', NULL, NULL, NULL, 3, NULL, '2026-01-26 12:25:36', '2026-01-29 06:13:35', NULL, 1),
(192, 'Maymuna Amin', 'Suptee', 'mr.pialgaming@gamil.com', '01841018407', '', 'eastern housing', 'Bachelor Degree', 'Spring 2026', 4.83, 4.00, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-30 11:33:17', NULL, '2026-01-30 11:33:17', NULL, NULL, NULL, 24, NULL, '2026-01-26 14:13:14', '2026-01-30 05:33:17', NULL, 1),
(193, 'Mahiatul ', 'suraiya', 'mr.pialgaming@gamil.com', '01851567514', 'MIRPUR\r\n', 'ctg', 'Bachelor Degree', 'Spring 2026', 4.50, 5.00, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Unable to reach once', NULL, '2026-01-31', '2026-01-30 11:31:23', NULL, NULL, NULL, 24, NULL, '2026-01-26 14:22:36', '2026-01-30 05:31:23', NULL, 1),
(194, 'Abil ', 'Sadman', 'na@gmail.com', '01300413390', 'PIROJPUR ', '', 'Bachelor Degree', 'Spring 2026', 5.00, 4.92, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', NULL, '2026-03-25', '2026-01-30 19:03:13', NULL, NULL, NULL, 27, NULL, '2026-01-27 05:05:14', '2026-01-30 13:03:13', NULL, 1),
(195, 'Sumayea Shameem', 'Chaity', 'shameemsumaiya515@gmail.com', '01758-807603', '136 pashchim kafrul, Agargaon', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 4.39, 4.33, '', NULL, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-27 12:35:22', '2026-02-01', '2026-01-29 12:11:41', NULL, NULL, NULL, 3, NULL, '2026-01-27 05:41:51', '2026-01-29 06:11:41', NULL, 1),
(196, 'mohammad sakline ', 'Moujudad', 'na@gmail.com', '01922456545', 'Rangpur', '', 'Master Degree', '', 4.88, 4.80, '3.03', 2.50, 38, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '2nd call', NULL, '2026-01-31', '2026-01-30 18:58:03', NULL, NULL, NULL, 27, NULL, '2026-01-27 06:09:24', '2026-01-30 12:58:03', NULL, 1),
(197, 'mohammad sakline ', 'Moujudad', 'na@gmail.com', '01922456545', 'Rangpur', '', 'Master Degree', '', 4.88, 4.80, '3.03', 2.50, 38, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', NULL, '2026-01-31', '2026-01-30 18:22:53', NULL, NULL, NULL, 27, NULL, '2026-01-27 06:09:24', '2026-01-30 12:22:53', NULL, 1),
(198, 'Harunur', 'Rashid', 'na@gmail.com', '01905208038', 'Kolanpur', 'Dhaka', 'Master Degree', 'Spring 2026', NULL, NULL, 'LLB', 3.00, 37, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '1st call', NULL, '2026-01-30', '2026-01-29 16:21:55', NULL, NULL, NULL, 29, NULL, '2026-01-27 06:22:12', '2026-01-29 10:21:55', NULL, 1),
(199, 'Md ', 'Minhaz', 'na@gmail.com', '01580819932', 'RAMPURA', '', 'Bachelor Degree', 'Spring 2026', 4.33, 4.33, '', NULL, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', NULL, '2026-02-03', '2026-01-30 19:00:20', NULL, NULL, NULL, 27, NULL, '2026-01-27 06:23:28', '2026-01-30 13:00:20', NULL, 1),
(200, 'Tanzila', 'Khan', 'na@gmail.com', '01673058522', 'Narangonj', '', 'Bachelor Degree', 'Spring 2026', 5.00, 5.00, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Admitted', NULL, '2026-01-28', '2026-01-28 10:45:55', NULL, NULL, NULL, 27, NULL, '2026-01-27 06:42:44', '2026-01-28 04:45:55', NULL, 1),
(201, 'Tahsin ul ', 'Haque', 'na@gmail.com', '01842708676', 'mirpur 1', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 5.00, 5.00, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Campus Visit', NULL, 'Admitted', NULL, '2026-01-29', '2026-01-29 10:15:17', NULL, NULL, NULL, 27, NULL, '2026-01-27 11:28:16', '2026-01-29 04:15:17', NULL, 1),
(202, 'Evan', 'Chowdury', 'mim423mim@gmail.com', '01907568506', 'Mirpur02', 'Mirpur', 'Bachelor Degree', 'Spring 2026', 4.22, 3.05, '', NULL, 39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Fresh', NULL, NULL, '2026-01-28 11:18:27', NULL, NULL, NULL, 3, NULL, '2026-01-27 11:31:44', '2026-01-28 05:18:27', NULL, 1),
(203, 'Sameul', 'islam', 'sameultalukder10@gamil.com', '1726409431', 'bogura', 'bogura', 'Bachelor Degree', 'Spring 2026', 5.00, 5.00, '', NULL, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '1st call', '2026-01-28 11:34:26', '2026-01-30', '2026-01-28 11:34:26', NULL, NULL, NULL, 3, NULL, '2026-01-28 03:58:51', '2026-01-28 05:34:26', NULL, 1),
(204, 'Nahin', '.', 'na@gmail.com', '01977063229', '', '', 'Bachelor Degree', 'Spring 2026', 4.78, 3.39, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Will visit office', NULL, '2026-01-31', '2026-01-30 18:56:30', '2026-01-31 11:00:00', NULL, NULL, 27, NULL, '2026-01-28 04:06:38', '2026-01-30 12:56:30', NULL, 1),
(205, 'Nahin', '.', 'na@gmail.com', '01977063229', '', '', 'Bachelor Degree', 'Spring 2026', 4.78, 3.39, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Will visit office', NULL, '2026-01-31', '2026-01-30 18:55:49', '2026-01-31 11:00:00', NULL, NULL, 27, NULL, '2026-01-28 04:06:39', '2026-01-30 12:55:49', NULL, 1),
(206, 'Mst', 'Shashi', 'mstshoshishoshi@gmail.com', '01782482368', 'Uttara', 'Dhaka-1230', 'Bachelor Degree', 'January 2025', 4.28, 5.00, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '1st call', NULL, '2026-02-14', '2026-01-28 16:16:35', NULL, NULL, NULL, 3, NULL, '2026-01-28 05:00:49', '2026-01-28 10:16:35', NULL, 1),
(207, 'Abib fayaz ', 'Nunam', 'na@gmail.com', '01950492364', 'Mirpur 12', '', 'Bachelor Degree', 'Spring 2026', 5.00, 4.92, '', NULL, 47, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Campus Visit', NULL, 'Will visit office', NULL, '2026-01-31', '2026-01-30 18:51:09', '2026-01-31 11:00:00', NULL, NULL, 27, NULL, '2026-01-28 05:07:01', '2026-01-30 12:51:09', NULL, 1),
(208, 'Afifa ', 'Akter', 'na@gmail.com', '018860080566', 'Brobazar . Mirpur', 'Dhaka', 'Master Degree', 'Spring 2026', NULL, NULL, 'LLB', 3.08, 38, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Campus Visit', NULL, 'Will visit office', NULL, '2026-02-05', NULL, NULL, NULL, NULL, 29, NULL, '2026-01-28 05:14:43', '2026-01-28 05:14:43', NULL, 1),
(209, 'Muntasin ', 'Islam', 'na@gmail.com', '01853888743', 'kolllanpur', 'Chittagong', 'Bachelor Degree', 'Spring 2026', 4.00, 4.00, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '2nd call', NULL, '2026-02-02', '2026-01-30 18:39:10', NULL, NULL, NULL, 27, NULL, '2026-01-28 05:20:32', '2026-01-30 12:39:10', NULL, 1),
(210, 'Mashrukh Al ', 'Hasan', 'na@gmail.com', '01307579839', '', 'Jessore', 'Bachelor Degree', 'Spring 2026', 4.00, 3.00, '', NULL, 35, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', NULL, '2026-01-31', '2026-01-30 18:33:34', NULL, NULL, NULL, 27, NULL, '2026-01-28 05:35:42', '2026-01-30 12:33:34', NULL, 1),
(211, 'Sakib', '.', 'na@gmail.com', '01400101162', 'Barguna', '', 'Bachelor Degree', 'Spring 2026', 4.11, 2.92, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '1st call', NULL, '2026-01-31', '2026-01-29 12:10:53', NULL, NULL, NULL, 29, NULL, '2026-01-28 05:45:55', '2026-01-29 06:10:53', NULL, 1),
(212, 'Anandda ', 'Das', 'na@gmail.com', '01748277006', 'batennagar', '', 'Master Degree', 'Spring 2026', 3.99, 3.17, 'somaj biggan', 2.84, 46, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Campus Visit', NULL, 'Admitted', '2026-01-28 11:51:51', '2026-01-28', '2026-01-29 21:43:58', NULL, NULL, NULL, 27, NULL, '2026-01-28 05:51:51', '2026-01-29 15:43:58', NULL, 1),
(213, 'Anandda ', 'Das', 'na@gmail.com', '01748277006', 'batennagar', '', 'Master Degree', 'Spring 2026', 3.99, 3.17, 'somaj biggan', 2.84, 46, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Campus Visit', NULL, 'Admitted', '2026-01-28 11:51:52', '2026-01-28', '2026-01-29 21:37:18', NULL, NULL, NULL, 27, NULL, '2026-01-28 05:51:52', '2026-01-29 15:37:18', NULL, 1),
(214, 'Mst Abeda ', 'Khanom', 'na@gmail.com', '01973063601', 'mirpur 1', '', 'Bachelor Degree', 'Spring 2026', 5.00, 5.00, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Admitted', '2026-01-28 12:11:06', '2026-01-28', '2026-01-28 12:11:33', NULL, NULL, NULL, 27, NULL, '2026-01-28 06:11:06', '2026-01-28 06:11:33', NULL, 1),
(215, 'Abdullah Al', 'Rafi', 'na@gmail.com', '01919149163', 'Mirpur 1', 'Dhaka', 'Master Degree', 'Spring 2026', 2.83, 2.83, 'LLB', 3.07, 37, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Campus Visit', NULL, 'Admitted', '2026-01-28 12:51:20', NULL, NULL, NULL, NULL, NULL, 27, NULL, '2026-01-28 06:51:20', '2026-01-28 06:51:20', NULL, 1),
(216, 'Limon ', 'Sheikh', 'na@gmailm.com', '01990536824', 'Mirpur 1', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 5.00, 5.00, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Campus Visit', NULL, 'Admitted', NULL, '2026-01-29', '2026-01-29 12:00:54', NULL, NULL, NULL, 30, NULL, '2026-01-28 06:53:57', '2026-01-29 06:00:54', NULL, 1),
(217, 'Labonno ', 'Chowdhury', 'na@gmail.com', '01966765070', 'Mirpur 10', 'Dhaka', 'Bachelor Degree', 'January 2025', 4.33, 4.00, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Agent', NULL, 'Admitted', '2026-01-28 13:06:24', NULL, '2026-01-30 20:29:26', NULL, NULL, NULL, 27, NULL, '2026-01-28 07:06:24', '2026-01-30 14:29:26', NULL, 1),
(218, 'Mst', 'Ratna Akter', 'na@gmail.com', '01842490725', 'Mazar Road-01', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 4.94, 4.83, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Campus Visit', NULL, '2nd call', NULL, '2026-01-29', '2026-01-30 14:06:19', NULL, NULL, NULL, 29, NULL, '2026-01-28 07:14:26', '2026-01-30 08:06:19', NULL, 1),
(219, 'Fahim', 'Ahmed', 'na@gmail.com', '01944893637', '', '', 'Bachelor Degree', '', 3.57, 3.61, '', NULL, 39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '2nd call', NULL, '2026-02-10', '2026-01-30 12:56:31', NULL, NULL, NULL, 27, NULL, '2026-01-28 07:30:29', '2026-01-30 06:56:31', NULL, 1),
(220, 'Shimuly', 'Akhter', 'shimulsuchi166@gmail.com', '01745997225', 'Dhaka , mirpur 12 , pallabi thana', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 3.39, 3.50, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '1st call', '2026-01-28 17:19:45', '2026-01-30', '2026-01-28 17:19:45', NULL, NULL, NULL, 3, NULL, '2026-01-28 07:33:21', '2026-01-28 11:19:45', NULL, 1),
(221, 'Sakib', 'Ahmed', 'sa9286169@gmail.com', '01700978462', 'Savar', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 4.72, 5.00, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '1st call', '2026-01-28 16:19:59', '2026-01-30', '2026-01-28 16:19:59', NULL, NULL, NULL, 3, NULL, '2026-01-28 07:40:21', '2026-01-28 10:19:59', NULL, 1),
(222, 'Jannatul ', 'Ferdosh ', 'na@gmail.vom', '01828411645', 'Mirpur 10', 'Dhaka', 'Bachelor Degree', '', 4.06, NULL, '', NULL, 35, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Will visit office', NULL, '2026-05-20', '2026-01-28 14:12:16', '2026-01-28 14:12:00', NULL, NULL, 30, NULL, '2026-01-28 07:40:33', '2026-01-28 08:12:16', NULL, 1),
(223, 'Moriom Akter Mim', 'Mim', 'moriomaktermim3334@gmail.com', '01706066325', 'Jessore', 'Jessore', 'Bachelor Degree', 'Spring 2026', 3.56, 4.32, '', NULL, 33, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '1st call', '2026-01-28 16:10:02', '2026-01-30', '2026-01-28 16:18:44', NULL, NULL, NULL, 3, NULL, '2026-01-28 07:44:17', '2026-01-28 10:18:44', NULL, 1),
(224, 'Abdirahman Ali', 'Ahmed', 'Socdaal358@gmail.com', '+252613182020', 'Hodan', 'Muqdisho', 'Master Degree', 'Spring 2026', 3.00, 3.00, 'Public Adminstration', 4.00, 37, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-28 16:06:54', NULL, '2026-01-28 16:06:54', NULL, NULL, NULL, 3, NULL, '2026-01-28 07:48:26', '2026-01-28 10:06:54', NULL, 1),
(225, 'Sakibul ', 'Islam', 'na@gmail.com', '01721604016', 'Mirpur 1', 'Dhaka', 'Bachelor Degree', '', 5.00, 4.67, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Campus Visit', NULL, 'Admitted', NULL, '2026-01-29', '2026-01-29 11:59:04', NULL, NULL, NULL, 30, NULL, '2026-01-28 08:05:09', '2026-01-29 05:59:04', NULL, 1),
(226, 'Humaira', 'Hasan', 'na@gmail.com', '01884598871', '', '', 'Bachelor Degree', 'Spring 2026', 3.22, 2.58, '', NULL, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '2nd call', NULL, '2026-01-31', '2026-01-30 12:52:01', NULL, NULL, NULL, 27, NULL, '2026-01-28 09:02:17', '2026-01-30 06:52:01', NULL, 1),
(227, 'Humaira', 'Hasan', 'na@gmail.com', '01884598871', '', '', 'Bachelor Degree', 'Spring 2026', 3.22, 2.58, '', NULL, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '2nd call', NULL, '2026-01-31', '2026-01-30 12:50:52', NULL, NULL, NULL, 27, NULL, '2026-01-28 09:02:19', '2026-01-30 06:50:52', NULL, 1),
(228, 'Humaira', 'Hasan', 'na@gmail.com', '01884598871', '', '', 'Bachelor Degree', 'Spring 2026', 3.22, 2.58, '', NULL, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '2nd call', NULL, '2026-01-31', '2026-01-30 12:49:15', NULL, NULL, NULL, 27, NULL, '2026-01-28 09:02:25', '2026-01-30 06:49:15', NULL, 1),
(229, 'Anika', 'Anzuman', 'anika33889750@gmail.com', '01335607698', 'Ambabur basa, Sreepur, Rajbari Sadar, Rajbari', 'Rajbari', 'Bachelor Degree', 'Spring 2026', 5.00, 4.83, '', NULL, 39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '1st call', '2026-01-28 15:59:31', '2026-01-30', '2026-01-28 15:59:31', NULL, NULL, NULL, 3, NULL, '2026-01-28 09:08:49', '2026-01-28 09:59:31', NULL, 1),
(230, 'Mst  Mollika', 'Akter', 'na@gmail.com', '01764917475', '', '', 'Bachelor Degree', 'Spring 2026', 3.00, 3.50, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-28 15:18:07', '2026-02-03', '2026-01-30 17:55:43', NULL, NULL, NULL, 27, NULL, '2026-01-28 09:18:07', '2026-01-30 11:55:43', NULL, 1),
(231, 'Mst  Mollika', 'Akter', 'na@gmail.com', '01764917475', 'Rangpur', '', 'Bachelor Degree', 'Spring 2026', 3.00, 3.50, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-28 15:18:17', '2026-02-03', '2026-01-30 17:54:59', NULL, NULL, NULL, 27, NULL, '2026-01-28 09:18:17', '2026-01-30 11:54:59', NULL, 1),
(232, 'Rana', 'Molla', 'ranahossainmd06@gmail.com', '01305737003', 'Mohammadpur,Magura,Khulna', 'Magura', 'Bachelor Degree', 'Spring 2026', 3.50, 3.17, NULL, NULL, 33, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Fresh', NULL, NULL, NULL, NULL, NULL, NULL, 3, NULL, '2026-01-28 10:28:10', '2026-01-28 10:28:10', NULL, 1),
(233, 'Md.mehedi ', 'hossan', 'no@gmail.com', '01929947758', 'mirpur 1', 'dhaka', 'Bachelor Degree', 'Spring 2026', 4.72, 4.00, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Campus Visit', NULL, '2nd call', NULL, '2026-01-30', '2026-01-30 12:44:00', NULL, NULL, NULL, 27, NULL, '2026-01-28 11:18:47', '2026-01-30 06:44:00', NULL, 1),
(234, 'Md.mehedi ', 'hossan', 'no@gmail.com', '01929947758', 'mirpur 1', 'dhaka', 'Bachelor Degree', 'Spring 2026', 4.72, 4.00, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Campus Visit', NULL, '2nd call', NULL, '2026-01-30', '2026-01-30 12:45:35', NULL, NULL, NULL, 27, NULL, '2026-01-28 11:18:48', '2026-01-30 06:45:35', NULL, 1),
(235, 'Sumaya Akter ', 'Srabony', 'na@gmail.com', '019977259985', 'Savar', '', 'Bachelor Degree', 'Spring 2026', 5.00, 4.50, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-28 17:23:51', '2026-02-03', '2026-01-30 17:45:25', NULL, NULL, NULL, 27, NULL, '2026-01-28 11:23:51', '2026-01-30 11:45:25', NULL, 1),
(236, 'Troyee ', 'Debath ', 'na@gmail.com', '01575560737', '', '', 'Bachelor Degree', 'Spring 2026', 4.39, 3.50, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '2nd call', NULL, '2026-02-04', '2026-01-30 12:40:54', NULL, NULL, NULL, 27, NULL, '2026-01-28 11:26:47', '2026-01-30 06:40:54', NULL, 1),
(237, 'Mariyam', '.', 'na@gmail.com', '01794613334', 'Savar', '', 'Bachelor Degree', 'Spring 2026', 4.78, 4.92, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', '2026-01-28 17:37:11', '2026-02-03', '2026-01-30 17:24:03', NULL, NULL, NULL, 27, NULL, '2026-01-28 11:37:11', '2026-01-30 11:24:03', NULL, 1),
(238, 'Tasfia Tasnim', 'Sinha', 'sinhaa4560@gmail.com', '01340475245', 'Jashore sador,jashore', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 5.00, 5.00, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '1st call', NULL, '2026-02-03', '2026-01-29 14:52:41', NULL, NULL, NULL, 3, NULL, '2026-01-28 11:38:07', '2026-01-29 08:52:41', NULL, 1),
(239, 'Mehejabeen Jahan', 'Mithila', 'mithilakter2001@gmail.com', '01342278699', 'Shahjadpur Badda, Dhaka', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 4.78, 4.42, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '1st call', '2026-01-29 14:08:06', '2026-01-31', '2026-01-29 14:08:15', NULL, NULL, NULL, 3, NULL, '2026-01-28 12:56:55', '2026-01-29 08:08:15', NULL, 1),
(240, 'Md', 'Minhaz', 'theminhaz244@gmail.com', '01323644830', 'Bhola, Barisal', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 4.33, 4.33, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Unable to reach once', '2026-01-29 15:38:39', '2026-01-30', '2026-01-29 15:38:39', NULL, NULL, NULL, 3, NULL, '2026-01-28 13:01:19', '2026-01-29 09:38:39', NULL, 1),
(241, 'Likhon', 'Molla', 'samiullahlikhon@gmail.com', '01338338665', 'Mirpur, 1216', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 4.78, 4.67, '', NULL, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '1st call', NULL, '2026-02-01', '2026-01-29 13:02:17', NULL, NULL, NULL, 3, NULL, '2026-01-28 13:10:09', '2026-01-29 07:02:17', NULL, 1),
(242, 'Bimostic tripura', 'Bimostic tripura', 'mr.pialgaming@gamil.com', '01331641035', 'MIRPUR\r\nhouse-17', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 4.61, 3.83, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Admitted', NULL, '2026-01-30', '2026-01-30 13:55:41', NULL, NULL, NULL, 24, NULL, '2026-01-28 13:57:28', '2026-01-30 07:55:41', NULL, 1),
(243, 'Nur Jahan', 'Ara Dipti', 'soul08891@gmail.com', '01712887161', '113/1 b.c.c road Wari', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 5.00, 4.08, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '1st call', NULL, '2026-03-10', '2026-01-30 19:49:07', NULL, NULL, NULL, 3, NULL, '2026-01-28 14:15:42', '2026-01-30 13:49:07', NULL, 1),
(244, 'Takrim', 'Ahsan', 'na@gmail.com', '01706079518', 'MIRPUR 10', '', 'Bachelor Degree', 'Spring 2026', 5.00, 5.00, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '2nd call', '2026-01-29 10:47:50', '2026-01-31', '2026-01-30 11:29:24', NULL, NULL, NULL, 24, NULL, '2026-01-29 04:47:50', '2026-01-30 05:29:24', NULL, 1),
(245, 'Limon', 'Shiekh', 'na@gmail.com', '01990536824', '', 'Sirajganj', 'Bachelor Degree', 'Spring 2026', NULL, NULL, '', NULL, 35, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Admitted', '2026-01-29 11:27:00', '2026-01-29', '2026-01-29 11:27:13', NULL, NULL, NULL, 24, NULL, '2026-01-29 05:27:00', '2026-01-29 05:27:13', NULL, 1),
(246, 'Midadur Rahman', 'Khan', 'na@gmail.com', '01914752320', '', '', 'Bachelor Degree', 'Spring 2026', 4.00, 4.00, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '1st call', NULL, '2026-01-31', '2026-01-29 12:07:09', NULL, NULL, NULL, 24, NULL, '2026-01-29 05:56:51', '2026-01-29 06:07:09', NULL, 1),
(247, 'Ayesha ', 'akter', 'na@gmail.com', '01323260892', '', '', 'Bachelor Degree', 'Spring 2026', 3.00, 3.00, '', NULL, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '2nd call', NULL, '2026-01-31', '2026-01-30 11:39:42', NULL, NULL, NULL, 24, NULL, '2026-01-29 06:06:46', '2026-01-30 05:39:42', NULL, 1),
(248, 'Shamim Reza', 'Shamim Reza', 'na@gmail.com', '01307040265', '', '', 'Master Degree', '', NULL, NULL, '', NULL, 46, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '1st call', NULL, '2026-02-10', '2026-01-29 13:53:30', NULL, NULL, NULL, 24, NULL, '2026-01-29 06:40:19', '2026-01-29 07:53:30', NULL, 1),
(249, 'Salman azad', 'Arafat', 'na@gmail.com', '01969319168', 'Ctg', 'Ctg', 'Bachelor Degree', 'Spring 2026', 5.00, 5.00, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '1st call', NULL, '2026-01-30', '2026-01-29 12:46:02', NULL, NULL, NULL, 30, NULL, '2026-01-29 06:42:08', '2026-01-29 06:46:02', NULL, 1),
(250, 'Rayhan Al tasin', 'Rayhan Al tasin', 'na@gmail.com', '01316441717', '', '', 'Bachelor Degree', 'Spring 2026', 4.00, 3.22, '', NULL, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '2nd call', NULL, '2026-01-31', '2026-01-30 11:19:26', NULL, NULL, NULL, 24, NULL, '2026-01-29 06:44:23', '2026-01-30 05:19:26', NULL, 1),
(251, 'Rayhan Al tasin', 'Rayhan Al tasin', 'na@gmail.com', '01316441717', '', '', 'Bachelor Degree', 'Spring 2026', 3.72, 3.50, '', NULL, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '2nd call', NULL, '2026-01-31', '2026-01-30 11:18:51', NULL, NULL, NULL, 24, NULL, '2026-01-29 06:44:23', '2026-01-30 05:18:51', NULL, 1),
(252, 'Nusrat Jahan ', 'Mitu', 'na@gmail.com', '01824314554', 'Mirpur-1', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 3.83, 4.08, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Campus Visit', NULL, '1st call', '2026-01-29 12:45:14', '2026-01-31', NULL, NULL, NULL, NULL, 37, NULL, '2026-01-29 06:45:14', '2026-01-29 06:45:14', NULL, 1),
(253, 'Irin', 'Akter', 'na@gmail.com', '01751056703', 'Mirpur-6', 'Dhaka', 'Bachelor Degree', '', 2.78, 2.33, '', NULL, 47, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Campus Visit', NULL, 'Will visit office', '2026-01-29 13:47:22', '2026-01-31', '2026-01-30 14:05:42', '2026-01-31 13:44:00', NULL, NULL, 24, NULL, '2026-01-29 07:47:22', '2026-01-30 08:05:42', NULL, 1),
(254, 'Md Harunur ', 'Rahid', 'na@gmail.com', '01727352137', '', '', 'Master Degree', 'Spring 2026', 3.89, 3.83, 'LLB', 3.00, 37, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Campus Visit', NULL, 'Admitted', '2026-01-29 14:24:55', NULL, NULL, NULL, NULL, NULL, 24, NULL, '2026-01-29 08:24:55', '2026-01-29 08:24:55', NULL, 1),
(255, 'Maisha ', 'Akter', 'na@gmail.com', '01920213843', '', '', 'Bachelor Degree', 'Spring 2026', 5.00, 5.00, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '3rd call', NULL, '2026-02-02', '2026-01-30 14:10:27', NULL, NULL, NULL, 24, NULL, '2026-01-29 09:49:43', '2026-01-30 08:10:27', NULL, 1),
(256, 'Md.Tanim ', 'Chowdhori', 'na@gmail.com', '015403482', 'Mirpur 1', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 4.39, 4.00, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Campus Visit', NULL, '1st call', NULL, '2026-01-30', NULL, NULL, NULL, NULL, 30, NULL, '2026-01-29 10:23:33', '2026-01-29 10:23:33', NULL, 1),
(257, 'Smriti', 'Moni', 'monysmrity24@gmail.com', '01833931554', 'Board:Mymensingh; zella: Netrokona; thana Barhatta ;', 'Barhatta', 'Bachelor Degree', 'Spring 2026', 3.58, 3.17, '', NULL, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '1st call', NULL, '2026-01-31', '2026-01-30 16:52:17', NULL, NULL, NULL, 3, NULL, '2026-01-29 10:46:00', '2026-01-30 10:52:17', NULL, 1),
(258, 'Mabruka', 'Noor', 'mabrukaislamnoor@gmail.com', '01710007233', 'Puran Dhaka Faridabad', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 4.80, 2.50, NULL, NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Fresh', NULL, NULL, NULL, NULL, NULL, NULL, 3, NULL, '2026-01-29 12:04:52', '2026-01-29 12:04:52', NULL, 1),
(259, 'Sadia', 'Afrin', 'sadiaafrinnuri99@gmail.com', '01792052422', 'Nilphamari', 'Nilphamari sadar', 'Bachelor Degree', 'Spring 2026', 5.00, 5.00, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '1st call', NULL, '2026-03-10', '2026-01-30 19:53:23', NULL, NULL, NULL, 3, NULL, '2026-01-29 13:16:10', '2026-01-30 13:53:23', NULL, 1),
(260, 'Shamiul', 'Hasan', 'test.my920@gmail.com', '01908747740', 'Gaibandha Sadar', 'Gaibandha', 'Bachelor Degree', 'Spring 2026', 4.78, 3.86, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '1st call', NULL, '2026-03-26', '2026-01-30 20:16:52', NULL, NULL, NULL, 3, NULL, '2026-01-29 13:16:46', '2026-01-30 14:16:52', NULL, 1),
(261, 'Md Motaleb', 'Shekh', 'm88432728@gmail.com', '01762852273', 'Savar.Dhaka', 'Savar', 'Master Degree', 'Spring 2026', 3.83, 4.00, 'Social Work, Political Science, Psychology', 3.00, 41, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Fresh', NULL, NULL, '2026-01-30 15:16:25', NULL, NULL, NULL, 3, NULL, '2026-01-29 13:17:16', '2026-01-30 09:16:25', NULL, 1),
(262, 'Sima', 'Islam', 'jfsiam66@gmail.com', '01766126573', 'Mohammadpur, dhaka', 'Mohammadpur', 'Bachelor Degree', 'Spring 2026', 4.83, 3.50, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Fresh', NULL, NULL, '2026-01-30 15:16:04', NULL, NULL, NULL, 3, NULL, '2026-01-29 13:32:29', '2026-01-30 09:16:04', NULL, 1),
(263, 'Al Nahian', 'Tayeeb', 'alnahiantayeeb0@gmail.com', '01880498126', 'Patikelbari, Nesarabad, Pirojpur', 'Barishal', 'Bachelor Degree', 'Spring 2026', 4.00, 2.67, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '1st call', NULL, '2026-01-31', '2026-01-30 20:28:02', NULL, NULL, NULL, 3, NULL, '2026-01-29 13:40:30', '2026-01-30 14:28:02', NULL, 1),
(264, 'Md Saju', 'Hossain', 'sajuhossainhbke@gmail.com', '+97433291598', 'Haripur, Thakurgaon', 'Haripur', 'Bachelor Degree', 'Spring 2026', 4.86, 4.46, '', NULL, 35, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Dead', '2026-01-30 20:18:43', NULL, '2026-01-30 20:18:43', NULL, NULL, NULL, 3, NULL, '2026-01-29 14:53:08', '2026-01-30 14:18:43', NULL, 1),
(265, 'Md Billal', 'Hossain', 'Joykst76@gmail.com', '01784317311', 'House-12,Road-13,Block-D, Mirpur-6,Dhaka-1216', 'Dhaka', 'Master Degree', 'January 2025', 3.66, 3.00, 'Marketing', 2.68, 46, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Fresh', NULL, NULL, '2026-01-30 14:08:07', NULL, NULL, NULL, 3, NULL, '2026-01-29 23:35:29', '2026-01-30 08:08:07', NULL, 1),
(266, 'Alma', 'Siddiqi', 'siddiquealma505@gmail.com', '01914545010', 'Rajbari Sador Rajbari', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 5.00, 4.00, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Fresh', NULL, NULL, '2026-01-30 14:07:44', NULL, NULL, NULL, 3, NULL, '2026-01-30 03:48:06', '2026-01-30 08:07:44', NULL, 1),
(267, 'Fatema Kabir ', 'Sima', 'na@gmail.com', '01776637858', 'Mirpur-02', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 5.00, 4.75, '', NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Fresh', NULL, '2026-01-31', '2026-01-30 11:16:35', NULL, NULL, NULL, 29, NULL, '2026-01-30 05:11:25', '2026-01-30 05:16:35', NULL, 1),
(268, 'Ashik ', 'Hossain', 'ashik@gmail.com', '01773780734', '', '', 'Bachelor Degree', 'Spring 2026', 4.17, 3.75, '', NULL, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Agent', NULL, 'Admitted', NULL, '2026-01-30', '2026-01-30 13:12:50', NULL, NULL, NULL, 24, NULL, '2026-01-30 07:01:50', '2026-01-30 07:12:50', NULL, 1),
(269, 'Shariar Nazim ', 'Joy', 'na@gmail.com', '01329528975', '', '', 'Bachelor Degree', 'Spring 2026', 3.83, 3.83, '', NULL, 44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Agent', NULL, 'Admitted', NULL, '2026-01-30', '2026-01-30 15:18:36', NULL, NULL, NULL, 24, NULL, '2026-01-30 07:03:33', '2026-01-30 09:18:36', NULL, 1),
(270, 'Jahidul Islam', 'Jahidul Islam', 'pialnahidhasan3@gmail.com', '01571179021', '', '', 'Bachelor Degree', 'Spring 2026', 4.56, 3.25, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '1st call', NULL, '2026-01-31', '2026-01-30 16:37:09', NULL, NULL, NULL, 24, NULL, '2026-01-30 10:34:13', '2026-01-30 10:37:09', NULL, 1),
(271, 'Tahsin Mahmud', 'sahitto', 'pialnahidhasan3@gmail.com', '01301568680', '', '', 'Bachelor Degree', 'Spring 2026', 4.46, 3.67, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '1st call', NULL, '2026-02-10', '2026-01-31 09:36:37', NULL, NULL, NULL, 24, NULL, '2026-01-30 10:35:38', '2026-01-31 03:36:37', NULL, 1),
(272, 'Mithila', 'Jahan', 'smithilajahan@gmail.com', '01884876646', 'Dhaka,Mirpur', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 5.00, 4.00, NULL, NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Fresh', NULL, NULL, NULL, NULL, NULL, NULL, 3, NULL, '2026-01-30 11:03:52', '2026-01-30 11:03:52', NULL, 1),
(273, 'Sakkhor', 'Biswas', 'pialnahidhasan3@gmail.com', '01734287734', '', '', 'Bachelor Degree', 'Spring 2026', 5.00, 3.83, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '1st call', NULL, '2026-02-12', '2026-01-31 09:34:45', NULL, NULL, NULL, 24, NULL, '2026-01-30 11:24:51', '2026-01-31 03:34:45', NULL, 1),
(274, 'Mohammad', ' Minhaz', 'na@gmail.com', '01715728802', '', '', 'Bachelor Degree', 'Spring 2026', 4.33, 4.33, '', NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '1st call', NULL, '2026-01-31', '2026-01-30 18:35:32', NULL, NULL, NULL, 27, NULL, '2026-01-30 11:38:56', '2026-01-30 12:35:32', NULL, 1),
(275, 'Hasib', 'Howlader', 'hasibahammed534@gmail.com', '01963239517', 'Uttara dhaka -6 number sec-16 number road', 'Uttara', 'Bachelor Degree', 'Spring 2026', 4.22, 3.83, NULL, NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Fresh', NULL, NULL, NULL, NULL, NULL, NULL, 3, NULL, '2026-01-30 11:54:30', '2026-01-30 11:54:30', NULL, 1),
(276, 'Jafor', 'Jafor', 'pialnahidhasan3@gmail.com', '01682967844', '', '', 'Bachelor Degree', 'Spring 2026', 5.00, 5.00, '', NULL, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, '1st call', NULL, '2026-02-10', '2026-01-31 09:33:14', NULL, NULL, NULL, 24, NULL, '2026-01-30 11:56:26', '2026-01-31 03:33:14', NULL, 1),
(277, 'Abyead', 'Haneen', 'abyeadxyz@gmail.com', '01570209038', '171/1 South Goran', 'Dhaka', 'Bachelor Degree', 'Spring 2026', 5.00, 5.00, NULL, NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Fresh', NULL, NULL, NULL, NULL, NULL, NULL, 3, NULL, '2026-01-30 12:10:45', '2026-01-30 12:10:45', NULL, 1),
(278, 'Ittehad Noor', 'Biswas', 'ittehadbiswas@gmail.com', '01400940377', 'Vikra,Manikganj Sadar,Manikgonj,Dhaka', 'Manikganj', 'Bachelor Degree', 'Spring 2026', 5.00, 4.33, NULL, NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Direct Online', NULL, 'Fresh', NULL, NULL, NULL, NULL, NULL, NULL, 3, NULL, '2026-01-30 17:41:20', '2026-01-30 17:41:20', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `lead_courses`
--

CREATE TABLE `lead_courses` (
  `id` int NOT NULL,
  `lead_id` int NOT NULL,
  `course_id` int NOT NULL,
  `added_by` int NOT NULL,
  `added_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lead_edit_history`
--

CREATE TABLE `lead_edit_history` (
  `id` int NOT NULL,
  `lead_id` int NOT NULL,
  `field_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `old_value` text COLLATE utf8mb4_unicode_ci,
  `new_value` text COLLATE utf8mb4_unicode_ci,
  `edited_by` int NOT NULL,
  `edited_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lead_edit_history`
--

INSERT INTO `lead_edit_history` (`id`, `lead_id`, `field_name`, `old_value`, `new_value`, `edited_by`, `edited_at`) VALUES
(98, 75, 'interested_course_id', '40', '39', 27, '2026-01-20 07:52:07'),
(99, 75, 'lead_status', 'Fresh', '1st call', 27, '2026-01-20 07:52:07'),
(100, 74, 'lead_status', 'Fresh', 'Unable to reach once', 27, '2026-01-20 07:59:16'),
(101, 73, 'lead_status', 'Fresh', 'Dead', 27, '2026-01-20 08:01:15'),
(102, 79, 'lead_status', 'Fresh', 'Will visit office', 27, '2026-01-20 08:17:11'),
(103, 79, 'campus_visit_date', NULL, '2026-01-23T09:00', 27, '2026-01-20 08:17:11'),
(104, 72, 'lead_status', 'Fresh', 'Dead', 27, '2026-01-20 08:45:00'),
(105, 78, 'lead_status', 'Fresh', 'Admitted', 27, '2026-01-20 08:51:16'),
(106, 80, 'email', 'khalidbinazad@gmail.com', 'na@gmail.com', 27, '2026-01-20 09:15:38'),
(107, 80, 'lead_status', 'Fresh', 'Will visit office', 27, '2026-01-20 09:15:38'),
(108, 80, 'campus_visit_date', NULL, '2026-01-20T16:15', 27, '2026-01-20 09:15:38'),
(109, 78, 'lead_source', 'Direct Campus Visit', 'Agent', 3, '2026-01-20 09:18:13'),
(110, 81, 'lead_status', 'Fresh', '1st call', 3, '2026-01-20 09:32:47'),
(111, 71, 'lead_status', 'Fresh', '1st call', 27, '2026-01-20 09:37:10'),
(112, 70, 'lead_status', 'Fresh', '1st call', 27, '2026-01-20 10:13:17'),
(113, 69, 'lead_status', 'Fresh', 'Dead', 27, '2026-01-20 10:19:25'),
(114, 68, 'lead_status', 'Fresh', 'Dead', 27, '2026-01-20 10:24:20'),
(115, 67, 'lead_status', 'Fresh', 'Dead', 27, '2026-01-20 10:30:06'),
(116, 66, 'lead_status', 'Fresh', '1st call', 27, '2026-01-20 10:32:27'),
(117, 65, 'lead_status', 'Fresh', 'Dead', 27, '2026-01-20 10:37:20'),
(118, 64, 'ssc_gpa', '1.00', '4.29', 27, '2026-01-20 10:44:33'),
(119, 64, 'hsc_gpa', '2.00', '4.13', 27, '2026-01-20 10:44:33'),
(120, 77, 'lead_status', 'Fresh', '1st call', 27, '2026-01-20 10:47:32'),
(121, 64, 'lead_status', 'Fresh', '1st call', 27, '2026-01-20 10:50:19'),
(123, 61, 'lead_status', 'Fresh', 'Unable to reach once', 3, '2026-01-20 10:52:17'),
(124, 62, 'lead_status', 'Fresh', 'Unable to reach once', 3, '2026-01-20 10:53:34'),
(125, 63, 'lead_status', 'Fresh', 'Dead', 27, '2026-01-20 10:55:08'),
(126, 63, 'first_name', 'Mimakther', 'Mim akther', 3, '2026-01-20 10:55:25'),
(127, 85, 'lead_status', 'Fresh', 'Dead', 27, '2026-01-20 11:07:47'),
(128, 84, 'lead_status', 'Fresh', 'Dead', 27, '2026-01-20 11:10:21'),
(129, 81, 'lead_status', '1st call', '2nd call', 27, '2026-01-21 04:43:26'),
(130, 62, 'lead_status', 'Unable to reach once', 'Unable to reach twice', 27, '2026-01-21 04:46:56'),
(131, 81, 'lead_status', '2nd call', 'Admitted', 27, '2026-01-21 05:18:11'),
(132, 99, 'lead_status', 'Fresh', 'Admitted', 27, '2026-01-21 05:58:19'),
(133, 100, 'lead_status', 'Fresh', 'Admitted', 27, '2026-01-21 06:07:04'),
(134, 101, 'lead_status', 'Fresh', '1st call', 27, '2026-01-21 06:14:12'),
(135, 102, 'lead_status', 'Fresh', '1st call', 27, '2026-01-21 06:28:20'),
(136, 102, 'lead_status', '1st call', '2nd call', 27, '2026-01-21 06:37:41'),
(137, 104, 'lead_status', 'Fresh', '1st call', 27, '2026-01-21 07:12:12'),
(138, 105, 'lead_status', 'Fresh', '1st call', 27, '2026-01-21 07:12:54'),
(139, 103, 'lead_status', 'Fresh', '1st call', 27, '2026-01-21 07:14:06'),
(140, 106, 'lead_status', 'Fresh', '2nd call', 27, '2026-01-21 07:16:51'),
(141, 107, 'lead_status', 'Fresh', '1st call', 27, '2026-01-21 07:24:53'),
(142, 108, 'lead_status', 'Fresh', 'Will visit office', 27, '2026-01-21 08:12:09'),
(143, 108, 'campus_visit_date', NULL, '2026-01-23T09:00', 27, '2026-01-21 08:12:09'),
(144, 109, 'lead_status', '1st call', 'Admitted', 27, '2026-01-21 08:22:40'),
(145, 83, 'lead_status', '1st call', 'Will visit office', 27, '2026-01-21 10:14:05'),
(146, 83, 'campus_visit_date', NULL, '2026-01-23T15:07', 27, '2026-01-21 10:14:05'),
(147, 74, 'lead_status', 'Unable to reach once', 'Unable to reach trice', 27, '2026-01-21 10:27:00'),
(148, 61, 'lead_status', 'Unable to reach once', 'Unable to reach twice', 27, '2026-01-21 10:31:27'),
(149, 60, 'lead_status', 'Fresh', 'Dead', 29, '2026-01-21 10:49:54'),
(150, 113, 'lead_status', 'Fresh', '1st call', 31, '2026-01-21 10:54:05'),
(151, 110, 'lead_status', 'Fresh', 'Will visit office', 27, '2026-01-21 11:01:58'),
(152, 110, 'campus_visit_date', NULL, '2026-01-30T10:01', 27, '2026-01-21 11:01:58'),
(153, 110, 'campus_visit_date', '2026-01-30 10:01:00', '2026-01-30T10:01', 27, '2026-01-21 11:01:58'),
(154, 112, 'lead_source', 'Direct Campus Visit', 'Direct Online', 27, '2026-01-21 11:02:49'),
(155, 57, 'lead_status', 'Fresh', 'Dead', 29, '2026-01-21 11:06:32'),
(156, 55, 'lead_status', 'Fresh', '2nd call', 29, '2026-01-21 11:20:08'),
(157, 97, 'lead_status', 'Fresh', 'Will visit office', 27, '2026-01-21 11:21:27'),
(158, 97, 'campus_visit_date', NULL, '2026-01-25T16:59', 27, '2026-01-21 11:21:27'),
(159, 97, 'campus_visit_date', '2026-01-25 16:59:00', '2026-01-25T16:59', 27, '2026-01-21 11:21:36'),
(160, 96, 'lead_status', 'Fresh', '1st call', 27, '2026-01-21 11:25:00'),
(161, 92, 'lead_status', 'Fresh', '1st call', 27, '2026-01-21 11:30:32'),
(162, 53, 'current_city', '', 'Dhaka', 29, '2026-01-21 11:39:49'),
(163, 53, 'lead_status', 'Fresh', '1st call', 29, '2026-01-21 11:39:49'),
(167, 91, 'lead_status', 'Fresh', '1st call', 30, '2026-01-22 05:40:11'),
(168, 87, 'lead_status', 'Fresh', '1st call', 30, '2026-01-22 05:45:04'),
(169, 117, 'lead_status', 'Fresh', '1st call', 30, '2026-01-22 05:49:52'),
(170, 119, 'lead_status', 'Fresh', '1st call', 29, '2026-01-22 05:55:14'),
(171, 118, 'last_name', 'h', '.', 29, '2026-01-22 05:55:52'),
(172, 118, 'current_city', '', 'Dhaka', 29, '2026-01-22 05:55:52'),
(173, 118, 'lead_status', 'Fresh', '1st call', 29, '2026-01-22 05:55:52'),
(174, 120, 'lead_status', 'Fresh', '1st call', 29, '2026-01-22 05:56:18'),
(175, 80, 'campus_visit_date', '2026-01-20 16:15:00', '2026-01-20T16:15', 29, '2026-01-22 06:01:29'),
(176, 121, 'lead_status', 'Fresh', '1st call', 29, '2026-01-22 06:09:56'),
(177, 93, 'lead_status', 'Fresh', '1st call', 30, '2026-01-22 06:26:10'),
(178, 79, 'lead_status', 'Will visit office', '2nd call', 29, '2026-01-22 06:37:23'),
(179, 123, 'lead_status', 'Fresh', '1st call', 30, '2026-01-22 06:47:03'),
(180, 130, 'lead_status', 'Fresh', '1st call', 29, '2026-01-22 07:58:02'),
(181, 131, 'lead_status', 'Fresh', '1st call', 29, '2026-01-22 08:10:56'),
(182, 132, 'lead_status', 'Fresh', 'Will visit office', 29, '2026-01-22 08:18:21'),
(183, 132, 'campus_visit_date', NULL, '2026-01-22T14:18', 29, '2026-01-22 08:18:21'),
(184, 135, 'lead_status', 'Fresh', '1st call', 29, '2026-01-22 10:12:12'),
(185, 136, 'lead_status', 'Fresh', '2nd call', 29, '2026-01-22 10:18:06'),
(186, 126, 'lead_status', 'Fresh', '1st call', 30, '2026-01-22 10:26:16'),
(187, 126, 'lead_status', '1st call', 'Fresh', 30, '2026-01-22 10:27:30'),
(188, 128, 'lead_status', 'Fresh', '1st call', 30, '2026-01-22 10:27:47'),
(189, 55, 'lead_status', '2nd call', '3rd call', 29, '2026-01-22 10:32:30'),
(190, 126, 'lead_status', 'Fresh', '1st call', 30, '2026-01-22 10:36:28'),
(192, 52, 'applying_for', NULL, 'Bachelor Degree', 29, '2026-01-22 10:39:05'),
(193, 52, 'interested_course_id', NULL, '44', 29, '2026-01-22 10:39:05'),
(194, 52, 'lead_status', 'Fresh', 'Dead', 29, '2026-01-22 10:40:00'),
(195, 116, 'lead_status', 'Fresh', '1st call', 30, '2026-01-22 10:42:20'),
(196, 86, 'lead_status', 'Fresh', '1st call', 30, '2026-01-22 10:49:07'),
(197, 123, 'lead_source', 'Direct Campus Visit', 'Direct Online', 30, '2026-01-22 10:55:39'),
(198, 80, 'campus_visit_date', '2026-01-20 16:15:00', '2026-01-26T04:15', 27, '2026-01-22 11:10:30'),
(199, 114, 'lead_status', 'Fresh', '1st call', 29, '2026-01-22 11:12:07'),
(200, 80, 'campus_visit_date', '2026-01-26 04:15:00', '2026-01-26T04:15', 27, '2026-01-22 11:13:23'),
(201, 80, 'campus_visit_date', '2026-01-26 04:15:00', '2026-01-26T04:15', 27, '2026-01-22 11:17:51'),
(202, 80, 'campus_visit_date', '2026-01-26 04:15:00', '2026-01-26T16:15', 27, '2026-01-22 11:18:19'),
(203, 77, 'lead_status', '1st call', 'Dead', 27, '2026-01-22 11:23:44'),
(204, 80, 'campus_visit_date', '2026-01-26 16:15:00', '2026-01-26T15:15', 27, '2026-01-22 11:24:41'),
(205, 80, 'campus_visit_date', '2026-01-26 15:15:00', '2026-01-26T15:15', 27, '2026-01-22 11:25:40'),
(206, 94, 'lead_status', 'Fresh', '1st call', 30, '2026-01-22 11:25:42'),
(207, 80, 'campus_visit_date', '2026-01-26 15:15:00', '2026-01-26T15:15', 27, '2026-01-22 11:26:08'),
(208, 76, 'lead_status', '1st call', '2nd call', 27, '2026-01-22 11:28:44'),
(209, 90, 'lead_status', 'Fresh', '1st call', 30, '2026-01-22 11:31:08'),
(210, 75, 'lead_status', '1st call', 'Will visit office', 27, '2026-01-22 11:36:56'),
(211, 75, 'campus_visit_date', NULL, '2026-01-23T15:36', 27, '2026-01-22 11:36:56'),
(212, 75, 'campus_visit_date', '2026-01-23 15:36:00', '2026-01-23T15:36', 27, '2026-01-22 11:37:23'),
(213, 74, 'lead_status', 'Unable to reach trice', 'Dead', 27, '2026-01-22 11:41:07'),
(214, 71, 'lead_status', '1st call', 'Will visit office', 27, '2026-01-22 11:52:55'),
(215, 71, 'campus_visit_date', NULL, '2026-01-30T11:01', 27, '2026-01-22 11:52:55'),
(216, 70, 'lead_status', '1st call', 'Dead', 27, '2026-01-22 11:58:39'),
(217, 66, 'lead_status', '1st call', '2nd call', 27, '2026-01-22 12:01:37'),
(218, 66, 'lead_status', '2nd call', 'Dead', 27, '2026-01-22 12:02:44'),
(219, 64, 'lead_status', '1st call', 'Dead', 27, '2026-01-22 12:17:16'),
(220, 62, 'semester', 'January 2025', 'Spring 2026', 27, '2026-01-22 12:23:37'),
(221, 62, 'interested_course_id', '45', '44', 27, '2026-01-22 12:23:37'),
(222, 62, 'lead_status', 'Unable to reach twice', 'Will visit office', 27, '2026-01-22 12:23:37'),
(223, 62, 'campus_visit_date', NULL, '2026-01-24T11:59', 27, '2026-01-22 12:23:37'),
(224, 62, 'campus_visit_date', '2026-01-24 11:59:00', '2026-01-24T11:59', 27, '2026-01-22 12:23:54'),
(225, 61, 'lead_status', 'Unable to reach twice', 'Dead', 27, '2026-01-22 12:26:43'),
(226, 80, 'campus_visit_date', '2026-01-26 15:15:00', '2026-01-26T15:15', 27, '2026-01-22 12:27:17'),
(227, 115, 'lead_status', 'Fresh', '1st call', 27, '2026-01-22 12:29:57'),
(228, 95, 'lead_status', 'Fresh', '1st call', 27, '2026-01-22 12:47:54'),
(229, 129, 'campus_visit_date', '2026-01-22 13:34:00', '2026-01-22T13:34', 29, '2026-01-23 04:05:31'),
(230, 137, 'lead_status', 'Fresh', '1st call', 30, '2026-01-23 04:16:22'),
(231, 136, 'lead_status', '2nd call', 'Will visit office', 24, '2026-01-23 04:26:03'),
(232, 136, 'campus_visit_date', NULL, '2026-01-26T22:25', 24, '2026-01-23 04:26:03'),
(233, 139, 'lead_status', 'Fresh', '1st call', 29, '2026-01-23 04:29:02'),
(234, 139, 'lead_status', '1st call', 'Will visit office', 29, '2026-01-23 04:29:10'),
(235, 139, 'campus_visit_date', NULL, '2026-01-23T10:29', 29, '2026-01-23 04:29:10'),
(236, 139, 'campus_visit_date', '2026-01-23 10:29:00', '2026-01-23T10:29', 29, '2026-01-23 04:29:21'),
(237, 134, 'lead_status', 'Fresh', '1st call', 24, '2026-01-23 04:33:10'),
(238, 133, 'lead_status', 'Fresh', '1st call', 24, '2026-01-23 04:41:09'),
(239, 142, 'lead_status', 'Fresh', 'Will visit office', 24, '2026-01-23 04:48:30'),
(240, 142, 'campus_visit_date', NULL, '2026-01-22T22:48', 24, '2026-01-23 04:48:30'),
(241, 127, 'lead_source', 'Direct Online', 'Agent', 24, '2026-01-23 04:58:37'),
(242, 127, 'lead_status', 'Fresh', '1st call', 24, '2026-01-23 04:58:37'),
(243, 125, 'lead_status', 'Fresh', '1st call', 24, '2026-01-23 04:59:38'),
(244, 124, 'lead_status', 'Fresh', '1st call', 24, '2026-01-23 05:02:40'),
(245, 113, 'lead_status', '1st call', 'Will visit office', 24, '2026-01-23 05:05:02'),
(246, 113, 'campus_visit_date', NULL, '2026-01-22T23:04', 24, '2026-01-23 05:05:02'),
(247, 53, 'lead_status', '1st call', '2nd call', 30, '2026-01-23 05:24:17'),
(248, 83, 'campus_visit_date', '2026-01-23 15:07:00', '2026-01-23T15:07', 29, '2026-01-23 05:25:12'),
(249, 89, 'lead_status', 'Fresh', '1st call', 24, '2026-01-23 05:28:00'),
(250, 133, 'lead_status', '1st call', 'Unable to reach twice', 24, '2026-01-23 05:33:45'),
(255, 51, 'applying_for', NULL, 'Bachelor Degree', 24, '2026-01-23 05:36:44'),
(256, 51, 'lead_status', 'Fresh', '1st call', 24, '2026-01-23 05:36:53'),
(259, 50, 'applying_for', NULL, 'Bachelor Degree', 24, '2026-01-23 05:39:34'),
(260, 50, 'interested_course_id', NULL, '39', 24, '2026-01-23 05:39:34'),
(261, 50, 'lead_status', 'Fresh', '1st call', 24, '2026-01-23 05:39:40'),
(262, 49, 'applying_for', NULL, 'Bachelor Degree', 24, '2026-01-23 05:42:23'),
(263, 49, 'interested_course_id', NULL, '39', 24, '2026-01-23 05:42:23'),
(264, 49, 'lead_status', 'Fresh', 'Dead', 24, '2026-01-23 05:42:45'),
(265, 80, 'campus_visit_date', '2026-01-26 15:15:00', '2026-01-26T15:15', 29, '2026-01-23 05:43:09'),
(266, 80, 'campus_visit_date', '2026-01-26 15:15:00', '2026-01-26T15:15', 24, '2026-01-23 05:45:33'),
(267, 80, 'campus_visit_date', '2026-01-26 15:15:00', '2026-01-26T15:15', 24, '2026-01-23 05:45:58'),
(268, 140, 'lead_status', 'Fresh', '1st call', 24, '2026-01-23 08:22:00'),
(269, 83, 'campus_visit_date', '2026-01-23 15:07:00', '2026-01-23T15:07', 24, '2026-01-23 08:25:31'),
(270, 138, 'lead_status', 'Fresh', '1st call', 30, '2026-01-23 08:48:56'),
(271, 145, 'lead_status', 'Fresh', 'Will visit office', 24, '2026-01-23 09:17:28'),
(272, 145, 'campus_visit_date', NULL, '2026-01-26T03:17', 24, '2026-01-23 09:17:28'),
(273, 98, 'lead_status', '1st call', 'Will visit office', 24, '2026-01-23 09:34:24'),
(274, 98, 'campus_visit_date', NULL, '2026-01-23T03:34', 24, '2026-01-23 09:34:24'),
(275, 101, 'lead_status', '1st call', '2nd call', 30, '2026-01-23 09:37:37'),
(276, 92, 'lead_source', 'Direct Online', 'Direct Campus Visit', 24, '2026-01-23 09:38:54'),
(277, 92, 'lead_status', '1st call', 'Unable to reach twice', 24, '2026-01-23 09:38:54'),
(278, 83, 'lead_status', 'Will visit office', 'Unable to reach once', 24, '2026-01-23 09:40:46'),
(279, 96, 'lead_status', '1st call', '2nd call', 30, '2026-01-23 09:42:43'),
(280, 146, 'lead_source', 'Direct Online', 'Direct Campus Visit', 24, '2026-01-23 09:44:02'),
(281, 146, 'lead_status', 'Fresh', 'Will visit office', 24, '2026-01-23 09:44:02'),
(282, 146, 'campus_visit_date', NULL, '2026-01-26T03:43', 24, '2026-01-23 09:44:02'),
(283, 144, 'lead_status', 'Fresh', '1st call', 24, '2026-01-23 09:55:45'),
(284, 80, 'lead_status', 'Will visit office', '2nd call', 24, '2026-01-23 10:05:58'),
(285, 148, 'lead_status', 'Fresh', '1st call', 24, '2026-01-23 10:30:00'),
(286, 142, 'lead_status', 'Will visit office', 'Admitted', 24, '2026-01-23 11:07:04'),
(287, 149, 'lead_status', 'Fresh', '1st call', 29, '2026-01-23 11:07:29'),
(288, 132, 'campus_visit_date', '2026-01-22 14:18:00', '2026-01-22T14:18', 29, '2026-01-23 11:51:45'),
(289, 132, 'lead_status', 'Will visit office', 'Admitted', 29, '2026-01-23 11:52:13'),
(290, 112, 'lead_status', '1st call', '2nd call', 27, '2026-01-23 12:51:30'),
(291, 111, 'lead_status', '1st call', 'Will visit office', 27, '2026-01-23 12:55:23'),
(292, 111, 'campus_visit_date', NULL, '2026-01-28T11:01', 27, '2026-01-23 12:55:23'),
(293, 110, 'campus_visit_date', '2026-01-30 10:01:00', '2026-01-30T10:01', 27, '2026-01-23 13:00:01'),
(294, 108, 'campus_visit_date', '2026-01-23 09:00:00', '2026-01-26T10:01', 27, '2026-01-23 13:06:47'),
(295, 107, 'lead_status', '1st call', 'Will visit office', 27, '2026-01-23 13:17:35'),
(296, 107, 'campus_visit_date', NULL, '2026-01-28T13:00', 27, '2026-01-23 13:17:35'),
(297, 106, 'lead_status', '2nd call', 'Admitted', 27, '2026-01-23 13:22:53'),
(298, 104, 'lead_status', '1st call', 'Will visit office', 27, '2026-01-23 13:30:56'),
(299, 104, 'campus_visit_date', NULL, '2026-01-25T11:00', 27, '2026-01-23 13:30:56'),
(300, 103, 'lead_status', '1st call', 'Will visit office', 27, '2026-01-23 13:33:22'),
(301, 103, 'campus_visit_date', NULL, '2026-01-25T11:01', 27, '2026-01-23 13:33:22'),
(302, 102, 'lead_status', '2nd call', 'Will visit office', 27, '2026-01-23 13:44:52'),
(303, 102, 'campus_visit_date', NULL, '2026-01-27T10:00', 27, '2026-01-23 13:44:52'),
(304, 97, 'campus_visit_date', '2026-01-25 16:59:00', '2026-01-25T16:59', 27, '2026-01-23 13:48:40'),
(305, 105, 'lead_status', '1st call', '2nd call', 27, '2026-01-23 13:49:29'),
(306, 110, 'campus_visit_date', '2026-01-30 10:01:00', '2026-01-30T10:01', 27, '2026-01-23 13:50:35'),
(307, 108, 'campus_visit_date', '2026-01-26 10:01:00', '2026-01-26T10:01', 27, '2026-01-23 13:51:37'),
(308, 88, 'lead_status', 'Fresh', '1st call', 27, '2026-01-23 13:55:02'),
(309, 108, 'campus_visit_date', '2026-01-26 10:01:00', '2026-01-26T10:01', 27, '2026-01-23 14:00:09'),
(310, 62, 'campus_visit_date', '2026-01-24 11:59:00', '2026-01-24T11:59', 29, '2026-01-24 03:27:51'),
(311, 132, 'semester', '', 'Spring 2026', 29, '2026-01-24 03:29:01'),
(312, 133, 'lead_status', 'Unable to reach twice', 'Unable to reach trice', 24, '2026-01-24 04:22:25'),
(313, 131, 'lead_status', '1st call', 'Unable to reach trice', 24, '2026-01-24 04:22:42'),
(314, 120, 'lead_status', '1st call', '2nd call', 24, '2026-01-24 04:26:55'),
(315, 93, 'lead_status', '1st call', '2nd call', 24, '2026-01-24 04:33:34'),
(316, 92, 'lead_status', 'Unable to reach twice', 'Will visit office', 24, '2026-01-24 04:35:17'),
(317, 92, 'campus_visit_date', NULL, '2026-01-23T22:35', 24, '2026-01-24 04:35:17'),
(318, 83, 'lead_status', 'Unable to reach once', '1st call', 24, '2026-01-24 04:37:04'),
(319, 62, 'campus_visit_date', '2026-01-24 11:59:00', '2026-01-24T11:59', 24, '2026-01-24 04:38:52'),
(320, 62, 'campus_visit_date', '2026-01-24 11:59:00', '2026-01-24T11:59', 24, '2026-01-24 04:39:01'),
(321, 62, 'lead_status', 'Will visit office', '2nd call', 24, '2026-01-24 04:39:15'),
(322, 55, 'lead_status', '3rd call', 'Unable to reach twice', 24, '2026-01-24 04:40:54'),
(323, 150, 'lead_status', 'Fresh', '1st call', 24, '2026-01-24 05:01:52'),
(324, 151, 'lead_status', 'Fresh', '1st call', 24, '2026-01-24 05:39:04'),
(325, 153, 'lead_status', 'Fresh', '1st call', 24, '2026-01-24 05:39:10'),
(326, 155, 'lead_status', 'Fresh', '1st call', 24, '2026-01-24 05:51:06'),
(327, 154, 'lead_status', 'Fresh', '1st call', 24, '2026-01-24 05:51:17'),
(328, 75, 'campus_visit_date', '2026-01-23 15:36:00', '2026-01-23T15:36', 29, '2026-01-24 06:24:12'),
(329, 156, 'lead_status', 'Fresh', '1st call', 24, '2026-01-24 06:42:34'),
(330, 158, 'lead_status', 'Fresh', '1st call', 24, '2026-01-24 08:31:25'),
(331, 157, 'lead_status', 'Fresh', '1st call', 24, '2026-01-24 08:31:35'),
(332, 159, 'lead_status', 'Fresh', '1st call', 24, '2026-01-24 08:38:32'),
(333, 160, 'lead_status', 'Fresh', '1st call', 24, '2026-01-24 09:13:05'),
(334, 161, 'lead_status', 'Fresh', '1st call', 24, '2026-01-24 09:25:13'),
(335, 162, 'lead_status', 'Fresh', '1st call', 24, '2026-01-24 09:28:19'),
(336, 164, 'lead_status', 'Fresh', '1st call', 24, '2026-01-24 09:40:52'),
(337, 163, 'lead_status', 'Fresh', '1st call', 24, '2026-01-24 09:47:17'),
(338, 165, 'lead_status', 'Fresh', '1st call', 24, '2026-01-24 09:57:59'),
(339, 131, 'lead_status', 'Unable to reach trice', 'Unable to reach twice', 24, '2026-01-24 10:07:38'),
(340, 93, 'lead_status', '2nd call', 'Admitted', 24, '2026-01-24 10:19:31'),
(341, 164, 'lead_status', '1st call', 'Admitted', 24, '2026-01-24 10:19:53'),
(342, 135, 'lead_status', '1st call', 'Admitted', 27, '2026-01-24 10:52:50'),
(343, 71, 'lead_status', 'Will visit office', '3rd call', 27, '2026-01-24 10:55:28'),
(344, 121, 'lead_status', '1st call', '2nd call', 27, '2026-01-24 10:58:12'),
(345, 115, 'lead_status', '1st call', '2nd call', 27, '2026-01-24 11:03:23'),
(346, 110, 'lead_status', 'Will visit office', '3rd call', 27, '2026-01-24 11:06:04'),
(347, 108, 'lead_status', 'Will visit office', '3rd call', 27, '2026-01-24 11:11:17'),
(348, 97, 'lead_status', 'Will visit office', '3rd call', 27, '2026-01-24 11:15:39'),
(349, 95, 'lead_status', '1st call', '2nd call', 27, '2026-01-24 11:23:31'),
(350, 86, 'lead_status', '1st call', 'Dead', 27, '2026-01-24 11:32:02'),
(351, 79, 'lead_status', '2nd call', '3rd call', 27, '2026-01-24 11:38:26'),
(352, 76, 'lead_status', '2nd call', '3rd call', 27, '2026-01-24 11:41:41'),
(353, 75, 'lead_status', 'Will visit office', '3rd call', 27, '2026-01-24 11:44:19'),
(354, 152, 'lead_status', 'Fresh', '1st call', 27, '2026-01-24 11:52:27'),
(355, 78, 'agent_id', NULL, NULL, 27, '2026-01-24 12:15:10'),
(356, 78, 'lead_source', 'Agent', 'Direct Online', 27, '2026-01-24 12:15:10'),
(357, 168, 'lead_status', 'Fresh', '1st call', 24, '2026-01-25 03:22:50'),
(358, 164, 'lead_source', 'Direct Online', 'Direct Campus Visit', 24, '2026-01-25 03:23:34'),
(359, 164, 'lead_source', 'Direct Campus Visit', 'Direct Online', 24, '2026-01-25 03:23:55'),
(360, 148, 'lead_status', '1st call', '2nd call', 24, '2026-01-25 03:43:39'),
(361, 130, 'lead_status', '1st call', '2nd call', 30, '2026-01-25 04:12:29'),
(362, 147, 'lead_status', '1st call', '2nd call', 24, '2026-01-25 04:14:02'),
(363, 129, 'lead_status', 'Will visit office', '2nd call', 30, '2026-01-25 04:18:21'),
(364, 128, 'lead_status', '1st call', '2nd call', 30, '2026-01-25 04:19:54'),
(365, 126, 'lead_status', '1st call', '2nd call', 30, '2026-01-25 04:23:11'),
(366, 123, 'lead_status', '1st call', '2nd call', 30, '2026-01-25 04:26:20'),
(367, 117, 'lead_status', '1st call', 'Dead', 30, '2026-01-25 04:31:11'),
(368, 116, 'lead_status', '1st call', '2nd call', 30, '2026-01-25 04:38:56'),
(369, 114, 'lead_status', '1st call', '2nd call', 30, '2026-01-25 04:40:20'),
(370, 91, 'lead_status', '1st call', '2nd call', 30, '2026-01-25 04:41:24'),
(371, 90, 'lead_status', '1st call', 'Dead', 30, '2026-01-25 04:42:49'),
(372, 87, 'lead_status', '1st call', '2nd call', 30, '2026-01-25 04:43:24'),
(373, 149, 'lead_status', '1st call', '2nd call', 30, '2026-01-25 04:44:13'),
(374, 146, 'lead_source', 'Direct Campus Visit', 'Direct Online', 24, '2026-01-25 04:45:38'),
(375, 146, 'lead_status', 'Will visit office', '2nd call', 24, '2026-01-25 04:45:38'),
(376, 138, 'lead_status', '1st call', 'Dead', 30, '2026-01-25 04:47:53'),
(377, 137, 'lead_status', '1st call', '2nd call', 30, '2026-01-25 04:48:32'),
(378, 94, 'lead_status', '1st call', 'Dead', 30, '2026-01-25 04:52:32'),
(379, 101, 'lead_status', '2nd call', '3rd call', 30, '2026-01-25 04:58:51'),
(380, 96, 'lead_status', '2nd call', '3rd call', 30, '2026-01-25 04:59:41'),
(381, 53, 'lead_status', '2nd call', '3rd call', 30, '2026-01-25 05:01:58'),
(382, 169, 'lead_status', 'Fresh', '1st call', 24, '2026-01-25 05:13:11'),
(383, 170, 'lead_status', 'Fresh', '1st call', 24, '2026-01-25 05:13:18'),
(384, 145, 'lead_status', 'Will visit office', 'Admitted', 24, '2026-01-25 05:37:06'),
(385, 168, 'lead_source', 'Direct Online', 'Agent', 24, '2026-01-25 05:45:33'),
(386, 168, 'lead_status', '1st call', 'Admitted', 24, '2026-01-25 05:45:33'),
(387, 171, 'lead_status', 'Fresh', '1st call', 24, '2026-01-25 06:21:30'),
(388, 144, 'lead_status', '1st call', '2nd call', 24, '2026-01-25 06:25:15'),
(389, 143, 'lead_status', 'Will visit office', '1st call', 24, '2026-01-25 06:28:18'),
(390, 141, 'lead_source', 'Direct Campus Visit', 'Agent', 24, '2026-01-25 06:32:02'),
(391, 141, 'lead_status', 'Will visit office', 'Admitted', 24, '2026-01-25 06:32:48'),
(392, 172, 'lead_status', 'Fresh', '1st call', 24, '2026-01-25 06:40:02'),
(393, 140, 'lead_status', '1st call', '2nd call', 24, '2026-01-25 06:42:28'),
(394, 136, 'lead_status', 'Will visit office', '3rd call', 24, '2026-01-25 06:43:30'),
(395, 134, 'lead_status', '1st call', 'Dead', 24, '2026-01-25 06:46:18'),
(396, 133, 'lead_status', 'Unable to reach trice', 'Admitted', 24, '2026-01-25 06:55:45'),
(397, 131, 'lead_status', 'Unable to reach twice', 'Admitted', 24, '2026-01-25 06:58:06'),
(398, 127, 'lead_status', '1st call', '2nd call', 24, '2026-01-25 07:01:26'),
(399, 125, 'lead_status', '1st call', '2nd call', 24, '2026-01-25 07:03:23'),
(400, 124, 'lead_status', '1st call', '2nd call', 24, '2026-01-25 07:06:57'),
(401, 113, 'lead_status', 'Will visit office', '3rd call', 24, '2026-01-25 07:15:47'),
(402, 98, 'campus_visit_date', '2026-01-23 03:34:00', '2026-01-23T03:34', 24, '2026-01-25 07:53:11'),
(403, 98, 'lead_status', 'Will visit office', '3rd call', 24, '2026-01-25 07:53:21'),
(404, 89, 'lead_status', '1st call', '2nd call', 24, '2026-01-25 08:25:28'),
(405, 80, 'lead_status', '2nd call', 'Dead', 24, '2026-01-25 08:32:36'),
(406, 55, 'lead_status', 'Unable to reach twice', 'Will visit office', 24, '2026-01-25 08:35:42'),
(407, 55, 'campus_visit_date', NULL, '2026-01-27T14:35', 24, '2026-01-25 08:35:42'),
(408, 51, 'lead_status', '1st call', '2nd call', 24, '2026-01-25 08:37:00'),
(409, 50, 'lead_status', '1st call', '2nd call', 24, '2026-01-25 08:38:25'),
(410, 173, 'lead_status', 'Fresh', '1st call', 24, '2026-01-25 09:08:13'),
(411, 175, 'lead_status', 'Fresh', '1st call', 24, '2026-01-25 09:48:52'),
(412, 176, 'lead_status', 'Fresh', '1st call', 24, '2026-01-25 10:03:04'),
(413, 178, 'lead_status', 'Fresh', '1st call', 24, '2026-01-25 10:45:30'),
(414, 179, 'lead_status', 'Fresh', '1st call', 24, '2026-01-25 10:53:57'),
(415, 119, 'lead_status', '1st call', '2nd call', 27, '2026-01-25 11:50:22'),
(416, 118, 'lead_status', '1st call', '2nd call', 27, '2026-01-25 11:59:24'),
(417, 88, 'lead_status', '1st call', 'Unable to reach trice', 27, '2026-01-25 12:11:00'),
(418, 88, 'lead_status', 'Unable to reach trice', '3rd call', 27, '2026-01-25 12:13:14'),
(419, 102, 'lead_status', 'Will visit office', '3rd call', 27, '2026-01-25 12:27:26'),
(420, 102, 'lead_status', '3rd call', 'Will visit office', 27, '2026-01-25 12:32:35'),
(421, 102, 'campus_visit_date', NULL, '2026-01-27T11:00', 27, '2026-01-25 12:32:35'),
(422, 103, 'lead_status', 'Will visit office', '3rd call', 27, '2026-01-25 12:35:33'),
(423, 104, 'lead_status', 'Will visit office', '3rd call', 27, '2026-01-25 12:36:45'),
(424, 104, 'lead_status', '3rd call', 'Will visit office', 27, '2026-01-25 12:38:23'),
(425, 104, 'campus_visit_date', NULL, '2026-01-27T10:00', 27, '2026-01-25 12:38:23'),
(426, 139, 'campus_visit_date', '2026-01-23 10:29:00', '2026-01-29T11:00', 27, '2026-01-25 12:45:11'),
(427, 103, 'lead_status', '3rd call', 'Will visit office', 27, '2026-01-25 12:47:44'),
(428, 103, 'campus_visit_date', NULL, '2026-01-27T11:00', 27, '2026-01-25 12:47:44'),
(429, 139, 'lead_status', 'Will visit office', '3rd call', 27, '2026-01-25 12:48:09'),
(430, 105, 'lead_status', '2nd call', 'Will visit office', 27, '2026-01-25 12:52:12'),
(431, 105, 'campus_visit_date', NULL, '2026-01-26T11:51', 27, '2026-01-25 12:52:12'),
(432, 105, 'campus_visit_date', '2026-01-26 11:51:00', '2026-01-26T12:01', 27, '2026-01-25 12:54:08'),
(433, 105, 'lead_status', 'Will visit office', '3rd call', 27, '2026-01-25 12:55:07'),
(434, 105, 'lead_status', '3rd call', '2nd call', 27, '2026-01-25 12:56:43'),
(435, 105, 'lead_status', '2nd call', 'Will visit office', 27, '2026-01-25 12:58:11'),
(436, 105, 'campus_visit_date', NULL, '2026-01-26T12:00', 27, '2026-01-25 12:58:11'),
(437, 112, 'lead_status', '2nd call', '3rd call', 27, '2026-01-25 13:03:18'),
(438, 107, 'lead_status', 'Will visit office', '3rd call', 27, '2026-01-25 13:05:42'),
(439, 107, 'lead_status', '3rd call', 'Will visit office', 27, '2026-01-25 13:07:52'),
(440, 107, 'campus_visit_date', NULL, '2026-01-28T11:00', 27, '2026-01-25 13:07:52'),
(441, 111, 'campus_visit_date', '2026-01-28 11:01:00', '2026-01-26T14:00', 27, '2026-01-25 13:12:16'),
(442, 111, 'campus_visit_date', '2026-01-26 14:00:00', '2026-01-26T14:00', 27, '2026-01-25 13:13:36'),
(443, 111, 'lead_status', 'Will visit office', '3rd call', 27, '2026-01-25 13:14:28'),
(444, 111, 'lead_status', '3rd call', 'Will visit office', 27, '2026-01-25 13:16:46'),
(445, 111, 'campus_visit_date', NULL, '2026-01-26T14:00', 27, '2026-01-25 13:16:46'),
(446, 166, 'lead_status', 'Fresh', '1st call', 27, '2026-01-25 13:20:14'),
(447, 167, 'lead_status', 'Fresh', 'Will visit office', 27, '2026-01-25 13:27:44'),
(448, 167, 'campus_visit_date', NULL, '2026-01-26T14:00', 27, '2026-01-25 13:27:44'),
(449, 167, 'lead_status', 'Will visit office', '1st call', 27, '2026-01-25 13:28:40'),
(450, 167, 'lead_status', '1st call', 'Will visit office', 27, '2026-01-25 13:29:31'),
(451, 167, 'campus_visit_date', NULL, '2026-01-26T14:00', 27, '2026-01-25 13:29:31'),
(452, 167, 'campus_visit_date', '2026-01-26 14:00:00', '2026-01-26T14:00', 27, '2026-01-25 13:32:33'),
(453, 174, 'lead_status', 'Fresh', '1st call', 27, '2026-01-25 13:35:31'),
(454, 152, 'lead_status', '1st call', '2nd call', 27, '2026-01-26 03:38:20'),
(455, 108, 'last_name', 'Islam', 'Akter', 27, '2026-01-26 04:04:36'),
(456, 108, 'lead_status', '3rd call', 'Will visit office', 27, '2026-01-26 04:04:36'),
(457, 108, 'campus_visit_date', NULL, '2026-01-26T10:00', 27, '2026-01-26 04:04:36'),
(458, 108, 'ssc_gpa', '4.00', '4.54', 27, '2026-01-26 04:09:36'),
(459, 108, 'hsc_gpa', '3.00', '3.44', 27, '2026-01-26 04:09:36'),
(460, 108, 'lead_status', 'Will visit office', 'Admitted', 27, '2026-01-26 04:09:36'),
(461, 62, 'lead_status', '2nd call', '3rd call', 27, '2026-01-26 04:26:47'),
(462, 182, 'lead_status', 'Fresh', 'Will visit office', 27, '2026-01-26 04:56:07'),
(463, 182, 'campus_visit_date', NULL, '2026-01-27T10:00', 27, '2026-01-26 04:56:07'),
(464, 182, 'lead_status', 'Will visit office', '1st call', 27, '2026-01-26 04:57:16'),
(465, 182, 'lead_status', '1st call', 'Will visit office', 27, '2026-01-26 04:59:24'),
(466, 182, 'campus_visit_date', NULL, '2026-01-27T11:00', 27, '2026-01-26 04:59:24'),
(467, 182, 'campus_visit_date', '2026-01-27 11:00:00', '2026-01-27T11:00', 27, '2026-01-26 05:03:37'),
(468, 177, 'lead_status', 'Fresh', '1st call', 30, '2026-01-26 05:03:49'),
(469, 182, 'campus_visit_date', '2026-01-27 11:00:00', '2026-01-26T11:00', 27, '2026-01-26 05:05:13'),
(470, 181, 'lead_status', 'Fresh', '1st call', 30, '2026-01-26 05:06:55'),
(471, 180, 'lead_status', 'Fresh', '1st call', 30, '2026-01-26 05:10:47'),
(472, 130, 'lead_status', '2nd call', 'Dead', 30, '2026-01-26 05:17:04'),
(473, 75, 'lead_status', '3rd call', 'Unable to reach once', 27, '2026-01-26 05:17:33'),
(474, 108, 'lead_source', 'Direct Online', 'Agent', 29, '2026-01-26 05:17:50'),
(475, 76, 'lead_status', '3rd call', 'Will visit office', 27, '2026-01-26 05:18:49'),
(476, 76, 'campus_visit_date', NULL, '2026-01-29T11:00', 27, '2026-01-26 05:18:49'),
(477, 126, 'lead_status', '2nd call', 'Admitted', 30, '2026-01-26 05:20:47'),
(478, 116, 'lead_status', '2nd call', '3rd call', 30, '2026-01-26 05:32:40'),
(479, 79, 'lead_status', '3rd call', 'Will visit office', 27, '2026-01-26 05:36:15'),
(480, 79, 'campus_visit_date', NULL, '2026-01-31T11:35', 27, '2026-01-26 05:36:15'),
(481, 95, 'lead_status', '2nd call', '3rd call', 27, '2026-01-26 05:37:24'),
(482, 71, 'lead_status', '3rd call', 'Will visit office', 27, '2026-01-26 05:42:36'),
(483, 71, 'campus_visit_date', NULL, '2026-01-27T11:00', 27, '2026-01-26 05:42:36'),
(484, 97, 'lead_status', '3rd call', 'Will visit office', 27, '2026-01-26 06:32:49'),
(485, 97, 'campus_visit_date', NULL, '2026-01-30T11:00', 27, '2026-01-26 06:32:49'),
(486, 97, 'campus_visit_date', '2026-01-30 11:00:00', '2026-01-30T11:00', 27, '2026-01-26 06:35:07'),
(487, 110, 'lead_status', '3rd call', 'Will visit office', 27, '2026-01-26 06:40:51'),
(488, 110, 'campus_visit_date', NULL, '2026-01-30T11:00', 27, '2026-01-26 06:40:51'),
(489, 183, 'lead_source', 'Direct Online', 'F2F Marketing', 3, '2026-01-26 06:41:15'),
(490, 184, 'lead_status', 'Fresh', 'Will visit office', 27, '2026-01-26 06:57:56'),
(491, 184, 'campus_visit_date', NULL, '2026-01-26T12:00', 27, '2026-01-26 06:57:56'),
(492, 184, 'lead_status', 'Will visit office', '2nd call', 27, '2026-01-26 07:00:27'),
(493, 184, 'lead_status', '2nd call', 'Will visit office', 27, '2026-01-26 07:03:32'),
(494, 184, 'campus_visit_date', NULL, '2026-01-26T13:00', 27, '2026-01-26 07:03:32'),
(495, 184, 'lead_status', 'Will visit office', 'Admitted', 27, '2026-01-26 07:33:07'),
(496, 184, 'lead_status', 'Admitted', '3rd call', 27, '2026-01-26 08:16:28'),
(497, 184, 'lead_status', '3rd call', 'Admitted', 27, '2026-01-26 08:17:22'),
(498, 184, 'lead_status', 'Admitted', 'Will visit office', 27, '2026-01-26 08:25:14'),
(499, 184, 'campus_visit_date', NULL, '2026-01-26T15:59', 27, '2026-01-26 08:25:14'),
(500, 184, 'campus_visit_date', '2026-01-26 15:59:00', '2026-01-26T15:59', 27, '2026-01-26 08:25:15'),
(501, 184, 'campus_visit_date', '2026-01-26 15:59:00', '2026-01-26T14:59', 27, '2026-01-26 08:26:44'),
(502, 184, 'lead_status', 'Will visit office', 'Admitted', 27, '2026-01-26 08:28:06'),
(503, 167, 'campus_visit_date', '2026-01-26 14:00:00', '2026-01-26T14:00', 27, '2026-01-26 09:13:41'),
(504, 186, 'lead_status', 'Fresh', 'Admitted', 27, '2026-01-26 09:28:49'),
(505, 186, 'lead_status', 'Admitted', '1st call', 27, '2026-01-26 09:30:01'),
(506, 186, 'lead_status', '1st call', 'Admitted', 27, '2026-01-26 09:32:06'),
(507, 186, 'lead_status', 'Admitted', 'Will visit office', 27, '2026-01-26 09:50:01'),
(508, 186, 'campus_visit_date', NULL, '2026-01-26T15:58', 27, '2026-01-26 09:50:01'),
(509, 186, 'lead_status', 'Will visit office', 'Admitted', 27, '2026-01-26 09:56:28'),
(510, 186, 'lead_status', 'Admitted', 'Will visit office', 27, '2026-01-26 10:21:18'),
(511, 186, 'campus_visit_date', NULL, '2026-01-26T16:21', 27, '2026-01-26 10:21:18'),
(512, 186, 'campus_visit_date', '2026-01-26 16:21:00', '2026-01-26T16:21', 27, '2026-01-26 10:21:19'),
(513, 186, 'lead_status', 'Will visit office', 'Admitted', 27, '2026-01-26 10:22:22'),
(514, 183, 'lead_status', 'Fresh', 'Dead', 29, '2026-01-26 10:29:07'),
(515, 185, 'lead_status', 'Fresh', '1st call', 29, '2026-01-26 10:29:43'),
(516, 189, 'lead_status', 'Fresh', 'Admitted', 27, '2026-01-26 10:36:30'),
(517, 188, 'lead_status', 'Fresh', '1st call', 27, '2026-01-26 10:37:08'),
(518, 189, 'lead_status', 'Admitted', '1st call', 27, '2026-01-26 10:37:37'),
(519, 189, 'lead_status', '1st call', 'Admitted', 27, '2026-01-26 10:38:16'),
(520, 188, 'lead_status', '1st call', 'Admitted', 27, '2026-01-26 10:40:38'),
(521, 186, 'lead_status', 'Admitted', 'Will visit office', 27, '2026-01-26 10:41:32'),
(522, 186, 'campus_visit_date', NULL, '2026-01-26T16:41', 27, '2026-01-26 10:41:32'),
(523, 186, 'campus_visit_date', '2026-01-26 16:41:00', '2026-01-26T16:41', 27, '2026-01-26 10:41:34'),
(524, 186, 'campus_visit_date', '2026-01-26 16:41:00', '2026-01-26T16:41', 27, '2026-01-26 10:46:25'),
(525, 186, 'lead_status', 'Will visit office', 'Admitted', 27, '2026-01-26 10:47:21'),
(526, 190, 'lead_status', 'Fresh', '1st call', 27, '2026-01-26 10:58:57'),
(527, 165, 'lead_status', '1st call', 'Will visit office', 24, '2026-01-26 11:08:10'),
(528, 165, 'campus_visit_date', NULL, '2026-01-26T17:08', 24, '2026-01-26 11:08:10'),
(529, 165, 'campus_visit_date', '2026-01-26 17:08:00', '2026-01-27T17:08', 24, '2026-01-26 11:08:25'),
(530, 121, 'lead_status', '2nd call', '3rd call', 27, '2026-01-26 11:11:32'),
(531, 179, 'lead_status', '1st call', '2nd call', 24, '2026-01-26 11:13:42'),
(532, 115, 'lead_status', '2nd call', 'Will visit office', 27, '2026-01-26 11:18:34'),
(533, 115, 'campus_visit_date', NULL, '2026-01-28T11:00', 27, '2026-01-26 11:18:34'),
(534, 115, 'campus_visit_date', '2026-01-28 11:00:00', '2026-01-28T11:00', 27, '2026-01-26 11:18:34'),
(535, 165, 'campus_visit_date', '2026-01-27 17:08:00', '2026-01-27T17:08', 24, '2026-01-26 11:53:39'),
(536, 163, 'lead_status', '1st call', '2nd call', 24, '2026-01-26 11:55:03'),
(537, 192, 'lead_status', 'Fresh', '1st call', 24, '2026-01-26 14:13:27'),
(538, 162, 'lead_status', '1st call', '2nd call', 24, '2026-01-26 14:15:52'),
(539, 161, 'lead_status', '1st call', '2nd call', 24, '2026-01-26 14:17:06'),
(540, 160, 'lead_status', '1st call', '2nd call', 24, '2026-01-26 14:19:01'),
(541, 193, 'lead_status', 'Fresh', '1st call', 24, '2026-01-26 14:22:51'),
(542, 159, 'lead_status', '1st call', '2nd call', 24, '2026-01-26 14:24:47'),
(543, 157, 'lead_status', '1st call', '2nd call', 24, '2026-01-26 14:29:09'),
(544, 156, 'lead_status', '1st call', 'Admitted', 24, '2026-01-26 14:31:17'),
(545, 154, 'lead_status', '1st call', '2nd call', 24, '2026-01-26 14:37:01'),
(546, 153, 'interested_course_id', '34', '44', 24, '2026-01-26 14:57:46'),
(547, 153, 'lead_status', '1st call', 'Admitted', 24, '2026-01-26 14:57:46'),
(548, 151, 'lead_status', '1st call', '2nd call', 24, '2026-01-26 14:59:53'),
(549, 150, 'lead_status', '1st call', 'Dead', 24, '2026-01-26 15:03:59'),
(550, 92, 'campus_visit_date', '2026-01-23 22:35:00', '2026-01-31T22:35', 24, '2026-01-26 15:07:14'),
(551, 83, 'lead_status', '1st call', '2nd call', 24, '2026-01-26 15:08:44'),
(552, 149, 'lead_status', '2nd call', '3rd call', 30, '2026-01-27 03:53:51'),
(553, 137, 'lead_status', '2nd call', '3rd call', 30, '2026-01-27 03:55:45'),
(554, 129, 'lead_status', '2nd call', '3rd call', 30, '2026-01-27 04:00:23'),
(555, 128, 'lead_status', '2nd call', '3rd call', 30, '2026-01-27 04:11:19'),
(556, 190, 'lead_status', '1st call', '2nd call', 27, '2026-01-27 04:12:36'),
(557, 190, 'address', '', 'mirpur 2 ', 27, '2026-01-27 04:14:25'),
(558, 190, 'lead_status', '2nd call', 'Will visit office', 27, '2026-01-27 04:14:25'),
(559, 190, 'campus_visit_date', NULL, '2026-01-27T16:00', 27, '2026-01-27 04:14:25'),
(560, 191, 'lead_status', 'Fresh', '1st call', 30, '2026-01-27 04:29:29'),
(561, 53, 'lead_status', '3rd call', 'Unable to reach once', 30, '2026-01-27 04:39:58'),
(562, 149, 'lead_status', '3rd call', 'Unable to reach twice', 30, '2026-01-27 04:40:19'),
(563, 182, 'lead_status', 'Will visit office', 'Admitted', 27, '2026-01-27 04:54:59'),
(564, 194, 'lead_status', 'Fresh', '1st call', 27, '2026-01-27 05:08:42'),
(565, 174, 'lead_status', '1st call', '2nd call', 27, '2026-01-27 05:12:25'),
(566, 166, 'lead_status', '1st call', '2nd call', 27, '2026-01-27 05:14:33'),
(567, 123, 'lead_status', '2nd call', '3rd call', 30, '2026-01-27 05:39:48'),
(568, 104, 'campus_visit_date', '2026-01-27 10:00:00', '2026-01-29T11:00', 27, '2026-01-27 05:51:13'),
(569, 103, 'campus_visit_date', '2026-01-27 11:00:00', '2026-01-29T11:00', 27, '2026-01-27 05:52:15'),
(570, 198, 'lead_status', 'Fresh', '1st call', 29, '2026-01-27 06:23:09'),
(571, 197, 'lead_status', 'Fresh', 'Will visit office', 27, '2026-01-27 06:25:53'),
(572, 197, 'campus_visit_date', NULL, '2026-01-30T09:00', 27, '2026-01-27 06:25:53'),
(573, 197, 'campus_visit_date', '2026-01-30 09:00:00', '2026-01-30T09:00', 27, '2026-01-27 06:25:56'),
(574, 199, 'lead_status', 'Fresh', '1st call', 29, '2026-01-27 06:27:05'),
(575, 195, 'lead_status', 'Fresh', '1st call', 30, '2026-01-27 06:35:22'),
(576, 200, 'lead_status', 'Fresh', '1st call', 27, '2026-01-27 06:44:26'),
(577, 200, 'lead_status', '1st call', 'Will visit office', 27, '2026-01-27 06:48:59'),
(578, 200, 'campus_visit_date', NULL, '2026-01-28T11:00', 27, '2026-01-27 06:48:59'),
(579, 200, 'campus_visit_date', '2026-01-28 11:00:00', '2026-01-28T11:00', 27, '2026-01-27 06:49:00'),
(580, 114, 'lead_status', '2nd call', '3rd call', 30, '2026-01-27 06:53:30'),
(581, 196, 'lead_status', 'Fresh', '1st call', 29, '2026-01-27 06:57:35'),
(582, 101, 'lead_status', '3rd call', 'Dead', 30, '2026-01-27 07:02:16'),
(583, 115, 'campus_visit_date', '2026-01-28 11:00:00', '2026-01-28T11:00', 3, '2026-01-27 07:17:14'),
(584, 97, 'campus_visit_date', '2026-01-30 11:00:00', '2026-01-30T11:00', 3, '2026-01-27 07:17:25'),
(585, 75, 'lead_status', 'Unable to reach once', 'Will visit office', 27, '2026-01-27 09:11:31'),
(586, 75, 'campus_visit_date', NULL, '2026-01-29T11:00', 27, '2026-01-27 09:11:31'),
(587, 96, 'lead_status', '3rd call', 'Dead', 30, '2026-01-27 09:18:02'),
(588, 88, 'lead_status', '3rd call', 'Dead', 27, '2026-01-27 09:19:47'),
(589, 91, 'lead_status', '2nd call', '3rd call', 30, '2026-01-27 09:19:52'),
(590, 87, 'lead_status', '2nd call', '3rd call', 30, '2026-01-27 09:22:13'),
(591, 139, 'lead_status', '3rd call', 'Will visit office', 27, '2026-01-27 09:26:55'),
(592, 139, 'campus_visit_date', NULL, '2026-01-29T11:00', 27, '2026-01-27 09:26:55'),
(593, 102, 'campus_visit_date', '2026-01-27 11:00:00', '2026-01-29T11:00', 27, '2026-01-27 09:30:27'),
(594, 118, 'lead_status', '2nd call', 'Will visit office', 27, '2026-01-27 09:35:17'),
(595, 118, 'campus_visit_date', NULL, '2026-01-31T11:00', 27, '2026-01-27 09:35:17'),
(596, 105, 'last_name', 'Ahmed', 'Jubayer', 27, '2026-01-27 09:39:06'),
(597, 105, 'lead_status', 'Will visit office', 'Admitted', 27, '2026-01-27 09:39:06'),
(598, 107, 'lead_status', 'Will visit office', 'Dead', 27, '2026-01-27 09:44:15'),
(599, 111, 'lead_status', 'Will visit office', '3rd call', 27, '2026-01-27 09:47:15'),
(600, 119, 'lead_status', '2nd call', '3rd call', 27, '2026-01-27 09:48:52'),
(601, 112, 'lead_status', '3rd call', 'Will visit office', 27, '2026-01-27 09:50:35'),
(602, 112, 'campus_visit_date', NULL, '2026-02-15T10:46', 27, '2026-01-27 09:50:35'),
(603, 178, 'lead_status', '1st call', '2nd call', 24, '2026-01-27 11:02:58'),
(604, 176, 'lead_status', '1st call', '2nd call', 24, '2026-01-27 11:04:04'),
(605, 175, 'lead_status', '1st call', '2nd call', 24, '2026-01-27 11:04:50'),
(606, 173, 'lead_status', '1st call', '2nd call', 24, '2026-01-27 11:09:16'),
(607, 172, 'lead_status', '1st call', '2nd call', 24, '2026-01-27 11:17:15'),
(608, 171, 'lead_status', '1st call', '2nd call', 24, '2026-01-27 11:18:30'),
(609, 170, 'hsc_gpa', '3.60', '3.67', 24, '2026-01-27 11:21:42'),
(610, 170, 'lead_status', '1st call', '2nd call', 24, '2026-01-27 11:21:42'),
(611, 169, 'lead_status', '1st call', 'Dead', 24, '2026-01-27 11:24:09'),
(612, 165, 'campus_visit_date', '2026-01-27 17:08:00', '2026-01-31T17:08', 24, '2026-01-27 11:24:58'),
(613, 163, 'lead_status', '2nd call', '3rd call', 24, '2026-01-27 11:26:03'),
(614, 161, 'lead_status', '2nd call', '3rd call', 24, '2026-01-27 11:27:30'),
(615, 151, 'lead_status', '2nd call', '3rd call', 24, '2026-01-27 11:28:50'),
(616, 160, 'lead_status', '2nd call', '3rd call', 24, '2026-01-27 11:31:59'),
(617, 148, 'lead_status', '2nd call', 'Dead', 24, '2026-01-27 11:35:45'),
(618, 146, 'lead_status', '2nd call', '3rd call', 24, '2026-01-27 11:38:28'),
(619, 144, 'lead_status', '2nd call', 'Dead', 24, '2026-01-27 11:40:56'),
(620, 163, 'lead_status', '3rd call', 'Admitted', 24, '2026-01-27 11:42:18'),
(621, 143, 'lead_status', '1st call', '2nd call', 24, '2026-01-27 11:43:47'),
(622, 140, 'lead_status', '2nd call', '3rd call', 24, '2026-01-27 12:04:33'),
(623, 127, 'lead_status', '2nd call', '3rd call', 24, '2026-01-27 12:08:45'),
(624, 125, 'lead_status', '2nd call', '3rd call', 24, '2026-01-27 12:14:57'),
(625, 124, 'lead_status', '2nd call', 'Dead', 24, '2026-01-27 12:16:52'),
(626, 89, 'lead_status', '2nd call', '3rd call', 24, '2026-01-27 15:11:05'),
(627, 55, 'campus_visit_date', '2026-01-27 14:35:00', '2026-01-29T14:35', 24, '2026-01-27 15:13:16'),
(628, 55, 'campus_visit_date', '2026-01-29 14:35:00', '2026-01-29T14:35', 24, '2026-01-27 15:13:31'),
(629, 51, 'lead_status', '2nd call', '3rd call', 24, '2026-01-27 15:14:45'),
(630, 50, 'lead_status', '2nd call', 'Dead', 24, '2026-01-27 15:16:37'),
(631, 190, 'lead_status', 'Will visit office', 'Admitted', 27, '2026-01-28 03:44:29'),
(632, 119, 'lead_status', '3rd call', 'Will visit office', 27, '2026-01-28 03:45:33'),
(633, 119, 'campus_visit_date', NULL, '2026-01-29T10:45', 27, '2026-01-28 03:45:33'),
(634, 119, 'campus_visit_date', '2026-01-29 10:45:00', '2026-01-29T10:45', 27, '2026-01-28 03:45:50'),
(635, 194, 'lead_status', '1st call', '2nd call', 27, '2026-01-28 03:59:39'),
(636, 205, 'lead_status', 'Fresh', '1st call', 27, '2026-01-28 04:07:48'),
(637, 204, 'lead_status', 'Fresh', '1st call', 27, '2026-01-28 04:08:09'),
(638, 167, 'campus_visit_date', '2026-01-26 14:00:00', '2026-01-29T14:00', 27, '2026-01-28 04:12:13'),
(639, 180, 'lead_status', '1st call', '2nd call', 30, '2026-01-28 04:14:36'),
(640, 116, 'lead_status', '3rd call', 'Dead', 30, '2026-01-28 04:18:31'),
(641, 62, 'lead_status', '3rd call', 'Will visit office', 27, '2026-01-28 04:21:20'),
(642, 62, 'campus_visit_date', NULL, '2026-01-30T10:00', 27, '2026-01-28 04:21:20'),
(643, 167, 'campus_visit_date', '2026-01-29 14:00:00', '2026-01-29T14:00', 27, '2026-01-28 04:26:04'),
(644, 152, 'lead_status', '2nd call', '3rd call', 27, '2026-01-28 04:28:01'),
(645, 115, 'campus_visit_date', '2026-01-28 11:00:00', '2026-01-29T11:00', 27, '2026-01-28 04:33:32'),
(646, 115, 'campus_visit_date', '2026-01-29 11:00:00', '2026-01-29T11:00', 27, '2026-01-28 04:34:06'),
(647, 181, 'lead_status', '1st call', '2nd call', 30, '2026-01-28 04:35:33'),
(648, 95, 'lead_status', '3rd call', 'Dead', 27, '2026-01-28 04:37:33'),
(649, 79, 'campus_visit_date', '2026-01-31 11:35:00', '2026-01-30T11:00', 27, '2026-01-28 04:40:07'),
(650, 200, 'lead_status', 'Will visit office', 'Admitted', 27, '2026-01-28 04:45:55'),
(651, 207, 'lead_status', '1st call', 'Will visit office', 27, '2026-01-28 05:08:12'),
(652, 207, 'campus_visit_date', NULL, '2026-01-29T11:00', 27, '2026-01-28 05:08:12'),
(653, 209, 'lead_status', 'Fresh', '1st call', 27, '2026-01-28 05:22:21'),
(654, 203, 'lead_status', 'Fresh', '1st call', 30, '2026-01-28 05:34:26'),
(655, 212, 'lead_status', 'Fresh', '1st call', 27, '2026-01-28 05:52:17'),
(656, 213, 'lead_status', 'Fresh', '1st call', 27, '2026-01-28 05:52:40'),
(657, 177, 'lead_status', '1st call', '2nd call', 30, '2026-01-28 06:01:05'),
(658, 210, 'lead_status', 'Fresh', '1st call', 27, '2026-01-28 06:05:30'),
(659, 214, 'lead_status', 'Fresh', 'Admitted', 27, '2026-01-28 06:11:33'),
(660, 218, 'lead_source', 'Direct Online', 'Direct Campus Visit', 29, '2026-01-28 07:15:49'),
(661, 218, 'lead_status', 'Fresh', 'Will visit office', 29, '2026-01-28 07:15:49'),
(662, 218, 'campus_visit_date', NULL, '2026-01-28T13:15', 29, '2026-01-28 07:15:49'),
(663, 219, 'lead_status', 'Fresh', '1st call', 27, '2026-01-28 07:30:53'),
(664, 225, 'lead_status', 'Fresh', 'Will visit office', 30, '2026-01-28 08:11:47'),
(665, 225, 'campus_visit_date', NULL, '2026-01-28T14:11', 30, '2026-01-28 08:11:47'),
(666, 222, 'lead_status', 'Fresh', 'Will visit office', 30, '2026-01-28 08:12:16'),
(667, 222, 'campus_visit_date', NULL, '2026-01-28T14:12', 30, '2026-01-28 08:12:16'),
(668, 227, 'lead_status', 'Fresh', '1st call', 27, '2026-01-28 09:25:26'),
(669, 231, 'address', '', 'Rangpur', 27, '2026-01-28 09:26:37'),
(670, 231, 'lead_status', 'Fresh', '1st call', 27, '2026-01-28 09:26:37'),
(671, 230, 'lead_status', 'Fresh', '1st call', 27, '2026-01-28 09:58:43'),
(672, 228, 'lead_status', 'Fresh', '1st call', 27, '2026-01-28 09:59:29'),
(673, 229, 'lead_status', 'Fresh', '1st call', 30, '2026-01-28 09:59:31'),
(674, 226, 'lead_status', 'Fresh', '1st call', 27, '2026-01-28 10:00:17'),
(675, 224, 'lead_status', 'Fresh', 'Dead', 30, '2026-01-28 10:06:54'),
(676, 223, 'lead_status', 'Fresh', '1st call', 30, '2026-01-28 10:10:02'),
(677, 206, 'lead_status', 'Fresh', '1st call', 27, '2026-01-28 10:16:35'),
(678, 223, 'lead_status', '1st call', '2nd call', 30, '2026-01-28 10:18:15'),
(679, 223, 'lead_status', '2nd call', '1st call', 30, '2026-01-28 10:18:44'),
(680, 221, 'lead_status', 'Fresh', '1st call', 30, '2026-01-28 10:19:59'),
(681, 201, 'current_city', '', 'Dhaka', 27, '2026-01-28 10:29:21'),
(682, 201, 'lead_status', '1st call', 'Admitted', 27, '2026-01-28 10:29:21'),
(683, 220, 'lead_status', 'Fresh', '1st call', 30, '2026-01-28 11:19:45'),
(684, 235, 'lead_status', 'Fresh', '1st call', 27, '2026-01-28 11:24:13'),
(685, 76, 'campus_visit_date', '2026-01-29 11:00:00', '2026-02-20T11:00', 27, '2026-01-28 11:28:14'),
(686, 71, 'campus_visit_date', '2026-01-27 11:00:00', '2026-01-30T11:00', 27, '2026-01-28 11:29:20'),
(687, 237, 'lead_status', 'Fresh', '1st call', 27, '2026-01-28 11:37:26'),
(688, 193, 'interested_course_id', '34', '36', 24, '2026-01-28 13:44:13'),
(689, 193, 'lead_status', '1st call', '2nd call', 24, '2026-01-28 13:44:20'),
(690, 192, 'lead_status', '1st call', '2nd call', 24, '2026-01-28 13:46:20'),
(691, 193, 'lead_status', '2nd call', '3rd call', 24, '2026-01-28 13:48:57'),
(692, 193, 'lead_status', '3rd call', '2nd call', 24, '2026-01-28 13:49:06'),
(693, 179, 'lead_status', '2nd call', '3rd call', 24, '2026-01-28 13:51:35'),
(694, 171, 'lead_status', '2nd call', '3rd call', 24, '2026-01-28 13:52:38'),
(695, 159, 'lead_status', '2nd call', '3rd call', 24, '2026-01-28 13:58:38'),
(696, 143, 'lead_status', '2nd call', '3rd call', 24, '2026-01-28 14:10:07'),
(697, 143, 'lead_status', '3rd call', 'Unable to reach once', 24, '2026-01-28 14:19:22'),
(698, 242, 'lead_status', 'Fresh', '1st call', 24, '2026-01-29 03:30:32'),
(699, 193, 'lead_status', '2nd call', '3rd call', 24, '2026-01-29 03:35:45'),
(700, 178, 'lead_status', '2nd call', '3rd call', 24, '2026-01-29 04:42:23'),
(701, 244, 'lead_status', 'Fresh', '1st call', 24, '2026-01-29 04:56:14'),
(702, 175, 'lead_status', '2nd call', '3rd call', 24, '2026-01-29 05:17:12'),
(703, 195, 'lead_status', '1st call', '2nd call', 30, '2026-01-29 05:17:45'),
(704, 245, 'lead_status', 'Fresh', 'Admitted', 24, '2026-01-29 05:27:13'),
(705, 170, 'lead_status', '2nd call', '3rd call', 24, '2026-01-29 05:30:41'),
(706, 157, 'lead_status', '2nd call', '3rd call', 24, '2026-01-29 05:35:17'),
(707, 158, 'lead_status', '1st call', '2nd call', 24, '2026-01-29 05:35:35'),
(708, 225, 'lead_status', 'Will visit office', 'Admitted', 30, '2026-01-29 05:58:25'),
(709, 216, 'lead_status', '1st call', 'Admitted', 30, '2026-01-29 06:00:49'),
(710, 247, 'lead_status', 'Fresh', '1st call', 24, '2026-01-29 06:06:57'),
(711, 246, 'lead_status', 'Fresh', '1st call', 24, '2026-01-29 06:07:09'),
(712, 211, 'lead_status', 'Fresh', '1st call', 29, '2026-01-29 06:10:53'),
(713, 195, 'lead_status', '2nd call', '3rd call', 30, '2026-01-29 06:11:05'),
(714, 191, 'lead_status', '1st call', '2nd call', 30, '2026-01-29 06:13:24'),
(715, 137, 'lead_status', '3rd call', 'Unable to reach once', 30, '2026-01-29 06:29:26'),
(716, 89, 'lead_status', '3rd call', 'Unable to reach once', 24, '2026-01-29 06:33:58'),
(717, 249, 'lead_status', 'Fresh', '1st call', 30, '2026-01-29 06:45:44'),
(718, 241, 'lead_status', 'Fresh', '1st call', 30, '2026-01-29 07:01:47'),
(719, 253, 'campus_visit_date', '2026-01-30 13:44:00', '2026-01-30T13:44', 29, '2026-01-29 07:50:15'),
(720, 250, 'lead_status', 'Fresh', '1st call', 24, '2026-01-29 07:53:08'),
(721, 251, 'lead_status', 'Fresh', '1st call', 24, '2026-01-29 07:53:18'),
(722, 248, 'lead_status', 'Fresh', '1st call', 24, '2026-01-29 07:53:30'),
(723, 55, 'campus_visit_date', '2026-01-29 14:35:00', '2026-01-30T14:35', 24, '2026-01-29 07:55:23'),
(724, 242, 'lead_status', '1st call', 'Admitted', 24, '2026-01-29 08:07:01'),
(725, 239, 'lead_status', 'Fresh', '1st call', 30, '2026-01-29 08:08:06'),
(726, 51, 'lead_status', '3rd call', 'Unable to reach trice', 24, '2026-01-29 08:09:18'),
(727, 238, 'lead_status', 'Fresh', '1st call', 24, '2026-01-29 08:52:41');
INSERT INTO `lead_edit_history` (`id`, `lead_id`, `field_name`, `old_value`, `new_value`, `edited_by`, `edited_at`) VALUES
(728, 240, 'lead_status', 'Fresh', 'Unable to reach once', 30, '2026-01-29 09:38:39'),
(729, 255, 'lead_status', 'Fresh', '1st call', 24, '2026-01-29 09:49:53'),
(730, 119, 'campus_visit_date', '2026-01-29 10:45:00', '2026-01-29T10:45', 29, '2026-01-29 10:15:58'),
(731, 218, 'campus_visit_date', '2026-01-28 13:15:00', '2026-01-28T13:15', 29, '2026-01-29 10:26:59'),
(732, 119, 'lead_status', 'Will visit office', 'Dead', 27, '2026-01-29 12:00:20'),
(733, 75, 'lead_status', 'Will visit office', 'Dead', 27, '2026-01-29 12:07:07'),
(734, 102, 'lead_status', 'Will visit office', 'Dead', 27, '2026-01-29 13:35:21'),
(735, 167, 'lead_status', 'Will visit office', 'Admitted', 27, '2026-01-29 13:48:20'),
(736, 237, 'lead_status', '1st call', 'Will visit office', 27, '2026-01-29 13:59:36'),
(737, 237, 'campus_visit_date', NULL, '2026-01-30T11:00', 27, '2026-01-29 13:59:36'),
(738, 237, 'campus_visit_date', '2026-01-30 11:00:00', '2026-01-30T11:00', 27, '2026-01-29 14:00:21'),
(739, 237, 'campus_visit_date', '2026-01-30 11:00:00', '2026-01-30T11:00', 27, '2026-01-29 14:00:56'),
(740, 235, 'lead_status', '1st call', '2nd call', 27, '2026-01-29 15:32:23'),
(741, 231, 'lead_status', '1st call', '2nd call', 27, '2026-01-29 15:33:36'),
(742, 230, 'lead_status', '1st call', '2nd call', 27, '2026-01-29 15:34:37'),
(743, 213, 'lead_status', '1st call', 'Admitted', 27, '2026-01-29 15:37:18'),
(744, 212, 'lead_status', '1st call', 'Admitted', 27, '2026-01-29 15:43:58'),
(745, 210, 'lead_status', '1st call', '2nd call', 27, '2026-01-29 15:46:51'),
(746, 207, 'lead_status', 'Will visit office', '2nd call', 27, '2026-01-29 15:49:06'),
(747, 199, 'lead_status', '1st call', '2nd call', 27, '2026-01-29 15:49:57'),
(748, 139, 'campus_visit_date', '2026-01-29 11:00:00', '2026-01-31T11:00', 27, '2026-01-29 15:53:38'),
(749, 166, 'lead_status', '2nd call', '3rd call', 27, '2026-01-29 15:54:30'),
(750, 115, 'lead_status', 'Will visit office', 'Dead', 27, '2026-01-29 15:56:38'),
(751, 110, 'campus_visit_date', '2026-01-30 11:00:00', '2026-01-30T11:00', 27, '2026-01-29 15:59:31'),
(752, 104, 'campus_visit_date', '2026-01-29 11:00:00', '2026-02-04T11:00', 27, '2026-01-29 16:00:45'),
(753, 103, 'campus_visit_date', '2026-01-29 11:00:00', '2026-02-04T11:00', 27, '2026-01-29 16:01:27'),
(754, 251, 'ssc_gpa', '4.00', '3.72', 24, '2026-01-30 05:18:51'),
(755, 251, 'hsc_gpa', '3.22', '3.5', 24, '2026-01-30 05:18:51'),
(756, 251, 'lead_status', '1st call', '2nd call', 24, '2026-01-30 05:18:51'),
(757, 250, 'lead_status', '1st call', '2nd call', 24, '2026-01-30 05:19:26'),
(758, 247, 'lead_status', '1st call', '2nd call', 24, '2026-01-30 05:27:34'),
(759, 244, 'lead_status', '1st call', '2nd call', 24, '2026-01-30 05:29:24'),
(760, 193, 'lead_status', '3rd call', 'Unable to reach once', 24, '2026-01-30 05:31:23'),
(761, 192, 'lead_status', '2nd call', 'Dead', 24, '2026-01-30 05:33:17'),
(762, 179, 'lead_status', '3rd call', 'Unable to reach twice', 24, '2026-01-30 05:34:47'),
(763, 178, 'lead_status', '3rd call', 'Unable to reach once', 24, '2026-01-30 05:36:20'),
(764, 176, 'lead_status', '2nd call', '3rd call', 24, '2026-01-30 05:42:21'),
(765, 255, 'lead_status', '1st call', '2nd call', 24, '2026-01-30 05:46:16'),
(766, 173, 'lead_status', '2nd call', '3rd call', 24, '2026-01-30 06:13:17'),
(767, 172, 'lead_status', '2nd call', '3rd call', 24, '2026-01-30 06:32:59'),
(768, 236, 'lead_status', 'Fresh', '1st call', 27, '2026-01-30 06:40:38'),
(769, 236, 'lead_status', '1st call', '2nd call', 27, '2026-01-30 06:40:54'),
(770, 233, 'lead_status', '1st call', '2nd call', 27, '2026-01-30 06:44:00'),
(771, 234, 'lead_status', '1st call', '2nd call', 27, '2026-01-30 06:45:35'),
(772, 228, 'lead_status', '1st call', '2nd call', 27, '2026-01-30 06:49:15'),
(773, 162, 'address', '', 'kushtia ', 24, '2026-01-30 06:50:37'),
(774, 227, 'lead_status', '1st call', '2nd call', 27, '2026-01-30 06:50:52'),
(775, 226, 'lead_status', '1st call', '2nd call', 27, '2026-01-30 06:51:45'),
(776, 219, 'lead_status', '1st call', '2nd call', 27, '2026-01-30 06:56:31'),
(777, 118, 'campus_visit_date', '2026-01-31 11:00:00', '2026-01-31T11:00', 27, '2026-01-30 06:58:25'),
(778, 155, 'lead_status', '1st call', '2nd call', 24, '2026-01-30 07:58:00'),
(779, 255, 'lead_status', '2nd call', '3rd call', 24, '2026-01-30 08:02:22'),
(780, 255, 'lead_status', '3rd call', 'Unable to reach once', 24, '2026-01-30 08:02:49'),
(781, 253, 'campus_visit_date', '2026-01-30 13:44:00', '2026-01-31T13:44', 24, '2026-01-30 08:05:42'),
(782, 218, 'lead_status', 'Will visit office', '2nd call', 29, '2026-01-30 08:06:19'),
(783, 255, 'lead_status', 'Unable to reach once', '3rd call', 24, '2026-01-30 08:10:27'),
(784, 177, 'lead_status', '2nd call', 'Admitted', 29, '2026-01-30 08:18:11'),
(785, 143, 'lead_status', 'Unable to reach once', '3rd call', 24, '2026-01-30 09:50:39'),
(786, 140, 'lead_status', '3rd call', 'Dead', 24, '2026-01-30 09:53:40'),
(787, 125, 'lead_status', '3rd call', 'Unable to reach once', 24, '2026-01-30 10:09:15'),
(788, 125, 'lead_status', 'Unable to reach once', '3rd call', 24, '2026-01-30 10:13:41'),
(789, 79, 'lead_status', 'Will visit office', 'Admitted', 24, '2026-01-30 10:18:57'),
(790, 271, 'lead_status', 'Fresh', '1st call', 24, '2026-01-30 10:37:03'),
(791, 270, 'lead_status', 'Fresh', '1st call', 24, '2026-01-30 10:37:09'),
(792, 89, 'lead_status', 'Unable to reach once', '3rd call', 24, '2026-01-30 10:41:49'),
(793, 62, 'lead_status', 'Will visit office', '3rd call', 24, '2026-01-30 10:45:01'),
(794, 55, 'lead_status', 'Will visit office', '3rd call', 24, '2026-01-30 10:48:05'),
(795, 257, 'lead_status', 'Fresh', '1st call', 24, '2026-01-30 10:52:17'),
(796, 237, 'lead_status', 'Will visit office', '3rd call', 27, '2026-01-30 11:24:03'),
(797, 235, 'lead_status', '2nd call', '3rd call', 27, '2026-01-30 11:45:25'),
(798, 231, 'lead_status', '2nd call', '3rd call', 27, '2026-01-30 11:54:45'),
(799, 230, 'lead_status', '2nd call', '3rd call', 27, '2026-01-30 11:55:43'),
(800, 276, 'lead_status', 'Fresh', '1st call', 24, '2026-01-30 11:56:41'),
(801, 273, 'lead_status', 'Fresh', '1st call', 24, '2026-01-30 11:56:52'),
(802, 197, 'lead_status', 'Will visit office', '3rd call', 27, '2026-01-30 12:22:53'),
(803, 210, 'lead_status', '2nd call', '3rd call', 27, '2026-01-30 12:33:34'),
(804, 274, 'lead_status', 'Fresh', '1st call', 27, '2026-01-30 12:34:11'),
(805, 209, 'lead_status', '1st call', '2nd call', 27, '2026-01-30 12:39:10'),
(806, 207, 'address', '', 'Mirpur 12', 27, '2026-01-30 12:51:09'),
(807, 207, 'lead_status', '2nd call', 'Will visit office', 27, '2026-01-30 12:51:09'),
(808, 207, 'campus_visit_date', NULL, '2026-01-31T11:00', 27, '2026-01-30 12:51:09'),
(809, 205, 'lead_status', '1st call', 'Will visit office', 27, '2026-01-30 12:55:30'),
(810, 205, 'campus_visit_date', NULL, '2026-01-31T11:00', 27, '2026-01-30 12:55:30'),
(811, 205, 'campus_visit_date', '2026-01-31 11:00:00', '2026-01-31T11:00', 27, '2026-01-30 12:55:49'),
(812, 204, 'lead_status', '1st call', 'Will visit office', 27, '2026-01-30 12:56:30'),
(813, 204, 'campus_visit_date', NULL, '2026-01-31T11:00', 27, '2026-01-30 12:56:30'),
(814, 196, 'lead_status', '1st call', '2nd call', 27, '2026-01-30 12:58:03'),
(815, 199, 'lead_status', '2nd call', '3rd call', 27, '2026-01-30 13:00:20'),
(816, 194, 'lead_status', '2nd call', '3rd call', 27, '2026-01-30 13:03:13'),
(817, 97, 'campus_visit_date', '2026-01-30 11:00:00', '2026-01-31T11:00', 27, '2026-01-30 13:07:36'),
(818, 97, 'campus_visit_date', '2026-01-31 11:00:00', '2026-01-31T11:00', 27, '2026-01-30 13:08:09'),
(819, 187, 'lead_status', '1st call', '2nd call', 27, '2026-01-30 13:09:51'),
(820, 71, 'lead_status', 'Will visit office', 'Dead', 27, '2026-01-30 13:14:43'),
(821, 110, 'lead_status', 'Will visit office', '3rd call', 27, '2026-01-30 13:17:45'),
(822, 185, 'lead_status', '1st call', 'Admitted', 27, '2026-01-30 13:26:06'),
(823, 174, 'lead_status', '2nd call', 'Dead', 27, '2026-01-30 13:29:16'),
(824, 139, 'lead_status', 'Will visit office', '3rd call', 27, '2026-01-30 13:37:37'),
(825, 243, 'lead_status', 'Fresh', '1st call', 27, '2026-01-30 13:49:07'),
(826, 259, 'lead_status', 'Fresh', '1st call', 27, '2026-01-30 13:53:23'),
(827, 260, 'lead_status', 'Fresh', '1st call', 27, '2026-01-30 14:16:52'),
(828, 264, 'lead_status', 'Fresh', 'Dead', 27, '2026-01-30 14:18:43'),
(829, 263, 'lead_status', 'Fresh', '1st call', 27, '2026-01-30 14:28:02');

-- --------------------------------------------------------

--
-- Table structure for table `lead_notes`
--

CREATE TABLE `lead_notes` (
  `id` int NOT NULL,
  `lead_id` int NOT NULL,
  `note_text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lead_notes`
--

INSERT INTO `lead_notes` (`id`, `lead_id`, `note_text`, `created_by`, `created_at`) VALUES
(51, 75, 'student applied BA in English but hw wants Ba in bng . he will contact within 1 week', 27, '2026-01-20 07:52:07'),
(52, 73, 'Student provides faluse data', 27, '2026-01-20 08:01:15'),
(53, 76, '1 week er modhee janabe', 27, '2026-01-20 08:06:29'),
(54, 78, 'student diploma korche, system e diploma option lagbe,  campus visit niye system update korte hobe, manual folloup date set korte hobe. ', 27, '2026-01-20 08:13:25'),
(55, 79, 'Student asbe and direct vorti hbe. ', 27, '2026-01-20 08:16:43'),
(56, 72, 'city University te admitted ', 27, '2026-01-20 08:45:00'),
(57, 78, 'previous visit  & today provinding all information he decided  to take admission ', 27, '2026-01-20 08:51:16'),
(58, 80, 'Diploma holder evening batch, Ajke admit hote aste chasce ', 27, '2026-01-20 09:13:32'),
(59, 78, 'Agent lead, Md Nayan Mia', 3, '2026-01-20 09:19:37'),
(60, 81, 'whatsapp e contact hoise information , 2 jon aksathe admit ', 27, '2026-01-20 09:30:32'),
(61, 71, 'interested . Ai week er modheee aste casce', 27, '2026-01-20 09:37:10'),
(62, 82, 'direct call & providing all information ', 27, '2026-01-20 09:48:50'),
(63, 83, 'Visited & information , will admit within 1 week ', 3, '2026-01-20 09:56:39'),
(64, 70, 'Decision niye janaben ', 27, '2026-01-20 10:13:17'),
(65, 69, 'se vorti hobe na & bolesen vortir jonno kono form fill up kore ni ', 27, '2026-01-20 10:19:25'),
(66, 67, 'student false number dise', 27, '2026-01-20 10:30:06'),
(67, 66, 'Number ti beabohar hosse na ', 27, '2026-01-20 10:32:27'),
(68, 65, 'provide false number', 27, '2026-01-20 10:37:20'),
(69, 64, 'decision nibe but aste boleci ', 27, '2026-01-20 10:44:33'),
(70, 77, 'not picked', 27, '2026-01-20 10:47:32'),
(71, 64, 'not picked', 27, '2026-01-20 10:50:19'),
(72, 61, 'Phone off', 3, '2026-01-20 10:52:17'),
(73, 62, 'phone rcv kore ni', 3, '2026-01-20 10:53:34'),
(74, 63, 'Student fake information dise , HSC e complete kore ni', 27, '2026-01-20 10:55:08'),
(75, 63, 'Student already admitted', 3, '2026-01-20 10:55:25'),
(76, 80, 'Lead attended office visit on 2026-01-20 10:58:37\n\nNotes: student sokol info niyeche, pore amader janabe, amra 3/4 din por ekta call dibo\r\n', 3, '2026-01-20 10:58:37'),
(77, 85, 'Provide false Number', 27, '2026-01-20 11:07:47'),
(78, 84, 'Fake & Fun information', 27, '2026-01-20 11:10:21'),
(79, 81, 'Ajke admit hobe & aksathe 2 jon admit hobe ( 10:42 am call time_ unara already rouna hoise)', 27, '2026-01-21 04:43:26'),
(80, 62, 'Again not picked', 27, '2026-01-21 04:46:56'),
(81, 77, 'Again not Picked', 27, '2026-01-21 05:00:32'),
(82, 98, '23 tarik er modhe decision janaben . Friday admit hote chasce ', 27, '2026-01-21 05:16:11'),
(83, 81, '2 jon aksathe admit howar kotha bolecilen but apatoto 1 jon admit hoise ', 27, '2026-01-21 05:18:11'),
(84, 99, 'FB te information & porobortite visit kore decision nise (Equivalence issues on condition )\r\n20 January admitted \r\n ', 27, '2026-01-21 05:56:50'),
(85, 100, 'FB & whatsapp information \r\nadmit 20 January ', 27, '2026-01-21 06:06:02'),
(86, 101, 'Class korte parbe na information nise year gap (HSC 2017) Bangla te admit hote parbe . Decision niye janabe', 27, '2026-01-21 06:13:35'),
(87, 102, 'information niyese 1 week er modhee asbe foridpur theke', 27, '2026-01-21 06:27:56'),
(88, 102, 'Hostel information dawa hoise 1 week er modheee asbe admit hote ', 27, '2026-01-21 06:37:41'),
(89, 103, 'FB Whatsapp call all information & Visited', 27, '2026-01-21 07:11:45'),
(90, 104, 'FB Whatsapp call all information & Visited', 27, '2026-01-21 07:11:47'),
(91, 105, 'Bro Vhai amader university te porche. Tara pore janabe ', 27, '2026-01-21 07:11:51'),
(92, 106, 'Dission niye pore janabe ', 27, '2026-01-21 07:16:37'),
(93, 107, 'Information Niyeche , pore janabe chinta kore ', 27, '2026-01-21 07:24:37'),
(94, 108, 'Wife admit hobe  basha versity er pasei  tini visit korbe . Friday te or thursday visit korbe .Diploma holer eveing batch', 27, '2026-01-21 08:11:06'),
(95, 109, 'last semester visited but vorti hoini porobortite phone call e contact korese & today admitted', 27, '2026-01-21 08:21:40'),
(96, 111, 'PU Brother ache , pore janabe ', 27, '2026-01-21 09:29:16'),
(97, 112, 'Information nite asche , pore janabe. diploma holder ', 27, '2026-01-21 09:53:47'),
(98, 83, 'boro vai er sathe  kotha bole decision nibe 23 tarik aste boleci  vortir jonno  ', 27, '2026-01-21 10:14:05'),
(99, 74, 'Again Not rached', 27, '2026-01-21 10:27:00'),
(100, 61, 'Phn off', 27, '2026-01-21 10:31:27'),
(101, 60, 'Call receive kore nai ', 29, '2026-01-21 10:33:57'),
(102, 60, 'No interested', 29, '2026-01-21 10:48:59'),
(103, 113, 'Ai Sopthe asbe', 31, '2026-01-21 10:53:40'),
(104, 110, '30 january admit hobe confirm korese', 27, '2026-01-21 11:01:58'),
(105, 110, '30 january admit hobe confirm korese', 27, '2026-01-21 11:01:58'),
(106, 57, 'Not interest ', 29, '2026-01-21 11:06:32'),
(107, 55, '25 Tarhik janabe ', 29, '2026-01-21 11:19:25'),
(108, 97, '25 tarik admit hote asbe sirajgonj theke asbe  ', 27, '2026-01-21 11:21:27'),
(109, 96, 'not picked', 27, '2026-01-21 11:25:00'),
(110, 92, 'Not picked', 27, '2026-01-21 11:30:32'),
(111, 117, '25 Visit korte ashbe ', 29, '2026-01-22 04:48:52'),
(112, 91, 'dont pick up phn', 30, '2026-01-22 05:32:49'),
(113, 87, 'dont pick up phn', 30, '2026-01-22 05:44:34'),
(114, 118, '30 tarikher moddhe asbe', 31, '2026-01-22 05:44:54'),
(115, 119, '25tarikh asbe', 31, '2026-01-22 05:47:38'),
(116, 120, 'Information niyeche pore janabe. ', 29, '2026-01-22 05:52:41'),
(117, 79, 'Tomorrow Ashbe admit hote 2 jon LLM', 29, '2026-01-22 06:05:06'),
(118, 121, 'Ai Months Ashbe visit korte ', 29, '2026-01-22 06:09:22'),
(119, 93, 'kal vorti hote asbe', 30, '2026-01-22 06:25:15'),
(120, 122, 'PU student er ref admitted hoyche ', 29, '2026-01-22 06:26:14'),
(121, 123, 'campus visit', 30, '2026-01-22 06:45:01'),
(122, 129, 'Information niyche pore janabe ', 29, '2026-01-22 07:34:47'),
(123, 130, 'admit hobe 25 tarihk ashbe', 29, '2026-01-22 07:57:42'),
(124, 132, 'Agami kal admit hobe. ', 29, '2026-01-22 08:18:02'),
(125, 135, 'Agami Kal Ashbe', 29, '2026-01-22 10:11:08'),
(126, 136, 'Information nite Hobe ', 29, '2026-01-22 10:17:14'),
(127, 128, 'busy', 30, '2026-01-22 10:25:25'),
(128, 128, 'busy', 30, '2026-01-22 10:28:23'),
(129, 126, 'visit tomorrow', 30, '2026-01-22 10:35:17'),
(130, 52, 'no interest ', 29, '2026-01-22 10:39:05'),
(131, 116, '24 tarikh visit korben', 30, '2026-01-22 10:42:00'),
(132, 86, 'talk to later', 30, '2026-01-22 10:48:41'),
(133, 80, 'Not picked\r\n\r\n', 27, '2026-01-22 11:13:23'),
(134, 77, '3 days call but not picked', 27, '2026-01-22 11:23:44'),
(135, 94, 'pore update janabe', 30, '2026-01-22 11:25:16'),
(136, 80, 'Will Visit 26 jan', 27, '2026-01-22 11:25:40'),
(137, 76, 'not picked', 27, '2026-01-22 11:28:44'),
(138, 90, 'no comment', 30, '2026-01-22 11:30:33'),
(139, 75, 'Magura theke asbe teacher der sathe kotha bolte cai tini confused ', 27, '2026-01-22 11:36:56'),
(140, 74, 'Again phn off and she provide faluse information ', 27, '2026-01-22 11:41:07'),
(141, 71, 'Call dici kotha hoise 1 week time nise crisis colse onr tobe campus visit korbe', 27, '2026-01-22 11:52:55'),
(142, 70, 'Family allow korse na tai ai semester e admit hobe na final ', 27, '2026-01-22 11:58:39'),
(143, 66, 'Student provide unused nuber, so ati r used hoi na ', 27, '2026-01-22 12:01:37'),
(144, 66, '3 times call ata dead number', 27, '2026-01-22 12:02:44'),
(145, 64, '3 mas er modhe desh er baire cole jabe tai admit hobe na', 27, '2026-01-22 12:17:16'),
(146, 62, 'BBA te admit hote isccuk saturday visit korbe ', 27, '2026-01-22 12:23:37'),
(147, 61, 'Unable to reached', 27, '2026-01-22 12:26:43'),
(148, 115, 'Call kete dicce', 27, '2026-01-22 12:29:57'),
(149, 95, 'Evening batch chasce but tarporew decision niye janabe', 27, '2026-01-22 12:47:54'),
(150, 137, 'Don’t pick up the phone ', 30, '2026-01-23 04:15:10'),
(151, 137, 'Don’t pick up the phone ', 30, '2026-01-23 04:16:03'),
(152, 136, 'he will admit in 26 january', 24, '2026-01-23 04:26:32'),
(153, 139, '3/4 Din pore ashbe', 29, '2026-01-23 04:28:31'),
(154, 134, 'His background is Arts in HSC. so can\'t do  bsc in cse', 24, '2026-01-23 04:34:24'),
(155, 133, 'Not picked', 24, '2026-01-23 04:40:12'),
(156, 133, 'Not picked, I called him 2 times', 24, '2026-01-23 04:40:40'),
(157, 141, 'will admit in Friday', 24, '2026-01-23 04:44:23'),
(158, 142, 'Will admit  22 January', 24, '2026-01-23 04:46:05'),
(159, 131, 'he will informe us very soon', 24, '2026-01-23 04:56:20'),
(160, 127, 'his phone is off', 24, '2026-01-23 04:58:37'),
(161, 127, 'his phone is off', 24, '2026-01-23 04:58:52'),
(162, 125, 'phone number is off', 24, '2026-01-23 04:59:38'),
(163, 124, 'he will let us know', 24, '2026-01-23 05:02:40'),
(164, 113, 'will admit 25 or 26 January', 24, '2026-01-23 05:05:02'),
(165, 53, 'Don’t pick up the phone ', 30, '2026-01-23 05:24:04'),
(166, 89, 'let us know with talking in home', 24, '2026-01-23 05:28:00'),
(167, 55, 'will call us very soon', 24, '2026-01-23 05:32:59'),
(168, 55, 'will call us very soon', 24, '2026-01-23 05:33:00'),
(169, 49, 'Not relevent leads', 24, '2026-01-23 05:42:23'),
(170, 80, 'will come 26 jan', 24, '2026-01-23 05:45:33'),
(171, 143, 'Diploma holder will admit before 26 jan', 24, '2026-01-23 06:55:42'),
(172, 140, 'Kichu DIscount chasse, will let us know', 24, '2026-01-23 08:22:00'),
(173, 83, 'Not picked phone, i called twice', 24, '2026-01-23 08:25:31'),
(174, 141, '30 January', 24, '2026-01-23 08:27:36'),
(175, 138, 'Decision niye pore janaben', 30, '2026-01-23 08:48:42'),
(176, 145, 'will let us know when admit', 24, '2026-01-23 09:17:09'),
(177, 98, 'will come tomorrow\r\n', 24, '2026-01-23 09:34:14'),
(178, 101, 'Decision niye 26 tarikh er moddhe janabe', 30, '2026-01-23 09:37:26'),
(179, 92, 'will visit and admit with in next week', 24, '2026-01-23 09:38:54'),
(180, 96, 'Not response ', 30, '2026-01-23 09:42:34'),
(181, 146, 'will admit and let me know', 24, '2026-01-23 09:44:02'),
(182, 144, 'not picked', 24, '2026-01-23 09:55:45'),
(183, 148, 'will let us know', 24, '2026-01-23 10:29:18'),
(184, 149, 'Information niyeche next week ashbe', 29, '2026-01-23 10:55:48'),
(185, 112, 'kotha hoyese parents er sathe kotha bole janabe shomoi nise', 27, '2026-01-23 12:51:30'),
(186, 111, 'Vai pore aslee agent soho asbe decision niye asbe', 27, '2026-01-23 12:55:23'),
(187, 110, 'January 30 tarik asbe tai call diye reminder dawa lagbe 28 tarik', 27, '2026-01-23 13:00:01'),
(188, 108, 'Ajke friday office duty na thakai tini visit koresen ki update paschi na . Tomorrow evening er agei call dibo .', 27, '2026-01-23 13:06:47'),
(189, 107, 'Kotha hoiyse  bollo 1 week er modhee visit korbe  basha mirpur 1 e', 27, '2026-01-23 13:17:35'),
(190, 106, 'Kotha hoise admit hoiye gese bollo', 27, '2026-01-23 13:22:53'),
(191, 105, 'Pu student agent tai r call deini', 27, '2026-01-23 13:24:56'),
(192, 104, 'Sunday admit hobe bollo', 27, '2026-01-23 13:30:56'),
(193, 103, 'Double lead, plz delete the lead (sunday will admit)', 27, '2026-01-23 13:33:22'),
(194, 102, 'Monday te reminder dibo', 27, '2026-01-23 13:44:52'),
(195, 97, '25 tarik admit hobe, reminder 24  jan  before evening', 27, '2026-01-23 13:48:40'),
(196, 88, 'Not reached', 27, '2026-01-23 13:55:02'),
(197, 88, 'Not reached', 27, '2026-01-23 13:55:04'),
(198, 120, 'He was not interested for this semester', 24, '2026-01-24 04:26:34'),
(199, 93, 'will  come today for admission', 24, '2026-01-24 04:33:24'),
(200, 92, 'she will admit in next week', 24, '2026-01-24 04:35:02'),
(201, 83, 'Will admit next semester', 24, '2026-01-24 04:37:04'),
(202, 62, 'Will come in Monday', 24, '2026-01-24 04:38:52'),
(203, 150, 'Mamun Sobhan Sir je lead diyechilo, he is interested', 24, '2026-01-24 05:01:11'),
(204, 151, 'will admit this week', 24, '2026-01-24 05:15:27'),
(205, 153, 'will admit 1st week', 24, '2026-01-24 05:38:51'),
(206, 154, 'want to admit , let us know after discuss with family', 24, '2026-01-24 05:50:45'),
(207, 155, 'want to admit , let us know after discuss with family', 24, '2026-01-24 05:50:47'),
(208, 156, 'diploma holder, 25/26 January will admit', 24, '2026-01-24 06:42:26'),
(209, 157, 'will visit and admit very soon', 24, '2026-01-24 07:42:36'),
(210, 158, 'will visit and admit very soon', 24, '2026-01-24 07:42:37'),
(211, 159, 'will let us know very soon , when he come , but he will admit ', 24, '2026-01-24 08:37:21'),
(212, 160, 'Let us know very soon', 24, '2026-01-24 09:12:56'),
(213, 161, 'Let us know very soon', 24, '2026-01-24 09:22:23'),
(214, 162, 'will admit in 1st or 2nd February', 24, '2026-01-24 09:28:10'),
(215, 163, 'Diploma holder ajkei asbe', 24, '2026-01-24 09:40:38'),
(216, 164, 'Diploma holder ajkei asbe', 24, '2026-01-24 09:40:39'),
(217, 165, 'Her husband called ,she will admit,26 january or 27 january', 24, '2026-01-24 09:57:50'),
(218, 164, 'Admitted', 24, '2026-01-24 10:52:22'),
(219, 135, 'Ajke admit hoise, CSE', 27, '2026-01-24 10:52:50'),
(220, 71, 'Crisis er karone shomoi nise 1 week moto', 27, '2026-01-24 10:55:28'),
(221, 121, 'Not picked', 27, '2026-01-24 10:58:12'),
(222, 115, 'Interested & 1 week er modhee visit korbe', 27, '2026-01-24 11:03:23'),
(223, 110, '30 jan admit hobe , 28 tarik reminder dite hobe', 27, '2026-01-24 11:06:04'),
(224, 108, 'Monday asbe bollo mina islam er husband , class er time jene nise. ', 27, '2026-01-24 11:11:17'),
(225, 97, '25 tarik admit howar kotha cilo basha theke bolse 2 3 din por hote , 30 tarik er modhee admit hobe ', 27, '2026-01-24 11:15:39'),
(226, 95, 'Jodi vorti hoi tobe janabe  all informationa provide kora hoise (call e birokto hosse)', 27, '2026-01-24 11:23:31'),
(227, 86, 'HSC candidate, caccur sathe kotha hoise exam er pore vebe dekhbe ', 27, '2026-01-24 11:32:02'),
(228, 79, 'aro kisu uni khuj nibe tn decision nibe ', 27, '2026-01-24 11:38:26'),
(229, 76, 'Decision niye janabe akhono family te discussed kore ni ', 27, '2026-01-24 11:41:41'),
(230, 75, 'Call dawa hoise recive kore kono kotha bole ni ', 27, '2026-01-24 11:44:19'),
(231, 152, 'Information niyese interested for next semester ', 27, '2026-01-24 11:52:27'),
(232, 168, 'Will Admit Today', 24, '2026-01-25 03:22:37'),
(233, 148, 'Number is busy,called twice', 24, '2026-01-25 03:43:39'),
(234, 130, 'wrong number ', 30, '2026-01-25 04:12:17'),
(235, 147, 'Niye asbe student k khub druto e', 24, '2026-01-25 04:13:53'),
(236, 129, 'Don’t pick up the phone ', 30, '2026-01-25 04:17:52'),
(237, 128, 'Don’t pick up the phone ', 30, '2026-01-25 04:19:47'),
(238, 126, 'Visit tomorrow ', 30, '2026-01-25 04:22:59'),
(239, 123, 'Don’t pick up the phone ', 30, '2026-01-25 04:26:15'),
(240, 117, 'Wrong number ', 30, '2026-01-25 04:30:56'),
(241, 116, 'Today coming ', 30, '2026-01-25 04:37:45'),
(242, 114, 'Don’t pick up the phone ', 30, '2026-01-25 04:40:13'),
(243, 91, 'Don’t pick up the phone ', 30, '2026-01-25 04:41:18'),
(244, 90, 'Wrong number ', 30, '2026-01-25 04:42:35'),
(245, 87, 'Don’t pick up the phone ', 30, '2026-01-25 04:43:18'),
(246, 149, 'Pore janabe', 30, '2026-01-25 04:44:07'),
(247, 146, 'Not picked called three times', 24, '2026-01-25 04:45:38'),
(248, 138, 'Possible na cz from ctg', 30, '2026-01-25 04:47:48'),
(249, 137, 'Don’t pick up the phone ', 30, '2026-01-25 04:48:25'),
(250, 94, 'Onno varsity te vorti hoyeche', 30, '2026-01-25 04:52:21'),
(251, 101, 'Bramanbaria thaken class krte parbe na..visit korle solution deya hbe \r\nAjkr moddhe janabe', 30, '2026-01-25 04:58:36'),
(252, 96, 'Don’t pick up the phone ', 30, '2026-01-25 04:59:35'),
(253, 53, 'Don’t pick up the phone ', 30, '2026-01-25 05:01:15'),
(254, 169, 'THURSDAY te class korte parben na', 24, '2026-01-25 05:01:22'),
(255, 53, 'Don’t pick up the phone ', 30, '2026-01-25 05:01:51'),
(256, 170, 'She will let us know very soon ', 24, '2026-01-25 05:09:31'),
(257, 145, 'Already admitted with his friend reference', 24, '2026-01-25 05:37:06'),
(258, 168, 'having reference', 24, '2026-01-25 05:45:33'),
(259, 171, 'This week will admit ', 24, '2026-01-25 06:21:21'),
(260, 144, 'Basai kotha bole admit hoben ', 24, '2026-01-25 06:25:15'),
(261, 144, 'Basai kotha bole admit hoben ', 24, '2026-01-25 06:25:16'),
(262, 144, 'Basai kotha bole admit hoben ', 24, '2026-01-25 06:25:31'),
(263, 143, 'will let us know after discussing family', 24, '2026-01-25 06:29:20'),
(264, 141, 'he is promoter taking admission ', 24, '2026-01-25 06:32:48'),
(265, 172, 'Decision Niye janabe', 24, '2026-01-25 06:35:52'),
(266, 140, 'let us know', 24, '2026-01-25 06:42:28'),
(267, 136, 'called him not picked', 24, '2026-01-25 06:43:30'),
(268, 134, 'Diploma korbe se,', 24, '2026-01-25 06:46:18'),
(269, 133, 'Guardian picked and said admitted already', 24, '2026-01-25 06:55:45'),
(270, 131, 'Admitted', 24, '2026-01-25 06:58:06'),
(271, 127, '2,00,000 taka hole se porte pare', 24, '2026-01-25 07:01:26'),
(272, 125, 'he was in the bus will call us later', 24, '2026-01-25 07:03:23'),
(273, 124, 'let us know', 24, '2026-01-25 07:06:57'),
(274, 113, 'Not picked', 24, '2026-01-25 07:15:47'),
(275, 113, 'Not picked', 24, '2026-01-25 07:16:00'),
(276, 98, 'admission taka manage hoi ni , hole asbe\r\n', 24, '2026-01-25 07:53:11'),
(277, 89, 'didn\'t picked', 24, '2026-01-25 08:25:28'),
(278, 80, 'Admitted in DIU,', 24, '2026-01-25 08:30:22'),
(279, 55, 'will visit very soon', 24, '2026-01-25 08:35:42'),
(280, 51, 'Not picked', 24, '2026-01-25 08:37:00'),
(281, 50, 'Not picked', 24, '2026-01-25 08:38:25'),
(282, 173, 'Interested', 24, '2026-01-25 09:07:42'),
(283, 173, 'will visit campus', 24, '2026-01-25 09:08:13'),
(284, 175, 'will let us know', 24, '2026-01-25 09:48:44'),
(285, 176, 'Interested', 24, '2026-01-25 10:02:55'),
(286, 178, 'will admit on next friday', 24, '2026-01-25 10:44:19'),
(287, 179, 'Will admit this week', 24, '2026-01-25 10:53:39'),
(288, 119, 'Vorti hole janabe', 27, '2026-01-25 11:50:22'),
(289, 118, '31 tarik admit hobe jessore theke asbe, khub request kortese 1 ta sit rakhar jonno ', 27, '2026-01-25 11:59:24'),
(290, 88, 'unreacable', 27, '2026-01-25 12:11:00'),
(291, 102, '27 tarik visit korbe ', 27, '2026-01-25 12:27:26'),
(292, 103, 'Not picked', 27, '2026-01-25 12:35:33'),
(293, 104, 'Not picked', 27, '2026-01-25 12:36:45'),
(294, 139, 'Confued akhono decision nei ni. 3 -4 din shomoi niyese', 27, '2026-01-25 12:45:11'),
(295, 105, 'Kotha hoise kalke admit hobe', 27, '2026-01-25 12:52:12'),
(296, 112, 'Appeared , next semester e hote parbe ', 27, '2026-01-25 13:03:18'),
(297, 107, 'Not picked', 27, '2026-01-25 13:05:42'),
(298, 111, 'Kalke admit hobe', 27, '2026-01-25 13:12:16'),
(299, 111, 'dupur 1 ta -2 tar modhee asbe kal admit hote', 27, '2026-01-25 13:16:46'),
(300, 166, 'Busy ase ', 27, '2026-01-25 13:20:14'),
(301, 167, 'Kalke visit korbe', 27, '2026-01-25 13:27:44'),
(302, 167, 'Uttara theke asbe tribal qouta pabe', 27, '2026-01-25 13:32:33'),
(303, 174, 'Not picked', 27, '2026-01-25 13:35:31'),
(304, 152, 'next semester ', 27, '2026-01-26 03:38:20'),
(305, 108, 'Lead attended office visit on 2026-01-26 04:07:19\n\nNotes: class kora niye aktu tensed', 27, '2026-01-26 04:07:19'),
(306, 62, 'Busy ase pore call dibe', 27, '2026-01-26 04:26:47'),
(307, 71, 'next semester', 27, '2026-01-26 04:36:37'),
(308, 182, 'visited , And online jogajog hoise whatsappp e . kalke admit hobe ', 27, '2026-01-26 04:41:48'),
(309, 182, 'kalke admit hobe ', 27, '2026-01-26 04:56:07'),
(310, 177, 'LLB sit thakle 28 tarikhe vorti hbe', 30, '2026-01-26 05:03:35'),
(311, 182, 'Lead attended office visit on 2026-01-26 05:05:40\n\nNotes: Kalke admit hobe ', 27, '2026-01-26 05:05:40'),
(312, 181, 'Don’t pick up the phone ', 30, '2026-01-26 05:06:48'),
(313, 180, 'Next semester vorti hoben', 30, '2026-01-26 05:10:42'),
(314, 126, 'Vorti hoyeche', 30, '2026-01-26 05:21:02'),
(315, 116, 'Arshi apur sthe ktha hoyeche', 30, '2026-01-26 05:32:24'),
(316, 79, 'decision pending..', 27, '2026-01-26 05:36:15'),
(317, 95, 'Decision pending pore janabe', 27, '2026-01-26 05:37:24'),
(318, 97, '30 tarik er modhe hobe ', 27, '2026-01-26 06:35:07'),
(319, 110, '30 tarik admit hobe ', 27, '2026-01-26 06:40:51'),
(320, 184, 'Today will visit , previous call ', 27, '2026-01-26 06:55:30'),
(321, 184, 'Lead attended office visit on 2026-01-26 07:04:39\n\nNotes: vortir preparation niye asce', 27, '2026-01-26 07:04:39'),
(322, 184, 'admiited', 27, '2026-01-26 07:34:39'),
(323, 167, 'Lead attended office visit on 2026-01-26 07:50:06\n\nNotes: Tribule quata niye asce admit hobe , 27 tarik asbe ', 27, '2026-01-26 07:50:06'),
(324, 186, 'online (FB & Whatsapp)', 27, '2026-01-26 09:28:27'),
(325, 186, 'Lead attended office visit on 2026-01-26 09:54:53\n\nNotes: Admit hobe', 27, '2026-01-26 09:54:53'),
(326, 186, 'Admitted', 27, '2026-01-26 09:56:28'),
(327, 187, 'decision nibe 30 tarik er modhee asbe', 27, '2026-01-26 10:14:17'),
(328, 188, 'FB & call', 27, '2026-01-26 10:36:10'),
(329, 189, 'FB & call', 27, '2026-01-26 10:36:11'),
(330, 189, 'Admitted', 27, '2026-01-26 10:38:16'),
(331, 188, 'Admitted', 27, '2026-01-26 10:40:38'),
(332, 190, 'visited', 27, '2026-01-26 10:58:14'),
(333, 165, 'The number is from UAE but his wife will be admit that  date', 24, '2026-01-26 11:08:10'),
(334, 121, 'Kutubuddin . Referred ase', 27, '2026-01-26 11:11:32'),
(335, 121, 'Kutubuddin . Referred ase', 27, '2026-01-26 11:11:55'),
(336, 179, 'He will let us know very soon', 24, '2026-01-26 11:13:42'),
(337, 163, 'Not picked', 24, '2026-01-26 11:55:03'),
(338, 192, 'will admit in Thursday', 24, '2026-01-26 14:13:14'),
(339, 162, 'will call us very soon', 24, '2026-01-26 14:15:52'),
(340, 161, 'Number is off', 24, '2026-01-26 14:17:06'),
(341, 160, 'will call us very soon', 24, '2026-01-26 14:19:01'),
(342, 193, 'will let us know', 24, '2026-01-26 14:22:36'),
(343, 159, 'Agmaikal ba porsu asben ', 24, '2026-01-26 14:24:47'),
(344, 158, 'called him not picked, office number', 24, '2026-01-26 14:28:18'),
(345, 157, 'Not picked , office Number', 24, '2026-01-26 14:29:09'),
(346, 155, 'He Can come up with his 3/4 friend', 24, '2026-01-26 14:36:48'),
(347, 153, 'Not picked', 24, '2026-01-26 14:57:46'),
(348, 151, 'Not picked', 24, '2026-01-26 14:59:53'),
(349, 151, 'will come with in 1 or 2 days', 24, '2026-01-26 15:01:59'),
(350, 150, 'he will go into the japan', 24, '2026-01-26 15:03:47'),
(351, 92, 'will admit next week', 24, '2026-01-26 15:07:14'),
(352, 83, 'will call us later', 24, '2026-01-26 15:08:44'),
(353, 149, 'Student er baba aj visit krben', 30, '2026-01-27 03:53:36'),
(354, 137, 'Don’t pick up the phone ', 30, '2026-01-27 03:55:33'),
(355, 129, 'Don’t pick up the phone ', 30, '2026-01-27 03:59:44'),
(356, 128, 'Don’t pick up the phone ', 30, '2026-01-27 04:11:08'),
(357, 190, 'Ajke admit hobe', 27, '2026-01-27 04:12:36'),
(358, 191, 'Don’t pick up the phone ', 30, '2026-01-27 04:29:23'),
(359, 53, 'Don’t pick up the phone ', 30, '2026-01-27 04:39:06'),
(360, 71, 'Lead attended office visit on 2026-01-27 04:54:28\n\nNotes: asce', 27, '2026-01-27 04:54:28'),
(361, 194, 'Projpur theke admit howa problem tai online admit hobe ', 27, '2026-01-27 05:08:42'),
(362, 174, 'Not picked', 27, '2026-01-27 05:12:25'),
(363, 166, 'Not Picked', 27, '2026-01-27 05:14:33'),
(364, 123, 'Next semester vorti', 30, '2026-01-27 05:39:11'),
(365, 104, 'Decision niye asbe or online admit hobe', 27, '2026-01-27 05:51:13'),
(366, 103, 'Decision niye asbe or online admit hobe', 27, '2026-01-27 05:52:15'),
(367, 196, 'Friday te admit hobe ', 27, '2026-01-27 06:09:24'),
(368, 197, 'Friday te admit hobe ', 27, '2026-01-27 06:09:24'),
(369, 198, 'PU Student 2/3 diner moddhe admission nibe  LLM subject ', 29, '2026-01-27 06:22:12'),
(370, 199, 'Dcision nibe ', 27, '2026-01-27 06:23:28'),
(371, 195, 'Update janabe', 30, '2026-01-27 06:35:16'),
(372, 200, 'Wed te 28 tarik asbe', 27, '2026-01-27 06:42:44'),
(373, 114, 'Don’t pick up the phone ', 30, '2026-01-27 06:53:24'),
(374, 101, 'Dur hoye jacche tai possible na', 30, '2026-01-27 07:02:06'),
(375, 96, 'Don’t pick up the phone ', 30, '2026-01-27 09:17:54'),
(376, 91, 'Don’t pick up the phone ', 30, '2026-01-27 09:19:46'),
(377, 87, 'Don’t pick up the phone ', 30, '2026-01-27 09:22:06'),
(378, 118, '31 Tarik admit hobe', 27, '2026-01-27 09:35:17'),
(379, 105, 'Admiited', 27, '2026-01-27 09:39:06'),
(380, 107, 'Public e chance hoise', 27, '2026-01-27 09:44:15'),
(381, 111, 'Not picked ', 27, '2026-01-27 09:47:15'),
(382, 119, 'Informed kora hoise, admit hole janabe', 27, '2026-01-27 09:48:52'),
(383, 178, 'will let us know come in 30 January', 24, '2026-01-27 11:02:58'),
(384, 176, 'not picked', 24, '2026-01-27 11:04:04'),
(385, 175, 'his number is off', 24, '2026-01-27 11:04:50'),
(386, 173, 'will let us know very soon', 24, '2026-01-27 11:09:16'),
(387, 172, 'want to admit next semester. But he will try to admit this semester. i said our cost can be increase on the next semester', 24, '2026-01-27 11:17:15'),
(388, 171, 'Not picked', 24, '2026-01-27 11:18:30'),
(389, 170, 'will come very soon, and admit', 24, '2026-01-27 11:21:42'),
(390, 169, 'He admitted in presidancy,,,,He want to do class on others day but not friday', 24, '2026-01-27 11:24:09'),
(391, 163, 'Not picked', 24, '2026-01-27 11:26:03'),
(392, 161, 'will call us later, he was in the work', 24, '2026-01-27 11:27:30'),
(393, 201, 'admit hote asbe', 27, '2026-01-27 11:28:16'),
(394, 151, 'will admit on 1 or 2 february', 24, '2026-01-27 11:28:50'),
(395, 160, 'will not admit this semester, will be try next semester, waiting for the publc university result', 24, '2026-01-27 11:31:59'),
(396, 148, 'wrong number . not actual student number', 24, '2026-01-27 11:35:45'),
(397, 147, 'Not picked', 24, '2026-01-27 11:36:52'),
(398, 146, 'Not picked', 24, '2026-01-27 11:38:28'),
(399, 144, 'National e admitted, Khoroch tar jonno besi hoye jai , 2,00,000 hole porto', 24, '2026-01-27 11:40:56'),
(400, 143, 'will call me later', 24, '2026-01-27 11:43:47'),
(401, 140, 'Not picked', 24, '2026-01-27 12:04:33'),
(402, 127, 'his financial condition is not good if 200000, he can study', 24, '2026-01-27 12:08:45'),
(403, 140, 'will go abroad ', 24, '2026-01-27 12:10:49'),
(404, 125, 'he will let us know very soon,...his job posting in commilla he will be happy if online class , ', 24, '2026-01-27 12:14:57'),
(405, 124, 'Sonargaon. extra facility. bus facility ache', 24, '2026-01-27 12:16:52'),
(406, 113, 'will come and admit at 29 jan', 24, '2026-01-27 12:19:34'),
(407, 161, 'He wants to admit on 5 February. because he didn\'t get his salary yet. but he will try this month', 24, '2026-01-27 15:05:32'),
(408, 98, 'Next semester, admission fees manage hoi ni,', 24, '2026-01-27 15:09:51'),
(409, 89, 'didn\'t picked', 24, '2026-01-27 15:11:05'),
(410, 55, 'will visit very soon', 24, '2026-01-27 15:13:31'),
(411, 51, 'not picked', 24, '2026-01-27 15:14:45'),
(412, 50, 'onno kew form fill up kore dise, uni koren ni', 24, '2026-01-27 15:16:37'),
(413, 119, 'janabe', 27, '2026-01-28 03:45:50'),
(414, 194, 'online a admit howar posibilty  ase', 27, '2026-01-28 03:59:39'),
(415, 204, 'only information ', 27, '2026-01-28 04:06:38'),
(416, 205, 'only information ', 27, '2026-01-28 04:06:39'),
(417, 167, 'Not picked', 27, '2026-01-28 04:12:13'),
(418, 180, 'February 15 tarikh kotha blte hbe', 30, '2026-01-28 04:14:24'),
(419, 62, 'call kete dicce', 27, '2026-01-28 04:21:20'),
(420, 152, 'next semester', 27, '2026-01-28 04:28:01'),
(421, 115, 'kalke visit korbe ', 27, '2026-01-28 04:33:32'),
(422, 181, '30 tarikh kotha bole janaben', 30, '2026-01-28 04:35:13'),
(423, 95, 'onno kothaw admit hoise', 27, '2026-01-28 04:37:33'),
(424, 95, 'onno kothaw admit hoise', 27, '2026-01-28 04:37:34'),
(425, 79, 'call e birokto hoi ', 27, '2026-01-28 04:40:07'),
(426, 207, 'FDAE te interested , consesssion korte hobe.  kalke call dite hobe ,admit hobe', 27, '2026-01-28 05:07:01'),
(427, 208, 'Next month 5 tarhik ashbe ', 29, '2026-01-28 05:14:43'),
(428, 209, 'kotha hoise agei , visit korte asce,  interested', 27, '2026-01-28 05:20:32'),
(429, 203, 'Don’t pick up the phone ', 30, '2026-01-28 05:34:19'),
(430, 210, 'Diploma holder evening batch , Online admission nite chasce  ', 27, '2026-01-28 05:35:42'),
(431, 211, 'Information niyeche pore janabe', 29, '2026-01-28 05:45:55'),
(432, 212, 'MBA or EMBA te admit hobe ,  information nise ', 27, '2026-01-28 05:51:51'),
(433, 213, 'MBA or EMBA te admit hobe ,  information nise ', 27, '2026-01-28 05:51:52'),
(434, 177, 'Don’t pick up the phone ', 30, '2026-01-28 06:00:59'),
(435, 214, 'online FB & Whatsapp (Visited)', 27, '2026-01-28 06:11:06'),
(436, 177, 'Call back korechilen…Friday te vorti hoben sure', 30, '2026-01-28 06:15:41'),
(437, 215, 'PU student', 27, '2026-01-28 06:51:20'),
(438, 217, 'promotor ', 27, '2026-01-28 07:06:24'),
(439, 218, 'Agamikal Admit hobe ', 29, '2026-01-28 07:14:26'),
(440, 219, 'year gap 2018', 27, '2026-01-28 07:30:29'),
(441, 222, 'Diploma Result ekhno ber hoy ni .result ber hole vorti hobe', 30, '2026-01-28 07:40:33'),
(442, 225, '30 tarikher moddhe vorti hbe', 30, '2026-01-28 08:05:09'),
(443, 226, 'phn call &  visit korese  decision niye  2 din er modhee asbe ', 27, '2026-01-28 09:02:17'),
(444, 227, 'phn call &  visit korese  decision niye  2 din er modhee asbe ', 27, '2026-01-28 09:02:19'),
(445, 228, 'phn call &  visit korese  decision niye  2 din er modhee asbe ', 27, '2026-01-28 09:02:25'),
(446, 230, 'Gardian  er sathe kotha bole decision nibe ', 27, '2026-01-28 09:18:07'),
(447, 231, 'Gardian  er sathe kotha bole decision nibe ', 27, '2026-01-28 09:18:17'),
(448, 229, 'Don’t pick up the phone ', 30, '2026-01-28 09:59:24'),
(449, 224, 'Fake information ', 30, '2026-01-28 10:06:54'),
(450, 223, 'Don’t pick up the phn', 30, '2026-01-28 10:09:55'),
(451, 206, 'Not sure decision nibe ', 27, '2026-01-28 10:16:35'),
(452, 223, 'Kal janabe', 30, '2026-01-28 10:18:07'),
(453, 221, 'Tar ktha clear na pore call dite hbe', 30, '2026-01-28 10:19:52'),
(454, 201, 'Admiited', 27, '2026-01-28 10:29:21'),
(455, 201, 'Admiited', 27, '2026-01-28 10:29:22'),
(456, 233, 'campus visit', 27, '2026-01-28 11:18:47'),
(457, 234, 'campus visit', 27, '2026-01-28 11:18:48'),
(458, 220, 'Don’t pick up the phn', 30, '2026-01-28 11:19:38'),
(459, 235, 'Visited, kalke admit hobe . ', 27, '2026-01-28 11:23:51'),
(460, 236, 'Visited &  interested', 27, '2026-01-28 11:26:47'),
(461, 76, 'Next semester', 27, '2026-01-28 11:28:14'),
(462, 71, 'Decision pending', 27, '2026-01-28 11:29:20'),
(463, 237, 'Visited, Kalke admit hobe ', 27, '2026-01-28 11:37:11'),
(464, 193, 'will contact tomorrow morning', 24, '2026-01-28 13:44:13'),
(465, 192, 'vai osusto thakai late hocche ,', 24, '2026-01-28 13:46:20'),
(466, 179, 'will let us know', 24, '2026-01-28 13:51:00'),
(467, 171, 'Not picked', 24, '2026-01-28 13:52:38'),
(468, 162, 'will let us know very soon', 24, '2026-01-28 13:54:13'),
(469, 242, 'will admit tommorow morning', 24, '2026-01-28 13:57:28'),
(470, 159, 'Not picked', 24, '2026-01-28 13:58:38'),
(471, 155, 'will let us know , he want some discount', 24, '2026-01-28 14:03:31'),
(472, 154, 'will let us know ', 24, '2026-01-28 14:04:16'),
(473, 146, 'want to admit in next semester', 24, '2026-01-28 14:07:26'),
(474, 143, 'he can\'t during  network should call tomorrow', 24, '2026-01-28 14:10:07'),
(475, 193, 'Not picked', 24, '2026-01-29 03:35:45'),
(476, 178, 'will come tomorrow', 24, '2026-01-29 04:42:23'),
(477, 176, 'not picked', 24, '2026-01-29 04:44:18'),
(478, 244, 'will come in monday', 24, '2026-01-29 04:47:50'),
(479, 175, 'Not Picked', 24, '2026-01-29 05:16:24'),
(480, 195, 'Don’t pick up the phone ', 30, '2026-01-29 05:17:36'),
(481, 173, 'Not picked', 24, '2026-01-29 05:18:32'),
(482, 245, 'admitted', 24, '2026-01-29 05:27:00'),
(483, 170, 'will admit in sunday or Monday', 24, '2026-01-29 05:30:41'),
(484, 161, 'Not picked', 24, '2026-01-29 05:32:19'),
(485, 157, 'didn\'t talked', 24, '2026-01-29 05:35:17'),
(486, 143, 'he is busy now, talk later', 24, '2026-01-29 05:37:45'),
(487, 246, 'will admit in saturday , and Friday', 24, '2026-01-29 05:56:51'),
(488, 225, 'Vorti hoyeche', 30, '2026-01-29 05:58:52'),
(489, 216, 'Vorti hoyeche', 30, '2026-01-29 06:00:49'),
(490, 247, 'will admit this month', 24, '2026-01-29 06:06:46'),
(491, 195, 'Don’t pick up the phone ', 30, '2026-01-29 06:10:56'),
(492, 191, 'Don’t pick up the phone ', 30, '2026-01-29 06:13:19'),
(493, 136, 'Not picked', 24, '2026-01-29 06:27:01'),
(494, 113, 'Number is Busy Now', 24, '2026-01-29 06:29:14'),
(495, 89, 'Not picked', 24, '2026-01-29 06:33:58'),
(496, 89, 'Not picked', 24, '2026-01-29 06:34:00'),
(497, 248, 'china theke bachelors korechen', 24, '2026-01-29 06:40:19'),
(498, 250, 'interested', 24, '2026-01-29 06:44:23'),
(499, 251, 'interested', 24, '2026-01-29 06:44:23'),
(500, 252, 'Info Nichce pore janabe.', 37, '2026-01-29 06:45:14'),
(501, 247, 'will admit Friday or Saturday', 24, '2026-01-29 06:52:11'),
(502, 241, 'Pore janabe', 30, '2026-01-29 07:01:19'),
(503, 253, 'Tomorrow Admit hobe Ref. Omar Faruk Sir', 24, '2026-01-29 07:47:22'),
(504, 55, 'Not picked', 24, '2026-01-29 07:55:23'),
(505, 242, 'admitted', 24, '2026-01-29 08:07:01'),
(506, 239, 'Don’t pick up the phone ', 30, '2026-01-29 08:08:00'),
(507, 51, 'not picked', 24, '2026-01-29 08:09:18'),
(508, 254, 'Our student ', 24, '2026-01-29 08:24:55'),
(509, 238, 'Will inform us soon', 24, '2026-01-29 08:52:41'),
(510, 240, 'Unable to reach ', 30, '2026-01-29 09:38:26'),
(511, 255, 'interested for admission , will come very soon', 24, '2026-01-29 09:49:43'),
(512, 198, 'Call Dhore nai', 29, '2026-01-29 10:21:55'),
(513, 119, 'Admit hobe na', 27, '2026-01-29 12:00:20'),
(514, 75, 'Hsc pass kore ni', 27, '2026-01-29 12:07:07'),
(515, 102, 'Hsc exam dei ni ', 27, '2026-01-29 13:35:21'),
(516, 237, 'kalke admit hobe ( family crisis)  ', 27, '2026-01-29 13:59:36'),
(517, 235, 'Kalke admit hobe', 27, '2026-01-29 15:32:23'),
(518, 231, 'Janabe', 27, '2026-01-29 15:33:36'),
(519, 230, 'Janabe', 27, '2026-01-29 15:34:37'),
(520, 194, 'Amr home office thakai confirmation paschi na', 27, '2026-01-29 15:45:41'),
(521, 210, 'kalke call dibo', 27, '2026-01-29 15:46:51'),
(522, 207, 'kalke call dibo', 27, '2026-01-29 15:49:06'),
(523, 199, 'kalke call', 27, '2026-01-29 15:50:29'),
(524, 209, 'kalke call', 27, '2026-01-29 15:51:47'),
(525, 166, 'Not picked', 27, '2026-01-29 15:54:30'),
(526, 115, 'onno jaigai admitted', 27, '2026-01-29 15:56:38'),
(527, 267, 'Information Niyeche , Ajke janabe ', 29, '2026-01-30 05:11:25'),
(528, 251, 'will let us know', 24, '2026-01-30 05:18:51'),
(529, 250, 'will let us know', 24, '2026-01-30 05:19:26'),
(530, 247, 'will let us know', 24, '2026-01-30 05:27:34'),
(531, 244, 'Not picked', 24, '2026-01-30 05:29:24'),
(532, 193, 'Not picked', 24, '2026-01-30 05:31:23'),
(533, 192, 'UiTS, Location kase ajjono', 24, '2026-01-30 05:33:17'),
(534, 179, 'he cuts the phone', 24, '2026-01-30 05:34:47'),
(535, 178, 'not picked', 24, '2026-01-30 05:36:20'),
(536, 247, 'let us know ', 24, '2026-01-30 05:39:42'),
(537, 176, 'will visit tomorrow or 1 Feb', 24, '2026-01-30 05:42:11'),
(538, 255, 'not picked', 24, '2026-01-30 05:46:16'),
(539, 175, 'Not picked', 24, '2026-01-30 06:11:33'),
(540, 173, '2,3 February will come', 24, '2026-01-30 06:13:17'),
(541, 172, 'Not picked,next semester', 24, '2026-01-30 06:32:59'),
(542, 171, 'Not picked', 24, '2026-01-30 06:38:11'),
(543, 236, 'Not reached', 27, '2026-01-30 06:40:38'),
(544, 233, 'Unreachable', 27, '2026-01-30 06:44:00'),
(545, 234, 'Unreachable', 27, '2026-01-30 06:45:35'),
(546, 228, 'Not picked', 27, '2026-01-30 06:49:15'),
(547, 162, 'Osusto , next semester, law te tar chele aste pare ', 24, '2026-01-30 06:50:37'),
(548, 227, 'Not picked', 27, '2026-01-30 06:50:52'),
(549, 226, 'not picked', 27, '2026-01-30 06:51:45'),
(550, 161, 'let us know', 24, '2026-01-30 06:52:34'),
(551, 159, 'will come today or tomorrow', 24, '2026-01-30 06:54:35'),
(552, 158, 'picked but not talked', 24, '2026-01-30 06:56:28'),
(553, 219, 'Janabe', 27, '2026-01-30 06:56:31'),
(554, 268, 'Admitted', 24, '2026-01-30 07:01:50'),
(555, 269, 'Admitted', 24, '2026-01-30 07:03:33'),
(556, 155, 'taka manage korte paren ni', 24, '2026-01-30 07:58:00'),
(557, 151, 'next semester', 24, '2026-01-30 08:00:48'),
(558, 255, 'not picked', 24, '2026-01-30 08:02:22'),
(559, 253, 'let us know , they said monthly cost is much for them', 24, '2026-01-30 08:05:42'),
(560, 218, 'Other University Admission niyeche ', 29, '2026-01-30 08:05:59'),
(561, 147, 'let us know very soon', 24, '2026-01-30 08:08:59'),
(562, 255, 'called back, will let us know soon', 24, '2026-01-30 08:10:27'),
(563, 143, 'will admit in next semester', 24, '2026-01-30 09:50:39'),
(564, 140, 'canadian university te admission niyeche, parmanent campus  in ugc website, and other facilities', 24, '2026-01-30 09:53:40'),
(565, 136, 'next semester', 24, '2026-01-30 09:55:32'),
(566, 127, 'let us know', 24, '2026-01-30 10:05:46'),
(567, 125, 'phone is off', 24, '2026-01-30 10:09:15'),
(568, 125, 'next semester', 24, '2026-01-30 10:13:41'),
(569, 113, 'not picked', 24, '2026-01-30 10:17:13'),
(570, 270, 'will make decision', 24, '2026-01-30 10:34:13'),
(571, 271, 'will let us know this semester or next', 24, '2026-01-30 10:35:38'),
(572, 89, 'next semester', 24, '2026-01-30 10:41:49'),
(573, 62, 'Money problem, next semester e asteo pare\r\n', 24, '2026-01-30 10:45:01'),
(574, 55, 'let us know after discussing with family this semester or next semester', 24, '2026-01-30 10:47:48'),
(575, 51, 'not picked', 24, '2026-01-30 10:49:18'),
(576, 257, 'will let us know after talking with home ', 24, '2026-01-30 10:52:17'),
(577, 237, 'Next semester', 27, '2026-01-30 11:24:03'),
(578, 273, 'let us know', 24, '2026-01-30 11:24:51'),
(579, 274, 'Vola  theke admit hobe , online admit hote chasce', 27, '2026-01-30 11:38:56'),
(580, 235, 'Next semester', 27, '2026-01-30 11:45:25'),
(581, 231, 'baba mara gese decision nite deri hosse', 27, '2026-01-30 11:54:45'),
(582, 230, 'baba mara gese decision nite deri hosse', 27, '2026-01-30 11:55:43'),
(583, 276, 'let us know his wife in english he in ma in english', 24, '2026-01-30 11:56:26'),
(584, 197, 'Kalke admit hole online or next semester', 27, '2026-01-30 12:22:53'),
(585, 210, 'Kalke adnit hote chasce', 27, '2026-01-30 12:33:34'),
(586, 209, 'Monday admit hote chasce', 27, '2026-01-30 12:39:10'),
(587, 207, 'Kal visit korbe & admit hobe( FDAE te hote chascilo but now CSE/EEE)', 27, '2026-01-30 12:51:09'),
(588, 205, 'Kalke admit hobe', 27, '2026-01-30 12:55:30'),
(589, 204, 'Kalke admit hobe', 27, '2026-01-30 12:56:30'),
(590, 196, 'Kalke online admit hobe or next semester ', 27, '2026-01-30 12:58:03'),
(591, 199, 'Not reached', 27, '2026-01-30 13:00:20'),
(592, 194, 'Next semester ', 27, '2026-01-30 13:03:13'),
(593, 97, 'kalke admit hobe', 27, '2026-01-30 13:08:09'),
(594, 187, 'Busy', 27, '2026-01-30 13:09:51'),
(595, 71, 'Uttara uni te admit hoise', 27, '2026-01-30 13:14:43'),
(596, 110, 'not reached', 27, '2026-01-30 13:17:45'),
(597, 111, 'Tour e gese kalke admit hole online e or next semester ', 27, '2026-01-30 13:22:03'),
(598, 185, 'Admitted ', 27, '2026-01-30 13:26:06'),
(599, 185, 'Today visit', 27, '2026-01-30 13:26:58'),
(600, 174, 'onno uni te admit hoise', 27, '2026-01-30 13:29:16'),
(601, 139, 'Next semester, parents k convensce korte hobe senior/faculty k diye ', 27, '2026-01-30 13:37:37'),
(602, 243, 'only information', 27, '2026-01-30 13:49:07'),
(603, 259, 'next semester ', 27, '2026-01-30 13:53:23'),
(604, 260, 'next semester ', 27, '2026-01-30 14:16:52'),
(605, 264, 'Provide fake information', 27, '2026-01-30 14:18:43'),
(606, 263, 'Kal call', 27, '2026-01-30 14:28:02'),
(607, 276, 'Next semester', 24, '2026-01-31 03:33:14'),
(608, 273, 'phone number is off', 24, '2026-01-31 03:34:45'),
(609, 271, 'next semester', 24, '2026-01-31 03:36:37');

-- --------------------------------------------------------

--
-- Table structure for table `lead_semesters`
--

CREATE TABLE `lead_semesters` (
  `id` int NOT NULL,
  `lead_id` int NOT NULL,
  `semester_id` int NOT NULL,
  `added_by` int NOT NULL,
  `added_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lead_staff_assignments`
--

CREATE TABLE `lead_staff_assignments` (
  `id` int NOT NULL,
  `lead_id` int NOT NULL,
  `staff_id` int NOT NULL,
  `assigned_by` int NOT NULL,
  `assigned_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lead_staff_assignments`
--

INSERT INTO `lead_staff_assignments` (`id`, `lead_id`, `staff_id`, `assigned_by`, `assigned_at`) VALUES
(78, 49, 24, 3, '2026-01-19 20:52:27'),
(79, 50, 24, 3, '2026-01-19 20:53:16'),
(80, 51, 24, 3, '2026-01-19 20:53:16'),
(82, 74, 27, 3, '2026-01-20 07:33:04'),
(83, 73, 27, 3, '2026-01-20 07:33:11'),
(84, 72, 27, 3, '2026-01-20 07:33:19'),
(85, 71, 27, 3, '2026-01-20 07:33:34'),
(86, 70, 27, 3, '2026-01-20 07:33:42'),
(87, 69, 27, 3, '2026-01-20 07:33:48'),
(88, 68, 27, 3, '2026-01-20 07:33:55'),
(89, 67, 27, 3, '2026-01-20 07:34:15'),
(90, 66, 27, 3, '2026-01-20 07:34:23'),
(91, 65, 27, 3, '2026-01-20 07:34:28'),
(92, 64, 27, 3, '2026-01-20 07:34:45'),
(103, 78, 27, 3, '2026-01-20 09:20:49'),
(104, 77, 27, 3, '2026-01-20 09:23:59'),
(106, 81, 27, 3, '2026-01-20 09:32:47'),
(107, 82, 27, 27, '2026-01-20 09:48:50'),
(109, 84, 27, 3, '2026-01-20 10:22:23'),
(110, 85, 27, 3, '2026-01-20 10:47:23'),
(111, 61, 27, 3, '2026-01-20 10:52:17'),
(113, 63, 27, 3, '2026-01-20 10:55:25'),
(115, 99, 27, 27, '2026-01-21 05:56:50'),
(116, 100, 27, 27, '2026-01-21 06:06:02'),
(118, 102, 27, 27, '2026-01-21 06:27:56'),
(119, 103, 27, 27, '2026-01-21 07:11:45'),
(120, 104, 27, 27, '2026-01-21 07:11:47'),
(121, 105, 27, 27, '2026-01-21 07:11:51'),
(122, 106, 27, 27, '2026-01-21 07:16:37'),
(123, 107, 27, 27, '2026-01-21 07:24:37'),
(125, 109, 27, 27, '2026-01-21 08:21:40'),
(126, 111, 27, 27, '2026-01-21 09:29:16'),
(127, 112, 27, 27, '2026-01-21 09:53:47'),
(128, 110, 27, 29, '2026-01-21 10:23:40'),
(132, 91, 30, 29, '2026-01-21 10:44:21'),
(134, 60, 24, 29, '2026-01-21 10:49:54'),
(136, 57, 24, 29, '2026-01-21 11:06:32'),
(143, 95, 27, 29, '2026-01-22 05:17:07'),
(144, 87, 30, 29, '2026-01-22 05:22:31'),
(146, 117, 30, 29, '2026-01-22 05:42:51'),
(153, 121, 27, 29, '2026-01-22 06:09:56'),
(156, 123, 30, 30, '2026-01-22 06:45:01'),
(157, 131, 24, 29, '2026-01-22 08:10:56'),
(158, 126, 30, 29, '2026-01-22 08:56:06'),
(160, 89, 24, 29, '2026-01-22 08:57:36'),
(161, 125, 24, 29, '2026-01-22 08:58:05'),
(163, 124, 24, 29, '2026-01-22 09:00:04'),
(164, 127, 24, 29, '2026-01-22 09:00:19'),
(166, 128, 30, 29, '2026-01-22 10:01:00'),
(167, 116, 30, 29, '2026-01-22 10:11:51'),
(168, 135, 27, 29, '2026-01-22 10:12:12'),
(169, 136, 24, 29, '2026-01-22 10:18:06'),
(170, 53, 30, 29, '2026-01-22 10:31:56'),
(171, 55, 24, 29, '2026-01-22 10:32:30'),
(173, 52, 24, 29, '2026-01-22 10:40:00'),
(175, 114, 30, 29, '2026-01-22 11:12:07'),
(176, 94, 30, 29, '2026-01-22 11:13:15'),
(177, 90, 30, 29, '2026-01-22 11:13:40'),
(179, 113, 24, 29, '2026-01-23 04:04:02'),
(180, 137, 30, 29, '2026-01-23 04:04:43'),
(181, 134, 24, 29, '2026-01-23 04:05:08'),
(182, 133, 24, 29, '2026-01-23 04:05:20'),
(183, 129, 30, 29, '2026-01-23 04:05:31'),
(184, 130, 30, 29, '2026-01-23 04:05:53'),
(185, 139, 27, 29, '2026-01-23 04:29:21'),
(186, 141, 24, 24, '2026-01-23 04:44:23'),
(187, 142, 24, 24, '2026-01-23 04:46:05'),
(188, 83, 24, 29, '2026-01-23 05:25:12'),
(189, 80, 27, 29, '2026-01-23 05:43:09'),
(190, 80, 24, 29, '2026-01-23 05:43:09'),
(191, 140, 24, 29, '2026-01-23 06:17:58'),
(192, 143, 24, 24, '2026-01-23 06:55:42'),
(193, 138, 30, 29, '2026-01-23 07:04:52'),
(194, 120, 24, 29, '2026-01-23 07:05:16'),
(195, 145, 24, 24, '2026-01-23 09:17:09'),
(196, 92, 24, 29, '2026-01-23 09:26:07'),
(197, 96, 30, 29, '2026-01-23 09:27:25'),
(200, 101, 27, 29, '2026-01-23 09:30:20'),
(201, 101, 30, 29, '2026-01-23 09:30:20'),
(202, 146, 24, 29, '2026-01-23 09:32:27'),
(203, 144, 24, 29, '2026-01-23 09:32:53'),
(204, 147, 24, 24, '2026-01-23 10:18:53'),
(205, 148, 24, 24, '2026-01-23 10:29:18'),
(209, 88, 27, 29, '2026-01-23 11:57:53'),
(210, 149, 30, 29, '2026-01-24 03:22:01'),
(211, 93, 30, 29, '2026-01-24 03:25:16'),
(212, 93, 24, 29, '2026-01-24 03:25:16'),
(213, 62, 27, 29, '2026-01-24 03:27:51'),
(214, 62, 24, 29, '2026-01-24 03:27:51'),
(215, 132, 33, 29, '2026-01-24 03:29:01'),
(216, 150, 24, 24, '2026-01-24 05:01:11'),
(217, 151, 24, 24, '2026-01-24 05:15:27'),
(218, 153, 24, 24, '2026-01-24 05:38:51'),
(219, 154, 24, 24, '2026-01-24 05:50:45'),
(220, 155, 24, 24, '2026-01-24 05:50:47'),
(225, 79, 27, 29, '2026-01-24 06:26:00'),
(226, 79, 24, 29, '2026-01-24 06:26:00'),
(227, 86, 24, 29, '2026-01-24 06:26:31'),
(228, 86, 27, 29, '2026-01-24 06:26:31'),
(229, 152, 27, 29, '2026-01-24 06:27:01'),
(230, 156, 24, 24, '2026-01-24 06:42:26'),
(231, 157, 24, 24, '2026-01-24 07:42:36'),
(232, 158, 24, 24, '2026-01-24 07:42:37'),
(233, 159, 24, 24, '2026-01-24 08:37:21'),
(234, 160, 24, 24, '2026-01-24 09:12:56'),
(235, 161, 24, 24, '2026-01-24 09:22:23'),
(236, 162, 24, 24, '2026-01-24 09:28:10'),
(237, 163, 24, 24, '2026-01-24 09:40:38'),
(238, 164, 24, 24, '2026-01-24 09:40:39'),
(239, 165, 24, 24, '2026-01-24 09:57:50'),
(240, 168, 24, 24, '2026-01-25 03:22:37'),
(241, 167, 27, 29, '2026-01-25 03:41:18'),
(242, 166, 27, 29, '2026-01-25 03:41:40'),
(243, 118, 31, 29, '2026-01-25 03:42:13'),
(244, 118, 27, 29, '2026-01-25 03:42:13'),
(247, 169, 24, 24, '2026-01-25 05:01:22'),
(248, 170, 24, 24, '2026-01-25 05:09:31'),
(249, 171, 24, 24, '2026-01-25 06:21:21'),
(250, 172, 24, 24, '2026-01-25 06:35:52'),
(251, 173, 24, 24, '2026-01-25 09:07:42'),
(252, 175, 24, 24, '2026-01-25 09:48:44'),
(253, 176, 24, 24, '2026-01-25 10:02:55'),
(254, 174, 27, 29, '2026-01-25 10:33:08'),
(255, 178, 24, 24, '2026-01-25 10:44:19'),
(256, 179, 24, 24, '2026-01-25 10:53:39'),
(257, 181, 30, 29, '2026-01-26 04:39:19'),
(258, 180, 30, 29, '2026-01-26 04:39:33'),
(259, 182, 27, 27, '2026-01-26 04:41:48'),
(261, 75, 27, 29, '2026-01-26 04:51:15'),
(262, 76, 27, 29, '2026-01-26 04:51:29'),
(263, 108, 27, 29, '2026-01-26 05:17:50'),
(265, 184, 27, 29, '2026-01-26 08:22:09'),
(267, 186, 27, 27, '2026-01-26 09:28:27'),
(268, 187, 27, 27, '2026-01-26 10:14:17'),
(270, 188, 27, 27, '2026-01-26 10:36:10'),
(271, 189, 27, 27, '2026-01-26 10:36:11'),
(272, 190, 27, 27, '2026-01-26 10:58:14'),
(273, 192, 24, 24, '2026-01-26 14:13:14'),
(274, 193, 24, 24, '2026-01-26 14:22:36'),
(275, 191, 30, 29, '2026-01-27 03:48:36'),
(276, 194, 27, 27, '2026-01-27 05:05:14'),
(277, 185, 27, 29, '2026-01-27 05:51:23'),
(279, 197, 27, 27, '2026-01-27 06:09:24'),
(283, 195, 30, 29, '2026-01-27 06:25:24'),
(284, 199, 27, 29, '2026-01-27 06:27:05'),
(285, 200, 27, 27, '2026-01-27 06:42:44'),
(286, 196, 27, 29, '2026-01-27 06:57:35'),
(287, 115, 27, 3, '2026-01-27 07:17:14'),
(288, 97, 27, 3, '2026-01-27 07:17:25'),
(289, 98, 24, 29, '2026-01-27 09:52:19'),
(291, 204, 27, 27, '2026-01-28 04:06:38'),
(292, 205, 27, 27, '2026-01-28 04:06:39'),
(293, 207, 27, 27, '2026-01-28 05:07:01'),
(294, 206, 27, 29, '2026-01-28 05:15:25'),
(295, 202, 27, 29, '2026-01-28 05:18:27'),
(296, 203, 30, 29, '2026-01-28 05:19:41'),
(297, 209, 27, 27, '2026-01-28 05:20:32'),
(298, 210, 27, 27, '2026-01-28 05:35:42'),
(300, 212, 27, 27, '2026-01-28 05:51:51'),
(301, 213, 27, 27, '2026-01-28 05:51:52'),
(302, 214, 27, 27, '2026-01-28 06:11:06'),
(303, 215, 27, 27, '2026-01-28 06:51:20'),
(304, 216, 30, 30, '2026-01-28 06:53:57'),
(305, 217, 27, 27, '2026-01-28 07:06:24'),
(307, 219, 27, 27, '2026-01-28 07:30:29'),
(308, 222, 30, 30, '2026-01-28 07:40:33'),
(309, 225, 30, 30, '2026-01-28 08:05:09'),
(310, 223, 30, 29, '2026-01-28 08:24:37'),
(311, 224, 30, 29, '2026-01-28 08:24:49'),
(312, 220, 30, 29, '2026-01-28 08:25:16'),
(313, 226, 27, 27, '2026-01-28 09:02:17'),
(314, 227, 27, 27, '2026-01-28 09:02:19'),
(315, 228, 27, 27, '2026-01-28 09:02:25'),
(316, 230, 27, 27, '2026-01-28 09:18:07'),
(317, 231, 27, 27, '2026-01-28 09:18:17'),
(318, 229, 30, 29, '2026-01-28 09:18:20'),
(319, 221, 30, 29, '2026-01-28 09:27:16'),
(320, 233, 27, 27, '2026-01-28 11:18:47'),
(321, 234, 27, 27, '2026-01-28 11:18:48'),
(322, 235, 27, 27, '2026-01-28 11:23:51'),
(324, 236, 27, 27, '2026-01-28 11:26:47'),
(325, 237, 27, 27, '2026-01-28 11:37:11'),
(326, 242, 24, 24, '2026-01-28 13:57:28'),
(327, 201, 27, 3, '2026-01-29 04:15:17'),
(328, 244, 24, 24, '2026-01-29 04:47:50'),
(329, 245, 24, 24, '2026-01-29 05:27:00'),
(330, 246, 24, 24, '2026-01-29 05:56:51'),
(331, 247, 24, 24, '2026-01-29 06:06:46'),
(332, 211, 33, 29, '2026-01-29 06:10:53'),
(333, 243, 27, 29, '2026-01-29 06:11:31'),
(334, 241, 30, 29, '2026-01-29 06:11:48'),
(335, 240, 30, 29, '2026-01-29 06:12:03'),
(336, 239, 30, 29, '2026-01-29 06:12:13'),
(337, 238, 24, 29, '2026-01-29 06:13:05'),
(338, 248, 24, 24, '2026-01-29 06:40:19'),
(339, 249, 30, 30, '2026-01-29 06:42:08'),
(340, 250, 24, 24, '2026-01-29 06:44:23'),
(341, 251, 24, 24, '2026-01-29 06:44:23'),
(342, 252, 30, 37, '2026-01-29 06:45:14'),
(344, 253, 33, 29, '2026-01-29 07:50:15'),
(345, 254, 24, 24, '2026-01-29 08:24:55'),
(346, 255, 24, 24, '2026-01-29 09:49:43'),
(347, 119, 27, 29, '2026-01-29 10:15:58'),
(348, 198, 33, 29, '2026-01-29 10:21:55'),
(349, 256, 30, 30, '2026-01-29 10:23:33'),
(351, 267, 33, 29, '2026-01-30 05:16:35'),
(352, 268, 24, 24, '2026-01-30 07:01:50'),
(354, 218, 33, 29, '2026-01-30 08:06:19'),
(355, 266, 27, 29, '2026-01-30 08:07:44'),
(356, 265, 27, 29, '2026-01-30 08:08:07'),
(357, 264, 27, 29, '2026-01-30 08:08:38'),
(358, 263, 27, 29, '2026-01-30 08:08:58'),
(359, 177, 30, 29, '2026-01-30 08:18:11'),
(360, 262, 30, 29, '2026-01-30 09:16:04'),
(361, 261, 30, 29, '2026-01-30 09:16:25'),
(362, 260, 27, 29, '2026-01-30 09:16:34'),
(363, 257, 24, 29, '2026-01-30 09:16:50'),
(364, 259, 27, 29, '2026-01-30 09:17:23'),
(365, 269, 24, 29, '2026-01-30 09:18:36'),
(366, 270, 24, 24, '2026-01-30 10:34:13'),
(367, 271, 24, 24, '2026-01-30 10:35:38'),
(368, 273, 24, 24, '2026-01-30 11:24:51'),
(369, 274, 27, 27, '2026-01-30 11:38:56'),
(370, 276, 24, 24, '2026-01-30 11:56:26');

-- --------------------------------------------------------

--
-- Table structure for table `lead_universities`
--

CREATE TABLE `lead_universities` (
  `id` int NOT NULL,
  `lead_id` int NOT NULL,
  `university_id` int NOT NULL,
  `added_by` int NOT NULL,
  `added_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `semesters`
--

CREATE TABLE `semesters` (
  `id` int NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` enum('Active','Inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `semesters`
--

INSERT INTO `semesters` (`id`, `name`, `start_date`, `end_date`, `status`, `created_at`, `updated_at`, `created_by`, `updated_by`) VALUES
(1, 'January 2025', '2025-01-01', NULL, 'Active', '2025-04-29 20:32:09', '2025-04-29 20:32:09', NULL, NULL),
(2, 'Spring 2026', '2026-05-01', '2026-01-29', 'Active', '2026-01-14 08:44:45', '2026-01-14 08:44:45', 3, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subscription_payments`
--

CREATE TABLE `subscription_payments` (
  `id` int NOT NULL,
  `company_subscription_id` int NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_date` datetime NOT NULL,
  `payment_method` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` enum('Success','Pending','Failed') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `notes` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subscription_plans`
--

CREATE TABLE `subscription_plans` (
  `id` int NOT NULL,
  `plan_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `plan_type` enum('Monthly','Yearly','Lifetime') COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `features` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` enum('Active','Inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subscription_plans`
--

INSERT INTO `subscription_plans` (`id`, `plan_name`, `plan_type`, `price`, `description`, `features`, `created_at`, `updated_at`, `status`) VALUES
(2, 'Monthly', 'Monthly', 99.95, 'Professional plan with advanced features', '[\"Unlimited Staff Accounts\",\"Unlimited Students\",\"Unlimited agent Accounts\"]', '2025-01-11 23:13:36', '2025-01-16 00:14:03', 'Active'),
(59, 'Yearly', 'Yearly', 895.00, 'Unlimited', '[\"Unlimited\"]', '2025-01-16 00:15:11', '2025-01-16 00:15:11', 'Active'),
(60, 'Lifetime Deal', 'Lifetime', 3995.00, 'Unlimited', '[\"Unlimited d\"]', '2025-01-16 00:16:30', '2025-02-12 17:09:02', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `universities`
--

CREATE TABLE `universities` (
  `id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `website` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('Active','Inactive') COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reset_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reset_token_expiry` datetime DEFAULT NULL,
  `user_type` enum('Super Admin','Admin','Manager','Counselor','Agent') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `account_status` enum('Active','Deactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `company_id` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `reset_token`, `reset_token_expiry`, `user_type`, `created_at`, `created_by`, `updated_at`, `account_status`, `company_id`) VALUES
(3, 'farukdesk@gmail.com', '$2y$10$tzeTwR9M/dNPN4mT0fiNBuLMYJ5zu.W7THGeK9eVx7PqEIgeMo/ae', 'd81ebb28889d52d968c41c7917978a2d9312cd1fd0852fa67817ae126b990a89', '2026-01-20 10:43:07', 'Admin', '2025-01-07 03:32:44', NULL, '2026-01-20 09:43:07', 'Active', 1),
(23, 'sdfsdf@gmal.com', '$2y$10$QVgMUzOES1JGN6viM6are.GlHpV3DCfDuuVErngCHlu.K4lX5US4G', NULL, NULL, 'Agent', '2026-01-14 19:15:24', 3, '2026-01-14 19:15:24', 'Active', 1),
(24, 'pialnahidhasan3@gmail.com', '$2y$10$P1oLmXvo2Jkl/cEBHX.k8Od/v6g/zpLgbciRzXCYxSXRyluw5xgBi', NULL, NULL, 'Counselor', '2026-01-15 06:55:20', 3, '2026-01-15 06:55:20', 'Active', 1),
(25, 'isratjahan482848@gmail.com', '$2y$10$FbnmvxhZCHN2oWcBow118O3CHp0JTCdnjOKAexdH/KNsN6mv4kt.K', NULL, NULL, 'Admin', '2026-01-19 06:42:27', 3, '2026-01-19 06:42:27', 'Active', 1),
(26, 'mdmirazmahmud6@gmail.com', '$2y$10$T7TkDFmIfijy6mRj0PtRDOSU8BjVE5SlABndR.Rqkc6Mymuv3d2K.', NULL, NULL, 'Admin', '2026-01-19 06:43:07', 3, '2026-01-19 06:46:26', 'Active', 1),
(27, 'rooterarshi7144@gmail.com', '$2y$10$rkQ1nfksGniu8gcuo5MZXOuxFMyQHRvaNctf9fFzC7EWeusR0BGni', NULL, NULL, 'Counselor', '2026-01-20 07:32:46', 3, '2026-01-20 07:32:46', 'Active', 1),
(29, 'jowelranadmt@gmail.com', '$2y$10$f4NlepsCn69VvuLezq2oYu78AOyGJPtg0MxQ0rsOmcXMqx4K06r4u', NULL, NULL, 'Admin', '2026-01-20 09:23:23', 3, '2026-01-21 10:19:03', 'Active', 1),
(30, 'farjanashanta25092002@gmail.com', '$2y$10$3SEWmLABw1bDZCelDV.8q.sBtAG/zD9wEmuXgbJKxPNk117uOy/k6', NULL, NULL, 'Counselor', '2026-01-21 10:36:32', 29, '2026-01-21 10:36:32', 'Active', 1),
(31, 'naznin.gp@gmail.com', '$2y$10$jpw5HyVbvaYOpwIZWiebiuJ5kDg3zVgKmkVCfPntUxe.oPIx62ebC', NULL, NULL, 'Counselor', '2026-01-21 10:38:51', 29, '2026-01-21 10:45:52', 'Active', 1),
(32, 'na@gmail.com', '$2y$10$6X9qAcEyRFE2p2z0/QFByuQXIvgF0mQHhhxv6O3DlylsZ6CAFH2Vm', NULL, NULL, 'Agent', '2026-01-22 06:19:50', 29, '2026-01-22 06:19:50', 'Active', 1),
(33, 'dmpu@primeuniversity.ed.bd', '$2y$10$uy/irZyi7y24KjbdnbCgZeHAmn8ESswuNSNMrYTUjzzXf7vCr89UW', NULL, NULL, 'Counselor', '2026-01-23 11:51:29', 29, '2026-01-23 11:51:29', 'Active', 1),
(34, 'naimurrahman720908@gmail.com', '$2y$10$sNu58wKdCYQgI58nJBqMFeyrKgnyIZWbVxSsmNdTJCY/.WOLKOkwi', NULL, NULL, 'Agent', '2026-01-26 04:33:21', 29, '2026-01-26 04:33:21', 'Active', 1),
(35, 'tanuafrine@gmail.com', '$2y$10$/cLF77LaJWw7K8GmORWaOOzpbLa8dcz4TbEWpPJO8wSRqlroSj9e.', NULL, NULL, 'Agent', '2026-01-26 06:32:31', 29, '2026-01-26 06:32:31', 'Active', 1),
(36, '11hasib111@gmail.com', '$2y$10$u7fgHRM0d8b7wXvftg5sFexH1n4URG0h0fLwXh06ck5IF1Z9MENnC', NULL, NULL, 'Agent', '2026-01-26 09:06:45', 29, '2026-01-26 09:06:45', 'Active', 1),
(37, 'jamila.admission@primeuniversity.ac.bd', '$2y$10$JJfcPPv6m5vkkxl9nPpyC.7hFWLGAcJIDV6iA2abtATFOVIziBxZ2', NULL, NULL, 'Counselor', '2026-01-29 06:20:47', 29, '2026-01-29 07:50:27', 'Active', 1),
(38, 'saiudurnewton1@gmail.com', '$2y$10$blvE09EtXsRn0lQO0irj4.U1L3uhqMBDTw6.Muj2RVc6Qy.VZxZWy', NULL, NULL, 'Agent', '2026-01-30 07:10:00', 29, '2026-01-30 07:10:00', 'Active', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_profile`
--

CREATE TABLE `user_profile` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `profile_photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `mobile_number` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `designation` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_profile`
--

INSERT INTO `user_profile` (`id`, `user_id`, `profile_photo`, `first_name`, `last_name`, `email`, `date_of_birth`, `mobile_number`, `designation`) VALUES
(29, 3, '6783024197875_unnamed (4).jpg', 'Md. Omar', 'Faruk', 'farukdesk@gmail.com', '1996-01-17', '01926751810', 'System Adminstrator'),
(47, 23, NULL, 'Test', 'Promoter ', 'sdfsdf@gmal.com', NULL, 'asdasd', NULL),
(48, 24, NULL, 'Nahid Hasan', 'Pial', 'pialnahidhasan3@gmail.com', NULL, '01830494309', NULL),
(49, 25, '697080129f6b4_IMG_9268.JPG', 'Israt Jahan', 'Mukti', 'isratjahan482848@gmail.com', '2002-12-06', '01736365428', ''),
(50, 26, NULL, 'MD Miraz', 'Mahmud', 'mdmirazmahmud6@gmail.com', NULL, '01750811347', NULL),
(51, 27, NULL, 'Layla Farzana', 'Arshi', 'rooterarshi7144@gmail.com', NULL, '01794568344', NULL),
(53, 29, NULL, 'Md. Jowel ', 'Rana', 'jowelranadmt@gmail.com', NULL, '01955395756', NULL),
(54, 30, NULL, 'Farjana', 'Akter Shanta', 'farjanashanta25092002@gmail.com', '2002-09-25', '01315007009', ''),
(55, 31, NULL, 'Nazin', 'Nahar', 'naznin.gp@gmail.com', NULL, '01712238176', NULL),
(56, 32, NULL, 'Yeasian', 'Ahmed', 'na@gmail.com', NULL, '01318037476', NULL),
(57, 33, NULL, 'Md. Jowel ', 'Rana', 'dmpu@primeuniversity.ed.bd', NULL, '01955395756', NULL),
(58, 34, NULL, 'Naimur', 'Rahman', 'naimurrahman720908@gmail.com', NULL, '01831014008', NULL),
(59, 35, NULL, 'Sadia', 'Akter', 'tanuafrine@gmail.com', NULL, '01327415961', NULL),
(60, 36, NULL, 'Md', 'Hasibur Rahman Hasib', '11hasib111@gmail.com', NULL, '01788052661', NULL),
(61, 37, NULL, 'Jamila ', 'Khatun', 'jamila.admission@primeuniversity.ac.bd', NULL, '01687191986', NULL),
(62, 38, NULL, 'Saidur', 'Rahman Newton', 'saiudurnewton1@gmail.com', NULL, '01787727948', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agents`
--
ALTER TABLE `agents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`);

--
-- Indexes for table `call_logs`
--
ALTER TABLE `call_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_call_lead_id` (`lead_id`),
  ADD KEY `fk_call_staff_id` (`staff_id`);

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `company_name` (`company_name`),
  ADD UNIQUE KEY `contact_email` (`contact_email`),
  ADD UNIQUE KEY `system_email` (`system_email`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `company_subscriptions`
--
ALTER TABLE `company_subscriptions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `company_id` (`company_id`),
  ADD KEY `subscription_plan_id` (`subscription_plan_id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_department` (`department`),
  ADD KEY `idx_created_by` (`created_by`),
  ADD KEY `fk_courses_updated_by` (`updated_by`);

--
-- Indexes for table `leads`
--
ALTER TABLE `leads`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_leads_created_by` (`created_by`),
  ADD KEY `fk_leads_agent_id` (`agent_id`),
  ADD KEY `fk_leads_company_id` (`company_id`),
  ADD KEY `fk_leads_updated_by` (`updated_by`),
  ADD KEY `fk_leads_interested_course` (`interested_course_id`),
  ADD KEY `idx_next_followup_date` (`next_followup_date`),
  ADD KEY `idx_last_status_change` (`last_status_change_date`);

--
-- Indexes for table `lead_courses`
--
ALTER TABLE `lead_courses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_lead_course` (`lead_id`,`course_id`),
  ADD KEY `fk_lead_course_course_id` (`course_id`),
  ADD KEY `fk_lead_course_added_by` (`added_by`);

--
-- Indexes for table `lead_edit_history`
--
ALTER TABLE `lead_edit_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_lead_history_lead_id` (`lead_id`),
  ADD KEY `fk_lead_history_edited_by` (`edited_by`);

--
-- Indexes for table `lead_notes`
--
ALTER TABLE `lead_notes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_lead_notes_lead_id` (`lead_id`),
  ADD KEY `fk_lead_notes_created_by` (`created_by`);

--
-- Indexes for table `lead_semesters`
--
ALTER TABLE `lead_semesters`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_lead_intake` (`lead_id`,`semester_id`),
  ADD KEY `fk_lead_intake_intake_id` (`semester_id`),
  ADD KEY `fk_lead_intake_added_by` (`added_by`);

--
-- Indexes for table `lead_staff_assignments`
--
ALTER TABLE `lead_staff_assignments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_lead_staff` (`lead_id`,`staff_id`),
  ADD KEY `fk_assignment_staff_id` (`staff_id`),
  ADD KEY `fk_assignment_assigned_by` (`assigned_by`);

--
-- Indexes for table `lead_universities`
--
ALTER TABLE `lead_universities`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_lead_university` (`lead_id`,`university_id`),
  ADD KEY `fk_lead_university_university_id` (`university_id`),
  ADD KEY `fk_lead_university_added_by` (`added_by`);

--
-- Indexes for table `semesters`
--
ALTER TABLE `semesters`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `updated_by` (`updated_by`);

--
-- Indexes for table `subscription_payments`
--
ALTER TABLE `subscription_payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `company_subscription_id` (`company_subscription_id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `subscription_plans`
--
ALTER TABLE `subscription_plans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `universities`
--
ALTER TABLE `universities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `users_company_fk` (`company_id`);

--
-- Indexes for table `user_profile`
--
ALTER TABLE `user_profile`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `agents`
--
ALTER TABLE `agents`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `call_logs`
--
ALTER TABLE `call_logs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=333;

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `company_subscriptions`
--
ALTER TABLE `company_subscriptions`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `leads`
--
ALTER TABLE `leads`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=279;

--
-- AUTO_INCREMENT for table `lead_courses`
--
ALTER TABLE `lead_courses`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `lead_edit_history`
--
ALTER TABLE `lead_edit_history`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=830;

--
-- AUTO_INCREMENT for table `lead_notes`
--
ALTER TABLE `lead_notes`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=610;

--
-- AUTO_INCREMENT for table `lead_semesters`
--
ALTER TABLE `lead_semesters`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `lead_staff_assignments`
--
ALTER TABLE `lead_staff_assignments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=371;

--
-- AUTO_INCREMENT for table `lead_universities`
--
ALTER TABLE `lead_universities`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `semesters`
--
ALTER TABLE `semesters`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `subscription_payments`
--
ALTER TABLE `subscription_payments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subscription_plans`
--
ALTER TABLE `subscription_plans`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `universities`
--
ALTER TABLE `universities`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `user_profile`
--
ALTER TABLE `user_profile`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `agents`
--
ALTER TABLE `agents`
  ADD CONSTRAINT `fk_agents_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `call_logs`
--
ALTER TABLE `call_logs`
  ADD CONSTRAINT `fk_call_lead_id` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_call_staff_id` FOREIGN KEY (`staff_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `companies`
--
ALTER TABLE `companies`
  ADD CONSTRAINT `companies_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `company_subscriptions`
--
ALTER TABLE `company_subscriptions`
  ADD CONSTRAINT `company_subscriptions_company_fk` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `company_subscriptions_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `company_subscriptions_plan_fk` FOREIGN KEY (`subscription_plan_id`) REFERENCES `subscription_plans` (`id`);

--
-- Constraints for table `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `fk_courses_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_courses_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `leads`
--
ALTER TABLE `leads`
  ADD CONSTRAINT `fk_leads_agent_id` FOREIGN KEY (`agent_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_leads_company_id` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  ADD CONSTRAINT `fk_leads_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_leads_interested_course` FOREIGN KEY (`interested_course_id`) REFERENCES `courses` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_leads_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `lead_courses`
--
ALTER TABLE `lead_courses`
  ADD CONSTRAINT `fk_lead_course_added_by` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_lead_course_lead_id` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `lead_edit_history`
--
ALTER TABLE `lead_edit_history`
  ADD CONSTRAINT `fk_lead_history_edited_by` FOREIGN KEY (`edited_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_lead_history_lead_id` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `lead_notes`
--
ALTER TABLE `lead_notes`
  ADD CONSTRAINT `fk_lead_notes_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_lead_notes_lead_id` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `lead_semesters`
--
ALTER TABLE `lead_semesters`
  ADD CONSTRAINT `fk_lead_intake_added_by` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_lead_intake_intake_id` FOREIGN KEY (`semester_id`) REFERENCES `semesters` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_lead_intake_lead_id` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `lead_staff_assignments`
--
ALTER TABLE `lead_staff_assignments`
  ADD CONSTRAINT `fk_assignment_assigned_by` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_assignment_lead_id` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_assignment_staff_id` FOREIGN KEY (`staff_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `lead_universities`
--
ALTER TABLE `lead_universities`
  ADD CONSTRAINT `fk_lead_university_added_by` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_lead_university_lead_id` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_lead_university_university_id` FOREIGN KEY (`university_id`) REFERENCES `universities` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `semesters`
--
ALTER TABLE `semesters`
  ADD CONSTRAINT `semesters_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `semesters_ibfk_2` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `subscription_payments`
--
ALTER TABLE `subscription_payments`
  ADD CONSTRAINT `subscription_payments_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `subscription_payments_subscription_fk` FOREIGN KEY (`company_subscription_id`) REFERENCES `company_subscriptions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_company_fk` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `user_profile`
--
ALTER TABLE `user_profile`
  ADD CONSTRAINT `user_profile_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
