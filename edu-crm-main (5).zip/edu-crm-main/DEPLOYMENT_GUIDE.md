# Quick Deployment Guide - Lead Landing Page Feature

## Overview
This guide will help you deploy the Lead Landing Page feature to your production environment.

## Prerequisites
- [x] Access to production database
- [x] Access to production web server
- [x] Backup of current production database
- [x] Git repository access

## Deployment Steps

### Step 1: Backup Current System
**⚠️ CRITICAL: Always backup before making changes!**

```bash
# Backup database
mysqldump -u username -p database_name > backup_$(date +%Y%m%d_%H%M%S).sql

# Backup files (optional, since we're using Git)
tar -czf backup_files_$(date +%Y%m%d_%H%M%S).tar.gz /path/to/edu-crm/
```

### Step 2: Pull Latest Code
```bash
cd /path/to/edu-crm/
git fetch origin
git checkout copilot/add-lead-landing-page
git pull origin copilot/add-lead-landing-page
```

**Files that will be updated/created:**
- ✅ `database_migration_add_interested_course.sql` (new)
- ✅ `public-lead-form.php` (new)
- ✅ `app/models/lead_model.php` (modified)
- ✅ `app/views/lead_management_view.php` (modified)
- ✅ `app/views/partials/edit_lead_form.php` (modified)
- ✅ `app/views/partials/lead_detail.php` (modified)
- ✅ `LEAD_LANDING_PAGE_FEATURE.md` (new - documentation)
- ✅ `TESTING_PLAN.md` (new - testing guide)

### Step 3: Run Database Migration

**Option A: Using MySQL Command Line**
```bash
mysql -u username -p database_name < database_migration_add_interested_course.sql
```

**Option B: Using phpMyAdmin**
1. Log in to phpMyAdmin
2. Select your database
3. Go to SQL tab
4. Copy and paste content from `database_migration_add_interested_course.sql`
5. Click "Go"

**Verify Migration Success:**
```sql
-- Check if column was added
DESCRIBE leads;

-- Should see 'interested_course_id' column
-- Type: INT, NULL: YES, Default: NULL

-- Check foreign key
SHOW CREATE TABLE leads;

-- Should see constraint fk_leads_interested_course
```

### Step 4: Verify File Permissions
```bash
# Ensure web server can read the new public form
chmod 644 public-lead-form.php

# Ensure PHP files are readable
chmod 644 app/models/lead_model.php
chmod 644 app/views/lead_management_view.php
chmod 644 app/views/partials/*.php
```

### Step 5: Test the Deployment

**Quick Smoke Test:**
1. ✅ Access the public form: `https://yourdomain.com/public-lead-form.php`
2. ✅ Submit a test lead
3. ✅ Log into CRM and verify the lead appears
4. ✅ Verify lead has:
   - Lead Source: "Direct Online"
   - Lead Status: "Fresh"
   - Interested Course: (whatever you selected)

**Detailed Testing:**
- Follow the comprehensive testing plan in `TESTING_PLAN.md`

### Step 6: Share Public Form Link

**Get the public form URL:**
```
https://yourdomain.com/public-lead-form.php
```

**Where to share:**
- 🌐 Website homepage (add "Apply Now" button)
- 📱 Social media profiles
- 📧 Email signatures
- 📄 Marketing materials
- 🎓 Student portals

**Example HTML button for your website:**
```html
<a href="https://yourdomain.com/public-lead-form.php" 
   class="btn btn-primary btn-lg"
   target="_blank">
   Apply Now
</a>
```

## Rollback Procedure

If something goes wrong, follow these steps:

### Step 1: Restore Database
```bash
mysql -u username -p database_name < backup_YYYYMMDD_HHMMSS.sql
```

### Step 2: Revert Code
```bash
cd /path/to/edu-crm/
git checkout main  # or your previous stable branch
```

### Step 3: Verify System
- Log in and verify system works
- Check existing leads still display correctly

## Post-Deployment Monitoring

### Monitor for 24-48 Hours

**Check these metrics:**
- 📊 Number of form submissions
- ⚠️ Error logs in web server
- 🗄️ Database performance
- 📧 Any user-reported issues

**Server Log Locations (typical):**
- Apache: `/var/log/apache2/error.log`
- Nginx: `/var/log/nginx/error.log`
- PHP: Check php.ini for error_log location

**Check for errors:**
```bash
# Check recent errors in Apache log
tail -n 100 /var/log/apache2/error.log | grep -i "public-lead-form\|interested_course"

# Check PHP errors
tail -n 100 /var/log/php_errors.log | grep -i "interested_course"
```

## Troubleshooting

### Issue: Public form shows blank page
**Solution:**
- Check PHP error logs
- Verify database connection in `config/database.php`
- Check file permissions

### Issue: Form submits but lead doesn't appear
**Solution:**
- Check if database migration ran successfully
- Verify `interested_course_id` column exists
- Check error logs for SQL errors
- Verify courses exist in database

### Issue: Course dropdown is empty
**Solution:**
```sql
-- Check if courses exist
SELECT COUNT(*) FROM courses;

-- If zero, add some courses:
INSERT INTO courses (course_title, department, credit, created_by) 
VALUES ('Computer Science', 'Engineering', 4, 1);
```

### Issue: Foreign key error when deleting course
**Expected Behavior:**
- When a course is deleted, `interested_course_id` is set to NULL in related leads
- This is by design (ON DELETE SET NULL)
- Lead data is preserved

### Issue: Form is slow to load
**Solution:**
- Check number of courses in database
- Consider adding pagination or search to course dropdown
- Optimize database queries
- Enable page caching

## Configuration Options

### Customizing the Public Form

**Change university branding:**
Edit `public-lead-form.php`:
```php
// Line ~46: Change logo URL
<img src="https://your-university-logo-url.png" alt="Your University">

// Line ~47-48: Change page title
<h1>Apply to Your University</h1>
<p>Your custom message here</p>
```

**Change form styling:**
Edit CSS in `<style>` section of `public-lead-form.php` (lines ~127-177)

**Add/Remove Fields:**
Edit the form structure starting at line ~222

### Default Values

**Change default lead status:**
Currently: "Fresh"
To change, edit `app/models/lead_model.php` line ~496-499

**Change default lead source:**
Currently: "Direct Online" (hardcoded in public form)
To change, edit `public-lead-form.php` line ~69

## Support Contacts

If you encounter issues during deployment:
1. Check the documentation files in this repository
2. Review error logs
3. Contact development team
4. Create an issue in the repository

## Success Checklist

- [ ] Database backup created
- [ ] Code deployed successfully
- [ ] Database migration completed
- [ ] Public form is accessible
- [ ] Test lead submitted successfully
- [ ] Test lead visible in CRM with correct source and status
- [ ] Interested course displays correctly
- [ ] Edit form shows interested course field
- [ ] Public form link shared with stakeholders
- [ ] Monitoring set up for 24-48 hours

---

**Deployment Version:** 1.0  
**Created:** 2026-01-19  
**Estimated Time:** 15-30 minutes  
**Difficulty:** Easy to Medium
