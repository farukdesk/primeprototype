-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 15, 2026 at 12:55 AM
-- Server version: 8.0.44
-- PHP Version: 8.1.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `primeuniadmin_crm25`
--

DELIMITER $$
--
-- Functions
--
CREATE DEFINER=`primeuniadmin`@`localhost` FUNCTION `format_company_date` (`company_id` INT, `date_value` DATETIME) RETURNS VARCHAR(50) CHARSET utf8mb4 DETERMINISTIC BEGIN
    DECLARE format_string VARCHAR(20);
    
    SELECT date_format INTO format_string
    FROM companies 
    WHERE id = company_id;
    
    IF format_string IS NULL THEN
        SET format_string = 'YYYY-MM-DD';
    END IF;
    
    SET format_string = REPLACE(format_string, 'YYYY', '%Y');
    SET format_string = REPLACE(format_string, 'MM', '%m');
    SET format_string = REPLACE(format_string, 'DD', '%d');
    
    RETURN DATE_FORMAT(date_value, format_string);
END$$

CREATE DEFINER=`primeuniadmin`@`localhost` FUNCTION `get_user_full_name` (`p_user_id` INT) RETURNS VARCHAR(101) CHARSET utf8mb4 DETERMINISTIC READS SQL DATA BEGIN
    DECLARE v_full_name VARCHAR(101);
    
    SELECT CONCAT(first_name, ' ', last_name)
    INTO v_full_name
    FROM user_profile
    WHERE user_id = p_user_id;
    
    RETURN COALESCE(v_full_name, 'Unknown User');
END$$

CREATE DEFINER=`primeuniadmin`@`localhost` FUNCTION `get_user_hierarchy` (`p_user_id` INT) RETURNS TEXT CHARSET utf8mb4 DETERMINISTIC READS SQL DATA BEGIN
    DECLARE v_hierarchy TEXT;
    DECLARE v_current_id INT;
    DECLARE v_manager_name VARCHAR(101);
    
    SET v_hierarchy = '';
    SET v_current_id = p_user_id;
    
    WHILE v_current_id IS NOT NULL DO
        SELECT 
            CONCAT(up.first_name, ' ', up.last_name),
            up2.user_id
        INTO v_manager_name, v_current_id
        FROM user_profile up
        LEFT JOIN user_profile up2 ON up.reports_to = up2.user_id
        WHERE up.user_id = v_current_id;
        
        IF v_manager_name IS NOT NULL THEN
            SET v_hierarchy = CONCAT_WS(' > ', v_hierarchy, v_manager_name);
        END IF;
    END WHILE;
    
    RETURN TRIM(BOTH ' > ' FROM v_hierarchy);
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `agents`
--

CREATE TABLE `agents` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `agent_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `phone_number` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `is_our_student` tinyint(1) DEFAULT '0',
  `student_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `batch` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `department` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `call_logs`
--

CREATE TABLE `call_logs` (
  `id` int NOT NULL,
  `lead_id` int NOT NULL,
  `staff_id` int NOT NULL,
  `call_type` enum('1st call','2nd call','3rd call','Follow-up call','Office visit confirmation','Final call') COLLATE utf8mb4_unicode_ci NOT NULL,
  `previous_status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `new_status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `call_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `call_duration` int DEFAULT NULL COMMENT 'Call duration in seconds',
  `call_notes` text COLLATE utf8mb4_unicode_ci,
  `call_outcome` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `call_converted` tinyint(1) DEFAULT '0' COMMENT '1 if call led to conversion, 0 otherwise',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `id` int NOT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_first_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_last_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `website_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `system_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` enum('Active','Inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `company_name`, `contact_first_name`, `contact_last_name`, `phone_number`, `website_url`, `contact_email`, `system_email`, `address`, `logo`, `created_by`, `created_at`, `updated_at`, `status`) VALUES
(1, 'Technofic Lab LTD', 'John', 'Doe', '+1234567890', '', 'contact@testcompany.com', 'system@testcompany.com', '', '67870eee2ca73_Logo-1-1024x407 (3).png', 3, '2025-01-11 23:17:03', '2025-01-15 01:27:10', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `company_subscriptions`
--

CREATE TABLE `company_subscriptions` (
  `id` int NOT NULL,
  `company_id` int NOT NULL,
  `subscription_plan_id` int NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime DEFAULT NULL,
  `subscription_status` enum('Active','Expired','Cancelled','Suspended') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `price_paid` decimal(10,2) NOT NULL,
  `payment_status` enum('Paid','Pending','Failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `payment_method` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `notes` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `company_subscriptions`
--

INSERT INTO `company_subscriptions` (`id`, `company_id`, `subscription_plan_id`, `start_date`, `end_date`, `subscription_status`, `price_paid`, `payment_status`, `payment_method`, `transaction_id`, `created_by`, `created_at`, `updated_at`, `notes`) VALUES
(1, 1, 2, '2025-01-11 23:17:03', '2025-02-11 23:17:03', 'Active', 49.99, 'Pending', NULL, NULL, 3, '2025-01-11 23:17:03', '2025-01-11 23:17:03', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int NOT NULL,
  `course_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `department` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `credit` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `course_title`, `department`, `credit`, `created_at`, `updated_at`, `created_by`, `updated_by`) VALUES
(1, 'Introduction to Computer Science', 'Computer Science', 3, '2026-01-14 18:44:43', '2026-01-14 18:44:43', NULL, NULL),
(2, 'Data Structures and Algorithms', 'Computer Science', 4, '2026-01-14 18:44:43', '2026-01-14 18:44:43', NULL, NULL),
(3, 'Database Management Systems', 'Computer Science', 3, '2026-01-14 18:44:43', '2026-01-14 18:44:43', NULL, NULL),
(4, 'Introduction to Business', 'Business Administration', 3, '2026-01-14 18:44:43', '2026-01-14 18:44:43', NULL, NULL),
(5, 'Financial Accounting', 'Business Administration', 3, '2026-01-14 18:44:43', '2026-01-14 18:44:43', NULL, NULL),
(6, 'Marketing Principles', 'Business Administration', 3, '2026-01-14 18:44:43', '2026-01-14 18:44:43', NULL, NULL),
(7, 'Organic Chemistry', 'Chemistry', 4, '2026-01-14 18:44:43', '2026-01-14 18:44:43', NULL, NULL),
(8, 'General Physics', 'Physics', 4, '2026-01-14 18:44:43', '2026-01-14 18:44:43', NULL, NULL),
(9, 'Calculus I', 'Mathematics', 4, '2026-01-14 18:44:43', '2026-01-14 18:44:43', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `leads`
--

CREATE TABLE `leads` (
  `id` int NOT NULL,
  `first_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `current_city` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `applying_for` enum('Bachelor Degree','Master Degree') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `semester` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ssc_gpa` decimal(3,2) DEFAULT NULL,
  `hsc_gpa` decimal(3,2) DEFAULT NULL,
  `bachelor_subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bachelor_cgpa` decimal(3,2) DEFAULT NULL,
  `most_recent_degree` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gpa` decimal(3,2) DEFAULT NULL,
  `ielts_overall` decimal(2,1) DEFAULT NULL,
  `ielts_reading` decimal(2,1) DEFAULT NULL,
  `ielts_writing` decimal(2,1) DEFAULT NULL,
  `ielts_speaking` decimal(2,1) DEFAULT NULL,
  `ielts_listening` decimal(2,1) DEFAULT NULL,
  `country_applying_from` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nationality` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `budget` decimal(10,2) DEFAULT NULL,
  `lead_source` enum('Direct Online','Direct Office Visit','Agent') COLLATE utf8mb4_unicode_ci NOT NULL,
  `assigned_campus` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lead_status` enum('Fresh','1st call','2nd call','3rd call','Unable to reach once','Unable to reach twice','Unable to reach trice','Dead','Will visit office','Lead converted to Applicant') COLLATE utf8mb4_unicode_ci DEFAULT 'Fresh',
  `campus_visit_date` datetime DEFAULT NULL,
  `campus_visit_attended_at` datetime DEFAULT NULL,
  `attended_at` timestamp NULL DEFAULT NULL COMMENT 'When the lead attended their office visit',
  `created_by` int NOT NULL,
  `updated_by` int DEFAULT NULL COMMENT 'User ID who last updated this lead',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `agent_id` int DEFAULT NULL,
  `company_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lead_courses`
--

CREATE TABLE `lead_courses` (
  `id` int NOT NULL,
  `lead_id` int NOT NULL,
  `course_id` int NOT NULL,
  `added_by` int NOT NULL,
  `added_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lead_edit_history`
--

CREATE TABLE `lead_edit_history` (
  `id` int NOT NULL,
  `lead_id` int NOT NULL,
  `field_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `old_value` text COLLATE utf8mb4_unicode_ci,
  `new_value` text COLLATE utf8mb4_unicode_ci,
  `edited_by` int NOT NULL,
  `edited_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lead_notes`
--

CREATE TABLE `lead_notes` (
  `id` int NOT NULL,
  `lead_id` int NOT NULL,
  `note_text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lead_semesters`
--

CREATE TABLE `lead_semesters` (
  `id` int NOT NULL,
  `lead_id` int NOT NULL,
  `semester_id` int NOT NULL,
  `added_by` int NOT NULL,
  `added_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lead_staff_assignments`
--

CREATE TABLE `lead_staff_assignments` (
  `id` int NOT NULL,
  `lead_id` int NOT NULL,
  `staff_id` int NOT NULL,
  `assigned_by` int NOT NULL,
  `assigned_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lead_universities`
--

CREATE TABLE `lead_universities` (
  `id` int NOT NULL,
  `lead_id` int NOT NULL,
  `university_id` int NOT NULL,
  `added_by` int NOT NULL,
  `added_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `semesters`
--

CREATE TABLE `semesters` (
  `id` int NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` enum('Active','Inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `semesters`
--

INSERT INTO `semesters` (`id`, `name`, `start_date`, `end_date`, `status`, `created_at`, `updated_at`, `created_by`, `updated_by`) VALUES
(1, 'January 2025', '2025-01-01', NULL, 'Active', '2025-04-29 20:32:09', '2025-04-29 20:32:09', NULL, NULL),
(2, 'Spring 2026', '2026-05-01', '2026-01-29', 'Active', '2026-01-14 08:44:45', '2026-01-14 08:44:45', 3, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subscription_payments`
--

CREATE TABLE `subscription_payments` (
  `id` int NOT NULL,
  `company_subscription_id` int NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_date` datetime NOT NULL,
  `payment_method` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` enum('Success','Pending','Failed') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `notes` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subscription_plans`
--

CREATE TABLE `subscription_plans` (
  `id` int NOT NULL,
  `plan_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `plan_type` enum('Monthly','Yearly','Lifetime') COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `features` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` enum('Active','Inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subscription_plans`
--

INSERT INTO `subscription_plans` (`id`, `plan_name`, `plan_type`, `price`, `description`, `features`, `created_at`, `updated_at`, `status`) VALUES
(2, 'Monthly', 'Monthly', 99.95, 'Professional plan with advanced features', '[\"Unlimited Staff Accounts\",\"Unlimited Students\",\"Unlimited agent Accounts\"]', '2025-01-11 23:13:36', '2025-01-16 00:14:03', 'Active'),
(59, 'Yearly', 'Yearly', 895.00, 'Unlimited', '[\"Unlimited\"]', '2025-01-16 00:15:11', '2025-01-16 00:15:11', 'Active'),
(60, 'Lifetime Deal', 'Lifetime', 3995.00, 'Unlimited', '[\"Unlimited d\"]', '2025-01-16 00:16:30', '2025-02-12 17:09:02', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `universities`
--

CREATE TABLE `universities` (
  `id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `website` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('Active','Inactive') COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reset_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reset_token_expiry` datetime DEFAULT NULL,
  `user_type` enum('Super Admin','Admin','Manager','Counselor','Agent') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `account_status` enum('Active','Deactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `company_id` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `reset_token`, `reset_token_expiry`, `user_type`, `created_at`, `created_by`, `updated_at`, `account_status`, `company_id`) VALUES
(3, 'farukdesk@gmail.com', '$2y$10$tzeTwR9M/dNPN4mT0fiNBuLMYJ5zu.W7THGeK9eVx7PqEIgeMo/ae', '7019016082b37105cd52ad7df4df37c87e39c33cc9531f43a215258911269f1d', '2025-01-12 01:24:09', 'Super Admin', '2025-01-07 03:32:44', NULL, '2025-01-12 04:13:42', 'Active', 1),
(6, 'admin1@example.com', '$2y$10$ZD3e8FSrYKu1MTfQwYxpF.r5sVkr93RDNTIrWoM1bbjLK1nZzbgOi', NULL, NULL, 'Admin', '2025-04-30 00:38:05', 3, '2025-04-30 00:38:05', 'Active', 1),
(7, 'admin2@example.com', '$2y$10$ZD3e8FSrYKu1MTfQwYxpF.r5sVkr93RDNTIrWoM1bbjLK1nZzbgOi', NULL, NULL, 'Admin', '2025-04-30 00:38:05', 3, '2025-04-30 00:38:05', 'Deactive', 1),
(8, 'manager1@example.com', '$2y$10$ZD3e8FSrYKu1MTfQwYxpF.r5sVkr93RDNTIrWoM1bbjLK1nZzbgOi', NULL, NULL, 'Manager', '2025-04-30 00:38:05', 3, '2025-04-30 00:38:05', 'Active', 1),
(9, 'manager2@example.com', '$2y$10$ZD3e8FSrYKu1MTfQwYxpF.r5sVkr93RDNTIrWoM1bbjLK1nZzbgOi', NULL, NULL, 'Manager', '2025-04-30 00:38:05', 3, '2025-04-30 00:38:05', 'Active', 1),
(10, 'manager3@example.com', '$2y$10$ZD3e8FSrYKu1MTfQwYxpF.r5sVkr93RDNTIrWoM1bbjLK1nZzbgOi', NULL, NULL, 'Manager', '2025-04-30 00:38:05', 3, '2025-04-30 00:38:05', 'Deactive', 1),
(11, 'staff1@example.com', '$2y$10$tzeTwR9M/dNPN4mT0fiNBuLMYJ5zu.W7THGeK9eVx7PqEIgeMo/ae', NULL, NULL, 'Counselor', '2025-04-30 00:38:05', 3, '2025-04-30 00:40:57', 'Active', 1),
(12, 'staff2@example.com', '$2y$10$ZD3e8FSrYKu1MTfQwYxpF.r5sVkr93RDNTIrWoM1bbjLK1nZzbgOi', NULL, NULL, 'Counselor', '2025-04-30 00:38:05', 3, '2025-04-30 00:38:05', 'Active', 1),
(13, 'staff3@example.com', '$2y$10$tzeTwR9M/dNPN4mT0fiNBuLMYJ5zu.W7THGeK9eVx7PqEIgeMo/ae', NULL, NULL, 'Counselor', '2025-04-30 00:38:05', 3, '2025-05-05 06:40:06', 'Active', 1),
(14, 'staff4@example.com', '$2y$10$ZD3e8FSrYKu1MTfQwYxpF.r5sVkr93RDNTIrWoM1bbjLK1nZzbgOi', NULL, NULL, 'Counselor', '2025-04-30 00:38:05', 3, '2025-04-30 00:38:05', 'Deactive', 1),
(15, 'agent1@example.com', '$2y$10$ZD3e8FSrYKu1MTfQwYxpF.r5sVkr93RDNTIrWoM1bbjLK1nZzbgOi', NULL, NULL, 'Agent', '2025-04-30 00:38:05', 3, '2025-04-30 00:38:05', 'Active', 1),
(16, 'agent2@example.com', '$2y$10$ZD3e8FSrYKu1MTfQwYxpF.r5sVkr93RDNTIrWoM1bbjLK1nZzbgOi', NULL, NULL, 'Agent', '2025-04-30 00:38:05', 3, '2025-04-30 00:38:05', 'Active', 1),
(18, 'agent4@example.com', '$2y$10$ZD3e8FSrYKu1MTfQwYxpF.r5sVkr93RDNTIrWoM1bbjLK1nZzbgOi', NULL, NULL, 'Agent', '2025-04-30 00:38:05', 3, '2025-04-30 00:38:05', 'Deactive', 1),
(19, 'agent5@example.com', '$2y$10$ZD3e8FSrYKu1MTfQwYxpF.r5sVkr93RDNTIrWoM1bbjLK1nZzbgOi', NULL, NULL, 'Agent', '2025-04-30 00:38:05', 3, '2025-04-30 00:38:05', 'Active', 1),
(20, 'Mirajasdfasfd@gmidsaf.com', '$2y$10$OXJ9KCvl4EkAuKK1iNt5GuMw8HpffbLsldBYztukIOFf6ODmndw.e', NULL, NULL, 'Agent', '2026-01-14 09:15:26', 3, '2026-01-14 09:15:26', 'Active', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_profile`
--

CREATE TABLE `user_profile` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `profile_photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `mobile_number` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `designation` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_profile`
--

INSERT INTO `user_profile` (`id`, `user_id`, `profile_photo`, `first_name`, `last_name`, `email`, `date_of_birth`, `mobile_number`, `designation`) VALUES
(29, 3, '6783024197875_unnamed (4).jpg', 'Md. Omar', 'Faruk', '', '1996-01-17', '01926751810', 'System Adminstrator'),
(30, 6, 'admin1_avatar.jpg', 'Sarah', 'Johnson', 'admin1@example.com', '1985-03-15', '01712345678', 'Administrative Director'),
(31, 7, 'admin2_avatar.jpg', 'Michael', 'Chen', 'admin2@example.com', '1988-07-22', '01898765432', 'IT Administrator'),
(32, 8, 'manager1_avatar.jpg', 'Lisa', 'Patel', 'manager1@example.com', '1990-05-12', '01611223344', 'Project Manager'),
(33, 9, 'manager2_avatar.jpg', 'David', 'Wilson', 'manager2@example.com', '1982-11-30', '01755667788', 'Operations Manager'),
(34, 10, 'manager3_avatar.jpg', 'Emily', 'Garcia', 'manager3@example.com', '1987-08-19', '01944556677', 'Sales Manager'),
(35, 11, 'staff1_avatar.jpg', 'James', 'Taylor', 'staff1@example.com', '1992-02-28', '01833445566', 'Senior counselor'),
(36, 12, 'staff2_avatar.jpg', 'Sophia', 'Kim', 'staff2@example.com', '1991-09-17', '01722334455', 'Senior counselor'),
(37, 13, '68185dce7a042_omar-shalaby.jpg', 'Omar', 'Hassan', 'staff3@example.com', '1995-04-05', '01688990011', 'Senior counselor'),
(38, 14, 'staff4_avatar.jpg', 'Priya', 'Sharma', 'staff4@example.com', '1989-12-10', '01911223344', 'Senior counselor'),
(39, 15, 'agent1_avatar.jpg', 'Ahmed', 'Khan', 'agent1@example.com', '1993-10-08', '01822334455', 'Sales Agent'),
(40, 16, 'agent2_avatar.jpg', 'Jessica', 'Lee', 'agent2@example.com', '1994-06-24', '01766778899', 'Customer Support Agent'),
(42, 18, 'agent4_avatar.jpg', 'Maria', 'Lopez', 'agent4@example.com', '1988-07-03', '01955667788', 'Account Representative'),
(43, 19, 'agent5_avatar.jpg', 'Daniel', 'Nguyen', 'agent5@example.com', '1996-11-20', '01877889900', 'Service Agent'),
(44, 20, NULL, 'Miraj', '', 'Mirajasdfasfd@gmidsaf.com', NULL, '01555555', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agents`
--
ALTER TABLE `agents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`);

--
-- Indexes for table `call_logs`
--
ALTER TABLE `call_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_call_lead_id` (`lead_id`),
  ADD KEY `fk_call_staff_id` (`staff_id`);

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `company_name` (`company_name`),
  ADD UNIQUE KEY `contact_email` (`contact_email`),
  ADD UNIQUE KEY `system_email` (`system_email`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `company_subscriptions`
--
ALTER TABLE `company_subscriptions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `company_id` (`company_id`),
  ADD KEY `subscription_plan_id` (`subscription_plan_id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_department` (`department`),
  ADD KEY `idx_created_by` (`created_by`),
  ADD KEY `fk_courses_updated_by` (`updated_by`);

--
-- Indexes for table `leads`
--
ALTER TABLE `leads`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_leads_created_by` (`created_by`),
  ADD KEY `fk_leads_agent_id` (`agent_id`),
  ADD KEY `fk_leads_company_id` (`company_id`),
  ADD KEY `fk_leads_updated_by` (`updated_by`);

--
-- Indexes for table `lead_courses`
--
ALTER TABLE `lead_courses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_lead_course` (`lead_id`,`course_id`),
  ADD KEY `fk_lead_course_course_id` (`course_id`),
  ADD KEY `fk_lead_course_added_by` (`added_by`);

--
-- Indexes for table `lead_edit_history`
--
ALTER TABLE `lead_edit_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_lead_history_lead_id` (`lead_id`),
  ADD KEY `fk_lead_history_edited_by` (`edited_by`);

--
-- Indexes for table `lead_notes`
--
ALTER TABLE `lead_notes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_lead_notes_lead_id` (`lead_id`),
  ADD KEY `fk_lead_notes_created_by` (`created_by`);

--
-- Indexes for table `lead_semesters`
--
ALTER TABLE `lead_semesters`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_lead_intake` (`lead_id`,`semester_id`),
  ADD KEY `fk_lead_intake_intake_id` (`semester_id`),
  ADD KEY `fk_lead_intake_added_by` (`added_by`);

--
-- Indexes for table `lead_staff_assignments`
--
ALTER TABLE `lead_staff_assignments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_lead_staff` (`lead_id`,`staff_id`),
  ADD KEY `fk_assignment_staff_id` (`staff_id`),
  ADD KEY `fk_assignment_assigned_by` (`assigned_by`);

--
-- Indexes for table `lead_universities`
--
ALTER TABLE `lead_universities`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_lead_university` (`lead_id`,`university_id`),
  ADD KEY `fk_lead_university_university_id` (`university_id`),
  ADD KEY `fk_lead_university_added_by` (`added_by`);

--
-- Indexes for table `semesters`
--
ALTER TABLE `semesters`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `updated_by` (`updated_by`);

--
-- Indexes for table `subscription_payments`
--
ALTER TABLE `subscription_payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `company_subscription_id` (`company_subscription_id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `subscription_plans`
--
ALTER TABLE `subscription_plans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `universities`
--
ALTER TABLE `universities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `users_company_fk` (`company_id`);

--
-- Indexes for table `user_profile`
--
ALTER TABLE `user_profile`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `agents`
--
ALTER TABLE `agents`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `call_logs`
--
ALTER TABLE `call_logs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `company_subscriptions`
--
ALTER TABLE `company_subscriptions`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `leads`
--
ALTER TABLE `leads`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `lead_courses`
--
ALTER TABLE `lead_courses`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `lead_edit_history`
--
ALTER TABLE `lead_edit_history`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `lead_notes`
--
ALTER TABLE `lead_notes`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `lead_semesters`
--
ALTER TABLE `lead_semesters`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `lead_staff_assignments`
--
ALTER TABLE `lead_staff_assignments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `lead_universities`
--
ALTER TABLE `lead_universities`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `semesters`
--
ALTER TABLE `semesters`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `subscription_payments`
--
ALTER TABLE `subscription_payments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subscription_plans`
--
ALTER TABLE `subscription_plans`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `universities`
--
ALTER TABLE `universities`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `user_profile`
--
ALTER TABLE `user_profile`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `agents`
--
ALTER TABLE `agents`
  ADD CONSTRAINT `fk_agents_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `call_logs`
--
ALTER TABLE `call_logs`
  ADD CONSTRAINT `fk_call_lead_id` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_call_staff_id` FOREIGN KEY (`staff_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `companies`
--
ALTER TABLE `companies`
  ADD CONSTRAINT `companies_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `company_subscriptions`
--
ALTER TABLE `company_subscriptions`
  ADD CONSTRAINT `company_subscriptions_company_fk` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `company_subscriptions_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `company_subscriptions_plan_fk` FOREIGN KEY (`subscription_plan_id`) REFERENCES `subscription_plans` (`id`);

--
-- Constraints for table `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `fk_courses_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_courses_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `leads`
--
ALTER TABLE `leads`
  ADD CONSTRAINT `fk_leads_agent_id` FOREIGN KEY (`agent_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_leads_company_id` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  ADD CONSTRAINT `fk_leads_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_leads_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `lead_courses`
--
ALTER TABLE `lead_courses`
  ADD CONSTRAINT `fk_lead_course_added_by` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_lead_course_lead_id` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `lead_edit_history`
--
ALTER TABLE `lead_edit_history`
  ADD CONSTRAINT `fk_lead_history_edited_by` FOREIGN KEY (`edited_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_lead_history_lead_id` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `lead_notes`
--
ALTER TABLE `lead_notes`
  ADD CONSTRAINT `fk_lead_notes_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_lead_notes_lead_id` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `lead_semesters`
--
ALTER TABLE `lead_semesters`
  ADD CONSTRAINT `fk_lead_intake_added_by` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_lead_intake_intake_id` FOREIGN KEY (`semester_id`) REFERENCES `semesters` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_lead_intake_lead_id` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `lead_staff_assignments`
--
ALTER TABLE `lead_staff_assignments`
  ADD CONSTRAINT `fk_assignment_assigned_by` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_assignment_lead_id` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_assignment_staff_id` FOREIGN KEY (`staff_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `lead_universities`
--
ALTER TABLE `lead_universities`
  ADD CONSTRAINT `fk_lead_university_added_by` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_lead_university_lead_id` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_lead_university_university_id` FOREIGN KEY (`university_id`) REFERENCES `universities` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `semesters`
--
ALTER TABLE `semesters`
  ADD CONSTRAINT `semesters_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `semesters_ibfk_2` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `subscription_payments`
--
ALTER TABLE `subscription_payments`
  ADD CONSTRAINT `subscription_payments_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `subscription_payments_subscription_fk` FOREIGN KEY (`company_subscription_id`) REFERENCES `company_subscriptions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_company_fk` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `user_profile`
--
ALTER TABLE `user_profile`
  ADD CONSTRAINT `user_profile_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
